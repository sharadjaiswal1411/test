

export const environment = {
  production: true, 
  apiUrl:"http://13.127.199.234:5000/" 
};


