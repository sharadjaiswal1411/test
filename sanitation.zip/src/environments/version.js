// IMPORTANT: THIS FILE IS AUTO GENERATED! DO NOT MANUALLY EDIT OR CHECKIN!
/* tslint:disable */
export const VERSION = {
    "dirty": true,
    "raw": "30374842-dirty",
    "hash": "30374842",
    "distance": null,
    "tag": null,
    "semver": null,
    "suffix": "30374842-dirty",
    "semverString": null,
    "version": "0.0.15"
};
/* tslint:enable */