export const firebaseConfig = {
    apiKey: 'AIzaSyAHMkYkbjRTa9RazdKPJjtOJrdHCZVxxYg',
    databaseURL: 'https://ecogreen-citizen-app-2ad05.firebaseio.com/',
    storageBucket: 'ecogreen-citizen-app.appspot.com',
    projectId:'ecogreen-citizen-app'
  };