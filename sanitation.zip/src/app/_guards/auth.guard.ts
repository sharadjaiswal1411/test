﻿
import { Injectable } from '@angular/core';

import { Router, CanActivate, ActivatedRouteSnapshot, } from '@angular/router';
import { AuthService } from '../_services/index';
@Injectable()
export class AuthGuard implements CanActivate {

  constructor(public auth: AuthService, private router: Router) { }
  public default:any
  getDefaultroute(permissions){
    if(permissions){
      var match = permissions.split('.');
      var path =   match[0] 
      var ret = false;
      var per = this.auth.permissionJson();
      var val = this.findDefault(per, path);
      if(val){
        return '/'+ val;
      }else{
        return '/login'
      }    
      
    }else{
      
    }
       
  }

  findDefault(obj, prop) {
    return obj[prop].default;
}
  canActivate(route: ActivatedRouteSnapshot): boolean {
    // if (localStorage.getItem('userCode') && localStorage.getItem('userName')) {
    //     return true
    // }else{
    //   this.router.navigate(['/login'])
    //   return false;
    // }
    const permission = route.data.permission;
    // const token = localStorage.getItem('token');
    // // decode the token to get its payload
    // const tokenPayload = decode(token);
    // this.default = this.getDefaultroute(permission)
    // if(permission && this.default){
    //   this.router.navigate(['/home/maptracker/khatta']);
    //   return false;
    // }else{
    //   this.router.navigate(['/login'])
    //   return false;
    // }
    
    if (!this.auth.userHasPermission(permission)) {
         this.router.navigate([this.getDefaultroute(permission)]);
         return false;
    }
    return true;
  }
}
