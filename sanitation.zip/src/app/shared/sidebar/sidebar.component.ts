import { Component, OnInit } from '@angular/core';
import { HasPermissionDirective} from '../../_directives';
declare const $: any;
declare interface RouteInfo {
    path: string;
    title: string;
    icon: string;
    permission:string;
}
export const ROUTES: RouteInfo[] = [
    { path: 'dashboard', title: 'Dashboard',  icon: '/assets/img/dashboard.png', permission:'dashboard.active'},
    { path: 'alarm', title: 'Alarm',  icon: '/assets/img/alarm-clock.png' ,permission:'alarm.active'},
    { path: 'maptracker', title: 'Maptracker',  icon: '/assets/img/maptracker.png' ,permission:'maptracker.active.active'},
    { path: 'admin', title: 'Admin',  icon: '/assets/img/admin.png', permission:'admin.active' },  
    { path: 'reports', title: 'Reports',  icon: '/assets/img/reports.png' ,permission:'reports.active'},
    { path: 'crm', title: 'CRM',  icon: '/assets/img/crm.png', permission:'crm.active'},
    { path: 'superAdmin', title: 'Super Admin',  icon: '/assets/img/superadmin.png',permission:'superAdmin.active'},
    { path: 'maintenance', title: 'Maintenance', icon: '/assets/img/maintenance.png', permission:'maintenance.active'}, 
    { path: 'mobility', title: 'Mobility',  icon: '/assets/img/mobility.png',permission:'mobility.active'},
];

@Component({
  selector: 'app-sidebar',
  templateUrl: './sidebar.component.html',
  providers: [ HasPermissionDirective ],
})
export class SidebarComponent implements OnInit {
  menuItems: any[];

  constructor() { }

  ngOnInit() {
    this.menuItems = ROUTES.filter(menuItem => menuItem);
  }
  isMobileMenu() {
      if ($(window).width() > 600) {
          return false;
      }
      return true;
  };
}
