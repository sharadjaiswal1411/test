import { Component, ElementRef } from '@angular/core';

import {Location} from '@angular/common';
import { Router, ActivatedRoute } from '@angular/router';

import { Http } from '@angular/http'

import { AuthService } from '../../_services/index';
import { Broadcaster } from '../../../environments/broadcaster';

import { environment } from '../../../environments/environment';
import { VERSION } from '../../../environments/version';

declare var $: any;
@Component({
    selector: 'navbar-cmp',
    templateUrl: 'navbar.component.html'
})

export class NavbarComponent {
    userId:any;
    version = VERSION;
    projectMaster:any
    selectedValue:any
    userName:any
    location: Location;
    private toggleButton: any;
    private sidebarVisible: boolean;
    public currentDatabase:any;
    public mode:any;
    selctedProjectName:any;
    oldPassModal:any;
    newPassModal:any;
    confirmPassModal:any;
    responceMsg:any;
    passChangeSuccess=false;
    passChangeError=false;
    constructor(private auth:AuthService,private http: Http,location: Location,  private element: ElementRef, private router: Router,private broadcaster: Broadcaster,private route: ActivatedRoute) {
        this.location = location;
        this.sidebarVisible = false;
    }

    logOut(){
       localStorage.removeItem("authData");
       localStorage.removeItem("projectId");
       this.router.navigate(['/login']);
    }
    selectedProject(data){
        this.selctedProjectName  = data.PRJNAME
        localStorage.setItem("projectId", data.ID);
        window.location.reload();
        //this.broadcaster.broadcast('globalCountUpdate', project);
        //console.log(this.router.url)
        //this.router.navigated = false;
        //this.router.navigate([this.router.url],{ replaceUrl: true });
    }
    sidebarOpen() {
        const toggleButton = this.toggleButton;
        const body = document.getElementsByTagName('body')[0];
        setTimeout(function(){
            toggleButton.classList.add('toggled');
        }, 500);
        body.classList.add('nav-open');

        this.sidebarVisible = true;
    };
    sidebarClose() {
        const body = document.getElementsByTagName('body')[0];
        this.toggleButton.classList.remove('toggled');
        this.sidebarVisible = false;
        body.classList.remove('nav-open');
    };
    sidebarToggle() {
        // const toggleButton = this.toggleButton;
        // const body = document.getElementsByTagName('body')[0];
        if (this.sidebarVisible === false) {
            this.sidebarOpen();
        } else {
            this.sidebarClose();
        }
    };

    getVersion(){
        this.http.get(environment.apiUrl + 'getVersion').subscribe(response => {
            if(response){
            alert(this.version.version);
                if(this.version.version == response.json()[0].version){
                   
                }else{
                   
                    $('#Version_Modal').modal('show')
                }
            }
        })
    }

    reloadPage(){
        location.reload(true);
    }
    getCurrentDatabase(){
        this.http.get(environment.apiUrl + 'getCurrentDatabase').subscribe(response => {
            if(response){
                var currentDatabase = response.json()[0].CurrentDatabase
                  if(currentDatabase == "ECOCLEANDEV"){
                     this.currentDatabase = "DEVELOPMENT"
                     this.mode = " ( " + "DEVELOPMENT DATABASE" + ")"
                  }else if(currentDatabase == "ECOCLEANQA"){
                    this.currentDatabase = "QA"
                    this.mode = " ( " + "QA DATABASE" + ")"
                  }else{
                    this.mode = null
                  }
                console.log( this.currentDatabase)
            }
        })
    }

    getProjectNameById(projectMaster,id){
        for(var i = 0;i<projectMaster.length;i++){
            if(projectMaster[i].ID == id ){
                return projectMaster[i].PRJNAME
            }
        }
    }

     /*
     * Open Modal popup windows for change login password
     */ 
    changePasswordModal(data){ 
        $("#changeUserPassModal").modal("show"); 
        this.oldPassModal=null;
        this.newPassModal=null;
        this.confirmPassModal=null;
        this.passChangeSuccess=false;
        this.passChangeError=false;
    }

    /*
     * Change Login password
     */ 
    changePassword(){
        if(!this.oldPassModal){
            alert("Old password is required!")
            return;
        }else if(!this.newPassModal){
            alert("New password is required!")
            return;
        }else if(!this.confirmPassModal){
            alert("Confirm password is required!")
            return;
        }else if(this.newPassModal!=this.confirmPassModal){
            alert("New password and Confirm password not match")
            return;
        }
        var dataJson={
            userId:this.userId,
            oldPassword:this.oldPassModal.trim(),
            newPassword:this.newPassModal.trim()
        }
        this.http.post(environment.apiUrl + 'changeLoginPassword',dataJson).subscribe(response => {
            if(response){
                var changeStatus = response.json()  
                var resMsg=changeStatus.output[0].msg  
                if(changeStatus.output[1].error_code=="200"){
                    this.responceMsg=resMsg
                    this.passChangeSuccess=true;
                    this.oldPassModal=null;
                    this.newPassModal=null;
                    this.confirmPassModal=null;
                    setTimeout(()=>{  
                        this.passChangeSuccess=false;
                        $("#changeUserPassModal").modal("hide"); 
                        this.logOut();
                       },2000);  
                }else{
                    this.responceMsg=resMsg
                    this.passChangeError=true;
                    this.passChangeSuccess=false;
                } 
            }
        })
    }
    




    ngOnInit() {
        $('[data-toggle="tooltip"]').tooltip();   
        this.projectMaster = this.auth.getActiveProjects()
        console.log(this.projectMaster)
        this.getVersion();
        this.selctedProjectName = this.getProjectNameById(this.projectMaster,Number(localStorage.getItem("projectId")))
        this.userName = this.auth.getAuthentication().userName 
        this.userId=this.auth.getAuthentication().id
        const navbar: HTMLElement = this.element.nativeElement;
        this.toggleButton = navbar.getElementsByClassName('navbar-toggle')[0];
        this.getCurrentDatabase(); 
    }
}
