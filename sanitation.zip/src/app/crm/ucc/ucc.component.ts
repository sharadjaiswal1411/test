
import { Component } from '@angular/core'; 
@Component({ 
    selector: 'crm-ucc',
    templateUrl: './ucc.component.html',  
  })
export class CrmUccComponent{ 
}