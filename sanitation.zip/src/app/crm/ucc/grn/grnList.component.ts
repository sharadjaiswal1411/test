import { Component } from '@angular/core';
import { Http } from '@angular/http'
import { environment } from '../../../../environments/environment';
import { Observable } from 'rxjs/Observable'; 
import { AuthService } from '../../../_services/index';
import * as _ from 'underscore'; 
import { LoaderService } from '../../../_services/loader.service';
import * as _moment from 'moment';
import * as _rollupMoment from 'moment'; 
//For KENDO UI
import { process, State,aggregateBy  } from '@progress/kendo-data-query';
import { GroupDescriptor, DataResult } from '@progress/kendo-data-query';
import {GridDataResult,DataStateChangeEvent} from '@progress/kendo-angular-grid';
import { ExcelExportData } from '@progress/kendo-angular-excel-export'; 
import { Broadcaster } from '../../../../environments/broadcaster';

import { utils, write, WorkBook } from 'xlsx';  
import { saveAs } from 'file-saver';  
const moment = _rollupMoment || _moment;

declare var $: any;  
const distinctDeno = data => data.filter((x, idx, xs) => xs.findIndex(y => y.Denomination === x.Denomination) === idx); 
@Component({
    selector: 'grnList-cmp',
    templateUrl: './grnList.component.html' ,
  })

  export class GrnComponent {   
  public prjId:any;
  public userId:any; 
  public uccGrnList:any;
  public showLoader:boolean;
  public defStartDt:any;
  public defEndDate:any;
  public startDate:any;
  public endDate:any; 
  public groups: GroupDescriptor[] = [];
  public view: Observable<GridDataResult>;
  public gridView: DataResult;
  public gridDataUccGrn: GridDataResult 
  public uccGrnDataList:any;
  public grnDate:any;
  public denoList:any;
  public grnInventoryList=[]; 
  public grnInventoryUpdtList=[]; 
  public denoModel:any;
  public serialCode:any; 
  public firstSrNoModal:any;
  public startSrNoModal:any;
  public firstSrNoRequired=false;
  public empDetailsList:any;
  public toEnpId:any;
  public toEmpRoleId:any;
  endSrNoModal:any;
  amountModal:any;
  countModal:any; 
  success=false;
  error=false;
  isSaveActive=true;
  denoIsRequired=false;
  uccRoleCode:any;
  dataRangeModal:any;
  couponSeriesId:any;
  totalCount:any;
  totalAmount:any;
  public responceMessage:any;
  bookleNoInvalid=false;
  limitOverMsg=false;
  isAddBtnActive=false;
  invalidBookletNo=false;
  rowCount:any;
  rowDataAmount:any; 
  deleteResMsg:any;
  delSuccess=false;
  delError=false;
  grnId:any;
  jsonDataResult:any;
  isexcelDisable=false;
  public statusObject:any
  bookletNo:any;
  bookletDetail:any;
  public aggregates: any[] = [{field: 'Qty', aggregate: 'sum'},{field: 'Amount', aggregate: 'sum'}];
  public state: State = {
    skip: 0,
    take: 12, 
    filter: {
      logic: 'and',
      filters: []
    }
  };
  public distinctDeno: any[]
  public allData(): ExcelExportData {
    const result: ExcelExportData =  {
        data: this.uccGrnDataList
    };
    return result;
   } 
 
  public groupChange(groups: GroupDescriptor[]): void {
    this.groups = groups;
    this.loadProducts();
  } 
  private loadProducts(): void {
    this.gridDataUccGrn = process(this.uccGrnList, { group: this.groups });  
  } 

    constructor(private http: Http,private auth : AuthService,private loaderService: LoaderService,private broadcaster: Broadcaster){ 
        this.loaderService.status.subscribe((val: boolean) =>{
          this.showLoader = val;
        }); 
        this.allData = this.allData.bind(this);
        var date = new Date();
        this.grnDate=date
        this.rowCount=0;
        this.rowDataAmount=0;
        var firstDay = new Date(date.getFullYear(), date.getMonth(), 1);
        var lastDay = new Date(date.getFullYear(), date.getMonth() + 1, 0); 
        this.defStartDt = (firstDay.getFullYear()) + '-' + (firstDay.getMonth() + 1) + '-' + firstDay.getDate(); 
        this.defEndDate = (lastDay.getFullYear()) + '-' + (lastDay.getMonth() + 1) + '-' + lastDay.getDate();
        this.dataRangeModal= {beginDate: {year: date.getFullYear(), month: date.getMonth()+1, day: date.getDate()}, endDate: {year: date.getFullYear(), month: date.getMonth()+1, day: date.getDate()}};  
     }    
     
    /*
    * Get GRN INVENTORY LIST
    */  
    getUccGrnInventoryList(){ 
    this.loaderService.display(true); 
    var sourceFrom="GRN"
    this.http.get(environment.apiUrl + 'uccnew/getUccGrnList?prjId='+this.prjId+'&userId='+this.userId+'&startDt='+this.startDate+'&endDt='+this.endDate+'&sourceFrom='+sourceFrom).subscribe(data =>{ 
             this.uccGrnDataList= data.json(); 
             if(this.uccGrnDataList.length>0){  
              this.distinctDeno=distinctDeno(this.uccGrnDataList)  
              this.totalCount = aggregateBy(this.uccGrnDataList, this.aggregates)["Qty"].sum;  
              this.totalAmount = aggregateBy(this.uccGrnDataList, this.aggregates)["Amount"].sum;  
              this.gridDataUccGrn=process(this.uccGrnDataList, this.state); 
              this.loaderService.display(false);
             }
             else if(this.uccGrnDataList.length==0){ 
               this.loaderService.display(false); 
               this.totalCount = 0;
              this.totalAmount = 0 ;
              this.gridDataUccGrn=null;
             }
        });
      }


/*
 * filter The Grid Data
*/
  public dataStateChange(state: DataStateChangeEvent): void {
    this.state = state;
    this.gridDataUccGrn=process(this.uccGrnDataList, this.state); 
    if (state && state.group) {
      state.group.map(group => group.aggregates = this.aggregates);  
      this.distinctDeno=distinctDeno(this.uccGrnDataList) 
      this.totalCount = aggregateBy(this.gridDataUccGrn.data, this.aggregates)["Qty"].sum;  
      this.totalAmount = aggregateBy(this.gridDataUccGrn.data, this.aggregates)["Amount"].sum;   
      this.gridDataUccGrn=process(this.uccGrnDataList, this.state); 
      } 
  } 

  /*
*select start Date Nad To date
*/
 onDateRangeChanged(dataRange)
 {  
   if(dataRange.beginDate.day>0){ 
     this.startDate= dataRange.beginDate.year + "-"  + dataRange.beginDate.month+ "-" + dataRange.beginDate.day 
     this.endDate = dataRange.endDate.year + "-"  + dataRange.endDate.month  + "-" + dataRange.endDate.day 
     this.getUccGrnInventoryList(); 
   }
   else if(dataRange.beginDate.day==0){
     this.startDate= this.defStartDt
     this.endDate = this.defEndDate
     this.getUccGrnInventoryList(); 
   }  
 } 
  


      /***
       * Bind Denomination as per proiject Wise
       * */
      getDenoSeries(){
        this.http.get(environment.apiUrl + 'uccnew/getDenominations?prjId='+this.prjId).subscribe(data =>{ 
          this.denoList= data.json();   
        });  
      }

      /* 
       * Add GRN ENTRY DETAILS
      */
      addGrnEntryDetail(){
        $('#grnEntryModal').modal({backdrop: 'static', keyboard: false}) 
        if(this.uccRoleCode=="UCCHEAD")
        {
          this.startSrNoModal=null;
          this.endSrNoModal=null;
          this.amountModal=null;
          this.countModal=null;
          this.denoModel=null;
          this.serialCode=null;
          this.firstSrNoModal=null;
          this.firstSrNoRequired=false;
          this.grnInventoryList=[];
          this.success=false;
          this.error=false;
          this.bookleNoInvalid=false;
          this.denoIsRequired=false;
          $('#grnEntryModal').modal('show'); 
          this.isAddBtnActive=false;
          this.rowCount=0;
          this.rowDataAmount=0;  
        }
        else{ 
          $('#uccheadOnlyModal').modal('show');  
        }
        this.grnInventoryList=[];
        this.isexcelDisable=false    
        this.isSaveActive=true   
      
      } 
      /***
       * Caliculate Start serial No and End Serials NO
       * */ 
      validateBookletNo(data){ 
        if(data!=null){ 
        if(this.firstSrNoModal.length<7){
          this.invalidBookletNo=true 
          return;
        }
        else{
          this.invalidBookletNo=false;
        } 
        this.startSrNoModal=data
        var srNo=data.slice(2,10) 
        var code=data.slice(0,2) 
        var startLen=srNo.toString().length         
       if(startLen>2){
        var endSrno=parseInt(srNo)+99 
        this.endSrNoModal=code+this.pad(endSrno,startLen)  
        if(srNo%100==1){
          this.bookleNoInvalid=false;
          this.countModal=(Number(endSrno)-Number(srNo))+1;
          this.amountModal=this.denoModel*this.countModal
        }else{
          this.bookleNoInvalid=true;
          this.countModal=0;
          this.amountModal=0;
        } 
       } 
       else{ 
       this.bookleNoInvalid=true;
       this.startSrNoModal=null;
       this.endSrNoModal=null;
       this.amountModal=0;
       this.countModal=0;
       } 
     } 
    }
       //to Increase The Sr no auto increatemented
       pad(str,size){
        var s = String(str);
        while (s.length < (size || 2)) {s = "0" + s;}
        return s;
      }

      onSelectDeno(coupAmount){ 
      if(coupAmount!=null){  
      this.denoIsRequired=false;
      this.denoModel=coupAmount.denomination
      var len = coupAmount.denomination.toString().length 
       this.amountModal=Number(coupAmount.denomination)*Number(this.countModal) 
       if(len==3){
         this.serialCode=coupAmount.series+coupAmount.denomination  
        } 
       if(len==2){
         this.serialCode=coupAmount.series+'0'+coupAmount.denomination 
        }
       if(len==1)
        {
         this.serialCode=coupAmount.series+'00'+coupAmount.denomination 
        } 
      }else{
        this.denoIsRequired=true;
      } 
       }  
    /*
    * get Issuer Details
    */
    getIssuerDetails(){
      this.http.get(environment.apiUrl + 'uccnew/getUccIssuerDetails?userId='+this.userId).subscribe(data =>{ 
               this.empDetailsList=data.json(); 
               this.toEnpId=this.empDetailsList[0].empId
               this.toEmpRoleId=this.empDetailsList[0].roleId 
               this.uccRoleCode=this.empDetailsList[0].roleCd 
               console.log("uccRoleCode",this.uccRoleCode);
             }); 
     } 
      
      addCouponSeries(){ 
       

        if(this.denoModel==null){
           this.denoIsRequired=true;
           return;
        } 
        if(!this.firstSrNoModal &&  this.firstSrNoModal.length>=7){
          this.bookleNoInvalid=true;
          return;
        }
        if(this.countModal<=0 && this.amountModal<=0){
          alert("Coupon Count/Amount is Invalid!")
          return;
        } 
         var grnJsonData={
          "ID":null,
          "PRJID":this.prjId,
          "FROMEMP":null,
          "FROMROLEID":null,
          "TOEMP":this.toEnpId, 
          "UCCHEADID":this.toEnpId,
          "TOROLEID":this.toEmpRoleId, 
          "DENOMINATION":this.denoModel, 
          "FIRSTSRNO":this.serialCode+this.firstSrNoModal.toUpperCase(),
          "FROMSRNO":this.serialCode+this.startSrNoModal.toUpperCase(),
          "TOSRNO":this.serialCode+this.endSrNoModal.toUpperCase(), 
          "QTY": this.countModal,
          "AMOUNT": this.amountModal,
          "ISACTIVE":1, 
          "ISSUEDATE":moment(this.grnDate).format('YYYY-MM-DD'),
          "USERID":this.userId,
          "SOURCEFROM":"GRN"
         }  
         var len=this.grnInventoryList.length
         if(len>14){ 
           this.isAddBtnActive=false; 
           this.limitOverMsg=true;  
           return
          }
         this.grnInventoryList.push(grnJsonData)
         this.isSaveActive=false;
         this.rowCount=this.rowCount+1
         var len=this.grnInventoryList.length 
         this.rowDataAmount=Number(this.rowDataAmount)+Number(this.amountModal) 
      }
      
      

      /*
       * Delete Data from Array list
       */ 
      deleteCoupon(index,data){  
        this.grnInventoryList.splice(index,1)  
        this.rowCount=this.rowCount-1
        this.rowDataAmount=Number(this.rowDataAmount)-Number(data.AMOUNT) 
          if(this.grnInventoryList.length==0){ 
              this.isAddBtnActive=false
              this.isSaveActive=true;
              this.rowCount=0;
              this.rowDataAmount=0; 
              this.success=false;
              this.error=false;
              this.isexcelDisable=false;
            } 
           if(this.grnInventoryList.length>0 && this.grnInventoryList.length<=15){
              this.isAddBtnActive=false
              this.limitOverMsg=false  
              this.isSaveActive=false;
            }  
      }  
    /*
    *  Save GRN COUPON DETAILS
    */
      saveCouponDetails(){  
          this.http.post(environment.apiUrl + 'uccnew/saveUccGrnInventory',this.grnInventoryList).subscribe(data =>{ 
                var code=data.json();  
                var responceCode=code[0].RESPONSECODE 
                var responceMsg =code[1].RESPONSEMESSAGE 
                this.jsonDataResult=code[2].UPLOADRESULT 
                if(responceCode=="200"){ 
                  this.success=true; 
                  this.responceMessage=responceMsg
                  this.getUccGrnInventoryList();
                  setTimeout(()=>{ 
                    this.success=false; 
                    this.error=false;
                    this.rowCount=0;
                    this.rowDataAmount=0;
                    this.grnInventoryList=[];
                    this.isSaveActive=true;
                    this.isAddBtnActive=false
                    this.limitOverMsg=false;  
                   }, 1000); 
                }else{
                  this.showErrorRow(JSON.parse(this.jsonDataResult)) 
                  this.isexcelDisable=true
                  this.success=false;
                  this.error=true;
                  this.responceMessage=responceMsg 
                }               
            });       
      } 
 

      
 showErrorRow(data){
  var errorRow = []
  for(var i = 0;i<data.length;i++){
       errorRow.push(data[i])
  }

   for(var i =0;i<this.grnInventoryList.length;i++){
      for(var j = 0;j<errorRow.length;j++){
      if(this.grnInventoryList[i].FIRSTSRNO == errorRow[j].FIRSTSRNO){
        this.grnInventoryList[i].error = true
        this.grnInventoryList[i].remark = errorRow[j].ERRORREMARK
      }
    }
     
   }
}
  
      
      /***
       * Edit Coupon Series 
       * */
      editCouponSeries(data){
        $('#editModal').modal('show');  
        console.log("data",data)
        this.couponSeriesId=data.ID
        this.denoModel=data.Denomination
        var len=data.FirstSrNo.length 
        var prjCode=data.FirstSrNo.slice(0,4) 
        this.serialCode=prjCode 
        var series=data.FirstSrNo.slice(4,len) 
        this.firstSrNoModal=series
        this.startSrNoModal=series
        this.endSrNoModal=series
        this.countModal=data.Qty
        this.amountModal=data.Amount
        this.success=false;
        this.error=false;
      }
     

      /*
       * ******************************************Update Coupon Series******************************************
       */
      updateCouponDetails(){
        if(this.denoModel==null){
          this.denoIsRequired=true;
          return;
       } 
       if(this.firstSrNoModal==null || this.firstSrNoModal.length<7){
         this.firstSrNoRequired=true;
         return;
       }
        var grnUpdtJshon={
          "ID":this.couponSeriesId,
          "PRJID":this.prjId,
          "FROMEMP":null,
          "FROMROLEID":null,
          "TOEMP":this.toEnpId, 
          "UCCHEADID":this.toEnpId,
          "TOROLEID":this.toEmpRoleId, 
          "DENOMINATION":this.denoModel, 
          "FIRSTSRNO":this.serialCode+this.firstSrNoModal,
          "FROMSRNO":this.serialCode+this.startSrNoModal,
          "TOSRNO":this.serialCode+this.endSrNoModal, 
          "QTY": this.countModal,
          "AMOUNT": this.amountModal,
          "ISACTIVE":1, 
          "ISSUEDATE":moment(this.grnDate).format('YYYY-MM-DD'),
          "USERID":this.userId,
          "SOURCEFROM":"GRN"
         } 
         this.grnInventoryUpdtList.push(grnUpdtJshon)
         console.log("data",this.grnInventoryUpdtList)
         this.http.post(environment.apiUrl + 'uccnew/saveUccGrnInventory',this.grnInventoryUpdtList).subscribe(data =>{ 
          var code=data.json();  
          var responceCode=code[0].RESPONSECODE 
          var responceMsg =code[1].RESPONSEMESSAGE 
          if(responceCode=="200"){
            this.success=true;
            this.error=false;
            this.responceMessage=responceMsg
            this.getUccGrnInventoryList();
            setTimeout(()=>{ 
              this.success=false;
              this.error=false;
              this.grnInventoryUpdtList=[]; 
              $('#editModal').modal('hide');  
             }, 1000); 
          }
          else if(responceCode!="200"){ 
            this.success=false;
            this.error=true;
            this.responceMessage=responceMsg 
          }   
      });       
      }


 //*****************************************DELETE*************************************** */
      //Delete GRN entry Details 
      deleteGrnModal(data){        
        $('#deleteGrnModal').modal('show'); 
        this.grnId={
          "ID":data.ID
        }  
      }

      deleteGrnEntryDetails(){
        this.http.post(environment.apiUrl + 'uccnew/deleteCouponDetails',this.grnId).subscribe(data =>{ 
          var code=data.json();  
          var responceCode=code[0].RESPONSECODE 
          var responceMsg =code[1].RESPONSEMESSAGE 
          if(responceCode=="200"){
            this.delSuccess=true;
            this.delError=false;
            this.deleteResMsg=responceMsg
            this.getUccGrnInventoryList();
            setTimeout(()=>{ 
              this.delSuccess=false;
              this.delError=false;
              this.grnInventoryUpdtList=[]; 
              $('#deleteGrnModal').modal('hide');  
             }, 1000); 
          }
          else if(responceCode!="200"){ 
            this.delSuccess=false;
            this.delError=true;
            this.deleteResMsg=responceMsg 
          }   
      });      
      }
      
    
      downloadExcelFile(collectionData){
        const ws_name = 'ErnErrorReport';
        const wb: WorkBook = { SheetNames: [], Sheets: {} };
        const ws: any = utils.json_to_sheet(collectionData);
        wb.SheetNames.push(ws_name);
        wb.Sheets[ws_name] = ws;
        const wbout = write(wb, { bookType: 'xlsx', bookSST: true, type:'binary' });
        saveAs(new Blob([this.s2ab(wbout)], { type: 'application/octet-stream' }), 'GrnErrorReport.xlsx');
        }
        s2ab(s) 
        {
          const buf = new ArrayBuffer(s.length);
          const view = new Uint8Array(buf);
          for (let i = 0; i !== s.length; ++i) {
          view[i] = s.charCodeAt(i) & 0xFF;
          };
          return buf;
        }
  


      


    
    couponHistory(BookletNo)
      {  
        this.broadcaster.broadcast('couponHistory',BookletNo);  
      }

      
     ngOnInit(){ 
       
      this.prjId = this.auth.getAuthentication().projectId  
      this.userId = this.auth.getAuthentication().id 
      this.startDate = moment(new Date()).format('YYYY-MM-DD');
      this.endDate= moment(new Date()).format('YYYY-MM-DD');  
      this.getDenoSeries();
      this.getIssuerDetails();
      this.getUccGrnInventoryList();
     } 
    
   
 } 


