import { Component } from '@angular/core';
import { Http } from '@angular/http'
import { environment } from '../../../../environments/environment'; 
import { Observable } from 'rxjs/Observable'; 
import { AuthService } from '../../../_services/index';
import * as _ from 'underscore'; 
import { LoaderService } from '../../../_services/loader.service';
import * as _moment from 'moment';
import * as _rollupMoment from 'moment';
import { MomentDateAdapter } from '@angular/material-moment-adapter';
import { DateAdapter, MAT_DATE_FORMATS, MAT_DATE_LOCALE } from '@angular/material/core';
//For KENDO UI
import { process, State  } from '@progress/kendo-data-query';
import { GroupDescriptor, DataResult } from '@progress/kendo-data-query';
import {GridDataResult,DataStateChangeEvent} from '@progress/kendo-angular-grid';
import { ExcelExportData } from '@progress/kendo-angular-excel-export'; 
import { utils, write, WorkBook } from 'xlsx';  
import { saveAs } from 'file-saver';  
const moment = _rollupMoment || _moment;

export const MY_FORMATS = {
  parse: {
    dateInput: 'LL',
  },
  display: {
    dateInput: 'LL',
    monthYearLabel: 'MMM YYYY',
    dateA11yLabel: 'LL',
    monthYearA11yLabel: 'MMMM YYYY',
  },
};

declare var $: any;  
const distinctZone = data => data.filter((x, idx, xs) => xs.findIndex(y => y.zoneID === x.zoneID) === idx);
const distinctWard = data => data.filter((x, idx, xs) => xs.findIndex(y => y.wardID === x.wardID) === idx);
const distinctBeat = data => data.filter((x, idx, xs) => xs.findIndex(y => y.beatID === x.beatID) === idx);
const distinctDeno = data => data.filter((x, idx, xs) => xs.findIndex(y => y.amount === x.amount) === idx);

@Component({
    selector: 'couponCollection-cmp',
    templateUrl: './couponCollection.component.html' ,
    providers: [
      { provide: DateAdapter, useClass: MomentDateAdapter, deps: [MAT_DATE_LOCALE] },
      { provide: MAT_DATE_FORMATS, useValue: MY_FORMATS },
    ],
  })

  export class CouponCollectionComponent {   
  public prjId:any;
  public userId:any; 
  public uccGrnList:any;
  public showLoader:boolean;
  public defStartDate:any;
  public defEndDate:any;
  public startDate:any;
  public endDate:any;
  public denoList:any; 
  public groups: GroupDescriptor[] = [];
  public view: Observable<GridDataResult>;
  public gridView: DataResult;
  public gridDataCollection: GridDataResult  
  denoModel:any;
  serialCode:any;
  collectionDate:any;
  collectionArray=[]; 
  nameModal:any;
mobileNoModal:any;
preSeriesCode:any;
serialNoModal:any;
addressModal:any;
couponCount:any;
totalAmount:any;
rowCount:any;
limitOverMsg=false; 
isSaveBtnActive=true;
isSaveActive=true;
isAddBtnActive=false
responceCode:any;
responceMsg:any;
jsonDataResult:any;
SaveSuccessMsg:any;
erroSuccessMsg:any;
collectionId:any;
delCollSuccess=false;
delCollError=false;
deleteRetResMsg:any;
couponCollectionData:any; 
dataRangeModal:any;
wardList:any;
wardModal:any;
isexcelDisable=false 
collectionTypJson:any;
collectionTypModal:any;
  public aggregates: any[] = [{field: 'AMOUNT', aggregate: 'sum'},{field: 'DENOMINATION', aggregate: 'count'}];
  public state: State = {
    skip: 0,
    take: 12, 
    filter: {
      logic: 'and',
      filters: []
    }
  };
  public allData(): ExcelExportData {
    const result: ExcelExportData =  {
        data: this.couponCollectionData
    };
    return result;
   } 
 
  public groupChange(groups: GroupDescriptor[]): void {
    this.groups = groups;
    this.loadProducts();
  } 
  private loadProducts(): void {
    this.gridDataCollection = process(this.uccGrnList, { group: this.groups });  
  } 
  public distinctZone: any[]
  public distinctWard: any[]
  public distinctBeat: any[]
  public distinctDeno: any[]

    constructor(private http: Http,private auth : AuthService,private loaderService: LoaderService){ 
        this.loaderService.status.subscribe((val: boolean) =>{
          this.showLoader = val;
        }); 
        var date = new Date();
        this.collectionDate=date;
        this.rowCount=0;
        this.totalAmount=0;
        this.allData = this.allData.bind(this);
        var firstDay = new Date(date.getFullYear(), date.getMonth(), 1);
        var lastDay = new Date(date.getFullYear(), date.getMonth() + 1, 0); 
        this.defStartDate = (firstDay.getFullYear()) + '-' + (firstDay.getMonth() + 1) + '-' + firstDay.getDate(); 
        this.defEndDate = (lastDay.getFullYear()) + '-' + (lastDay.getMonth() + 1) + '-' + lastDay.getDate(); 
        this.dataRangeModal= {beginDate: {year: date.getFullYear(), month: date.getMonth()+1, day: date.getDate()}, endDate: {year: date.getFullYear(), month: date.getMonth()+1, day: date.getDate()}};
        this.collectionTypJson=
        [{  
        "ID":1,
        "VALUE":"Collected", 
        },
        {  
          "ID":2,
          "VALUE":"Missing", 
        }] 
     } 

     
     /*
      * TO get collection Type on slect Collection type ddl list
      */
     onSelectCollectionType(data){
       this.collectionTypModal=data.ID
     }
     
    /*
    * Get GRN INVENTORY LIST
    */  
    /*
   * get Collection List
  */
  getCollectionList(){
    this.loaderService.display(true); 
    this.http.get(environment.apiUrl + 'uccnew/getCouponList?userId='+this.userId+'&startDate='+this.startDate+'&endDate='+this.endDate).subscribe(data =>{ 
          this.couponCollectionData=data.json();  
          if(this.couponCollectionData.length>0){ 
            this.gridDataCollection = process(this.couponCollectionData,this.state);  
            this.distinctZone = distinctZone(this.couponCollectionData) 
            this.distinctWard = distinctWard(this.couponCollectionData) 
            this.distinctBeat = distinctBeat(this.couponCollectionData)
            this.distinctDeno = distinctDeno(this.couponCollectionData)  
            this.loaderService.display(false); 
          } else{ 
          this.gridDataCollection=null;
          this.loaderService.display(false);  
          }  
       });
  }


/*
 * filter The Grid Data
*/
public dataStateChange(state: DataStateChangeEvent): void {
  this.state = state;
  this.gridDataCollection = process(this.couponCollectionData,this.state);  
  if (state && state.group) {
    state.group.map(group => group.aggregates = this.aggregates);  
    this.distinctZone = distinctZone(this.couponCollectionData) 
    this.distinctWard = distinctWard(this.couponCollectionData) 
    this.distinctBeat = distinctBeat(this.couponCollectionData)
    this.distinctDeno = distinctDeno(this.couponCollectionData) 
    this.gridDataCollection = process(this.couponCollectionData,this.state);  
    } 
} 

          /*
          *select start Date Nad To date
          */
          onDateRangeChanged(dataRange)
          {  
          if(dataRange.beginDate.day>0){ 
            this.startDate= dataRange.beginDate.year + "-"  + dataRange.beginDate.month+ "-" + dataRange.beginDate.day 
            this.endDate = dataRange.endDate.year + "-"  + dataRange.endDate.month  + "-" + dataRange.endDate.day 
            this.getCollectionList(); 
          }
          else if(dataRange.beginDate.day==0){
            this.startDate= this.defStartDate
            this.endDate = this.defEndDate
            this.getCollectionList(); 
          }  
          }   
        /**
       * Bind Denomination as per proiject Wise
       **/
      getDenoSeries(){
        this.http.get(environment.apiUrl + 'uccnew/getDenominations?prjId='+this.prjId).subscribe(data =>{ 
          this.denoList= data.json();   
        });  
      }

      onSelectDeno(coupAmount){ 
        if(coupAmount!=null){   
        this.denoModel=coupAmount.denomination
        var len = (coupAmount.denomination).toString().length 
         if(len==3){
           this.serialCode=coupAmount.series+coupAmount.denomination  
          } 
         if(len==2){
           this.serialCode=coupAmount.series+'0'+coupAmount.denomination  
          }
         if(len==1)
          {
           this.serialCode=coupAmount.series+'00'+coupAmount.denomination 
          } 
        } 
      } 

      //Coupon Collection
      couponCollectionModal(){ 
        $('#couponCollectionModal').modal({backdrop: 'static', keyboard: false}) 
        this.rowCount=0;
        this.totalAmount=0; 
        this.SaveSuccessMsg=false;
        this.erroSuccessMsg=false;
        this.denoModel=null;
        this.nameModal=null;
        this.mobileNoModal=null;
        this.serialCode=null;
        this.preSeriesCode=null
        this.serialNoModal=null;
        this.addressModal=null;
        this.collectionArray=[];
        this.isexcelDisable=false; 
        this.limitOverMsg=false;
        this.isAddBtnActive=false;
        $('#couponCollectionModal').modal('show'); 
      }

        /*
     * Alfabet only
     */
    public restrictAlphabets(e){ 
            var x=e.which||e.keycode;
            if((x>=48 && x<=57) || x==8 ||(x>=35 && x<=40)|| x==46)
                return false;
            else
                return true;        
    }

    /*
     * Prefix Code Validations(2 Char only)
    */
    prefixCodeValid(prefixCode)
    {
      if(prefixCode.length<2){ 
      }
      else if(prefixCode.length==2){
        $("#txtSerialNo").focus(); 
      }
    }

    public restrictNumericOnly(e) 
    {
      let input;
      var inputlen;
      if (e.metaKey || e.ctrlKey) {
        return true;
      }
      if (e.which === 32) {
       return false;
      }
      if (e.which === 0) {
       return true;
      }
      if (e.which < 33) {
        return true;
      } 
      input = String.fromCharCode(e.which); 
      return !!/[\d\s]/.test(input);
     }

/**
  * Add Coupon Collections
 */
addCouponCollection()
{
 if(!this.wardModal){
  alert("Ward is Required!")
  return;
 }
 if(!this.denoModel)  {
  alert("Denomination is Required!")
  return;
 }
  if(this.preSeriesCode==null||this.preSeriesCode.length!=2){
    alert("Invalid Series Code")
    return;
  }
  if(!this.serialNoModal){
    alert("Invalid Serial No")
    return;
  } 
  if(!this.collectionTypModal){
    alert("Collection is required!")
    return;
  }
  var collectionJson={
   "ID":null,
   "CONSNAME":this.nameModal?this.nameModal:null,
   "PHONE":this.mobileNoModal?this.mobileNoModal:null,
   "COLLECTIONDATE":moment(this.collectionDate).format('YYYY-MM-DD'),
   "COLLWARDID":this.wardModal,
   "DENOMINATION":this.denoModel,
   "SRNO":this.serialCode+this.preSeriesCode.toUpperCase()+this.serialNoModal.toUpperCase(),
   "AMOUNT":this.denoModel, 
   "COUNT":1,
   "ADDRESS":this.addressModal,
   "USERID":this.userId,
   "STATUS":this.collectionTypModal,
   "error":false
  }   
      if(this.collectionArray.length<30)
      { 
      this.isSaveActive=false;  
      $("#txtSerialNo").focus();   
      this.collectionArray.push(collectionJson) 
      var startLen=this.serialNoModal.toString().length  
      this.couponCount=this.couponCount+1  
      this.totalAmount=Number(this.totalAmount+this.denoModel) 
      this.serialNoModal=parseInt(this.serialNoModal)+1
      this.pad(this.serialNoModal,startLen) 
      this.serialNoModal=this.pad(this.serialNoModal,startLen)  
      this.rowCount=this.collectionArray.length; 
      }
      else
      {
       this.limitOverMsg=true; 
       this.isSaveBtnActive=true;
       this.isAddBtnActive=true;
       return;
      } 
     } 
     //to Increase The Sr no auto increatemented
     pad(str,size){
       var s = String(str);
       while (s.length < (size || 2)) {s = "0" + s;}
       return s;
     }

       /*
       * Delete Data from Array list
       */ 
      deleteCoupon(index,data){   
        this.collectionArray.splice(index,1)  
        this.rowCount=this.rowCount-1
        this.totalAmount=Number(this.totalAmount)-Number(data.AMOUNT) 
          if(this.collectionArray.length==0){ 
              this.isAddBtnActive=false
              this.isSaveActive=true;
              this.rowCount=0;
              this.totalAmount=0; 
              this.SaveSuccessMsg=false;
              this.erroSuccessMsg=false;
              this.isexcelDisable=false;
            } 
           if(this.collectionArray.length>0 && this.collectionArray.length<=30){
              this.isAddBtnActive=false
              this.limitOverMsg=false  
              this.isSaveActive=false;
              this.isexcelDisable=false;
            }  
      }


      
 /**
  * Save Coupon Collections 
 */ 
 saveCouponCollection()
 {  
    this.http.post(environment.apiUrl + 'uccnew/saveCouponCollections',this.collectionArray).subscribe(data =>{  
          var code=data.json(); 
          var Code=code[0].RESPONSECODE
          this.responceMsg=code[1].RESPONSEMESSAGE
          this.jsonDataResult=code[2].UPLOADRESULT 
          if(Code==200){  
            this.SaveSuccessMsg=true;  
            this.rowCount=0;
            this.totalAmount=0; 
            this.getCollectionList();
            $("#txtSerialNo").focus(); 
            setTimeout(()=>{ 
              this.isSaveBtnActive=false;
              this.limitOverMsg=false;
              this.collectionArray=[];  
              this.SaveSuccessMsg=false; 
             }, 1000); 
          }
          else if(Code =="400"){
            this.showErrorRow(JSON.parse(this.jsonDataResult)) 
            this.isexcelDisable=true;
            this.erroSuccessMsg=true; 
            $("#txtSerialNo").focus();
          }
          else if(Code =="8115"){
            this.erroSuccessMsg=true; 
            $("#txtSerialNo").focus();
          }  
       });
 }


 showErrorRow(data){
  var errorRow = []
  for(var i = 0;i<data.length;i++){
       errorRow.push(data[i])
  }

   for(var i =0;i<this.collectionArray.length;i++){
      for(var j = 0;j<errorRow.length;j++){
      if(this.collectionArray[i].SRNO == errorRow[j].srno){
        this.collectionArray[i].error = true
        this.collectionArray[i].remark = errorRow[j].Remark
      }
    } 
   }
} 

 collectionDeleteModal(data){
  $('#deleteCollectionModal').modal('show'); 
   this.collectionId=data.id
   console.log("coll",data)
 }

 


        deleteCollectionEntryDetails(){
          this.http.get(environment.apiUrl + 'uccnew/deleteCollectionEntry?collectionId='+this.collectionId).subscribe(data =>{ 
            var code=data.json();  
            //var responceCode=code[0].RESPONSECODE 
            //var responceMsg =code[1].RESPONSEMESSAGE 
            if(code.status=="ok"){
              this.delCollSuccess=true;
              this.delCollError=false;
              this.deleteRetResMsg="Collection entry deleted successfully." 
              this.getCollectionList(); 
              setTimeout(()=>{ 
                this.delCollSuccess=false;
                this.delCollError=false;
                this.collectionArray=[]; 
                $('#deleteCollectionModal').modal('hide');  
              }, 1000); 
            }
            else{ 
              this.delCollSuccess=false;
              this.delCollError=true; 
              this.deleteRetResMsg="Error during Collection entry Deletion."
            }   
        });      
        } 


      //get zone by default selected in case of zonal accountant only 
      getwardByUserId(userId){
        this.http.get(environment.apiUrl + 'uccnew/getWardbyUserId?prjid='+this.prjId+'&userId='+userId).subscribe(data =>{ 
          this.wardList =data.json();  
        });      
      } 
      onSelectWard(data){
        console.log("log",data)
      }


  downloadExcelFile(collectionData)
   {
  const ws_name = 'ErrorcollectionReport';
  const wb: WorkBook = { SheetNames: [], Sheets: {} };
  const ws: any = utils.json_to_sheet(collectionData);
  wb.SheetNames.push(ws_name);
  wb.Sheets[ws_name] = ws;
  const wbout = write(wb, { bookType: 'xlsx', bookSST: true, type:'binary' });
  saveAs(new Blob([this.s2ab(wbout)], { type: 'application/octet-stream' }), 'collectionReport.xlsx');
  }
  s2ab(s) 
  {
    const buf = new ArrayBuffer(s.length);
    const view = new Uint8Array(buf);
    for (let i = 0; i !== s.length; ++i) {
    view[i] = s.charCodeAt(i) & 0xFF;
    };
    return buf;
  }





     ngOnInit(){ 
      this.prjId = this.auth.getAuthentication().projectId  
      this.userId = this.auth.getAuthentication().id 
      this.startDate = moment(new Date()).format('YYYY-MM-DD');
      this.endDate= moment(new Date()).format('YYYY-MM-DD');    
      this.getDenoSeries();
      this.getCollectionList();
      this.getwardByUserId(this.userId)
      this.collectionTypModal = this.collectionTypJson[0].ID;
     }  
 } 


