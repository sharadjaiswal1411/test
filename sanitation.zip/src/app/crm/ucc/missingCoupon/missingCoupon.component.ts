import { Component } from '@angular/core';
import { Http } from '@angular/http'
import { environment } from '../../../../environments/environment'; 
import { Observable } from 'rxjs/Observable'; 
import { AuthService } from '../../../_services/index';
import * as _ from 'underscore'; 
import { LoaderService } from '../../../_services/loader.service';
import * as _moment from 'moment';
import * as _rollupMoment from 'moment';
//For KENDO UI
import { process, State  } from '@progress/kendo-data-query';
import { GroupDescriptor, DataResult } from '@progress/kendo-data-query'; 
import {GridDataResult,DataStateChangeEvent} from '@progress/kendo-angular-grid';
import { ExcelExportData } from '@progress/kendo-angular-excel-export'; 
const moment = _rollupMoment || _moment;  
import { utils, write, WorkBook } from 'xlsx'; 
import { saveAs } from 'file-saver';  
import { Broadcaster } from '../../../../environments/broadcaster';
declare var $: any;  
const distinctDeno = data => data.filter((x, idx, xs) => xs.findIndex(y => y.DENOMINATION === x.DENOMINATION) === idx); 
@Component({
    selector: 'couponMissing-cmp',
    templateUrl: './missingCoupon.component.html' ,
  })

  export class CouponMissingComponent {   
  public prjId:any;
  public userId:any; 
  public uccGrnList:any;
  public showLoader:boolean;
  public defStartDate:any;
  public defEndDate:any;
  public startDate:any;
  public endDate:any; 
  public groups: GroupDescriptor[] = [];
  public view: Observable<GridDataResult>;
  public gridView: DataResult;
  public gridDataCopMissing: GridDataResult 
  public uccCouponMissingList:any;
  public assignTypJson:any;
  public dataRangeModal:any;
  public showWardMgrDiv=false;
  public assignTypeModal:any;
  public zoneList:any;
  public zonalAccountList:any;
  zaEmpId:any;
  zaEmpRoleId:any;
  zaEmpName:any;
  wardList:any;
  zoneId:any;
  missingDate:any;
  wardManagerList:any
  wardManagerModal:any;
  wmEmpId:any;
  wmEmpRoleId:any;
  wmEmpName:any;
  denoList:any;
  serialCode:any;
  serialNoModal:any;
  denoModel:any;  
  invalidSerialNo=false;
  missinCoupongArray=[];
  fromEmpId:any;
  fromEmpRoleId:any;
  fromEmpName:any;
  rowCount:any;
  rowDataAmount:any;
  amountModal:any;
  isAddBtnActive=false;
  limitOverMsg=false;
  isSaveActive=true; 
  missError=false;
  zoneModal:any;
  wardModal:any;
  toEmpId:any;
  toEmpRoleId:any;
  accountantModal:any;
  missSuccess=false; 
  missResponceMsg:any;
  remarkModal:any;
  missingCouponId:any;
  delMissSuccess=false
  delmissError=false; 
  isExcelDisable=false; 
  jsonDataResult:any; 
  startSerialNoModal:any;
  endSerialModal:any;
  startSrNo:any;
  bookletSeriesModal:any; 
  public aggregates: any[] = [{field: 'AMOUNT', aggregate: 'sum'},{field: 'DENOMINATION', aggregate: 'count'}];
  public state: State = {
    skip: 0,
    take: 15, 
    filter: {
      logic: 'and',
      filters: []
    }
  };
  public allData(): ExcelExportData {
    const result: ExcelExportData =  {
        data: this.uccCouponMissingList
    };
    return result;
   } 
   public distinctDeno: any[]
  public groupChange(groups: GroupDescriptor[]): void {
    this.groups = groups;
    this.loadProducts();
  } 
  private loadProducts(): void {
    this.gridDataCopMissing = process(this.uccCouponMissingList, { group: this.groups });  
  } 

    constructor(private http: Http,private auth : AuthService,private loaderService: LoaderService,private broadcaster: Broadcaster){ 
        this.loaderService.status.subscribe((val: boolean) =>{
          this.showLoader = val;
        }); 
        this.allData = this.allData.bind(this);
        var date = new Date(); 
        this.missingDate=date
        this.rowCount=0;
        this.rowDataAmount=0;
        var firstDay = new Date(date.getFullYear(), date.getMonth(), 1);
        var lastDay = new Date(date.getFullYear(), date.getMonth() + 1, 0); 
        this.defStartDate = (firstDay.getFullYear()) + '-' + (firstDay.getMonth() + 1) + '-' + firstDay.getDate(); 
        this.defEndDate = (lastDay.getFullYear()) + '-' + (lastDay.getMonth() + 1) + '-' + lastDay.getDate(); 
        this.dataRangeModal= {beginDate: {year: date.getFullYear(), month: date.getMonth()+1, day: date.getDate()}, endDate: {year: date.getFullYear(), month: date.getMonth()+1, day: date.getDate()}};
     }    
     
    /*
    * Get GRN INVENTORY LIST
    */  
    getCouponMissingList(){ 
    this.loaderService.display(true); 
    this.http.get(environment.apiUrl + 'uccnew/getCouponMissingList?prjId='+this.prjId+'&startDt='+this.startDate+'&endDt='+this.endDate).subscribe(data =>{ 
             this.uccCouponMissingList= data.json();  
             this.distinctDeno=distinctDeno(this.uccCouponMissingList)  
             this.gridDataCopMissing=process(this.uccCouponMissingList, this.state); 
             if(this.uccCouponMissingList.length>0){  
               this.loaderService.display(false);
             }
             else if(this.uccCouponMissingList.length==0){ 
               this.loaderService.display(false); 
               this.gridDataCopMissing=null;
             }
        });
      }
      
  /*
 * filter The Grid Data
*/
  public dataStateChange(state: DataStateChangeEvent): void {
    this.state = state;
    this.gridDataCopMissing=process(this.uccCouponMissingList, this.state); 
    if (state && state.group) {
      state.group.map(group => group.aggregates = this.aggregates);  
      this.distinctDeno=distinctDeno(this.uccCouponMissingList)  
      this.gridDataCopMissing=process(this.uccCouponMissingList, this.state); 
      } 
  } 

  /*
*select start Date Nad To date
*/
 onDateRangeChanged(dataRange)
 {  
   if(dataRange.beginDate.day>0){ 
     this.startDate= dataRange.beginDate.year + "-"  + dataRange.beginDate.month+ "-" + dataRange.beginDate.day 
     this.endDate = dataRange.endDate.year + "-"  + dataRange.endDate.month  + "-" + dataRange.endDate.day 
     this.getCouponMissingList(); 
   }
   else if(dataRange.beginDate.day==0){
     this.startDate= this.defStartDate
     this.endDate = this.defEndDate
     this.getCouponMissingList(); 
   }  
 }  


      //To bind Gender Data
    public assignTypeData()
    { 
      this.assignTypJson=
      [{  
      "ID":1,
      "VALUE":"Missing From Accountant", 
      },
      {  
        "ID":2,
        "VALUE":"Missing From Ward Manager", 
      }]
    } 
      //Open Modal popup Windows
      couponMissModal(){ 
        $('#couponMissingModal').modal({backdrop: 'static', keyboard: false})
        this.clearFields();
        this.missinCoupongArray=[];
        this.isExcelDisable=false
        this.isSaveActive=true;
        this.limitOverMsg=false;
        $('#couponMissingModal').modal('show'); 
        
      } 
      clearFields(){
        this.rowCount=0;
        this.rowDataAmount=0;
        this.zoneModal=null;
        this.accountantModal=null;
        this.wardModal=null;
        this.wardManagerModal=null;
        this.denoModel=null;
        this.startSerialNoModal=null;
        this.endSerialModal=null;
        this.bookletSeriesModal=null;
        this.missSuccess=false;
        this.missError=false;
        this.remarkModal=null;
        this.serialCode=null;
      } 

      //On select Change Missing from 
      onSelectRetutnFrom(data){
        if(data.ID==1){
          this.showWardMgrDiv=false;
        }else{
          this.showWardMgrDiv=true;
        } 
      }
       /*
     * Get Zone By Prj Id
    */
   getZoneByProject(prjid){    
    this.http.get(environment.apiUrl + 'consumer/getZoneByProject?prjid='+prjid+'&oemid=7').subscribe(data =>{ 
             this.zoneList= data.json(); 
        }); 
    }
   //GET ZONAL ACCOUNTANT and Ward List 
   onSelectZone(zoneId){  
    this.zoneId=zoneId.id  
    this.getWardByProject(this.zoneId)
    this.http.get(environment.apiUrl + 'uccnew/getAccountantByZoneId?prjId='+this.prjId+'&entityId='+this.zoneId).subscribe(data =>{ 
           this.zonalAccountList= data.json();  
           if(this.zonalAccountList.length>0){ 
             this.zaEmpId=this.zonalAccountList[0].EMPID
             this.zaEmpRoleId=this.zonalAccountList[0].ROLEID
             this.zaEmpName=this.zonalAccountList[0].EMPNAME 
           }  
      }); 
    } 
     //GET WARD LIST by ZONE ID
     getWardByProject(zoneId){  
      this.http.get(environment.apiUrl + "consumer/getZoneByProject?prjid="+this.prjId+"&oemid=8&entityid="+zoneId).subscribe(data =>{ 
      this.wardList=data.json();  
        }); 
      } 
      
       //Get Ward Manager BY WARD ID
       onSelectWard(data){  
        this.http.get(environment.apiUrl + 'uccnew/getEmployeeDetailsbyEntity?entityId=' +data.id+'&role=WM').subscribe(data => {
        this.wardManagerList = data.json();  
        if(this.wardManagerList.length>0){
          this.wardManagerModal=this.wardManagerList[0].ID
          this.wmEmpId=this.wardManagerList[0].EMPID
          this.wmEmpRoleId=this.wardManagerList[0].ROLEID
          this.wmEmpName=this.wardManagerList[0].EMPNAME
        }else{
         this.wardManagerModal=null;
         this.wmEmpId=null;
         this.wmEmpRoleId=null;
         this.wmEmpName=null;
        }
      })
     }
     /***
       * Bind Denomination as per proiject Wise
       * */
      getDenoSeries(){
        this.http.get(environment.apiUrl + 'uccnew/getDenominations?prjId='+this.prjId).subscribe(data =>{ 
          this.denoList= data.json();   
        });  
      }  

      /*
      * on Select Denomination 
       */
      onSelectDeno(coupAmount){  
        if(coupAmount!=null){   
        this.denoModel=coupAmount.denomination
        var len = coupAmount.denomination.toString().length;
         if(len==3){
           this.serialCode=coupAmount.series+coupAmount.denomination  
          } 
         if(len==2){
           this.serialCode=coupAmount.series+'0'+coupAmount.denomination 
          }
         if(len==1){
           this.serialCode=coupAmount.series+'00'+coupAmount.denomination 
          } 
        }else{
          alert("Invalid Serial No")
        } 
      } 

     /*
      * validate First Serial No 
      */
      validateSerialNo(data){ 
         if(data.length>=7){  
          var startSerialNo=this.serialCode+data.toUpperCase() 
          this.startSrNo=data.toUpperCase()
          this.startSerialNoModal=data.toUpperCase()
          this.endSerialModal=data.toUpperCase() 
          this.getbookletSeriesNo(startSerialNo); 
         } 
      }

    /*
    * Get booklet series No
    */
    getbookletSeriesNo(data){
      this.http.get(environment.apiUrl + 'uccnew/getbookLetSrtNo?serialNo='+data).subscribe(data =>{ 
        var bookletStartNo=data.json();
        if(bookletStartNo.length>0){
          this.bookletSeriesModal=bookletStartNo[0].BOOKLETSERIES
        }else{
          this.bookletSeriesModal=null;
        }
      }); 
    }

    /*
    * Validate End serial No with Start Serial No
    */
    validateBookletStartSrNo(data){ 
    var endLen=data.length 
    if(this.startSrNo.length!=endLen){
      this.invalidSerialNo=true 
      return;
       }else{
        this.invalidSerialNo=false 
      } 
    } 

    /*
    * get Issuer Details(UCC HEAD)
    */ 
   getIssuerDetails(){
    this.http.get(environment.apiUrl + 'uccnew/getUccIssuerDetails?userId='+this.userId).subscribe(data =>{ 
             var empDetailsList=data.json(); 
             this.toEmpId=empDetailsList[0].empId
             this.toEmpRoleId=empDetailsList[0].roleId 
             //this.uccRoleCode=empDetailsList[0].roleCd  
           }); 
     } 

      //Add Coupon Series data
      async addMissingSeries(){
        if(this.startSerialNoModal && this.endSerialModal.length){ 
          var startSrNo = this.serialCode + this.startSerialNoModal
          var endSrNo = this.serialCode + this.endSerialModal
          let isValid = await fetch(environment.apiUrl + 'uccNew/checkValidSeries' + "?startSrNo=" + startSrNo + "&endSrNo="  + endSrNo)
          var response = await isValid.json()
          if(!response[0].keyValue){
           this.invalidSerialNo=true
            return;
          } 
        }  
        if(!this.assignTypeModal){
          alert("Missing Type is Required!")
          return;
        }
        if(!this.zoneModal){
          alert("Zone is Required!")
          return;
        }
        if(!this.accountantModal){
          alert("Zonal Accountant is Required!")
          return;
        }  
        if(this.assignTypeModal==1){
         this.fromEmpId=this.zaEmpId
         this.fromEmpRoleId=this.zaEmpRoleId
         this.fromEmpName=this.zaEmpName
        }else{
          this.fromEmpId=this.wmEmpId
          this.fromEmpRoleId=this.wmEmpRoleId
          this.fromEmpName=this.wmEmpName
        }
        if(this.assignTypeModal==2 && this.wardModal==null){
          alert("Ward is Required!")
          return;
        }
        if(this.assignTypeModal==2 && this.wardManagerModal==null){
          alert("Ward Manager is Required!")
          return;
        }
        if(!this.denoModel){
          alert("Denomination is Required!")
          return;
        }  
        var MissingJson={
          "ID":null,
          "PRJID":this.prjId,
          "FROMEMP":this.fromEmpId,
          "FROMROLEID":this.fromEmpRoleId, 
          "TOEMP":this.toEmpId,          //Ward manager/ZA EMP ID
          "TOROLEID":this.toEmpRoleId,  //Ward Mamager/ZA EMP ID
          "UCCHEADID":this.fromEmpId,      
          "DENOMINATION":this.denoModel, 
          "FIRSTSRNO":this.bookletSeriesModal,
          "FROMSRNO":this.serialCode+this.startSerialNoModal,
          "TOSRNO":this.serialCode+this.endSerialModal,  
          "ZONEID":this.zoneModal,
          "ZAID":this.zaEmpId,
          "WARDID":this.wardModal?this.wardModal:null, 
          "WMID":this.wmEmpId?this.wmEmpId:null,  
          "ISACTIVE":1, 
          "ISSUEDATE":moment(this.missingDate).format('YYYY-MM-DD'),
          "ZANAME":this.fromEmpName?this.fromEmpName:null, 
          "USERID":this.userId,
          "REMARK":this.remarkModal?this.remarkModal:null
         } 
         console.log("missing array",this.missinCoupongArray) 
         if(this.missinCoupongArray.length<10){ 
          this.missinCoupongArray.push(MissingJson)
          this.rowCount=this.rowCount+1
          this.rowDataAmount=Number(this.rowDataAmount)+Number(this.denoModel) 
          this.isAddBtnActive=false 
          this.limitOverMsg=false; 
          this.isSaveActive=false;
         } 
         else{ 
          this.isAddBtnActive=true
          this.limitOverMsg=true;  
          this.isSaveActive=false;
          return;
         }
         
      }
      //On select ZONAL ACCOUNTANT EMP ID AND EMPRILEID
      onSelectAccountant(data){ 
        this.zaEmpId=data.EMPID
        this.zaEmpRoleId=data.ROLEID
        this.zaEmpName=data.EMPNAME
      }

      /*
       * Delete Data from Array list
       */ 
      deleteCoupon(index,data){   
        this.missinCoupongArray.splice(index,1)  
        this.rowCount=this.rowCount-1
        this.rowDataAmount=Number(this.rowDataAmount)-Number(data.DENOMINATION) 
          if(this.missinCoupongArray.length==0){ 
              this.isAddBtnActive=false
              this.isSaveActive=true;
              this.rowCount=0;
              this.rowDataAmount=0; 
              this.missSuccess=false;
              this.missError=false;
              this.isExcelDisable=false
            } 
           if(this.missinCoupongArray.length>0 && this.missinCoupongArray.length<=10){
              this.isAddBtnActive=false
              this.limitOverMsg=false  
              this.isSaveActive=false;
            }  
      } 
      
      //Save Coupon Missing Details
      saveCouponMissingDetails(){
        this.http.post(environment.apiUrl + 'uccnew/saveCouponMissing',this.missinCoupongArray).subscribe(data =>{ 
          var code=data.json();  
          var responceCode=code[0].RESPONSECODE 
          var responceMsg =code[1].RESPONSEMESSAGE 
          this.jsonDataResult=code[2].UPLOADRESULT 
          if(responceCode=="200"){
            this.missSuccess=true;
            this.missError=false;
            this.missResponceMsg=responceMsg
            this.getCouponMissingList() 
            setTimeout(()=>{ 
              this.missSuccess=false;
              this.missError=false;
              this.missinCoupongArray=[];
              this.isSaveActive=true;
              this.rowCount=0;
              this.rowDataAmount=0;
            }, 1000); 
          }
          else{ 
            if(this.jsonDataResult){
              this.showErrorRow(JSON.parse(this.jsonDataResult))  
            }            
            this.isExcelDisable=true
            this.missSuccess=false;
            this.missError=true;
            this.missResponceMsg=responceMsg 
          }  
       });  
      }
     
      //Show Error After click on Save button
      showErrorRow(data){
        var errorRow = []
        for(var i = 0;i<data.length;i++){
             errorRow.push(data[i])
        } 
         for(var i =0;i<this.missinCoupongArray.length;i++){
            for(var j = 0;j<errorRow.length;j++){
            if(this.missinCoupongArray[i].FIRSTSRNO == errorRow[j].FIRSTSRNO){
              this.missinCoupongArray[i].error = true
              this.missinCoupongArray[i].remark = errorRow[j].ERRORREMARK
            }
          }
           
         }
      }
     
      deleteMissingCoupon(data){
        $('#deleteMissCouponModal').modal('show');   
          this.missingCouponId=data.ID 
      }
      
      deleteMissEntryDetails(){
        this.http.get(environment.apiUrl + 'uccnew/deleteMissingEntry?missingId='+this.missingCouponId).subscribe(data =>{ 
          var code=data.json();  
          if(code.status=="ok"){
            this.delMissSuccess=true
            this.missResponceMsg="Missing entry deleted successfully."
            this.getCouponMissingList();
            setTimeout(()=>{ 
                  this.delMissSuccess=false
                  this.delmissError=false;
                  this.missinCoupongArray=[];
                  this.isSaveActive=true;
                  this.rowCount=0;
                  this.rowDataAmount=0; 
                  $('#deleteMissCouponModal').modal('hide');   
                }, 1000); 
          }else{
            this.delMissSuccess=false
            this.delmissError=true;
            this.missResponceMsg="Error during missning entry Deletion."
          } 
       });  
      }

    //Download Missing coupon entry details
    downloadExcelFile(missCouponData){
     const ws_name = 'ErrorCouponMissingReport';
     const wb: WorkBook = { SheetNames: [], Sheets: {} };
     const ws: any = utils.json_to_sheet(missCouponData);
     wb.SheetNames.push(ws_name);
     wb.Sheets[ws_name] = ws;
     const wbout = write(wb, { bookType: 'xlsx', bookSST: true, type:'binary' });
     saveAs(new Blob([this.s2ab(wbout)], { type: 'application/octet-stream' }), 'ErrorCouponMissingReport.xlsx');
     }
     s2ab(s) 
     {
       const buf = new ArrayBuffer(s.length);
       const view = new Uint8Array(buf);
       for (let i = 0; i !== s.length; ++i) {
       view[i] = s.charCodeAt(i) & 0xFF;
       };
       return buf;
     }

     couponHistory(BookletNo)
     {  
       this.broadcaster.broadcast('couponHistory',BookletNo);  
     }

   
     ngOnInit(){ 
      this.prjId = this.auth.getAuthentication().projectId  
      this.userId = this.auth.getAuthentication().id   
      this.startDate = moment(new Date()).format('YYYY-MM-DD');
      this.endDate= moment(new Date()).format('YYYY-MM-DD');  
      this.getCouponMissingList()
      this.assignTypeData();
      this.getIssuerDetails()
      this.assignTypeModal = this.assignTypJson[0].ID;
      this.getZoneByProject(this.prjId)
      this.getDenoSeries();
     } 
    
   
 } 


