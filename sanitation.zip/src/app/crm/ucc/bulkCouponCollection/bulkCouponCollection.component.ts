import { Component } from '@angular/core';
import { Http } from '@angular/http'
import { environment } from '../../../../environments/environment';
import { MomentDateAdapter } from '@angular/material-moment-adapter';
import { DateAdapter, MAT_DATE_FORMATS, MAT_DATE_LOCALE } from '@angular/material/core';
import { Observable } from 'rxjs/Observable';
import { AuthService } from '../../../_services/index';
import { LoaderService } from '../../../_services/loader.service';
import * as _moment from 'moment';
import * as _rollupMoment from 'moment';
const moment = _rollupMoment || _moment; 
import { process, State ,aggregateBy } from '@progress/kendo-data-query';
import { GroupDescriptor, DataResult } from '@progress/kendo-data-query';
import { SelectableSettings } from '@progress/kendo-angular-grid';
import { ExcelExportData } from '@progress/kendo-angular-excel-export'; 
import {
  GridDataResult,
  DataStateChangeEvent
} from '@progress/kendo-angular-grid'; 

declare var $: any; 
export const MY_FORMATS = {
    parse: {
      dateInput: 'LL',
    },
    display: {
      dateInput: 'LL',
      monthYearLabel: 'MMM YYYY',
      dateA11yLabel: 'LL',
      monthYearA11yLabel: 'MMMM YYYY',
    },
  };  

  const distinctZone = data => data
  .filter((x, idx, xs) => xs.findIndex(y => y.zoneName === x.zoneName) === idx); 

@Component({
    selector: 'BulkCouponCollection-cmp',
    templateUrl: './bulkCouponCollection.component.html',
    providers: [
        { provide: DateAdapter, useClass: MomentDateAdapter, deps: [MAT_DATE_LOCALE] },
        { provide: MAT_DATE_FORMATS, useValue: MY_FORMATS },
      ],    
  }) 
 
  export class BulkCouponCollectionComponent {  
      wardList:any;
      driverList:any    
      wardManagerList:any;
      uccCouponData:any;
      wardId:any;
      wardManagerId:any;    
      prjId:any;
      userId:any;
      showLoader:boolean;
      issueDate:any;
      beatList:any; 
      entityId:any;
      updtDriverList:any;
      driverId:any;
      couponDenomination:any;
      driverIsRequired:any;
      serialNoData:any;
      denomIsRequired=false;
      couponCount:any;
      denomination:any;
      totalAmount:any;
      countModal:any;
      countIsRequired:any;
      currDeno:any;
      couponSuccessMsg=false;
      issuerId:any;
      issuerRoleId:any;
      driverEmpId:any;
      driverRoleId:any; 
      beatId:any;  
      responceMsg=false;
      couponErrorMsg=false;
      collectionList:any;
      couponListNotFound=false;
      selectedRow:Number;
      updtIssueDate:any;
      currId:any;
      driverIdModal:any;
      updtCurrDeno:any;
      updtCountModal:any;
      updtTotalAmount:any;
      beatIdModal:any;
      updtdriverEmpId:any;
      driverRoleIdInUpdt:any;
      denominationModal:any;
      responceMessage:any;
      updtCouponSuccessMsg=false;
      updtCouponErrorMsg=false;
      couponInUpdtData:any;
      updtBeatIsRequired=false;
      driverRequiredUpdt=false;
      updtDenomIsRequired=false;
      countIsRequiredUpdt=false;
      deleteSuccessMsg=false;
      deleteErrorMsg=false;
      isSubmitActive=false;
      search:any;
      updtBeatList:any;
      currCouponId:any;
      wardListUpdt:any;
      wardIdModalUpdt:any;
      wardManagerIdUpdt:any;
      wardManagerListUpdt:any;
      beatListUpdt:any;
      beatIdUpdt:any;
      driverIdUpdt:any;
      driverListUpdt:any;
      denominationIdUpdt:any;
      wardIsRequiredInUpdt=false;
      managerRequiredInUpdt=false;
      beatRequiredUpdt=false;
      driverRoleUpdt:any;
      incAmount:any;
      inctAmtModal:any;
      incentiveAmountList:any;
      receivedAmtModal:any; 
      total:any;     
      totalIncentiveAmnt:any;
      totalReceivedAmnt:any; 
      dataRangeModal:any;
      defStartDate:any;
      defEndDate:any
      startDate:any;
      endDate:any;

    public aggregates: any[] = [{field: 'amount', aggregate: 'sum'},{field: 'denomination', aggregate: 'count'},{field: 'IncentiveAmount', aggregate: 'sum'},{field: 'ReceivedAmount', aggregate: 'sum'}];
    public state: State = {
      skip: 0,
      take: 12, 
      filter: {
        logic: 'and',
        filters: []
      }
    }; 


    public allData(): ExcelExportData {
        const result: ExcelExportData =  {
            data: this.collectionList
        };
        return result;
       } 

    public checkboxOnly = false;
    public mode = 'multiple';
    public selectableSettings: SelectableSettings;  
    public distinctZone: any[] 
    public groups: GroupDescriptor[] = [];
    public view: Observable<GridDataResult>;
    public gridView: DataResult;
    public groupChange(groups: GroupDescriptor[]): void {
      this.groups = groups;
      this.loadProducts();
    }
  
    private loadProducts(): void {
      this.gridData = process(this.collectionList, { group: this.groups });
    }
    public gridData: GridDataResult
    constructor(private http: Http,private auth : AuthService,private loaderService: LoaderService){ 
      this.loaderService.status.subscribe((val: boolean) =>{
        this.showLoader = val;
      }); 
      this.issueDate=new Date(); 
      var firstDay = new Date();
      var lastDay = new Date(); 
      this.allData = this.allData.bind(this);
      this.defStartDate = (firstDay.getFullYear()) + '-' + (firstDay.getMonth() + 1) + '-' + firstDay.getDate(); 
      this.defEndDate = (lastDay.getFullYear()) + '-' + (lastDay.getMonth() + 1) + '-' + lastDay.getDate(); 
      this.dataRangeModal= {beginDate: {year: lastDay.getFullYear(), month: lastDay.getMonth()+1, day: lastDay.getDate()}, endDate: {year: lastDay.getFullYear(), month: lastDay.getMonth()+1, day: lastDay.getDate()}};
     } 
    ngOnInit() 
    {   
      this.startDate  = moment(this.defStartDate).format('YYYY-MM-DD');
      this.endDate = moment(this.defEndDate).format('YYYY-MM-DD');
      this.prjId = this.auth.getAuthentication().projectId  
      this.userId = this.auth.getAuthentication().id 
      this.getCollectionList();
      this.getAssignedBeatInUpdt(this.prjId,this.userId)    
      this.getAssignedWard(this.prjId,this.userId);
      this.getUccDenominations();
      this.getIssuerDetails();
      this.getAssignedWardUpdt(this.prjId,this.userId);
      this.getIncentiveAmount();
    }   


   /*
    * GetBulkCoupon collection
   */
   getCollectionList(){
    this.loaderService.display(true); 
    this.http.get(environment.apiUrl + 'uccnew/getCollectionList?prjId='+this.prjId+'&userId='+ this.userId + "&startDate=" + this.startDate + "&endDate="  +this.endDate) .subscribe(data => { 
        this.collectionList= data.json(); 
        if(this.collectionList.length>0){ 
        this.distinctZone = distinctZone(this.collectionList)
        this.total = aggregateBy(this.collectionList, this.aggregates)["amount"].sum;   
        this.totalIncentiveAmnt = aggregateBy(this.collectionList, this.aggregates)["IncentiveAmount"].sum; 
        this.totalReceivedAmnt = aggregateBy(this.collectionList, this.aggregates)["ReceivedAmount"].sum;            
        this.gridData = process(this.collectionList, this.state);           
          this.couponListNotFound=false;
          this.loaderService.display(false); 
       } 
        if(this.collectionList.length==0){
            this.couponListNotFound=true; 
            this.loaderService.display(false); 
        }  
        this.loaderService.display(false); 
   }); 
} 

    onDateRangeChanged(dataRange){  
      if(dataRange.beginDate.day>0){ 
        this.startDate= dataRange.beginDate.year + "-"  + dataRange.beginDate.month+ "-" + dataRange.beginDate.day 
        this.endDate = dataRange.endDate.year + "-"  + dataRange.endDate.month  + "-" + dataRange.endDate.day  
        this.getCollectionList();
      }
      else if(dataRange.beginDate.day==0){  
        this.startDate= this.defStartDate
        this.endDate = this.defEndDate
        this.getCollectionList();
      }  
    }
 
    /*
     * Get INCENTIVE AMOUNT
    */
   getIncentiveAmount(){
    this.http.get(environment.apiUrl + 'uccnew/getIncentiveAmount?prjId='+this.prjId) .subscribe(data => { 
      this.incentiveAmountList= data.json(); 
      this.incAmount=this.incentiveAmountList[0].INCENTIVEAMOUNT
    });
  }
  

    

     /**
      * Select Driver Name
     */ 
      selectDriver(data){  
        if(data==null){
          this.driverIsRequired=true;
          return; 
        }
        else if(data!=null){
        this.driverEmpId=data.EMPID
        this.driverRoleId=data.ROLEID
        this.driverIsRequired = false 
        }
      }  
        
        /*
        *  NumericOnly Restrict 
        */
        public restrictNumericOnly(e) 
        {
        let input;
        var inputlen;
        if (e.metaKey || e.ctrlKey) {
            return true;
        }
        if (e.which === 32) {
        return false;
        }
        if (e.which === 0) {
        return true;
        }
        if (e.which < 33) {
            return true;
        }
        input = String.fromCharCode(e.which); 
        return !!/[\d\s]/.test(input);
        } 


        couponCollectionModal(){
          $('#couponCollectionModal').modal({backdrop: 'static', keyboard: false})
            $('#couponCollectionModal').modal('show');   
        }




    /*
    * get Issuer ID and role Details
    */
     getIssuerDetails(){
      this.http.get(environment.apiUrl + 'uccnew/getUccIssuerDetails?userId='+this.userId).subscribe(data =>{ 
               var issuerData=data.json(); 
               if(issuerData.length>0){
                this.issuerId=issuerData[0].empId  
                this.issuerRoleId=issuerData[0].roleId  
               } 
        }); 
     }

     /*
      * Save Coupon Collection Details into the Data Base
     */
    savebulkCouponCollection(){   
        if(!this.wardId){alert("ward is Required!");return}  
        if(!this.beatId){alert("Beat is Required!");return}
        if(!this.driverId){alert("Driver is Required!");return}
        if(!this.denomination){alert("Denomination is Required!");return}
        if(!this.countModal){alert("Count is Required!");return}
        if(this.countModal<=0){alert("Invalid Count!");return}
        if(this.totalAmount<=0){alert("Invalid Amount!");return}
        if(this.inctAmtModal<=0){alert("Invalid Incentive Amount!");return}
        if(this.receivedAmtModal<=0){alert("Invalid Received Amount!");return}
       var couponJsonData={
           "ID":null,
           "PRJID":this.prjId,
           "COLLECTIONDT":moment(this.issueDate).format('YYYY-MM-DD'),
           "ENTITYID":this.beatId,
           "TOEMPID":this.issuerId,
           "TOEMPROLEID":this.issuerRoleId,
           "FROMEMPID":this.driverId,
           "FROMEMPROLEID":this.driverRoleId,  
           "DENOMINATION":this.denomination,
           "COUNT":this.countModal,
           "AMOUNT":this.totalAmount,
           "ISACTIVE":1,
           "WARDID":this.wardId,
           "WMID":this.wardManagerId,
           "USERID":this.userId
         } 
          this.isSubmitActive=true;
          this.http.post(environment.apiUrl + 'uccnew/saveCouponCollection',couponJsonData).subscribe(data =>{ 
           var collectionData=data.json(); 
           if(collectionData[0].RESPONSECODE==200){
            this.responceMsg=collectionData[1].RESPONSEMESSAGE
            this.couponSuccessMsg=true;
            this.getCollectionList();
            this.clearCoupnData();
            setTimeout(()=>{
                this.couponErrorMsg=false;
                this.couponSuccessMsg=false;
                this.clearAllinputFiels();
                this.isSubmitActive=false;
               }, 2000); 
           }
           if(collectionData[0].RESPONSECODE==400){
            this.responceMsg=collectionData[1].RESPONSEMESSAGE           
            this.couponErrorMsg=true;
            this.couponSuccessMsg=false;
           }       
        });  
     }
     /**
      * Clear all input fields
     */
     clearAllinputFiels()
     {
        this.beatId=null;
        this.driverId=null;
        this.denomination=null;
        this.countModal=null; 
        this.totalAmount=null;
        this.currDeno=null;
     }  

    
    /*
     * Get all Beat List in update
     */ 
    getAssignedBeatInUpdt(prjId,userId){
        this.http.get(environment.apiUrl + 'uccnew/getWardByProject?prjid='+prjId+'&userId='+ userId) .subscribe(data => { 
                 this.updtBeatList= data.json();                 
            }); 
      } 

      /*
      * Select Denominations 
     */ 
     selectDenomination(data){  
      if(data == null){
          this.denomIsRequired=true;
          this.totalAmount=0;
          this.inctAmtModal=this.incAmount
          this.receivedAmtModal=0
          return;
      }
      else if(data!=null){ 
          this.denomIsRequired=false;
          if(this.countModal!=null && data.denomination!=undefined){
              this.totalAmount=this.countModal*data.denomination*100 
              this.receivedAmtModal=this.totalAmount-this.inctAmtModal
          }
          else{
            this.totalAmount=0;
            this.receivedAmtModal=0;
          }
      } 
  }


     
      // vivek      
     inputCouponCount(count){  
        if(count==0){ 
            this.countIsRequired=true
            this.inctAmtModal=this.incAmount
            this.receivedAmtModal=0;
            this.totalAmount=0;
            return;
        } 
        else if(count>0){ 
            this.countIsRequired=false
            if(this.denomination!=undefined){
              this.totalAmount=count*this.denomination
              this.inctAmtModal=count*this.incAmount
              this.receivedAmtModal=this.totalAmount-this.inctAmtModal
            }
            else{
              this.totalAmount=0
              this.inctAmtModal=count*this.incAmount
              this.receivedAmtModal=this.totalAmount-this.inctAmtModal
            } 
        } 
    }
     

     getUccDenominations() {
        this.http.get(environment.apiUrl + 'uccnew/getDenominations?prjId=' + this.prjId).subscribe(data => {
          this.uccCouponData = data.json();
        });
      }

     getAssignedWard(prjId,userId){
        this.http.get(environment.apiUrl + 'uccnew/getWardByProject?prjid='+prjId+'&userId='+ userId) .subscribe(data => { 
                  this.wardList= data.json();                  
            }); 
      }

      selectWard(ward) {
        this.beatList = []
        this.getBeatByWard(ward.entityid, 9)
          this.http.get(environment.apiUrl + 'uccnew/getEmployeeDetailsbyEntity?entityId=' + ward.entityid + '&role=WM').subscribe(data => {
            this.wardManagerList = data.json(); 
          });
      }


      getBeatByWard(entityid, oemid) {
        this.beatList = []
        this.http.get(environment.apiUrl + 'entity/getEntityByParents' + "?prjid=" + this.prjId + "&entityid=" + entityid + "&oemid=" + oemid).subscribe(data => {
          if (data.json().length > 0) { 
            this.beatList = data.json();
          }
        })
      }


      selectBeat(data){
        this.http.get(environment.apiUrl + 'uccnew/getEmployeeDetailsbyEntity?entityId='+data.id + "&role=DVR") .subscribe(data => { 
            this.driverList= data.json();  
       });
     }

     clearCoupnData(){
         this.driverList = []
         this.wardManagerList = []
         this.beatList = []
         this.driverId = null;
         this.wardId = null;
         this.beatId = null;
         this.denomination = null
         this.countModal = null
         this.totalAmount = 0
         this.wardManagerId = null
         this.inctAmtModal=null
         this.receivedAmtModal=null
     } 

    //******************************************Update Sections --RAM(29_06_2018)*******************************************//
      /*
       * Edit/Update Coupon collections Details
      */ 
     public currdenomination:any;   
      editCollectionDetails(data){
        $("#editBulkCoupon").modal("show") 
        console.log("data",data)
        this.currId=data.id
        this.updtIssueDate=data.collectiondt      
        this.wardIdModalUpdt=data.entityId       
        this.getEmployeeDetailByWardId(data.entityId)       
        this.getBeatByWardUpdt(data.entityId, 9)
        this.beatIdUpdt=data.beatID        
        this.getDriverByBeatId(this.beatIdUpdt)       
        this.driverIdUpdt=data.empId        
        this.denominationIdUpdt=data.denoId 
        this.currdenomination=data.denomination
        this.updtCountModal=data.count
        this.updtTotalAmount=data.amount 
        this.clearMessage(); 
    }  

    clearMessage(){
      this.wardIsRequiredInUpdt=false;
      this.managerRequiredInUpdt=false;
      this.beatRequiredUpdt=false; 
      this.driverRequiredUpdt=false; 
      this.updtDenomIsRequired=false; 
      this.countIsRequiredUpdt=false; 
    }

    /**
     * Get Ward List On Update
    */
    getAssignedWardUpdt(prjId,userId){
        this.http.get(environment.apiUrl + 'uccnew/getWardByProject?prjid='+prjId+'&userId='+ userId) .subscribe(data => {                  
                  this.wardListUpdt= data.json(); 
            }); 
      }

    /*
     * Get Employee Details By Ward Id
    */
    getEmployeeDetailByWardId(wardId){
        this.http.get(environment.apiUrl + 'uccnew/getEmployeeDetailsbyEntity?entityId='+wardId + '&role=WM').subscribe(data => {
            this.wardManagerListUpdt = data.json(); 
            if(this.wardManagerListUpdt.length>0){
                this.wardManagerIdUpdt=this.wardManagerListUpdt[0].EMPID 
             }           
          });
    }

    /*
     * Get Driver Details By Beat Id
    */
    getDriverByBeatId(beatId){
        this.http.get(environment.apiUrl + 'uccnew/getEmployeeDetailsbyEntity?entityId='+beatId + "&role=DVR") .subscribe(data => { 
            this.driverListUpdt= data.json(); 
            this.driverRoleUpdt=this.driverListUpdt[0].ROLEID            
       });
     } 

    /*
    * Select Ward manager on ward select index change Ward
    */    
    selectWardUpdt(ward) { 
        if(ward==null){
            this.wardIsRequiredInUpdt=true;
            return;
        }
        this.wardIsRequiredInUpdt=false;
        this.beatList = []
        this.getBeatByWardUpdt(ward.entityid, 9)
            this.http.get(environment.apiUrl + 'uccnew/getEmployeeDetailsbyEntity?entityId=' + ward.entityid + '&role=WM').subscribe(data => {
            this.wardManagerListUpdt = data.json();  
          });
      }

     /*
    * Select Ward manager 
    */ 
      selectWardManager(managerData){
          if(managerData==null){
            this.managerRequiredInUpdt=true;
            return;
          }
          else{
            this.managerRequiredInUpdt=false;
          }
      }


      /*
       * Select Driver and Check Validations
      */
      selectDriverInUpdt(data){  
        if(data==null){
          this.driverRequiredUpdt=true;
          return; 
        }
        else if(data!=null){ 
        this.driverRoleUpdt=data.ROLEID 
        this.driverRequiredUpdt = false 
        }
      }
      
    /*
    * Select Beat Details on Ward Changes
    */ 
      getBeatByWardUpdt(entityid, oemid) {
        this.beatListUpdt = []
        this.http.get(environment.apiUrl + 'entity/getEntityByParents' + "?prjid=" + this.prjId + "&entityid=" + entityid + "&oemid=" + oemid).subscribe(data => {
          if (data.json().length > 0) { 
            this.beatListUpdt = data.json(); 
          }
        })
      }

       /*
       * Select Bit in update sections
      */
      selectBeatInUpdt(data){  
            if(data==null){
                this.beatRequiredUpdt=true; 
                return;
            }   
            this.beatRequiredUpdt = false
            this.http.get(environment.apiUrl + 'uccnew/getEmployeeDetailsbyEntity?entityId='+data.id + "&role=DVR") .subscribe(data => { 
            this.driverListUpdt= data.json();
            if(this.driverListUpdt.length==0){
              this.driverIdUpdt=null;
            }            
         });
     } 

    /*
    * Select Denominations 
    */    
    selectDenominationInUpdt(data){        
        if(data == null){
            this.updtDenomIsRequired=true;
        }
        else if(data!=null){
            this.updtDenomIsRequired=false;
            this.updtCurrDeno=data.denomination;           
            if(this.updtCountModal!=null){
                this.updtTotalAmount=this.updtCountModal*data.denomination
            }
            else{
                this.updtTotalAmount=0 
            } 
        } 
    }

    /**
     * Get coupon Amount
    */
    inputCouponCountiInUpdt(data){  
        if(data<=0){ 
            this.countIsRequiredUpdt=true           
            return;
        } 
        else if(data>0){ 
          this.countIsRequiredUpdt=false   
          this.updtTotalAmount=data*this.updtCurrDeno 
          this.updtTotalAmount=data*this.denominationIdUpdt     
        }  
    }
 

    /**
     * Update BULK COUPON COLLECTION DETAILS
    */ 
     updateBulkCouponDetails()
     {
        if(this.wardIdModalUpdt==null){this.wardIsRequiredInUpdt=true;return}
        if(this.wardManagerIdUpdt==null){this.managerRequiredInUpdt=true;return}
        if(this.beatIdUpdt==null){this.beatRequiredUpdt=true;return}
        if(this.driverIdUpdt==null){this.driverRequiredUpdt=true;return} 
        if(this.denominationIdUpdt==null){this.updtDenomIsRequired=true;return} 
        if(this.updtCountModal==0){this.countIsRequiredUpdt=true;return} 
        var couponJsonData={
            "ID":this.currId,
            "PRJID":this.prjId,
            "COLLECTIONDT":moment(this.updtIssueDate).format('YYYY-MM-DD'),
            "ENTITYID":this.beatIdUpdt,
            "TOEMPID":this.issuerId,
            "TOEMPROLEID":this.issuerRoleId, 
            "FROMEMPID":this.driverIdUpdt,          //Driver EMP ID
            "FROMEMPROLEID":this.driverRoleUpdt,    //Driver ROLE ID
            "DENOMINATION":this.denominationIdUpdt,
            "COUNT":this.updtCountModal,
            "AMOUNT":this.updtTotalAmount,
            "ISACTIVE":1,
            "WARDID":this.wardIdModalUpdt,
            "WMID":this.wardManagerIdUpdt,
            "USERID":this.userId            
            }           
        this.http.post(environment.apiUrl + 'uccnew/saveCouponCollection',couponJsonData).subscribe(data =>{ 
            var updtData=data.json(); 
            if(updtData[0].RESPONSECODE==200){
                this.responceMessage=updtData[1].RESPONSEMESSAGE 
                this.updtCouponSuccessMsg=true;
                this.getCollectionList(); 
               }
               if(updtData[0].RESPONSECODE==400){
                this.responceMessage=updtData[1].RESPONSEMESSAGE   
                this.updtCouponErrorMsg=true;
                this.updtCouponSuccessMsg=false;
               } 
               setTimeout(()=>{
                this.updtCouponErrorMsg=false;
                this.updtCouponSuccessMsg=false; 
                $("#editBulkCoupon").modal("hide")
               }, 2000);   
         }); 
     } 

     public dataStateChange(state: DataStateChangeEvent): void {
        this.state = state;
        this.gridData = process(this.collectionList, this.state);     
        if (state && state.group) {
          this.total = aggregateBy(this.gridData.data, this.aggregates)["amount"].sum;
          this.totalIncentiveAmnt = aggregateBy(this.gridData.data, this.aggregates)["IncentiveAmount"].sum;         
          this.totalReceivedAmnt = aggregateBy(this.gridData.data, this.aggregates)["ReceivedAmount"].sum;       
          state.group.map(group => group.aggregates = this.aggregates);
        }
      } 

  }

  




  
