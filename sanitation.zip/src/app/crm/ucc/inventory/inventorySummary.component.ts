import { Component } from '@angular/core';
import { Http } from '@angular/http'
import { environment } from '../../../../environments/environment';
import { Observable } from 'rxjs/Observable';
import { AuthService } from '../../../_services/index';
import { LoaderService } from '../../../_services/loader.service'; 
import { process, State, aggregateBy } from '@progress/kendo-data-query'; 
import { GroupDescriptor, DataResult } from '@progress/kendo-data-query';
import { GridDataResult } from '@progress/kendo-angular-grid';
import { ExcelExportData } from '@progress/kendo-angular-excel-export'; 

declare var $: any;

@Component({
    selector: 'inventorySummary-cmp',
    templateUrl: './inventorySummary.component.html',
})

export class InventorySummaryComponent {
    public prjId: any;
    public userId: any;
    public empId:any
    public firstColumns:any
    inventoryAmount:any;
    inventoryCount:any;
    secondColumns:any
    gridData:any;
    public reportLevelArray:any;
    showLoader: any
    inventorySummary: any; 

    public groups: GroupDescriptor[] = [];
    public view: Observable<GridDataResult>;
    public gridView: DataResult;
    public state: State = {
        skip: 0,
        take: 100000,
        filter: {
            logic: 'and',
            filters: []
        }
    };
    public allData(): ExcelExportData {
        const result: ExcelExportData =  {
            data: this.inventorySummary
        };
        return result;
       } 

    public aggregates: any[] = [{ field: 'Amount', aggregate: 'sum' },{ field: 'Count', aggregate: 'sum' }];

    constructor(private http: Http, private auth: AuthService, private loaderService: LoaderService) {
        this.loaderService.status.subscribe((val: boolean) => {
            this.showLoader = val;
            this.allData = this.allData.bind(this);
        });
        
       
    }


    getInventorySummary(reportLevel){
        this.loaderService.display(true); 
        var data = {
            prjId:this.prjId,
            empId:this.empId,
            userId:this.userId,
            reportLevel:reportLevel
        }
        this.http.post(environment.apiUrl + 'ucc/getInventorySummary',data).subscribe(data =>{ 
            this.inventorySummary = data.json()
            this.firstColumns= []
            this.secondColumns= []
            this.inventoryAmount = aggregateBy(this.inventorySummary, this.aggregates)["Amount"].sum;
            this.inventoryCount = aggregateBy(this.inventorySummary, this.aggregates)["Count"].sum;
            for(var k in this.inventorySummary[0]) {
                if(k != 'Amount' && k != "Count" && k !=  k.substring(0, 1)){
                    this.firstColumns.push(k);
                }else{
                    if(k == k.substring(0, 1)){
                        this.secondColumns.push(k);
                    }
                   
                }
               
            } 
            console.log(this.firstColumns)
            this.gridData = process(this.inventorySummary, this.state);
            this.loaderService.display(false); 
        })
    }

    selectReportLabel(reportLevel){
        this.getInventorySummary(reportLevel) 
    }
    
    getUccIssuerDetails(){
        this.http.get(environment.apiUrl + 'uccNew/getUccIssuerDetails?userId=' +this.userId).subscribe(data =>{ 
            var empDetail =data.json(); 
            console.log("empDetail",empDetail)
            this.empId=empDetail[0].empId
            if(empDetail[0].roleCd == "ACC"){
                this.getInventorySummary('ward')
                this.reportLevelArray = ["ward","beat"]
            }else{
                this.reportLevelArray = ["zone","ward","beat"]
                this.getInventorySummary('zone')
            }
            
        })
    }

    getSum(data){
        console.log(data)
       return aggregateBy(this.inventorySummary, this.aggregates)[data.field].sum;
    }


    ngOnInit() {
        this.prjId = this.auth.getAuthentication().projectId
        this.userId = this.auth.getAuthentication().id
        this.getUccIssuerDetails()  
    }
}


