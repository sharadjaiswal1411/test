import { Component } from '@angular/core';
import { Http } from '@angular/http'
import { environment } from '../../../../environments/environment';
import { AuthService } from '../../../_services/index';
import { LoaderService } from '../../../_services/loader.service';
import { utils, write, WorkBook } from 'xlsx';
import { saveAs } from 'file-saver';
import { Broadcaster } from '../../../../environments/broadcaster';
declare var $: any;

@Component({
    selector: 'inventoryDetail-cmp',
    templateUrl: './inventoryDetail.component.html',
})

export class InventoryDetailComponent {
    public prjId: any;
    public userId: any;
    public empId:any
    public searchList:any;
    public searchCouponDetail:any;
    public statusObject:any
    bookletDetail:any;
    bookletHistoryList:any;
    searchCouponHistory:any;
    detailsNotFound=false;
    showLoader: any
    uccAccountantList:any;
    inventoryDetail: any;
    inventoryDetailArray=[];
    uccheadModal:any;
    totalQty:any;
    totalCollection:any;
    outStendCollec:any;
    totalAmnt:any;
    totalAmntColl:any;
    outStendBalance:any;
    getStatusData:any;
    uccheadAccModal:any;
    constructor(private http: Http, private auth: AuthService,private broadcaster: Broadcaster, private loaderService: LoaderService) {
        this.loaderService.status.subscribe((val: boolean) => {
            this.showLoader = val;
        });
        this.statusObject = null 
        this.assignDefaultData();
    }



  /* 
     excel Import
  */

  s2ab(s) {
    const buf = new ArrayBuffer(s.length);
    const view = new Uint8Array(buf);
    for (let i = 0; i !== s.length; ++i) {
      view[i] = s.charCodeAt(i) & 0xFF;
    };
    return buf;
  }

  importToExcel(){ 
    var inventoryDetail = this.inventoryDetail 
    for(var i=0;i<inventoryDetail.length;i++){
      var qty=inventoryDetail[i].Qty  
      var collectQty=inventoryDetail[i].CollectionCount     
      var BalanceQty=qty-collectQty
      inventoryDetail[i].BalanceQty = BalanceQty
      var totalAmt=inventoryDetail[i].Amount
      var collectedAmt=inventoryDetail[i].CollectionAmount 
      var BalanceAmount=totalAmt-collectedAmt
      inventoryDetail[i].BalanceAmount = BalanceAmount
    } 
    const ws_name = 'SomeSheet';
    const wb: WorkBook = { SheetNames: [], Sheets: {} };
    const ws: any = utils.json_to_sheet(inventoryDetail);
    wb.SheetNames.push(ws_name);
    wb.Sheets[ws_name] = ws;
    const wbout = write(wb, {
      bookType: 'xlsx', bookSST: true, type:
        'binary'
    });
    saveAs(new Blob([this.s2ab(wbout)], { type: 'application/octet-stream' }), 'inventoryDetail.xlsx');
  }





  couponDetailExcel(){
    var data = this.bookletDetail
    const ws_name = 'SomeSheet';
    const wb: WorkBook = { SheetNames: [], Sheets: {} };
    const ws: any = utils.json_to_sheet(data);
    wb.SheetNames.push(ws_name);
    wb.Sheets[ws_name] = ws;
    const wbout = write(wb, {
      bookType: 'xlsx', bookSST: true, type:
        'binary'
    });
    saveAs(new Blob([this.s2ab(wbout)], { type: 'application/octet-stream' }), 'couponDetail.xlsx');
  }

  couponHistoryExcel(){
    var data = this.bookletHistoryList
    const ws_name = 'SomeSheet';
    const wb: WorkBook = { SheetNames: [], Sheets: {} };
    const ws: any = utils.json_to_sheet(data);
    wb.SheetNames.push(ws_name);
    wb.Sheets[ws_name] = ws;
    const wbout = write(wb, {
      bookType: 'xlsx', bookSST: true, type:
        'binary'
    });
    saveAs(new Blob([this.s2ab(wbout)], { type: 'application/octet-stream' }), 'couponDetailHistory.xlsx');
  }
  
   
    getInventoryDetail(){
        this.loaderService.display(true); 
        var data = {
            prjId:this.prjId,
            empId:this.empId,
            userId:this.userId,
        }
        this.http.post(environment.apiUrl + 'uccnew/getInventoryDetail',data).subscribe(data =>{ 
            this.inventoryDetail = data.json()
            if(this.inventoryDetail.length>0){
                console.log("data",this.inventoryDetail)
                for(var i=0;i<this.inventoryDetail.length;i++){
                    var qty=this.inventoryDetail[i].Qty
                    this.totalQty=this.totalQty+qty 
                    var collection=this.inventoryDetail[i].CollectionCount
                    this.totalCollection=this.totalCollection+collection
                    var totalAmt=this.inventoryDetail[i].Amount
                    this.totalAmnt=this.totalAmnt+totalAmt
                    var totalCollection=this.inventoryDetail[i].CollectionAmount
                    this.totalAmntColl=this.totalAmntColl+totalCollection
                }
                this.outStendCollec=this.totalQty-this.totalCollection 
                this.outStendBalance=this.totalAmnt-this.totalAmntColl  
                this.detailsNotFound=false; 
                this.loaderService.display(false);  
            } else{
                this.detailsNotFound=true;
                this.loaderService.display(false);  
            }
        })
    }

    detail(srNo){ 
        this.http.get(environment.apiUrl + 'uccnew/getBookletDetail?srNo=' + srNo).subscribe(data =>{ 
           var dataArray  = data.json()
           this.statusCount(dataArray)
           this.getBookLetHistory(srNo);
        })
    }

    statusObjectInit(){
        this.statusObject = {
            total:0,
            pending:0,
            collected:0,
            missing:0
        }
    }
    statusCount(data){
        this.bookletDetail = data
        this.statusObjectInit()
        for(var i = 0 ;i<this.bookletDetail.length;i++){
            if(this.bookletDetail[i].Status ==  0){
                this.bookletDetail[i].StatusName =  "Pending"
                this.statusObject.pending ++
            }else if(this.bookletDetail[i].Status ==  1){
                this.bookletDetail[i].StatusName =  "Collected"
                this.statusObject.collected ++
            }else if(this.bookletDetail[i].Status ==  2){
                this.bookletDetail[i].StatusName =  "Missing"
                this.statusObject.missing ++
            }
            
        }
        $('#ModalPopup').modal('show');
        this.statusObject.total = this.bookletDetail.length

    }
 
    getBookLetHistory(srNo){ 
        this.http.get(environment.apiUrl + 'uccnew/getBookletHistory?srNo=' + srNo).subscribe(data =>{ 
           this.bookletHistoryList  = data.json() 
        })
    }
    
    getUccIssuerDetails(){
        this.http.get(environment.apiUrl + 'uccNew/getUccIssuerDetails?userId=' +this.userId).subscribe(data =>{ 
            var empDetail =data.json(); 
            if(empDetail.length>0){
                this.empId=empDetail[0].empId
                this.getInventoryDetail()
            } 
        })
    }

    couponHistory(BookletNo)
      {  
        this.broadcaster.broadcast('couponHistory',BookletNo);  
      }

     
      /*
      * Get all Ucchead and accountant list 
      */  
      getUccHeadAccnt(){
        this.http.get(environment.apiUrl + 'uccNew/getUccheadAccountant?prjId=' +this.prjId).subscribe(data =>{ 
            this.uccAccountantList =data.json();
            if(this.uccAccountantList.length>0){
                var empId=this.uccAccountantList[0].empid 
                this.uccheadAccModal=empId
            }else{

            } 
        })
      }

      /*
       * Get Ucc Head/Zonal Accountant Details
      */
      selectUccAccountant(data){
          if(data){ 
            this.empId=data.empid
            this.userId=data.userid
            this.inventoryDetail=null; 
            this.assignDefaultData();
            this.getInventoryDetail()
          }
      }

       assignDefaultData(){
        this.totalQty=0;
        this.totalCollection=0;
        this.outStendCollec=0;
        this.totalAmnt=0;
        this.totalAmntColl=0;
        this.outStendBalance=0;
       }
      

      /*
       * get Login User Emp Details
       */
    //  getUccAccountDetails(){
    //     this.http.get(environment.apiUrl + 'uccNew/getUccIssuerDetails?userId='+this.userId).subscribe(data =>{ 
    //         var uccLoginData =data.json();
    //         if(uccLoginData.length>0){
    //             var empId=uccLoginData[0].empId  
              
    //         }  
    //     })
    //  }

    ngOnInit() {
        this.prjId = this.auth.getAuthentication().projectId
        this.userId = this.auth.getAuthentication().id  
        this.getUccHeadAccnt();
        this.getUccIssuerDetails(); 
        
    }
}


