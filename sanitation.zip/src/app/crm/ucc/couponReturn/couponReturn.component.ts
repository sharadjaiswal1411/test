import { Component } from '@angular/core';
import { Http } from '@angular/http'
import { environment } from '../../../../environments/environment'; 
import { Observable } from 'rxjs/Observable'; 
import { AuthService } from '../../../_services/index';
import * as _ from 'underscore'; 
import { LoaderService } from '../../../_services/loader.service';
import * as _moment from 'moment';
import * as _rollupMoment from 'moment';
//For KENDO UI
import { process, State  } from '@progress/kendo-data-query';
import { GroupDescriptor, DataResult } from '@progress/kendo-data-query';
import {GridDataResult,DataStateChangeEvent} from '@progress/kendo-angular-grid';
import { ExcelExportData } from '@progress/kendo-angular-excel-export'; 
const moment = _rollupMoment || _moment;
import { utils, write, WorkBook } from 'xlsx';  
import { saveAs } from 'file-saver';  
import { Broadcaster } from '../../../../environments/broadcaster';
declare var $: any;

const distinctDeno = data => data.filter((x, idx, xs) => xs.findIndex(y => y.Denomination === x.Denomination) === idx); 
const distinctZone = data => data.filter((x, idx, xs) => xs.findIndex(y => y.Zone === x.Zone) === idx); 
const distinctWard = data => data.filter((x, idx, xs) => xs.findIndex(y => y.Ward === x.Ward) === idx); 
const distinctBeat = data => data.filter((x, idx, xs) => xs.findIndex(y => y.Beat === x.Beat) === idx); 
const distinctAcc = data => data.filter((x, idx, xs) => xs.findIndex(y => y.AccName === x.AccName) === idx); 
const distinctMgr = data => data.filter((x, idx, xs) => xs.findIndex(y => y.WMName === x.WMName) === idx); 
@Component({
    selector: 'couponReturn-cmp',
    templateUrl: './couponReturn.component.html' ,
  })

  export class CouponReturnComponent {  
  public isRole:any;
  public prjId:any;
  public userId:any; 
  public uccGrnList:any;
  public showLoader:boolean;
  public defStartDate:any;
  public defEndDate:any;
  public startDate:any;
  public endDate:any;
  public returnDate:any;
  public groups: GroupDescriptor[] = [];
  public view: Observable<GridDataResult>;
  public gridView: DataResult;
  public gridDataCopReturn: GridDataResult 
  public couponReturnList:any;
  public dataRangeModal:any;
  public assignTypJson:any;
  public assignTypeModal:any;
  public zoneList:any;
  zoneId:any;
  zonalAccountList:any;
  wardList:any;
  wardManagerList:any;
  denoList:any;
  denoModel:any;
  amountModal:any;
  countModal:any;
  serialCode:any;
  denoIsRequired=false;
  couponReturnArray=[];
  wardManagerModal:any;
  wmEmpId:any;
  wmEmpRoleId:any;
  wmEmpName:any;
  showWardMgrDiv=false;
  fromEmpId:any;
     fromEmpRoleId:any;
     uccRoleCode:any;
     toEmpId:any;
     toEmpRoleId:any;
     fromEnpId:any;
     firstSrNoModal:any;
     startSrNoModal:any;
     endSrNoModal:any;
     zoneModal:any;
     zaEmpId:any;
     zaEmpRoleId:any;
     wardModal:any;
     toEmpName:any;
     zaEmpName:any;
     accountantModal:any;
     isAddBtnActive=false;
     isSaveActive=true;
     fromEmpName:any;
     returnResponceMsg:any;
     reSuccess=false;
     reError=false;
     startInputValue:any;
     startBookletNo:any;
     valideEndSrNo=false
     rowCount:any;
     rowDataAmount:any;
     limitOverMsg=false; 
     editReSuccess=false;
     editReerror=false;
     editReresponceMessage:any;
     returnUpdtJason:any;
     zonalAccountantList:any;
     returnId:any;
     returnAssignId:any;
     delRetSuccess=false;
     delRetError=false;
     deleteRetResMsg:any;
     isExcelDisable=false;
     jsonDataResult:any;
     isZoneDisable=true
  public aggregates: any[] = [{field: 'AMOUNT', aggregate: 'sum'},{field: 'DENOMINATION', aggregate: 'count'}];
  public state: State = {
    skip: 0,
    take: 10, 
    filter: {
      logic: 'and',
      filters: []
    }
  };
  public distinctDeno: any[]
  public distinctZone: any[]
  public distinctWard: any[]
  public distinctBeat: any[]
  public distinctAcc: any[]
  public distinctMgr: any[]
  public allData(): ExcelExportData {
    const result: ExcelExportData =  {
        data: this.couponReturnList
    };
    return result;
   } 

 
  public groupChange(groups: GroupDescriptor[]): void {
    this.groups = groups;
    this.loadProducts();
  } 
  private loadProducts(): void {
    this.gridDataCopReturn = process(this.couponReturnList, { group: this.groups });  
  } 

    constructor(private http: Http,private auth : AuthService,private loaderService: LoaderService,private broadcaster: Broadcaster){ 
        this.loaderService.status.subscribe((val: boolean) =>{
          this.showLoader = val;
        }); 
        this.allData = this.allData.bind(this);
        var date = new Date();
        this.returnDate=new Date();
        var firstDay = new Date(date.getFullYear(), date.getMonth(), 1);
        var lastDay = new Date(date.getFullYear(), date.getMonth() + 1, 0); 
        this.defStartDate = (firstDay.getFullYear()) + '-' + (firstDay.getMonth() + 1) + '-' + firstDay.getDate(); 
        this.defEndDate = (lastDay.getFullYear()) + '-' + (lastDay.getMonth() + 1) + '-' + lastDay.getDate(); 
        this.dataRangeModal= {beginDate: {year: lastDay.getFullYear(), month: lastDay.getMonth()+1, day: lastDay.getDate()}, endDate: {year: lastDay.getFullYear(), month: lastDay.getMonth()+1, day: lastDay.getDate()}};
     }    
     
    /*
    * Get GRN INVENTORY LIST
    */  
   getCouponReturnDataList(){ 
    this.loaderService.display(true); 
    var sourceFrom="RETURN"
    this.http.get(environment.apiUrl + 'uccnew/getCouponAssignmentList?prjId='+this.prjId+'&userId='+this.userId+'&startDt='+this.startDate+'&endDt='+this.endDate+'&sourceFrom='+sourceFrom).subscribe(data =>{ 
             this.couponReturnList= data.json();   
             if(this.couponReturnList.length>0){  
               this.loaderService.display(false);
               this.distinctDeno=distinctDeno(this.couponReturnList)  
               this.distinctZone=distinctZone(this.couponReturnList)  
               this.distinctWard=distinctWard(this.couponReturnList)  
               this.distinctBeat=distinctBeat(this.couponReturnList)  
               this.distinctAcc=distinctAcc(this.couponReturnList)  
               this.distinctMgr=distinctMgr(this.couponReturnList)
               this.gridDataCopReturn=process(this.couponReturnList, this.state); 
             }
             else if(this.couponReturnList.length==0){ 
               this.loaderService.display(false); 
               this.gridDataCopReturn=null;
             }
        });
      } 

 /*
 * filter The Grid Data
*/
public dataStateChange(state: DataStateChangeEvent): void {
  this.state = state;
  this.gridDataCopReturn=process(this.couponReturnList, this.state); 
  if (state && state.group) {
    state.group.map(group => group.aggregates = this.aggregates);  
    this.distinctDeno=distinctDeno(this.couponReturnList)  
    this.distinctZone=distinctZone(this.couponReturnList)  
    this.distinctWard=distinctWard(this.couponReturnList)  
    this.distinctBeat=distinctBeat(this.couponReturnList)  
    this.distinctAcc=distinctAcc(this.couponReturnList)  
    this.distinctMgr=distinctMgr(this.couponReturnList)
    this.gridDataCopReturn=process(this.couponReturnList, this.state); 
    } 
} 

/*
*select start Date Nad To date
*/
onDateRangeChanged(dataRange)
{  
 if(dataRange.beginDate.day>0){ 
   this.startDate= dataRange.beginDate.year + "-"  + dataRange.beginDate.month+ "-" + dataRange.beginDate.day 
   this.endDate = dataRange.endDate.year + "-"  + dataRange.endDate.month  + "-" + dataRange.endDate.day 
   this.getCouponReturnDataList(); 
 }
 else if(dataRange.beginDate.day==0){
   this.startDate= this.defStartDate
   this.endDate = this.defEndDate
   this.getCouponReturnDataList(); 
 }  
} 






  //*****************************************OPEN NEW MODAL POPUP AND ACTION*************************************************************** */
  
  
  
  //To bind Gender Data
   public assignTypeData()
   { 
     this.assignTypJson=
     [{  
     "ID":1,
     "VALUE":"Return From Accountant", 
     },
     {  
       "ID":2,
       "VALUE":"Return From Ward Manager", 
     }]
   } 
      //Coupon return Details(OPEN MODAL POPUP)
      couponReturnModal(){
        $('#couponReturnModal').modal({backdrop: 'static', keyboard: false})
        this.clearAllFields();
        this.isSaveActive=true;
        this.rowCount=0;
        this.rowDataAmount=0; 
        this.limitOverMsg=false; 
        this.couponReturnArray=[]; 
        $("#couponReturnModal").modal("show")  
      }
      
      onSelectRetutnFrom(data){
        if(data.ID==1){
          this.showWardMgrDiv=false;
        }else{
          this.showWardMgrDiv=true;
        } 
      }

     clearAllFields(){
      //this.zoneModal=null;
      //this.accountantModal=null;
      this.wardModal=null;
      this.wardManagerModal=null;
      this.denoModel=null;
      this.serialCode=null;
      this.startSrNoModal=null;
      this.endSrNoModal=null;
      this.firstSrNoModal=null;
      this.countModal=null;
      this.amountModal=null;
     }

    /*
     * Get Zone By Prj Id
    */
   getZoneByProject(prjid){    
    this.http.get(environment.apiUrl + 'consumer/getZoneByProject?prjid='+prjid+'&oemid=7').subscribe(data =>{ 
             this.zoneList= data.json(); 
        }); 
    }
   //GET ZONAL ACCOUNTANT and Ward List 
   onSelectZone(zoneId){  
     this.zoneId=zoneId.id  
     this.getWardByProject(this.zoneId)
     this.http.get(environment.apiUrl + 'uccnew/getAccountantByZoneId?prjId='+this.prjId+'&entityId='+this.zoneId).subscribe(data =>{ 
            this.zonalAccountList= data.json();  
            if(this.zonalAccountList.length>0){ 
              this.zaEmpId=this.zonalAccountList[0].EMPID
              this.zaEmpRoleId=this.zonalAccountList[0].ROLEID
              this.zaEmpName=this.zonalAccountList[0].EMPNAME
              this.accountantModal=this.zaEmpId
              console.log("ZONAL ACC EMP",this.accountantModal)
            }  
       }); 
     } 
     //GET WARD LIST by ZONE ID
     getWardByProject(zoneId){  
      this.http.get(environment.apiUrl + "consumer/getZoneByProject?prjid="+this.prjId+"&oemid=8&entityid="+zoneId).subscribe(data =>{ 
      this.wardList=data.json();  
      }); 
      } 
       //Get Ward Manager BY WARD ID
       onSelectWard(data){  
        this.http.get(environment.apiUrl + 'uccnew/getEmployeeDetailsbyEntity?entityId=' +data.id+'&role=WM').subscribe(data => {
        this.wardManagerList = data.json();  
        if(this.wardManagerList.length>0){
          this.wardManagerModal=this.wardManagerList[0].ID
          this.wmEmpId=this.wardManagerList[0].EMPID
          this.wmEmpRoleId=this.wardManagerList[0].ROLEID
          this.wmEmpName=this.wardManagerList[0].EMPNAME
          console.log("WM EMP",this.wmEmpId)
        }else{
         this.wardManagerModal=null;
         this.wmEmpId=null;
         this.wmEmpRoleId=null;
         this.wmEmpName=null;
        }
      })
     } 
     /***
       * Bind Denomination as per proiject Wise
       * */
      getDenoSeries(){
        this.http.get(environment.apiUrl + 'uccnew/getDenominations?prjId='+this.prjId).subscribe(data =>{ 
          this.denoList= data.json();   
        });  
      }
     
      onSelectDeno(coupAmount){ 
        if(coupAmount!=null){  
        this.denoIsRequired=false;
        this.denoModel=coupAmount.denomination
        var len = coupAmount.denomination.toString().length  
        if(!this.startSrNoModal){ 
          this.amountModal=Number(coupAmount.denomination)*Number(this.countModal) 
        }else{ 
          this.amountModal=0;
        } 
         if(len==3){
           this.serialCode=coupAmount.series+coupAmount.denomination  
          } 
         if(len==2){
           this.serialCode=coupAmount.series+'0'+coupAmount.denomination 
          }
         if(len==1)
          {
           this.serialCode=coupAmount.series+'00'+coupAmount.denomination 
          } 
        }else{
          this.denoIsRequired=true;
        } 
      } 
    /*
    * get Issuer Details(UCC HEAD)
    */ 
   getIssuerDetails(){
    this.http.get(environment.apiUrl + 'uccnew/getUccIssuerDetails?userId='+this.userId).subscribe(data =>{ 
             var empDetailsList=data.json();
             console.log("emp details",empDetailsList)
             if(empDetailsList.length>0){
             this.toEmpId=empDetailsList[0].empId
             this.toEmpRoleId=empDetailsList[0].roleId 
             this.uccRoleCode=empDetailsList[0].roleCd 
             console.log("uccRoleCode",empDetailsList);
             if(this.uccRoleCode=="ACC"){
              this.isZoneDisable=true
              this.isRole=true
              this.assignTypeModal = this.assignTypJson[1].ID; 
              this.isZoneDisable = true
              this.showWardMgrDiv=true;              
              this.getzoneAndzonalAccountant(); 
            } else{
              this.assignTypeModal = this.assignTypJson[0].ID;
              this.isZoneDisable = false
              this.showWardMgrDiv=false;
              this.isRole=false
            }
          }   
        }); 
     } 
      // //get Accountant Details
      onSelectAccountant(data){        
        console.log("on select Accountant",data)       
      } 

  //get zone by default selected in case of zonal accountant only 
  getzoneAndzonalAccountant(){
    this.http.get(environment.apiUrl + 'uccnew/getZoneWardbyUserId?prjid='+this.prjId+'&userId='+this.userId).subscribe(data =>{ 
      var zone =data.json();  
      this.zoneModal= zone[0].id  
      this.selectAccountant(this.zoneModal)
      this.getWardByProject(this.zoneModal)
    });      
  }
 







    
    
  //***********************************CHECk START SERIAl NO AND LAST SERIAL NO START****************************** */
      checkBookLetNo(data){  
        if(this.serialCode!=null){
          if(data!==""){ 
          this.startInputValue=data.slice(2,data.length) 
          var allSeries=this.serialCode+data
          this.http.get(environment.apiUrl + 'uccnew/getBookletNo'+"?bookLetNo="+allSeries).subscribe(data => {
            var result = data.json() 
            if(data.json().statusCode == 402){
              alert("Invalid Sr No")
              return;
            }
            var result = data.json().data   
            var series=result[0].BOOKLETNO 
            var serlen=series.length
            this.startBookletNo=series 
            if(serlen>4){
              this.firstSrNoModal=series.slice(4,series.length)  
            } 
            var len=Number(this.firstSrNoModal.toString().length)-2  
            var startNum=this.firstSrNoModal.slice(2,series.length)
            var code=this.firstSrNoModal.slice(0,2) 
            var endendNum=parseInt(startNum)+99  
            this.endSrNoModal=code+this.pad(endendNum,len)
            if(Number(endendNum)>=Number(this.startInputValue)){
              this.countModal=(Number(endendNum)-Number(this.startInputValue))+1  
              this.amountModal=Number(this.countModal)*Number(this.denoModel)
            }else{
              this.countModal=0;
              this.amountModal=0;
            } 
          });
         }else{
          this.firstSrNoModal=null;
          this.endSrNoModal=null;
         }
        }else{
          this.firstSrNoModal=null;
          this.endSrNoModal=null;
         }
        }  
        //To Increase The Sr no auto increatemented
          pad(str,size){
          var s = String(str);
          while (s.length < (size || 2)) {s = "0" + s;}
          return s;
        }
       
        //Validate End Serial No.  
        validateEndSrNo(data){
          if(data!==""){ 
            var endInputValue=data.slice(2,data.length) 
                this.valideEndSrNo=false;      
                if(Number(endInputValue)>=Number(this.startInputValue)){ 
                  this.countModal=(Number(endInputValue)-Number(this.startInputValue))+1
                  this.amountModal=Number(this.countModal)*Number(this.denoModel)
                }else{ 
                  this.valideEndSrNo=true; 
                  this.countModal=0;
                  this.amountModal=0;               
                } 
              } else{
                this.valideEndSrNo=true;             
              }
        }



    //***********************************CHECk START SERIAl NO AND LAST SERIAL NO END*******************************/
     
    //Return Coupon Series Details
    addReturnSeries(){ 
      console.log("data",this.assignTypeModal)
      if(this.assignTypeModal==1){
        this.fromEmpId=this.zaEmpId;   ///ZONAL ACCOUNTANT
        this.fromEmpRoleId=this.zaEmpRoleId;
        this.wardModal=null; 
        this.fromEmpName=this.uccRoleCode
      }else {
        this.fromEmpId=this.wmEmpId;  ///WARD MANAGER 
        this.fromEmpRoleId=this.wmEmpRoleId;
        this.fromEmpName=this.wmEmpName;
      }
      if(this.assignTypeModal==null){
        alert("Accountant/Ward Manager Type is required!")
        return;
      }
      if(this.zoneModal==null){
        alert("Zone is required.")
        return;
      }
      if(this.accountantModal==null){
        alert("Zonal Accountant is required.")
        return;
      }
      if(this.assignTypeModal==2){
        //this.wardModal=null;
        //this.wmEmpId=null;
        if(this.wardModal==null){
          alert("Ward is required.")
          return;
        }
        if(this.wardManagerModal==null){
          alert("Ward Manager is required.")
          return;
        }
      } 
      if(this.denoModel==null){
        alert("Denomination is required.")
        return;
      }
      if(this.startSrNoModal==null){
        alert("Start Serial No is required.")
        return;
      }
      if(this.startSrNoModal.length!=this.endSrNoModal.length){
        this.valideEndSrNo=true
        return;
      } else{
        this.valideEndSrNo=false;
      }
      if(this.countModal<=0 && this.amountModal<=0){
        alert("Coupon Count/Amount is invalid!")
        return;
      }
      var returnJson={
        "ID":null,
        "PRJID":this.prjId,
        "FROMEMP":this.fromEmpId,
        "FROMROLEID":this.fromEmpRoleId, 
        "TOEMP":this.toEmpId,          //Ward manager/ZA EMP ID
        "TOROLEID":this.toEmpRoleId,  //Ward Mamager/ZA EMP ID
        "UCCHEADID":this.fromEmpId,      
        "DENOMINATION":this.denoModel, 
        "FIRSTSRNO":this.serialCode+this.firstSrNoModal.toUpperCase(),
        "FROMSRNO":this.serialCode+this.startSrNoModal.toUpperCase(),
        "TOSRNO":this.serialCode+this.endSrNoModal.toUpperCase(), 
        "QTY": this.countModal,
        "AMOUNT": this.amountModal,
        "ZONEID":this.zoneModal, 
        "WARDID":this.wardModal,
        "WMID":this.wmEmpId?this.wmEmpId:null,  
        "ISACTIVE":1, 
        "ISSUEDATE":moment(this.returnDate).format('YYYY-MM-DD'),
        //"ZAID":this.zaEmpId,
        //"ZANAME":this.fromEmpName?this.fromEmpName:null, 
        "USERID":this.userId,
        "SOURCEFROM":"RETURN"
       }
       this.couponReturnArray.push(returnJson)
       console.log("return data array",this.couponReturnArray) 
      if(this.couponReturnArray.length<=15){ 
        this.rowCount=this.rowCount+1
        this.rowDataAmount=Number(this.rowDataAmount)+Number(this.amountModal) 
        this.isAddBtnActive=false 
        this.limitOverMsg=false; 
        this.isSaveActive=false;
       } 
       if(this.couponReturnArray.length>14){ 
        this.isAddBtnActive=true
        this.limitOverMsg=true;  
        this.isSaveActive=false;
        return;
       } 
      }

       /*
       * Delete Data from Array list
       */ 
      deleteCoupon(index,data){   
        this.couponReturnArray.splice(index,1)  
        this.rowCount=this.rowCount-1
        this.rowDataAmount=Number(this.rowDataAmount)-Number(data.AMOUNT) 
          if(this.couponReturnArray.length==0){ 
              this.isAddBtnActive=false
              this.isSaveActive=true;
              this.rowCount=0;
              this.rowDataAmount=0; 
              this.reSuccess=false;
              this.reError=false;
              this.isExcelDisable=false;
            } 
           if(this.couponReturnArray.length>0 && this.couponReturnArray.length<=15){
              this.isAddBtnActive=false
              this.limitOverMsg=false  
              this.isSaveActive=false;
            }  
      } 

     //Save Coupon Return Details
      saveCouponReturnDetails(){
        if(this.couponReturnArray.length>0){
            this.http.post(environment.apiUrl + 'uccnew/saveCouponAssignment',this.couponReturnArray).subscribe(data =>{ 
              var code=data.json();  
              var responceCode=code[0].RESPONSECODE 
              var responceMsg =code[1].RESPONSEMESSAGE 
              this.jsonDataResult=code[2].UPLOADRESULT 
              if(responceCode=="200"){
                this.reSuccess=true;
                this.reError=false;
                this.returnResponceMsg=responceMsg
                this.getCouponReturnDataList() 
                setTimeout(()=>{ 
                  this.reSuccess=false;
                  this.reError=false;
                  this.couponReturnArray=[];
                  this.isSaveActive=true;
                }, 1000); 
              }
              else{ 
                this.isExcelDisable=true
                this.showErrorRow(JSON.parse(this.jsonDataResult)) 
                this.reSuccess=false;
                this.reError=true;
                this.returnResponceMsg=responceMsg 
              }  
          });  
        }
     }  
     
      
 showErrorRow(data){
  var errorRow = []
  for(var i = 0;i<data.length;i++){
       errorRow.push(data[i])
  } 
   for(var i =0;i<this.couponReturnArray.length;i++){
      for(var j = 0;j<errorRow.length;j++){
      if(this.couponReturnArray[i].FIRSTSRNO == errorRow[j].FIRSTSRNO){
        this.couponReturnArray[i].error = true
        this.couponReturnArray[i].remark = errorRow[j].ERRORREMARK
      }
    }
     
   }
}    
     
 //**********************************EDIT COUPON RETURN SECTION********************************************************* */
        


  //GET ZONAL ACCOUNTANT and Ward List 
  onSelectZoneUpdt(zoneId){  
    this.zoneId=zoneId.id  
    this.getWardByProject(this.zoneId)
    this.http.get(environment.apiUrl + 'uccnew/getAccountantByZoneId?prjId='+this.prjId+'&entityId='+this.zoneId).subscribe(data =>{ 
           this.zonalAccountList= data.json();  
           if(this.zonalAccountList.length>0){ 
             this.zaEmpId=this.zonalAccountList[0].EMPID
             this.zaEmpRoleId=this.zonalAccountList[0].ROLEID
             this.zaEmpName=this.zonalAccountList[0].EMPNAME  
           }  
      }); 
    } 

  selectAccountant(entityId){
            this.http.get(environment.apiUrl + 'uccnew/getAccountantByZoneId?prjId='+this.prjId+'&entityId='+entityId).subscribe(data =>{ 
              var entityData= data.json();  
              if(entityData.length>0){
                this.zonalAccountList=entityData; 
                this.zaEmpId=entityData[0].EMPID 
                this.zaEmpRoleId=entityData[0].ROLEID
                this.zaEmpName=entityData[0].EMPNAME 
                this.accountantModal=this.zaEmpId 
                console.log("accId",this.accountantModal)    
              }else{
                this.zaEmpId=null;
                this.zaEmpRoleId=null;
                this.zaEmpName=null;
                this.accountantModal=0;
              }}); 
        } 
        //Select Ward Manager by Ward Id
        selectWMbyWardId(wardId){
          this.http.get(environment.apiUrl + 'uccnew/getEmployeeDetailsbyEntity?entityId=' +wardId+'&role=WM').subscribe(data => {
            this.wardManagerList = data.json();   
            this.wardManagerModal=this.wardManagerList[0].EMPID 
            this.wmEmpId=this.wardManagerList[0].EMPID
            this.wmEmpRoleId=this.wardManagerList[0].ROLEID
            console.log("this.wmEmpId1",this.wmEmpId) 
            console.log("this.wmEmpRoleId1",this.wmEmpRoleId) 
          })
        }
        //on select Ward Manager
        onSelectWardManager(data){ 
         this.wmEmpId=data.EMPID 
         this.wmEmpRoleId=data.ROLEID
         this.wmEmpName=data.EMPNAME  
        } 
        // UPDATE COUPON RETURN SECTION
        editCouponReturn(item){
           $("#editCupReturnModal").modal("show") 
           this.returnId=item.ID;
           var wardId=item.WardID
           if(wardId==null){
            this.showWardMgrDiv=false;
            this.assignTypeModal = this.assignTypJson[0].ID;
           }else{
            this.showWardMgrDiv=true;
            this.assignTypeModal = this.assignTypJson[1].ID;
           }  
           this.zoneModal=item.ZoneID
           this.selectAccountant(item.ZoneID) 
           this.denoModel=item.Denomination 
           this.serialCode=item.FirstSrNo.slice(0,4)
           this.startSrNoModal=item.FromSrNo.slice(4,10)
           this.endSrNoModal=item.ToSrNo.slice(4,10)
           this.firstSrNoModal=item.FirstSrNo.slice(4,10)
           this.countModal=item.Qty
           this.amountModal=item.Amount
           //Ward Acc
           this.getWardByProject(item.ZoneID)
           this.wardModal=item.WardID 
           this.wmEmpName=item.ToEmpName
           this.selectWMbyWardId(item.WardID)
           this.wardManagerModal=item.WMID 
           //Get From Emp Id details
           if(this.assignTypeModal==1){ 
            this.fromEmpId=this.zaEmpId;   //ZONAL ACCOUNTANT
            this.fromEmpRoleId=this.zaEmpRoleId;
            this.wardModal=null; 
          }else { 
            this.fromEmpId=this.wardManagerModal;  //WARD MANAGER 
            this.fromEmpRoleId=this.wmEmpRoleId; 
          } 
        } 

       //Update Coupon Return Details
        updateCouponReturnDetails(){ 
           this.returnUpdtJason={
            "ID":this.returnId,
            "PRJID":this.prjId,
            "FROMEMP":this.fromEmpId,
            "FROMROLEID":this.fromEmpRoleId, 
            "TOEMP":this.toEmpId,         //Ward manager/ZA EMP ID
            "TOROLEID":this.toEmpRoleId,  //Ward Mamager/ZA EMP ID
            "UCCHEADID":this.fromEmpId,      
            "DENOMINATION":this.denoModel, 
            "FIRSTSRNO":this.serialCode+this.firstSrNoModal.toUpperCase(),
            "FROMSRNO":this.serialCode+this.startSrNoModal.toUpperCase(),
            "TOSRNO":this.serialCode+this.endSrNoModal.toUpperCase(), 
            "QTY": this.countModal,
            "AMOUNT": this.amountModal,
            "ZONEID":this.zoneModal,
            "ZAID":this.zaEmpId,
            "WARDID":this.wardModal, 
            "WMID":this.wardManagerModal?this.wardManagerModal:null, 
            "ISACTIVE":1, 
            "ISSUEDATE":moment(this.returnDate).format('YYYY-MM-DD'),
            "ZANAME":this.zaEmpName?this.zaEmpName:null, 
            "WMNAME":this.wmEmpName?this.wmEmpName:null, 
            "USERID":this.userId
          }
          console.log("Json Data",this.returnUpdtJason)
          this.http.post(environment.apiUrl + 'uccnew/saveCouponAssignment',this.returnUpdtJason).subscribe(data =>{ 
            var code=data.json();  
            var responceCode=code[0].RESPONSECODE 
            var responceMsg =code[1].RESPONSEMESSAGE 
            if(responceCode=="200"){
              this.editReSuccess=true;
              this.editReerror=false;
              this.editReresponceMessage=responceMsg
              this.getCouponReturnDataList(); 
              setTimeout(()=>{ 
                this.editReSuccess=false;
                this.editReerror=false;
                this.returnUpdtJason=[];
                this.isSaveActive=true;
               }, 1000); 
            }
            else if(responceCode!="200"){ 
              this.editReSuccess=false;
              this.editReerror=true;
              this.editReresponceMessage=responceMsg 
            }  
          });  
        } 
        deleteReturnModal(data){
          $("#deleteReturnModal").modal("show")   
          this.returnAssignId={
            "ID":data.ID
          }
        }


        deleteReturnEntryDetails(){
          this.http.post(environment.apiUrl + 'uccnew/deleteCouponDetails',this.returnAssignId).subscribe(data =>{ 
            var code=data.json();  
            var responceCode=code[0].RESPONSECODE 
            var responceMsg =code[1].RESPONSEMESSAGE 
            if(responceCode=="200"){
              this.delRetSuccess=true;
              this.delRetError=false;
              this.deleteRetResMsg=responceMsg
              this.getCouponReturnDataList(); 
              setTimeout(()=>{ 
                this.delRetSuccess=false;
                this.delRetError=false;
                this.couponReturnArray=[]; 
                $('#deleteReturnModal').modal('hide');  
               }, 1000); 
            }
            else if(responceCode!="200"){ 
              this.delRetSuccess=false;
              this.delRetError=true;
              this.deleteRetResMsg=responceMsg 
            }   
        });      
        }
        
        downloadExcelFile(couponReturn){
          const ws_name = 'ErrorReturnReport';
          const wb: WorkBook = { SheetNames: [], Sheets: {} };
          const ws: any = utils.json_to_sheet(couponReturn);
          wb.SheetNames.push(ws_name);
          wb.Sheets[ws_name] = ws;
          const wbout = write(wb, { bookType: 'xlsx', bookSST: true, type:'binary' });
          saveAs(new Blob([this.s2ab(wbout)], { type: 'application/octet-stream' }), 'ErrorReturnReport.xlsx');
          }
          s2ab(s) 
          {
            const buf = new ArrayBuffer(s.length);
            const view = new Uint8Array(buf);
            for (let i = 0; i !== s.length; ++i) {
            view[i] = s.charCodeAt(i) & 0xFF;
            };
            return buf;
          }


          couponHistory(BookletNo)
          {  
            console.log("aa",BookletNo)
            this.broadcaster.broadcast('couponHistory',BookletNo);  
          }




     ngOnInit(){ 
      this.prjId = this.auth.getAuthentication().projectId  
      this.userId = this.auth.getAuthentication().id   
      this.startDate = moment(new Date()).format('YYYY-MM-DD');
      this.endDate= moment(new Date()).format('YYYY-MM-DD');  
      this.getCouponReturnDataList();
      this.assignTypeData();
      this.getZoneByProject(this.prjId)
      this.assignTypeModal = this.assignTypJson[0].ID;
      this.getDenoSeries();
      this.getIssuerDetails();
     } 
    
   
 } 


        
