import { Component } from '@angular/core';
import { Http } from '@angular/http'
import { environment } from '../../../../environments/environment';
import { Observable } from 'rxjs/Observable';
import { AuthService } from '../../../_services/index';
import { LoaderService } from '../../../_services/loader.service';
import Swal from 'sweetalert2'
//For KENDO UI
import { process, State ,aggregateBy } from '@progress/kendo-data-query';
import { GroupDescriptor, DataResult } from '@progress/kendo-data-query';
import {GridDataResult,DataStateChangeEvent} from '@progress/kendo-angular-grid';
import { ExcelExportData } from '@progress/kendo-angular-excel-export'; 
import * as _moment from 'moment';
import * as _rollupMoment from 'moment';
const moment = _rollupMoment || _moment;





declare var $: any;  

//const distinctZone = data => data.filter((x, idx, xs) => xs.findIndex(y => y.zoneID === x.zoneID) === idx);
//const distinctDeno = data => data.filter((x, idx, xs) => xs.findIndex(y => y.denomination === x.denomination) === idx);
 

@Component({
    selector: 'collectionReceived-cmp',
    templateUrl: './collectionReceived.component.html' ,  
  })

  export class CollectionReceivedComponent {  
    public prjId:any;
    public showLoader:boolean
    public userId:any;
    public collReceivedList:any;
    public total:any;
    public totalIncentiveAmnt:any;
    public totalReceivedAmnt:any;
    public userName:any;
    public secondColumns:any
    public firstColumns:any
    public defaultStartDate:any;
    public defaultEndDate:any;
    public dataRangeModal:any;
    public startDate:any;
    public endDate:any;
    public aggregates: any[] = [{field: 'TotalAmount', aggregate: 'sum'},{field: 'IncentiveAmount', aggregate: 'sum'},{field: 'ReceivedAmount', aggregate: 'sum'}];
    public state: State = {
      skip: 0,
      take: 12, 
      filter: {
        logic: 'and',
        filters: []
      }
    };
    
    public allData(): ExcelExportData {
      const result: ExcelExportData =  {
          data: this.collReceivedList
      };
      return result;
     } 
    public distinctZone: any[]
    public distinctDeno: any[]
    public paymentStatus: Array<string> = ["PENDING", "RECEIVED", "DEPOSITED"]; 
    
    public groups: GroupDescriptor[] = [];
    public view: Observable<GridDataResult>;
    public gridView: DataResult;
    public groupChange(groups: GroupDescriptor[]): void {
      this.groups = groups;
      this.loadProducts();
    }
    
    private loadProducts(): void {
      this.gridDataCollReceived = process(this.collReceivedList, { group: this.groups }); 
     
    }
    public gridDataCollReceived: GridDataResult 
    
    //distinctAmount
    
    constructor(private http: Http,private auth : AuthService,private loaderService: LoaderService){ 
      this.loaderService.status.subscribe((val: boolean) =>{
        this.showLoader = val;
      }); 
      var date = new Date();
      this.allData = this.allData.bind(this);
      var firstDay = new Date(date.getFullYear(), date.getMonth(), 1);
      //var lastDay = new Date(date.getFullYear(), date.getMonth() + 1, 0); 
      this.defaultStartDate = (firstDay.getFullYear()) + '-' + (firstDay.getMonth() + 1) + '-' + firstDay.getDate(); 
      this.defaultEndDate = (date.getFullYear()) + '-' + (date.getMonth() + 1) + '-' + date.getDate(); 
      this.dataRangeModal= {beginDate: {year: date.getFullYear(), month: date.getMonth()+1, day: date.getDate()}, endDate: {year: date.getFullYear(), month: date.getMonth()+1, day: date.getDate()}};
     }   
    
  /*
   *select start Date Nad To date
  */
  onDateRangeChanged(dataRange)
  {  
    if(dataRange.beginDate.day>0){ 
      this.startDate= dataRange.beginDate.year + "-"  + dataRange.beginDate.month+ "-" + dataRange.beginDate.day 
      this.endDate = dataRange.endDate.year + "-"  + dataRange.endDate.month  + "-" + dataRange.endDate.day 
      this.getCollectionReceived(); 
    }
    else if(dataRange.beginDate.day==0){
        this.startDate= this.defaultStartDate
        this.endDate = this.defaultEndDate
        this.getCollectionReceived(); 
    }  
  } 

     /*
     * UCC COLLECTION RECEIVED 
     */
    getCollectionReceived(){ 
      this.loaderService.display(true); 
      this.http.get(environment.apiUrl + 'uccnew/getCollectionReceived?prjId='+this.prjId+'&startDate='+this.startDate+'&endDate='+this.endDate).subscribe(data =>{ 
               this.collReceivedList=data.json(); 
               this.firstColumns = []
               this.secondColumns = []
               if(this.collReceivedList.length>0){
               for(var k in this.collReceivedList[0]) {
                if(k.substr(0,1) == "D"){
                    this.firstColumns.push(k)
                }else{
                  if(k != "TotalAmount" && k !="IncentiveAmount" && k!="ReceivedAmount" && k!="prjid" && k!= "zoneid" && k!= "status")
                  {
                    this.secondColumns.push(k);
                  } 
                } 
              }  
               this.loaderService.display(false);
               this.total = aggregateBy(this.collReceivedList, this.aggregates)["TotalAmount"].sum;               
               this.totalIncentiveAmnt = aggregateBy(this.collReceivedList, this.aggregates)["IncentiveAmount"].sum; 
               this.totalReceivedAmnt = aggregateBy(this.collReceivedList, this.aggregates)["ReceivedAmount"].sum;  
               this.gridDataCollReceived = process(this.collReceivedList, this.state); 
               }
               else{ 
                this.collReceivedList=[]
                this.gridDataCollReceived = process([], this.state); 
                this.total = null              
                this.totalIncentiveAmnt = null
                this.totalReceivedAmnt = null
                this.loaderService.display(false)
               } 
           });  
     }

    /*
     * Collection Filter
    */
    public dataStateChange(state: DataStateChangeEvent): void {
      this.state = state;
      this.gridDataCollReceived = process(this.collReceivedList, this.state); 
      if (state && state.group) { 
        state.group.map(group => group.aggregates = this.aggregates);
        this.total = aggregateBy(this.collReceivedList, this.aggregates)["TotalAmount"].sum;
        this.totalIncentiveAmnt = aggregateBy(this.collReceivedList, this.aggregates)["IncentiveAmount"].sum;
        this.totalReceivedAmnt = aggregateBy(this.collReceivedList, this.aggregates)["ReceivedAmount"].sum; 
      } 
    }

    /**
     * To change Payment Status
    */
    paymentStatusChange(data,status){ 
      console.log("data",data,'status',status)
      var zoneId=data.zoneid
      var collDate=data.COLLECTIONDATE
      //var statusId=data.id
      var currStatus=status 
      Swal({
        title: 'Are you sure?',
        text: "You are be able to revert this!",
        type: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Yes, Convert it!'
      }).then((result) => {
        if (result.value) { 
          this.http.get(environment.apiUrl + 'uccnew/updateCollectionStatus?prjId='+this.prjId+'&status='+currStatus+'&zoneId='+zoneId+'&collecDate='+collDate).subscribe(data =>{  
            var status = data.json().status; 
              if (status == "ok") 
              {
                this.getCollectionReceived()
                Swal(
                  "Status Changed ",
                  "Status Changed",
                  'success'
                )
              } else {
                Swal(
                  "Some Internal Problem",
                  'error'
                )
              }

              
            });
        }
      }) 
    } 
     ngOnInit(){ 
      this.prjId = this.auth.getAuthentication().projectId  
      this.userId = this.auth.getAuthentication().id 
      this.userName = this.auth.getAuthentication().userName 
      this.startDate = moment(new Date()).format('YYYY-MM-DD');
      this.endDate= moment(new Date()).format('YYYY-MM-DD');  
      this.getCollectionReceived()
     }  
  }
