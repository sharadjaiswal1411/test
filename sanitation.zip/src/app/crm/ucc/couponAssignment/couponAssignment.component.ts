import { Component } from '@angular/core';
import { Http } from '@angular/http'
import { environment } from '../../../../environments/environment'; 
import { Observable } from 'rxjs/Observable'; 
import { AuthService } from '../../../_services/index';
import * as _ from 'underscore'; 
import { LoaderService } from '../../../_services/loader.service';
import * as _moment from 'moment';
import * as _rollupMoment from 'moment';
//For KENDO UI
import { process, State,aggregateBy} from '@progress/kendo-data-query';
import { GroupDescriptor, DataResult } from '@progress/kendo-data-query';
import {GridDataResult,DataStateChangeEvent} from '@progress/kendo-angular-grid'; 
import { ExcelExportData } from '@progress/kendo-angular-excel-export'; 
import { utils, write, WorkBook } from 'xlsx';  
import { saveAs } from 'file-saver';  
import { Broadcaster } from '../../../../environments/broadcaster';
const moment = _rollupMoment || _moment;

declare var $: any;  
const distinctDeno = data => data.filter((x, idx, xs) => xs.findIndex(y => y.Denomination === x.Denomination) === idx); 
const distinctZone = data => data.filter((x, idx, xs) => xs.findIndex(y => y.Zone === x.Zone) === idx); 
const distinctWard = data => data.filter((x, idx, xs) => xs.findIndex(y => y.Ward === x.Ward) === idx); 
const distinctBeat = data => data.filter((x, idx, xs) => xs.findIndex(y => y.Beat === x.Beat) === idx); 
@Component({
    selector: 'couponAssignment-cmp',
    templateUrl: './couponAssignment.component.html' ,
  })

  export class CouponAssignComponent {   
  public isRole:any;
  public prjId:any;
  public userId:any; 
  public uccGrnList:any;
  public showLoader:boolean;
  public defStartDate:any;
  public defEndDate:any;
  public startDate:any;
  public endDate:any;
  public distinctDeno: any[]
  public distinctZone: any[]
  public distinctWard: any[]
  public distinctBeat:any[] 
  public groups: GroupDescriptor[] = [];
  public view: Observable<GridDataResult>;
  public gridView: DataResult;
  public gridDataCouponAssign: GridDataResult 
  public couponAssignMantList:any;
  public ddlZoneList:any;
  public assignType:any;
  public zoneId:any;
  wardAccountList:any; 
  accountantModal:any;
  wardList:any;  
  wardManagerList:any;
  wardManagerModal:any;
  dataRangeModal:any;
  assignmentDate:any;
  denoList:any;
  denoModel:any;
  amountModal:any;
  countModal:any;
  serialCode:any;
  startSrNoModal:any;
  endSrNoModal:any;
  couponAssignmentArray=[];  
  uccRoleCode:any;
  firstSrNoModal:any;
  zoneModal:any;
  wardModal:any;
  success=false;
  error=false;
  responceMessage:any;
  isSaveActive=true;
  wmEmpId:any;
  wmEmpRoleId:any;
  fromEmpId:any;
  fromEmpRoleId:any;
  beatList=[];
  beatId:any;
  beatName:any;
  slectedVehiclesId:any;
  vehicleList=[];
  driverList = [];
  selectedDriverId:any;
  driverName:any;
  selectedDriver:any;
  dvrEmpId:any; 
  newBeatNameModal:any;
  beatResponceMsg:any;
  beatsuccess=false;
  beaterror=false;
  beatModal:any;
  vehiclesListAll:any;
  assignTypeModal:any;
  driverModal:any;
  showWardMgrDiv=false;
  assignToId:any;
  toEmpId:any;
  toEmpRoleId:any;
  toEmpName:any;
  wmEmpName:any;
  zaEmpId:any;
  zaEmpRoleId:any;
  zaEmpName:any;
  vehicleListAll:any;
  vehAssignSuccess=false;
  vehAssignError=false; 
  vehiclesForAssign:any;
  vehAssignMsg:any;
  newVehicleModal:any;
  driverListAll:any; 
  newDriverModel:any;
  dvrAssignSuccess=false;
  dvrAssignError=false;
  dvrAssignMsg:any;
  isDvrAssignActive=true
  isDvrCretActive=true;
  newDriverModal:any;
  newDvrMobileModal:any;
  dvrCrtSuccess=false;
  dvrCrtError=false;
  dvrCreateMsg:any;
  vehicleModal:any;
  startBookletNo:any;
  valideEndSrNo=false;
  startInputValue:any; 
  totalCount:any;
  totalAmount:any;
  editSuccess=false;
  editError=false;
  assignId:any;
  rowCount:any;
  rowDataAmount:any; 
  updtResponceMessage:any;
  isAddBtnActive=false 
  limitOverMsg=false; 
  chkEndBookletno:any;
  isZoneDisable=true
  jsonDataResult:any;
  isexcelDisable=false
  assignmentId:any;
  delAssignSuccess=false;
  delAssignError=false;
  deleteAssignResMsg:any; 
  public aggregates: any[] = [{field: 'Qty', aggregate: 'sum'},{field: 'Amount', aggregate: 'sum'}];
  public state: State = {
    skip: 0,
    take: 10, 
    filter: {
      logic: 'and',
      filters: []
    }
  };

  public allData(): ExcelExportData {
    const result: ExcelExportData =  {
        data: this.couponAssignMantList
    };
    return result;
   } 
  public groupChange(groups: GroupDescriptor[]): void {
    this.groups = groups;
    this.loadProducts();
  } 
  private loadProducts(): void {
    this.gridDataCouponAssign = process(this.couponAssignMantList, { group: this.groups });  
  } 

    constructor(private http: Http,private auth : AuthService,private loaderService: LoaderService,private broadcaster: Broadcaster){ 
        this.loaderService.status.subscribe((val: boolean) =>{
          this.showLoader = val;
        }); 
        this.allData = this.allData.bind(this);
        var date = new Date();
        this.assignmentDate=date
        var firstDay = new Date(date.getFullYear(), date.getMonth(), 1);
        var lastDay = new Date(date.getFullYear(), date.getMonth() + 1, 0); 
        this.defStartDate = (firstDay.getFullYear()) + '-' + (firstDay.getMonth() + 1) + '-' + firstDay.getDate(); 
        this.defEndDate = (lastDay.getFullYear()) + '-' + (lastDay.getMonth() + 1) + '-' + lastDay.getDate(); 
        this.dataRangeModal= {beginDate: {year: date.getFullYear(), month: date.getMonth()+1, day: date.getDate()}, endDate: {year: date.getFullYear(), month: date.getMonth()+1, day: date.getDate()}};  
        this.assignType=
        [{  
        "ID":1,
        "VALUE":"Assign To Accountant", 
        },
        {  
          "ID":2,
          "VALUE":"Assign To Ward Manager", 
        }]
     }    
     
    /*
    * Get GRN INVENTORY LIST
    */  
    getCouponAssignmentList(){ 
             this.loaderService.display(true); 
             var sourceFrom="ASSIGNMENT"
             this.http.get(environment.apiUrl + 'uccnew/getCouponAssignmentList?prjId='+this.prjId+'&userId='+this.userId+'&startDt='+this.startDate+'&endDt='+this.endDate+'&sourceFrom='+sourceFrom).subscribe(data =>{ 
             this.couponAssignMantList= data.json(); 
             if(this.couponAssignMantList.length>0){ 
              this.distinctDeno=distinctDeno(this.couponAssignMantList); 
              this.distinctZone=distinctZone(this.couponAssignMantList);
              this.distinctWard=distinctWard(this.couponAssignMantList);
              this.distinctBeat=distinctBeat(this.couponAssignMantList);
              this.totalCount = aggregateBy(this.couponAssignMantList, this.aggregates)["Qty"].sum;  
              this.totalAmount = aggregateBy(this.couponAssignMantList, this.aggregates)["Amount"].sum;   
              this.gridDataCouponAssign=process(this.couponAssignMantList, this.state);  
              this.loaderService.display(false);
             }
             else if(this.couponAssignMantList.length==0){ 
               this.gridDataCouponAssign=null;
               this.loaderService.display(false); 
             }
        });
      }
      /*
 * filter The Grid Data
*/
  public dataStateChange(state: DataStateChangeEvent): void {
    this.state = state;
    this.gridDataCouponAssign=process(this.couponAssignMantList, this.state);  
    if (state && state.group) {
      state.group.map(group => group.aggregates = this.aggregates);  
      this.distinctDeno=distinctDeno(this.couponAssignMantList); 
      this.distinctZone=distinctZone(this.couponAssignMantList);
      this.distinctWard=distinctWard(this.couponAssignMantList);
      this.distinctBeat=distinctBeat(this.couponAssignMantList); 
      this.totalCount = aggregateBy(this.gridDataCouponAssign.data, this.aggregates)["Qty"].sum;  
      this.totalAmount = aggregateBy(this.gridDataCouponAssign.data, this.aggregates)["Amount"].sum;   
      this.gridDataCouponAssign=process(this.couponAssignMantList, this.state);  
      } 
  } 
  
/*
*select start Date Nad To date
*/
 onDateRangeChanged(dataRange)
 {  
   if(dataRange.beginDate.day>0){ 
     this.startDate= dataRange.beginDate.year + "-"  + dataRange.beginDate.month+ "-" + dataRange.beginDate.day 
     this.endDate = dataRange.endDate.year + "-"  + dataRange.endDate.month  + "-" + dataRange.endDate.day 
     this.getCouponAssignmentList(); 
   }
   else if(dataRange.beginDate.day==0){
     this.startDate= this.defStartDate
     this.endDate = this.defEndDate
     this.getCouponAssignmentList(); 
   }  
 } 
  
      
      /**
       * Get Assignment Coupon modal popup
       */
      couponAssignmentModal(){
        $('#couponAssignmentModal').modal({backdrop: 'static', keyboard: false}) 
        this.clearAllFiesls();
        this.rowCount=0;
        this.rowDataAmount=0;  
        this.limitOverMsg=false  
        this.isSaveActive=true;
        this.couponAssignmentArray=[];
        this.isexcelDisable=false;
        $('#couponAssignmentModal').modal('show');   
      } 

    /*
     * Get Zone By Prj Id
    */
    getZoneByProject(prjid){    
    this.http.get(environment.apiUrl + 'consumer/getZoneByProject?prjid='+prjid+'&oemid=7').subscribe(data =>{ 
             this.ddlZoneList= data.json(); 
             console.log(this.ddlZoneList)
        }); 
    } 

     
    couponHistory(BookletNo)
      {  
        this.broadcaster.broadcast('couponHistory',BookletNo);  
      }
   

 
   //Assign Ward mgr or Zonal Accountant
   onSelectAssignTo(data){ 
    this.clearallFields();
    if(data!=null){ 
      this.assignToId=data.ID
      this.assignTypeModal=this.assignToId
      if(data.ID=="2"){
        this.showWardMgrDiv=true;
      }else{ 
        this.showWardMgrDiv=false;
      }
    }else{
      alert("Please Select Assign Type")
    }
   } 

   clearallFields(){
    // this.zoneModal=null;
    // this.accountantModal=null;
     this.wardModal=null;
     this.wardManagerModal=null;
     this.beatModal=null;
     this.vehicleModal=null;
     this.driverModal=null;
     this.denoModel=null;
     this.serialCode=null;
     this.startSrNoModal=null;
     this.endSrNoModal=null;
     this.firstSrNoModal=null;
     this.countModal=null;
     this.amountModal=null;
     this.wmEmpId=null;
     this.dvrEmpId=null;
     this.slectedVehiclesId=null;
     this.beatId=null;
   }
    
  //Get Employee Details
   getEmployeeDetails(entityId){
     this.http.get(environment.apiUrl + 'uccnew/getAccountantByZoneId?prjId='+this.prjId+'&entityId='+entityId).subscribe(data =>{ 
              var entityData= data.json();  
              if(entityData.length>0){
                this.zaEmpId=entityData[0].EMPID 
                this.zaEmpRoleId=entityData[0].ROLEID
                this.zaEmpName=entityData[0].EMPNAME
              }else{
                this.zaEmpId=null;
                this.zaEmpRoleId=null;
                this.zaEmpName=null;
              } 
         }); 
   } 
   
  //Select Zonal accountant Data
   onSelectAccountant(data){
     if(data==null){
       alert("accountant is Required") 
       console.log("accountant",data)  
     } 
   } 
  
   //GET ACCOUNTANT/Ward 
   onSelectZone(zoneName){  
    this.zoneId=zoneName.id  
    this.getEmployeeDetails(this.zoneId); //Get accountant ID
    this.getWardByProject(this.zoneId);  //get Ward
    this.http.get(environment.apiUrl + 'uccnew/getAccountantByZoneId?prjId='+this.prjId+'&entityId='+this.zoneId).subscribe(data =>{ 
            this.wardAccountList= data.json();  
            if(this.wardAccountList.length>0){
              this.accountantModal=this.wardAccountList[0].EMPID
              this.zaEmpId=this.wardAccountList[0].EMPID
              this.accountantModal=this.zaEmpId
              console.log("ZA EMP ID",this.accountantModal)
            }  
       }); 
     } 

     //GET WARD LIST
     getWardByProject(entityid){ 
            this.zoneId=entityid;  
            this.http.get(environment.apiUrl + "consumer/getZoneByProject?prjid="+this.prjId+"&oemid=8&entityid="+entityid).subscribe(data =>{ 
            this.wardList=data.json();  
            }); 
      } 
      
      //Get Ward Manager as per ward Selection 
      onSelectWard(data){ 
         this.getBeatByWard(data.id, 9)
         this.http.get(environment.apiUrl + 'uccnew/getEmployeeDetailsbyEntity?entityId=' +data.id+'&role=WM').subscribe(data => {
         this.wardManagerList = data.json();  
         if(this.wardManagerList.length>0){
           this.wardManagerModal=this.wardManagerList[0].ID
           this.wmEmpId=this.wardManagerList[0].EMPID
           this.wmEmpRoleId=this.wardManagerList[0].ROLEID
           this.wmEmpName=this.wardManagerList[0].EMPNAME
           console.log("wmEmpName",this.wmEmpName)
         }else{
          this.wardManagerModal=null;
          this.wmEmpId=null;
          this.wmEmpRoleId=null;
          this.wmEmpName=null;
         }
       })
      }



      onSelectWardManager(data){
        if(data){ 
          this.wmEmpId=data.EMPID
          this.wmEmpRoleId=data.ROLEID
          this.wmEmpName=data.EMPNAME
        } 
      }
      //Get Beat By Ward selection 
      getBeatByWard(entityid, oemid) {
      this.beatList = []
      this.http.get(environment.apiUrl + 'entity/getEntityByParents' + "?prjid=" + this.prjId + "&entityid=" + entityid + "&oemid=" + oemid).subscribe(data => {
        if (data.json().length > 0) {
          this.beatList = data.json(); 
        }
      })
    }
   
    //On select Beat get Vehicle
    onSelectBeat(data){
      this.beatId = data.id
      this.beatName = data.entityName
      this.slectedVehiclesId = null
      this.getVehiclesByBeat(data)
    }
    //get Vehicle List
    getVehiclesByBeat(data) {
      this.vehicleList = []
      this.http.get(environment.apiUrl + 'entity/getVehiclesByEntity' + "?prjid=" + this.prjId + "&entityid=" + data.id + "&isassigned=" + 1).subscribe(data => {
      this.vehicleList = data.json(); 
      })
    }


   //get Driver List on select Vehicle list
    getDriverByVehicles(data) {
      this.slectedVehiclesId= data.vehID
      this.driverList = []
      this.selectedDriverId = null
      this.driverName =  null
      this.http.get(environment.apiUrl + 'entity/getDriverByVehicles' + "?vehid=" + this.slectedVehiclesId ).subscribe(data => {
        var result = data.json() 
        if (result.status == "ok") {
          this.driverList = data.json().data;
        }else{
          this.driverList = []
        }
      })
    }
  
    //Select Driver
    onSelectDriver(data){ 
      this.selectedDriver = data
      this.driverName = data.empname 
      this.dvrEmpId=data.empid 
    }


      /***
       * Bind Denomination as per proiject Wise
       * */
      getDenoSeries(){
        this.http.get(environment.apiUrl + 'uccnew/getDenominations?prjId='+this.prjId).subscribe(data =>{ 
          this.denoList= data.json();   
        });  
      }
      
      onSelectDeno(coupAmount){ 
        if(coupAmount!=null){  
        //this.denoIsRequired=false;
        this.denoModel=coupAmount.denomination
        var len = coupAmount.denomination.toString().length 
         this.amountModal=Number(coupAmount.denomination)*Number(this.countModal) 
         if(len==3){
           this.serialCode=coupAmount.series+coupAmount.denomination  
          } 
         if(len==2){
           this.serialCode=coupAmount.series+'0'+coupAmount.denomination 
          }
         if(len==1)
          {
           this.serialCode=coupAmount.series+'00'+coupAmount.denomination 
          } 
        }else{
          //this.denoIsRequired=true;
        } 
      } 
     /***
       * Caliculate Start serial No and End Serials NO
       * */ 
      firstSerialNo(data){ 
        if(data!=null){  
        //this.firstSrNoRequired=false;
        this.startSrNoModal=data
        var srNo=data.slice(2,10) 
        var code=data.slice(0,2) 
        var startLen=srNo.toString().length         
       if(startLen>2){
        var endSrno=parseInt(srNo)+99 
        this.endSrNoModal=code+this.pad(endSrno,startLen)  
        this.countModal=100;
        this.amountModal=this.denoModel*100
       } 
       else{ 
       this.startSrNoModal=null;
       this.endSrNoModal=null;
       this.amountModal=0;
       this.countModal=0;
       }
      } else{
        //this.firstSrNoRequired=true; 
      }
    }   

    /*
    * get Issuer Details
    */ 
   getIssuerDetails(){
    this.getZoneByProject(this.prjId)
    this.http.get(environment.apiUrl + 'uccnew/getUccIssuerDetails?userId='+this.userId).subscribe(data =>{ 
             var empDetailsList=data.json(); 
             this.fromEmpId=empDetailsList[0].empId
             this.fromEmpRoleId=empDetailsList[0].roleId 
             this.uccRoleCode=empDetailsList[0].roleCd 
             console.log("uccRoleCode",this.uccRoleCode); 
             if(this.uccRoleCode=="ACC"){
              this.isZoneDisable=true
              this.assignTypeModal = this.assignType[1].ID; 
              this.isRole = true
              this.showWardMgrDiv=true;
              this.getzoneAndzonalAccountant(); 
            } else{
              this.isZoneDisable=false
              this.assignTypeModal = this.assignType[0].ID;
              this.isRole = false
              this.showWardMgrDiv=false;
            } 
           }); 
     }   
    
      //get zone by default selected in case of zonal accountant only 
      getzoneAndzonalAccountant(){
        this.http.get(environment.apiUrl + 'uccnew/getZoneWardbyUserId?prjid='+this.prjId+'&userId='+this.userId).subscribe(data =>{ 
          var zone =data.json();  
          this.zoneModal= zone[0].id 
          this.selectAccountant(this.zoneModal)
          this.getWardByProject(this.zoneModal)
        });      
      }
      

       //get Index of denomination 
       getIndexOfDenomination(denomination){
        var searchTerm = denomination,
        index = -1;
          for(var i = 0, len = this.denoList.length; i < len; i++) {
             if (this.denoList[i].denomination == searchTerm) {
              index = i;
              return index
           }
        }
      }


//****************************CHECK BOOK LET NO*********************************** */
    checkBookLetNo(data){   
      if(this.serialCode!=null){
        if(data!==""){ 
        this.startInputValue=data.slice(2,data.length) 
        var allSeries=this.serialCode+data
        this.http.get(environment.apiUrl + 'uccnew/getBookletNo'+"?bookLetNo="+allSeries).subscribe(data => {
          if(data.json().statusCode == 402){
            alert("Invalid Sr No")
            return;
          }
          var result = data.json().data  
          if(result[0].BOOKLETNO){
          var series=result[0].BOOKLETNO 
          this.startBookletNo=series.toUpperCase();
          if(series.length>4){
            this.firstSrNoModal=series.slice(4,series.length)  
          } 
          var len=Number(this.firstSrNoModal.toString().length)-2  
          var startNum=this.firstSrNoModal.slice(2,series.length)
          var code=this.firstSrNoModal.slice(0,2) 
          var endendNum=parseInt(startNum)+99         
          this.endSrNoModal=code+this.pad(endendNum,len) 
          if(Number(endendNum)>=Number(this.startInputValue)){
            this.countModal=(Number(endendNum)-Number(this.startInputValue))+1  
            this.amountModal=Number(this.countModal)*Number(this.denoModel)
            this.valideEndSrNo=false;
          }else{
            this.countModal=0;
            this.amountModal=0;
          } 
        }
        });
      }else{
        this.firstSrNoModal=null;
        this.endSrNoModal=null;
      }
      }else{
        this.firstSrNoModal=null;
        this.endSrNoModal=null;
      }
      }  
      //To Increase The Sr no auto increatemented
      pad(str,size){
        var s = String(str);
        while (s.length < (size || 2)) {s = "0" + s;}
        return s;
      }
 
      //Validate End Serial No. 
      validateEndSrNo(data){
        if(data!==""){ 
          var endInputValue=data.slice(2,data.length) 
              this.valideEndSrNo=false;      
              if(Number(endInputValue)>=Number(this.startInputValue)){ 
                this.countModal=(Number(endInputValue)-Number(this.startInputValue))+1
                this.amountModal=Number(this.countModal)*Number(this.denoModel)
              } 
              else{ 
                this.valideEndSrNo=true; 
                this.countModal=0;
                this.amountModal=0;               
              } 
            } else{
              this.valideEndSrNo=true;             
            }
      }

     //To save coupon assignment details
      //Add Coupon series details and push on array
      async addCouponSeries(){  
        if(this.startSrNoModal && this.endSrNoModal.length){ 
          var startSrNo = this.serialCode + this.startSrNoModal
          var endSrNo = this.serialCode + this.endSrNoModal
          let isValid = await fetch(environment.apiUrl + 'uccNew/checkValidSeries' + "?startSrNo=" + startSrNo + "&endSrNo="  + endSrNo)
          var response = await isValid.json()
          if(!response[0].keyValue){
           this.valideEndSrNo=true
            return;
          } 
        } 
         if(this.assignTypeModal==null){
            alert('Please select Assign Type')
            return;
          }
          if(this.zoneModal==null){
            alert('Please select Zone')
            return;
          }
          if(this.accountantModal==null){
            alert('Please select Zonal accountant')
            return;
          }
          //To check validation to assign for only ward manager case 
          if(this.assignTypeModal==2){
            console.log("Ward Acc","ward accountant")
            this.toEmpId=this.wmEmpId;
            this.toEmpRoleId=this.wmEmpRoleId;
            this.toEmpName=this.wmEmpName;
            if(this.wardModal==null){
              alert('Please select Ward')
              return;
            }
            if(this.wardManagerModal==null){
              alert('Please select Ward Manager')
              return;
            } 
            if(this.beatModal==null){
              alert('Please select Beat')
              return;
            }
            if(this.vehicleModal==null){
              alert('Please select Vehicle')
              return;
            }
            if(this.driverModal==null){
              alert('Please select Driver')
              return;
            }
          } else if(this.assignTypeModal==1){ 
            console.log("ZONAL ACC","Zonal accountant")
            this.toEmpId=this.zaEmpId;
            this.toEmpRoleId=this.zaEmpRoleId;
            this.toEmpName=this.zaEmpName; 
          }
          if(this.denoModel==null){
            alert('Please select Denomination')
            return;
          }
          if(this.startSrNoModal==null){
            alert('Start serial no is Required')
            return;
          }
          if(this.endSrNoModal==null){
            alert('End serial no is Required')
            return;
          } 
          if(this.startSrNoModal.length!=this.endSrNoModal.length){ 
            this.valideEndSrNo=true;
            return;
          }else if(this.startSrNoModal.length==this.endSrNoModal.length) {
            this.valideEndSrNo=false;
          } 
          if(this.chkEndBookletno){
            if(this.startBookletNo!=this.chkEndBookletno){
              this.valideEndSrNo=true 
              return;
            }else if(this.startBookletNo==this.chkEndBookletno){
              this.valideEndSrNo=false 
            }
          } 
         var assignJsonData={
          "ID":null,
          "PRJID":this.prjId,
          "FROMEMP":this.fromEmpId,
          "FROMROLEID":this.fromEmpRoleId, 
          "TOEMP":this.toEmpId,  //Ward manager/ZA EMP ID
          "UCCHEADID":this.fromEmpId,      
          "TOROLEID":this.toEmpRoleId,  //Ward Mamager/ZA EMP ID
          "DENOMINATION":this.denoModel, 
          "FIRSTSRNO":this.serialCode+this.firstSrNoModal.toUpperCase(),
          "FROMSRNO":this.serialCode+this.startSrNoModal.toUpperCase(),
          "TOSRNO":this.serialCode+this.endSrNoModal.toUpperCase(), 
          "QTY": this.countModal,
          "AMOUNT": this.amountModal,
          "ZONEID":this.zoneModal,
          "ZAID":this.zaEmpId,
          "WARDID":this.wardModal,
          "BEATID":this.beatId?this.beatId:null,
          "VEHID":this.slectedVehiclesId?this.slectedVehiclesId:null,
          "DVRID":this.dvrEmpId?this.dvrEmpId:null,
          "WMID":this.wmEmpId?this.wmEmpId:null, 
          "ISACTIVE":1, 
          "ISSUEDATE":moment(this.assignmentDate).format('YYYY-MM-DD'),
          "ZANAME":this.toEmpName?this.toEmpName:null, 
          "USERID":this.userId,
          "SOURCEFROM":"ASSIGNMENT",
          "error":false
         } 
         var pos =this.getIndexOfDenomination(this.denoModel)
         this.denoList[pos].count = this.denoList[pos].count  + 1  
         console.log("Assign ment Data",this.couponAssignmentArray) 
        if(this.couponAssignmentArray.length<15){ 
          this.rowCount=this.rowCount+1
          this.couponAssignmentArray.push(assignJsonData) 
          this.rowDataAmount=Number(this.rowDataAmount)+Number(this.amountModal) 
          this.isAddBtnActive=false 
          this.limitOverMsg=false; 
          this.isSaveActive=false;
         } 
         else{ 
          this.isAddBtnActive=true
          this.limitOverMsg=true;  
          this.isSaveActive=false;
          return;
         } 
      }
      clearAllFiesls(){ 
       //this.zoneModal=null;
        //this.accountantModal=null;
        this.wardModal=null;
        this.wardManagerModal=null;
        this.beatModal=null;
        this.vehicleModal=null;
        this.driverModal=null;
        this.denoModel=null;
        this.serialCode=null;
        this.firstSrNoModal=null;
        this.startSrNoModal=null;
        this.endSrNoModal=null;
        this.countModal=null;
        this.amountModal=null;
        this.couponAssignmentArray=[];
        this.success=false;
        this.error=false;
        this.valideEndSrNo=false;
        this.updtResponceMessage=false;
      } 

      checkDeno(deno){
        for(var i = 0;i<this.denoList.length;i++){
          if(this.denoList[i].denomination == deno){
            this.denoList[i].count--
          }
        }
      }

      /*
       * Delete Data from Array list
       */
      deleteCoupon(index,data){ 
        this.checkDeno(data.DENOMINATION)
        this.couponAssignmentArray.splice(index,1)  
        this.rowCount=this.rowCount-1
        this.rowDataAmount=Number(this.rowDataAmount)-Number(data.AMOUNT) 
          if(this.couponAssignmentArray.length==0){ 
              this.isAddBtnActive=false
              this.isSaveActive=true;
              this.rowCount=0;
              this.rowDataAmount=0; 
              this.success=false;
              this.error=false;
              this.isexcelDisable=false;
            } 
           if(this.couponAssignmentArray.length>0 && this.couponAssignmentArray.length<=15){
              this.isAddBtnActive=false
              this.limitOverMsg=false  
              this.isSaveActive=false;
            }  
      }  
//Save Coupon Assignment Details
saveCouponAssignDetails(){
  this.http.post(environment.apiUrl + 'uccnew/saveCouponAssignment',this.couponAssignmentArray).subscribe(data =>{ 
    var code=data.json();  
    var responceCode=code[0].RESPONSECODE 
    var responceMsg =code[1].RESPONSEMESSAGE 
    this.jsonDataResult=code[2].UPLOADRESULT 
    if(responceCode=="200"){
      this.success=true;
      this.error=false;
      this.responceMessage=responceMsg
      this.getCouponAssignmentList(); 
      setTimeout(()=>{ 
        this.success=false;
        this.error=false;
        this.couponAssignmentArray=[];
        this.isSaveActive=true;
        this.rowCount=0;
        this.rowDataAmount=0; 
        this.limitOverMsg=false; 
       }, 1000); 
    }
    else if(responceCode =="400"){
      this.showErrorRow(JSON.parse(this.jsonDataResult)) 
      this.isexcelDisable=true;
      this.error=true;  
      this.responceMessage=responceMsg 
    }
    else{ 
      this.success=false;
      this.error=true;
      this.responceMessage=responceMsg 
    }  
});  
} 



showErrorRow(data){
  var errorRow = []
  for(var i = 0;i<data.length;i++){
       errorRow.push(data[i])
  }

   for(var i =0;i<this.couponAssignmentArray.length;i++){
      for(var j = 0;j<errorRow.length;j++){
      if(this.couponAssignmentArray[i].FIRSTSRNO == errorRow[j].FIRSTSRNO){
        this.couponAssignmentArray[i].error = true
        this.couponAssignmentArray[i].remark = errorRow[j].ERRORREMARK
      }
    } 
   }
} 

   //********************* */Create BEAT*******************************
   createBeatModal(){
     if(this.zoneModal==null || this.wardModal==null){
       alert("Please Select Zone and Ward.")
     }else{
      this.beatsuccess=false;
      this.beaterror=false;
      this.newBeatNameModal=null;
      $('#createBeatModal').modal('show');  
     } 
   }
   //Open Vehicle Assignment Modal popup windows
   vehicleAssignment(){
    if(!this.beatModal){
      alert("Please Select Zone and Ward and Beat.")
    }else{
     this.vehAssignSuccess=false
     this.vehAssignError=false;
     this.newVehicleModal=null;
     this.getVehiclesListAll(this.beatId)
     $('#vehicleAssignModal').modal('show');  
    }  
   } 
    
   createBeat(){ 
    //this.savingBeat = true
    if(!this.wardModal){
       alert("please select ward")
       return;
    }else if(!this.newBeatNameModal){
      alert("please Enter Beat Name")
      return;
    }
    var data = {
      wardId:this.wardModal,
      BeatCd:null,
      BeatName:this.newBeatNameModal,
      kml:null
    }
    this.http.post(environment.apiUrl + 'entity/createBit',data).subscribe(data => {
    var result = data.json()
    if(result.output[0].RESPONSECODE == 200){
       this.beatsuccess=true;
       this.getBeatByWard(this.wardModal, 9)
       this.beatResponceMsg=result.output[1].RESPONSEMESSAGE
       console.log("responceMsg",this.beatResponceMsg)
       setTimeout(()=>{ 
        this.beatsuccess=false;
        this.beaterror=false;
        this.newBeatNameModal=null;
        $("#createBeatModal").modal("hide")
       }, 1000); 
     }else{
      this.beatsuccess=false;
      this.beaterror=true;
       console.log(result)
     }
    })
  } 
    //********************************** */ASSIGN VEHICLE **********************************//

  getVehiclesListAll(entityid) {
    this.http.get(environment.apiUrl + 'entity/getVehiclesByEntity' + "?prjid=" + this.prjId + "&entityid=" + entityid + "&isassigned=" + 2).subscribe(data => {
      if (data.json().length > 0) {
        this.vehicleListAll = data.json();
        console.log("vehicle List all",this.vehicleList)
      }
    })
  }

  //Select Vehicle for assign data
  selectVehiclesForAssign(data){
    this.vehiclesForAssign = data 
  }  
  //Save Vehicle assignment Details
  saveVehicleAssignment(){
    if(!this.vehiclesForAssign){
      alert("please select vehicle")
      return;
    }else if(!this.beatId){
      alert("please select Beat")
      return;
    }
    var data = {
      VEHID: this.vehiclesForAssign.vehID,
      ENTITYID:this.beatId,
      STATUS:1,
      USERID:this.userId
    }
    this.http.post(environment.apiUrl + 'entity/assignVehicleToEntity',data).subscribe(data =>{
      var result = data.json() 
      if(result.output[0].RESPONSECODE == 200){
       var obj = {id: this.beatId}
       this.getVehiclesByBeat(obj)
       this.vehAssignSuccess=true
       this.vehAssignMsg=result.output[1].RESPONSEMESSAGE
       setTimeout(()=>{ 
        this.vehAssignSuccess=false
        this.vehAssignError=false;
        this.newVehicleModal=null;
        $("#vehicleAssignModal").modal("hide")
       }, 1000); 
     }else{
       this.vehAssignError=true;
       console.log(result)
     } 
    })
  }

//*********************************ASSIGN DRIVER******************************** */
assignCreateDriver(){
   if(!this.zoneModal){
    alert("please select Zone")
    return;
   }
   if(!this.wardModal){
    alert("please select ward")
    return;
   }
   if(!this.beatModal){
    alert("please select Beat")
    return;
   } 
   else if(!this.vehicleModal){
   alert("please select Vehicle")
   return;
   }
   this.dvrAssignSuccess=false;
   this.dvrAssignError=false;
   this.dvrCrtSuccess=false;
   this.dvrCrtError=false;
   this.newDriverModal=null;
   this.newDvrMobileModal=null;
   $('#driverAssignModal').modal('show'); 
   this.getDriverListAll(); 
 }
 
 //bind existing driver
 getDriverListAll(){
  this.http.get(environment.apiUrl + 'entity/getDriverListAll'+"?prjId="+this.prjId).subscribe(data => {
    var result = data.json() 
    if (result.status == "ok") {
      this.driverListAll = result.data
    }else{
      this.driverListAll = []
    }
  })
}
//On select Assign driver
onSelectAssignDriver(data){
 if(!data){
  this.isDvrAssignActive=true
  //this.isDvrCretActive=false;
 }else{
  this.isDvrAssignActive=false
  //this.isDvrCretActive=true;
 }
}


//Save existing driver
saveAssignDriverToVehicles() {
  if(!this.slectedVehiclesId){
    alert("please select vehicle")
    return;
  }else if(!this.newDriverModel){
    alert("please select driver")
    return;
  }else if(!this.beatId){
    alert("please select Beat")
    return;
  }
  var data = {
    VEHID: this.slectedVehiclesId,
    ROLEMAPID:this.newDriverModel,
    STATUS:1,
    USERID:this.userId,
    ENTITYID:this.beatId
  }
  this.http.post(environment.apiUrl + 'entity/assignDriverToVehicles',data).subscribe(data => {
    var result = data.json()
    console.log("data",result.output[1].RESPONSEMESSAGE)
    if(result.output[0].RESPONSECODE == 200){
      var obj = {vehID: this.slectedVehiclesId}
      this.dvrAssignMsg=result.output[1].RESPONSEMESSAGE
      this.getDriverByVehicles(obj)
      this.dvrAssignSuccess=true;
      setTimeout(()=>{ 
        this.dvrAssignSuccess=false;
        this.dvrAssignError=false;
        this.newDriverModel=null;
        this.isDvrAssignActive=true;
        $("#driverAssignModal").modal("hide")
       }, 2000); 
    }else{
      this.dvrAssignError=true;
      this.dvrAssignSuccess=false;
      console.log(result)
    } 
  })
}

//CREATE DRIVER
createDriver(){
  //this.savingDriver = true
 if(!this.newDriverModal){
   alert("please enter driver name")
   return;
 }else if(!this.slectedVehiclesId){
  alert("please select vehicle")
  return;
 }else if(!this.newDvrMobileModal){
   this.newDvrMobileModal = null
 }else if(!this.beatId){
  alert("please select beat")
  return; 
 } 
 var data = {
  prjid:this.prjId,
  EMPNAME:this.newDriverModal,
  MOBILENO:this.newDvrMobileModal,
  ENTITYID:this.beatId,
  VEHICLEID:this.slectedVehiclesId,
  USERID:this.userId,
  STATUS:1
 }
 this.http.post(environment.apiUrl + 'entity/createDriver',data).subscribe(data =>{
   var result = data.json()
   if(result.output[0].RESPONSECODE == 200){
    this.dvrCrtSuccess=true;
    var obj = {vehID: this.slectedVehiclesId}
    this.getDriverByVehicles(obj)
    this.dvrCreateMsg=result.output[1].RESPONSEMESSAGE
    setTimeout(()=>{ 
      this.dvrCrtSuccess=false;
      this.dvrCrtError=false;
      this.newDriverModal=null;
      this.newDvrMobileModal=null;
      $("#driverAssignModal").modal("hide")
     }, 2000);  
   }else{
    this.dvrCrtSuccess=false;
    this.dvrCrtError=true;
     console.log(result)
   }   
}) 
} 

 
//To check the
checkDriverMobile(data){
  if(data.length>=10){ 
     this.isDvrCretActive=false;  
  }else{ 
    this.isDvrCretActive=true; 
  }  
} 


      //EDIT**********************COUPON ASSIGNMENT********************************//  
       //get Accountant Details
       selectAccountant(entityId){
        this.http.get(environment.apiUrl + 'uccnew/getAccountantByZoneId?prjId='+this.prjId+'&entityId='+entityId).subscribe(data =>{ 
          var entityData= data.json();  
          if(entityData.length>0){
            this.wardAccountList=entityData;
            this.zaEmpId=entityData[0].EMPID 
            this.zaEmpRoleId=entityData[0].ROLEID
            this.zaEmpName=entityData[0].EMPNAME 
            this.accountantModal=this.zaEmpId            
          }else{
            this.zaEmpId=null;
            this.zaEmpRoleId=null;
            this.zaEmpName=null;
            this.accountantModal=0;
          } 
        }); 
      } 

      //Select Ward Manager by Ward Id
      selectWMbyWardId(wardId){
        this.http.get(environment.apiUrl + 'uccnew/getEmployeeDetailsbyEntity?entityId=' +wardId+'&role=WM').subscribe(data => {
          this.wardManagerList = data.json();  
          console.log("WM LIST",this.wardManagerList)
        })
      }

    //get Vehicle List
    selectVehicleByBeatId(beatId) {
      this.vehicleList = []
      this.http.get(environment.apiUrl + 'entity/getVehiclesByEntity' + "?prjid=" + this.prjId + "&entityid=" + beatId + "&isassigned=" + 1).subscribe(data => {
        this.vehicleList = data.json(); 
        console.log("vehicle List",this.vehicleList)
      })
    }



    selectDriverByVehicle(vehicleId){  
      this.driverList = []
      this.selectedDriverId = null
      this.driverName =  null
      this.http.get(environment.apiUrl + 'entity/getDriverByVehicles' + "?vehid=" + vehicleId).subscribe(data => {
        var result = data.json() 
        if (result.status == "ok") {
          this.driverList = data.json().data;
        }else{
          this.driverList = []
        }
      }) 
    }
         
      //Edit coupon assignment details
      editCouponAssignment(data){ 
       $("#editAssignmentModal").modal("show")
       var Ward=data.Ward
       this.valideEndSrNo=false;
       this.updtResponceMessage=false;
       this.editSuccess=false;
       this.editError=false;
      //When Edit to Accountant details
      if(Ward==null){
         this.showWardMgrDiv=false;
         this.assignTypeModal = this.assignType[0].ID; 
         this.zoneModal=data.ZoneID 
         this.selectAccountant(data.ZoneID) 
       } 
       //When Edit to WARD MANAGER details
       else{ 
         this.assignTypeModal = this.assignType[1].ID; 
         this.showWardMgrDiv=true
         this.selectAccountant(data.ZoneID)
         this.zoneModal=data.ZoneID 
         this.getWardByProject(data.ZoneID)
         this.wardModal=data.WardID  
         this.selectWMbyWardId(data.WardID)  
         this.wardManagerModal=data.WMID
         this.getBeatByWard(data.WardID, 9)
         this.beatModal=data.BeatID 
         this.selectVehicleByBeatId(data.BeatID) 
         this.vehicleModal=data.vehId
         this.selectDriverByVehicle(data.vehId);
         this.driverModal=data.DriverID 
       }
       this.assignId=data.ID
       this.denoModel=data.Denomination 
       this.serialCode=data.FirstSrNo.slice(0,4)
       this.startSrNoModal=data.FromSrNo.slice(4,data.FromSrNo.length)
       this.endSrNoModal=data.ToSrNo.slice(4,data.ToSrNo.length)
       this.firstSrNoModal=data.FromSrNo.slice(4,data.FromSrNo.length)
       this.countModal=data.Qty
       this.amountModal=data.Amount
      }
      
  //**************************************** */Update Ucc ASSIGNMENT DETAILS*************************************
      updateCouponAssignment(){
        if(this.assignTypeModal==null){
          alert('Please select Assign Type')
          return;
        }
        if(this.zoneModal==null){
          alert('Please select Zone')
          return;
        }
        if(this.accountantModal==null){
          alert('Please select Zonal accountant')
          return;
        }
        //To check validation to assign for only ward manager case
        if(this.assignToId==2){
          this.toEmpId=this.wmEmpId;
          this.toEmpRoleId=this.wmEmpRoleId;
          this.toEmpName=this.wmEmpName;
          if(this.wardModal==null){
            alert('Please select Ward')
            return;
          }
          if(this.wardManagerModal==null){
            alert('Please select Ward Manager')
            return;
          } 
          if(this.beatModal==null){
            alert('Please select Beat')
            return;
          }
          if(this.vehicleModal==null){
            alert('Please select Vehicle')
            return;
          }
          if(this.driverModal==null){
            alert('Please select Driver')
            return;
          }
        } else{
          this.toEmpId=this.zaEmpId;
          this.toEmpRoleId=this.zaEmpRoleId;
          this.toEmpName=this.zaEmpName; 
          this.beatId=null;
          this.slectedVehiclesId=null;
          this.dvrEmpId=null;
          this.wmEmpId=null;
        }
        if(this.denoModel==null){
          alert('Please select Denomination')
          return;
        }
        if(this.startSrNoModal==null){
          alert('Start serial no is Required')
          return;
        }
        if(this.endSrNoModal==null){
          alert('End serial no is Required')
          return;
        }  
        var updateJashonData={
          "ID":this.assignId,
          "PRJID":this.prjId,
          "FROMEMP":this.fromEmpId,
          "FROMROLEID":this.fromEmpRoleId, 
          "TOEMP":this.toEmpId,  //Ward manager/ZA EMP ID
          "UCCHEADID":this.fromEmpId,      
          "TOROLEID":this.toEmpRoleId,  //Ward Mamager/ZA EMP ID
          "DENOMINATION":this.denoModel, 
          "FIRSTSRNO":this.serialCode+this.firstSrNoModal.toUpperCase(),
          "FROMSRNO":this.serialCode+this.startSrNoModal.toUpperCase(),
          "TOSRNO":this.serialCode+this.endSrNoModal.toUpperCase(), 
          "QTY": this.countModal,
          "AMOUNT": this.amountModal,
          "ZONEID":this.zoneModal,
          "ZAID":this.zaEmpId,
          "WARDID":this.wardModal,
          "BEATID":this.beatModal?this.beatModal:null,
          "VEHID":this.vehicleModal?this.vehicleModal:null,
          "DVRID":this.driverModal?this.driverModal:null,
          "WMID":this.wardManagerModal?this.wardManagerModal:null, 
          "ISACTIVE":1, 
          "ISSUEDATE":moment(this.assignmentDate).format('YYYY-MM-DD'),
          "ZANAME":this.toEmpName?this.toEmpName:null, 
          "USERID":this.userId,
          "SOURCEFROM":"ASSIGNMENT"
         } 
         console.log("assign Name",updateJashonData)
         this.http.post(environment.apiUrl + 'uccnew/saveCouponAssignment',updateJashonData).subscribe(data =>{ 
          var code=data.json();  
          var responceCode=code[0].RESPONSECODE 
          var responceMsg =code[1].RESPONSEMESSAGE 
          if(responceCode=="200"){
            this.editSuccess=true;
            this.editError=false;
            this.updtResponceMessage=responceMsg
            this.getCouponAssignmentList(); 
            setTimeout(()=>{ 
              this.editSuccess=false;
              this.editError=false;
              this.couponAssignmentArray=[];
              this.isSaveActive=true;
             }, 1000); 
          }
          else if(responceCode!="200"){ 
            this.editSuccess=false;
            this.editError=true;
            this.updtResponceMessage=responceMsg 
          }  
      });  

      }

       
      deleteAssignModal(data){
        this.delAssignSuccess=false;
        this.delAssignError=false;
        $('#deleteAssignModal').modal('show'); 
        this.assignmentId={
          "ID":data.ID
        }
      }
      
      //Delete Assignment Details
      deleteAssignmentEntryDetails(){
        this.http.post(environment.apiUrl + 'uccnew/deleteCouponDetails',this.assignmentId).subscribe(data =>{ 
          var code=data.json();  
          var responceCode=code[0].RESPONSECODE 
          var responceMsg =code[1].RESPONSEMESSAGE 
          if(responceCode=="200"){
            this.delAssignSuccess=true;
            this.delAssignError=false;
            this.deleteAssignResMsg=responceMsg
            this.getCouponAssignmentList();
            setTimeout(()=>{ 
              this.delAssignSuccess=false;
              this.delAssignError=false;
              this.couponAssignmentArray=[]; 
              $('#deleteAssignModal').modal('hide');  
             }, 1000); 
          }
          else if(responceCode!="200"){ 
            this.delAssignSuccess=false;
            this.delAssignError=true;
            this.deleteAssignResMsg=responceMsg 
          }   
      });      
      }  
    downloadExcelFile(assignmentData)
    {
     const ws_name = 'ErrorAssignmentReport';
     const wb: WorkBook = { SheetNames: [], Sheets: {} };
     const ws: any = utils.json_to_sheet(assignmentData);
     wb.SheetNames.push(ws_name);
     wb.Sheets[ws_name] = ws;
     const wbout = write(wb, { bookType: 'xlsx', bookSST: true, type:'binary' });
     saveAs(new Blob([this.s2ab(wbout)], { type: 'application/octet-stream' }), 'ErrorAssignmentReport.xlsx');
     }
     s2ab(s) 
     {
       const buf = new ArrayBuffer(s.length);
       const view = new Uint8Array(buf);
       for (let i = 0; i !== s.length; ++i) {
       view[i] = s.charCodeAt(i) & 0xFF;
       };
       return buf;
     }
  
     ngOnInit(){  
      this.prjId = this.auth.getAuthentication().projectId  
      this.userId = this.auth.getAuthentication().id   
      this.startDate = moment(new Date()).format('YYYY-MM-DD');
      this.endDate= moment(new Date()).format('YYYY-MM-DD'); 
      this.getIssuerDetails();   
      this.getCouponAssignmentList(); 
      this.getDenoSeries();  
     }  
 } 


