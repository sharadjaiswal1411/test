export class Complain {

    constructor( 
      public mobile: number,
      public complainID:string,
      public name: string,
      public homeNo: string,
      public street: string,
      public address: string,
      public remarks: string,
      public zone: string,
      public ward: string,
      public beat: string, 
      public complainType:string,
      public complain:string,
      public supervisorName: string, 
      // public source:string,
      // public status:string,
      public sourceId:Number,
      public statusId:Number,
      public resolvedRemarks:string,
      
    ) {  }
  
  }