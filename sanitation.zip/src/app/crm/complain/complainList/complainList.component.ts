import { Component ,NgZone,ViewEncapsulation} from '@angular/core';
import { Http } from '@angular/http'
import { environment } from '../../../../environments/environment';
import { AuthService } from '../../../_services/index';
import { LoaderService } from '../../../_services/loader.service';
import { Complain }    from './complain';
import { saveAs } from 'file-saver';
import { utils, write, WorkBook } from 'xlsx';
import {IMyDrpOptions} from 'mydaterangepicker';  
import { process, State } from '@progress/kendo-data-query';
import { GroupDescriptor, DataResult } from '@progress/kendo-data-query';
import {GridDataResult,DataStateChangeEvent} from '@progress/kendo-angular-grid';
import { Observable } from 'rxjs/Observable';
import { RowClassArgs } from '@progress/kendo-angular-grid';
import { ExcelExportData } from '@progress/kendo-angular-excel-export';
import Swal from 'sweetalert2' ;
declare var require: any;
declare var google:any; 
var moment = require('moment');

declare var $: any;
const distinctZone= data => data.filter((x, idx, xs) => xs.findIndex(y => y.zone === x.zone) === idx); 
const distinctWard= data => data.filter((x, idx, xs) => xs.findIndex(y => y.ward === x.ward) === idx); 
const distinctCompSource= data => data.filter((x, idx, xs) => xs.findIndex(y => y.SOURCE === x.SOURCE) === idx); 
const distinctCompStatus= data => data.filter((x, idx, xs) => xs.findIndex(y => y.STATUS === x.STATUS) === idx); 
 

@Component({
    selector: 'complainList-cmp',
    templateUrl: './complainList.component.html', 
    encapsulation: ViewEncapsulation.None,
    styles: ['.green .codeColumn { color: green; font-weight: bold } .red .codeColumn { color: red; font-weight: bold}.feedback .codeColumn { color: #059; font-weight: bold}.other .codeColumn { color: #9F6000; font-weight: bold}'], 
  })

  export class ComplainListComponent{ 
    geocoder:any;
    prjId:any;
    userId:any;
    selectedCompRowData:number;
    ddlZoneData:any;
    ddlWordData:any;
    ddlBeatData:any;
    complinTypeData:any;
    complainType:any;
    complinDetailData:any;
    ComplainID:any;
    public complainStatusCode:any;
    complainSuccessMsg=false; 
    complainSuccessCode=false;
    complainData:any;  
    complainErrorMsg=false;  
    complainCategory:any;  
    public currStatus:any; 
    complainResolvedCode=false;
    complainForm=false;
    resolvedRemarkDiv=false;
    search:any;  
    public monthTillTotal:any;
    public monthTillResolved:any;
    public monthTillPending:any;
    public todaysTotal:any; 
    public todaysResolved:any;
    public todaysPending:any;
    public showPendingWarningMsg=false;
    public showResolvedWarningMsg=false;
    public showCompCatWarningMsg=false;
    public showCompCatTypeWarningMsg=false;
    public ddlStatusData:any;
    public loadingImg:any;
    public showLoadingImgDiv=false;
    public showIZoneNotFoundMsg=false;
    public mobileValidation=false;
    public mobLength:any;
    public nameLength:any;
    public nameValidation=false;
    public showZoneWarningMsg=false;
    public zoneId:any;
    public showWardWarningMsg=false; 
    public wardId:any;
    public beatId:any;
    public showLoader: boolean;
    public totalComplainData:any;
    public startDate:any;
    public endDate:any;  
    public defaultStartDate:any;
    public defaultEndDate:any;
    public dataRangeModal: any;
    public wardManager:any;
    public todaysPendingLate:any;
    public todaysFeedBack:any;
    public monthTillPendingLate:any;
    public monthTillFeedBack:any;
    public compSourceData:any;
    public compSourceRequired=false;
    public complainSource:any;
    public source:any;
    public wardMgrMobile:any;
    public complainMsg:any; 
    public compStatusList:any;
    public compSourceList:any;
    public todayLoader=true;
    public feedBackMsg=false;
    public underObsMsg=false;
    public resoDate:any;   
    public complainStatus:any;
    public ulbModal:any;
    public ulbId:any;
    public ulbList:any;
    public zoneList:any; 
    public respMsg:any;
    public todayUnderOb:any;
    public mtdUnderOb:any; 
    public complainTypeList:any;
    public complainTypeHrsList:any;
    public rowCount:any;
    complainTypeData:any;
    complainDataExcel:any;
    public state: State = { 
      skip: 0,
      take: 50,  
      filter: {
        logic: 'and',
        filters: []
      }
    };
    public allData(): ExcelExportData {
      const result: ExcelExportData =  {
          data: this.complainDataExcel
      };
      return result;
     } 
  public fields: string[];
  myDateRangePickerOptions: IMyDrpOptions={ 
      dateFormat: 'dd.mm.yyyy', 
  };
  model = new Complain(123,"112", '545', "454",'3243','fger','23', 'Chuck Overstreet',"10315","10315","10315","10315","10315",0,0,"1");
  submitted = false;
  compStatus: string;  
  public opened: boolean = true;
  public close(status) { 
    this.opened = false;
  }

  public open() {
    this.opened = true;
  } 

  public groups: GroupDescriptor[] = [];
  public view: Observable<GridDataResult>;
  public gridView: DataResult;
  public groupChange(groups: GroupDescriptor[]): void {
    this.groups = groups;
    this.loadProducts();
  }

  public distinctZone: any[]
  public distinctWard: any[]
  public distinctCompSource: any[]
  public distinctCompStatus: any[]

  private loadProducts(): void {
    this.gridDataComplainList = process(this.complainData, { group: this.groups }); 
  }
  public gridDataComplainList: GridDataResult 
  constructor(private auth : AuthService,private http: Http,private loaderService: LoaderService,private _ngZone: NgZone)
         {
          this.loaderService.status.subscribe((val: boolean)=>{
          this.showLoader = val;
        });
    var date = new Date();
    this.monthTillTotal=0;  
    this.monthTillResolved=0;
    this.monthTillPending=0;
    this.monthTillPendingLate=0;
    this.monthTillFeedBack=0;   
    this.todaysTotal=0;  
    this.todaysResolved=0;
    this.todaysPending=0; 
    this.todaysPendingLate=0;
    this.todaysFeedBack=0;   
    this.allData = this.allData.bind(this);
    this.defaultStartDate = (date.getFullYear()) + '-' + (date.getMonth() + 1) + '-' + date.getDate(); 
    this.defaultEndDate = (date.getFullYear()) + '-' + (date.getMonth() + 1) + '-' + date.getDate(); 
    this.dataRangeModal= {beginDate: {year: date.getFullYear(), month: date.getMonth()+1, day: date.getDate()}, endDate: {year: date.getFullYear(), month: date.getMonth()+1, day: date.getDate()}};
  } 
   
  /*
   *select start Date Nad To date
  */
  onDateRangeChanged(dataRange){ 
    this.rowCount=0;  
    if(dataRange.beginDate.day>0){ 
      this.startDate= dataRange.beginDate.year + "-"  + dataRange.beginDate.month+ "-" + dataRange.beginDate.day 
      this.endDate = dataRange.endDate.year + "-"  + dataRange.endDate.month  + "-" + dataRange.endDate.day 
      this.getComplainDetails(); 
    }
    else if(dataRange.beginDate.day==0){
      this.startDate= this.defaultStartDate
      this.endDate = this.defaultEndDate
      this.getComplainDetails(); 
    }  
  }
   
   /*
    * get Complain Details By Project Id
   */  
    getComplainDetails(){   
      this.loaderService.display(true);  
      this.http.get(environment.apiUrl + 'consumer/getComplainByProject?prjid='+this.prjId+'&StartDate='+this.startDate+'&EndDate='+this.endDate).subscribe(data =>{  
               this.complainData= data.json(); 
               this.complainDataExcel = data.json(); 
               this.rowCount=this.complainData.length
               if (this.complainData.length>0){ 
                this.distinctZone = distinctZone(this.complainData) 
                this.distinctWard = distinctWard(this.complainData) 
                this.distinctCompSource = distinctCompSource(this.complainData) 
                this.distinctCompStatus = distinctCompStatus(this.complainData)  
                 this.gridDataComplainList = process(this.complainData, this.state);   
                 console.log(this.gridDataComplainList)
              
                setTimeout(()=>{this.loaderService.display(false)},2000); 
               }
               else {
                this.complainData=[]; 
                this.gridDataComplainList = process(this.complainData, this.state);   
                this.loaderService.display(false);  
               }}, 
          error=>{ 
            this.loaderService.display(false);
            Swal({
              type: 'error',
              title: 'Oops...',
              text: 'An Error Occurred Please Try Again',
            })
          });  
    }


    /**
     * Column BG color Change
    */
   public rowCallback = (context: RowClassArgs) => { 
    switch (context.dataItem.STATUS) {
      case 'PENDING': 
        return {red : true}; 
      case 'RESOLVED': 
        return {green : true};
      case 'FEEDBACK': 
        return {feedback : true};
      case 'UNDER OBSERVATION': 
        return {other : true}; 
      default:
        return {}; 
     } 
   }
    

   
    /**
     * to filter the grid data
    */
    public dataStateChange(state: DataStateChangeEvent): void {
      this.state = state;
      if (state && state.group) {  
        this.gridDataComplainList = process(this.complainData, this.state); 
        var filters = this.state.filter.filters
        this.state = {   
          filter: {
            logic: 'and',
            filters: filters
          }
        }  
        this.complainDataExcel = process(this.complainData, this.state).data; 
        this.state = { 
          skip: 0,
          take: 50,   
          filter: {
            logic: 'and',
            filters: filters
          }
        }  

        } 
    } 


    /*
     * import excel details
    */ 
   importTotalComplainList(reportType){
      this.loaderService.display(true);       
      this.http.get(environment.apiUrl + 'consumer/getComplainExcelReport?prjid='+this.prjId+'&reportType='+reportType).subscribe(data =>{  
               this.totalComplainData= data.json();  
               if(this.totalComplainData.length>0){  
                this.loaderService.display(false);  
                this.importVehiclesExcelReport(this.totalComplainData)          
               }else{  
                this.loaderService.display(false); 
               }},
               error=>{ 
                this.loaderService.display(false);
                Swal({
                  type: 'error',
                  title: 'Oops...',
                  text: 'An Error Occurred Please Try Again',
                })
              });  
    } 

/*
 *To download the Excel file with selected data GRid  
*/
importVehiclesExcelReport(totalComplainData){
  const ws_name = 'ComplainReport';
  const wb: WorkBook = { SheetNames: [], Sheets: {} };
  const ws: any = utils.json_to_sheet(totalComplainData);
  wb.SheetNames.push(ws_name);
  wb.Sheets[ws_name] = ws;
  const wbout = write(wb, { bookType: 'xlsx', bookSST: true, type:'binary' });
 saveAs(new Blob([this.s2ab(wbout)], { type: 'application/octet-stream' }), 'exported.xlsx');
}
s2ab(s){
    const buf = new ArrayBuffer(s.length);
    const view = new Uint8Array(buf);
    for (let i = 0; i !== s.length; ++i) {
      view[i] = s.charCodeAt(i) & 0xFF;
    };
    return buf;
  }


  
    /*
     * Get complain Count Details.for Dash board only
    */  
    getComplainCount(){
      this.loaderService.display(true); 
      this.http.get(environment.apiUrl + 'consumer/getComplainCountDetails?PRJID='+this.prjId).subscribe(data =>{
          var getTotalComplain=data.json(); 
          if(getTotalComplain.length>0){   
          this.todaysTotal=getTotalComplain[2]?getTotalComplain[2].Total:0 
          this.todaysPending=getTotalComplain[2]?getTotalComplain[2].Pending:0  
          this.todaysPendingLate=getTotalComplain[2]?getTotalComplain[2].Late:0 
          this.todaysFeedBack=getTotalComplain[2]?getTotalComplain[2].Feedback:0 
          this.todaysResolved=getTotalComplain[2]?getTotalComplain[2].Resolved:0          
          this.monthTillTotal=getTotalComplain[1]?getTotalComplain[1].Total:0 
          this.monthTillPending=getTotalComplain[1]?getTotalComplain[1].PendingMonthTillDate:0  
          this.monthTillPendingLate=getTotalComplain[1]?getTotalComplain[1].Late:0 
          this.monthTillFeedBack=getTotalComplain[1]?getTotalComplain[1].Feedback:0 
          this.monthTillResolved=getTotalComplain[1]?getTotalComplain[1].Resolved:0 
          this.todayUnderOb=getTotalComplain[2]?getTotalComplain[2].UnderObservation:0 
          this.mtdUnderOb=getTotalComplain[1]?getTotalComplain[1].UnderObservation:0 
          }
          else{
            alert('No data found ')
          }
        });
        this.loaderService.display(false); 
    } 
    /**
     * bind Status
    */      
    public bindStatus(){ 
      this.http.get(environment.apiUrl + 'consumer/getComplainStatus?PRJID='+this.prjId).subscribe(data =>{
         this.compStatusList=data.json();  
      });

    }  
    
     /**
     * bind Status
    */      
    public getComplainSource(){
      this.http.get(environment.apiUrl + 'consumer/getComplainSource?PRJID='+this.prjId).subscribe(data =>{
        this.compSourceData=data.json();  
     });
    } 

    /*
    To Save the Complain Details and Send the Complain no to the user Registered Mobile No.
    */ 
    onSubmit(){   
      console.log("this.zoneId--",this.zoneId)
      console.log("this.wardId--",this.wardId)
      this.submitted = true; 
      var currentStatus:any; 
      var resolvedDate:any;
      this.mobLength=$('#txtMobileNo').val().length
      this.nameLength=$('#txtName').val().length
      if(this.mobLength<10||this.mobLength==0){this.mobileValidation=true;return} 
      if(this.nameLength<=0){this.nameValidation=true; return;} else{ this.nameValidation=false;}   
      if(this.model.complainType==null||this.model.complainType==''){this.showCompCatWarningMsg=true;return}
      if(this.model.complain==null||this.model.complain==''){this.showCompCatTypeWarningMsg=true;return}  
      if(this.ulbModal==null||this.ulbModal==''){this.showCompCatTypeWarningMsg=true;return}   
      if(this.zoneId==null){this.showZoneWarningMsg=true; return;}  
      if(this.wardId==null){this.showWardWarningMsg=true; return;} 
      if(this.model.sourceId==null||this.model.sourceId==undefined){this.compSourceRequired=true;return}  
      if(this.model.statusId==null||this.model.statusId==undefined){this.showPendingWarningMsg=true;return} 
       currentStatus=this.model.statusId  
      if(currentStatus==2){
          resolvedDate=new Date()
        }
      else if(currentStatus>2){
          resolvedDate=this.resoDate
        }   
      var jsonComplainData={  
         "PRJID":this.prjId,
         "COMPLAINID":this.model.complainID?this.model.complainID:null,
         "COMPLAINTYPEID":this.model.complain,
         "MOBNO":this.model.mobile?this.model.mobile:null,
         "NAME":this.model.name?this.model.name:null,
         "WARDID":this.model.ward?this.model.ward:null,
         "ZONEID":this.model.zone?this.model.zone:null,
         "BEATID":this.model.beat?this.model.beat:null,
         "ULBID":this.ulbModal?this.ulbModal:null,
         "HOUSENO":this.model.homeNo?this.model.homeNo:null,
         "STREET":this.model.street?this.model.street:null, 
         "COMPREMARK":this.model.remarks?this.model.remarks:null, 
         "STATUSID":this.complainStatus?this.complainStatus:null,
         "SOURCEID":this.complainSource?this.complainSource:null,
         "RESOLVEREMARK":this.model.resolvedRemarks?this.model.resolvedRemarks:null, 
         "USERIDENTRY":this.userId,
         "RESOLVEDATE":resolvedDate
         } 
        this.loaderService.display(true);
        $('#btnsave').attr("disabled", true); 
        this.http.post(environment.apiUrl + 'consumer/saveComplainDetails',jsonComplainData).subscribe(data =>{ 
               this.complainStatusCode= data.json(); 
               var statusId=this.complainStatusCode.output[2].IDRESPONSE;  
               this.respMsg=this.complainStatusCode.output[2].RESPONSEMESSAGE; 
               if(this.complainStatusCode.output[0].RESPONSECODE=="200"){  
                 var mobileNo = "91" + this.model.mobile ;              
                 if(currentStatus=="1"){  
                   this.complainSuccessCode=true;    
                   //Send SMS to customer   
                   if(this.currStatus == 'New'){  
                    var jsonSmsData={"GSM":mobileNo,"msg":this.complainMsg,"status":"new","id":statusId,"prjid":this.prjId}  
                    this.http.post('http://13.232.60.37:4000/mobileAPIs/sendComplainStatusSMS',jsonSmsData).subscribe(data=>{});  
                   }          
                   //Send SMS to Ward Manager  
                   var jsonDataToWM={"GSM":this.wardMgrMobile,"msg":this.complainMsg,"status":"new","id":statusId,"prjid":this.prjId,"custName":this.model.name,"custMobNo":this.model.mobile,"custHouseNo":this.model.homeNo,"custAddress":this.model.street?this.model.street:'',"complainDate":moment(new Date()).format('DD-MM-YYYY')} 
                   this.http.post('http://13.232.60.37:4000/mobileAPIs/sendComplainSMSToWardMgr',jsonDataToWM).subscribe(data=>{});                         
                 }
                else if(currentStatus=="2"){ 
                  this.complainResolvedCode=true; 
                  var jsonResolvedData={"GSM":mobileNo,"msg":this.complainMsg,"status":"resolved","id":statusId,"prjid":this.prjId}                     
                  this.http.post('http://13.232.60.37:4000/mobileAPIs/sendComplainStatusSMS',jsonResolvedData).subscribe(data=>{                                  
                  });  
                 }
                 else if(currentStatus=="3"){
                 this.feedBackMsg=true;
                 }
                 else if(currentStatus=="4"){
                  this.underObsMsg=true;
                 } 
                 setTimeout(()=>{
                  this.feedBackMsg=false;
                  this.underObsMsg=false;
                  this.complainResolvedCode=false; 
                  this.complainSuccessCode=false;    
                  $('#ComplainModal').modal('hide');   
                 }, 3000);  
               }
               this.getComplainDetails();
               this.getComplainCount(); 
               if(this.complainStatusCode.output[0].RESPONSECODE!="200"){ 
               $('#btnsave').attr("disabled", true);
                this.complainErrorMsg=true
                this.complainSuccessCode=false;
                this.complainResolvedCode=false; 
               } 
          },  
          error=>{ 
            this.complainSuccessCode=false;
            this.complainErrorMsg=true; 
            $('#btnsave').attr("disabled", false);
          });  
    } 

    /*
     * update the Complain And Change the Status Details
    */  
    resolvedComplain(item){  
      console.log("complain",item)
      this.currStatus="Pending" 
      $('#ComplainModal').modal('show');
      $('#btnsave').attr("disabled", false);
      $('#txtMobileNo').attr("disabled", true); 
      this.complainSuccessCode=false;
      this.complainResolvedCode=false; 
      this.resolvedRemarkDiv=true;
      this.complainErrorMsg=false; 
      this.mobileValidation=false;
      this.currStatus=item.STATUS;  
      this.getWardByProject(item.zoneID,null);
      this.getBeatByProject(item.wardID);
      this.beatId=item.beatID; 
      this.showPendingWarningMsg=false;
      this.complainType=item.complainTypeID 
      this.ulbModal=item.ULBID 
      var data={
        ComplainID:item.complainCatID
      }
      this.getComplainType(data)  
      this.model = new Complain(item.mobNo,item.complainID, item.name, item.houseNo, item.street,item.Address,item.compRemark,item.zoneID,item.wardID,item.beatID,item.complainCatID,item.complainTypeID,"",Number(item.SOURCEID),Number(item.STATUSID),item.resolveRemark);
      this.complainStatus=Number(item.STATUSID)
      this.complainSource=Number(item.SOURCEID)
      this.resoDate=item.resolveDate 
      this.complainMsg=item.complainCategory 
    }  

    
    // getcomplainTypeId(complainId){ 
    //   this.http.get(environment.apiUrl +'consumer/getComplainByPrjid?prjid='+this.prjId+'&ComplainId='+complainId)
    //   .subscribe(data =>{ 
    //            var compliantype= data.json();  
    //       });
    // }

    filterMobileData(){
      this.loaderService.display(true); 
      var compSource="Mobile App"
      this.http.get(environment.apiUrl + 'consumer/getComplainByProject?prjid='+this.prjId+'&StartDate='+this.startDate+'&EndDate='+this.endDate+'&compSource='+compSource).subscribe(data =>{  
               this.complainData= data.json();  
               if (this.complainData.length>0){ 
                this.distinctZone = distinctZone(this.complainData) 
                this.distinctWard = distinctWard(this.complainData) 
                this.distinctCompSource = distinctCompSource(this.complainData) 
                this.distinctCompStatus = distinctCompStatus(this.complainData)  
                this.gridDataComplainList = process(this.complainData, this.state);   
                this.loaderService.display(false);           
               }else{ 
                this.gridDataComplainList=null;
                this.loaderService.display(false);  
               }},
               error=>{ 
                this.loaderService.display(false);
                Swal({
                  type: 'error',
                  title: 'Oops...',
                  text: 'An Error Occurred Please Try Again',
                })
          });    
    } 

    refreshAllData(){
      this.getComplainDetails();
    }
  /*
  *  get Complain ID By Project
  */  
  getComplainType(data){  
    if(data.ComplainID==0||data.ComplainID==null){
      this.showCompCatWarningMsg=true;  
      return;
    }
    if(data.ComplainID!=0||data.ComplainID!=null||data.ComplainID!=''){
      this.showCompCatWarningMsg=false;  
    } 
    this.complainMsg=data.ComplainType;
    this.http.get(environment.apiUrl +'consumer/getComplainByPrjid?prjid='+this.prjId+'&ComplainId='+data.ComplainID).subscribe(data =>{ 
             this.complinDetailData= data.json(); 
        }); 
  } 

 
    /*
     * Add New Complain Details
     */
    AddComplainModal(){  
      this.newComplain(); 
      this.bindStatus(); 
      this.currStatus="New" 
      this.getZoneByProject(this.prjId);
      $('#ComplainModal').modal('show'); 
      $('#txtMobileNo').attr("disabled", false);   
      this.mobileValidation=false; 
      this.ddlWordData=null;
      this.ddlBeatData=null; 
      this.model.sourceId=null;
      this.model.statusId=null;
      this.complainResolvedCode=false;
      this.complainSuccessCode=false;
      this.resolvedRemarkDiv=false; 
      this.showPendingWarningMsg=false; 
      this.complainErrorMsg=false;
    } 

    /*
     * Select Complain Status
    */ 
    getCompStatus(ddlStatusData){  
      this.complainStatus=ddlStatusData.ID
      if(ddlStatusData==null||ddlStatusData==''||ddlStatusData==undefined){
        //$('#btnsave').attr("disabled", true);
        return;
      }
      if((ddlStatusData.ID==2) && (this.currStatus=="RESOLVED")){
        //$('#btnsave').attr("disabled", false);
        return;
      } 
      if(((this.currStatus=="New") && (ddlStatusData.ID=="RESOLVED"))){
        //$('#btnsave').attr("disabled", true);
        this.showPendingWarningMsg=true;
        this.showResolvedWarningMsg=false 
        return;
      } 
      if((this.currStatus=="New") && (ddlStatusData.ID=="PENDING")){
        //$('#btnsave').attr("disabled", false);
        this.showPendingWarningMsg=false;
        this.showResolvedWarningMsg=false 
      }
      if((this.currStatus=="PENDING")){
        //$('#btnsave').attr("disabled", false);
        this.showPendingWarningMsg=false;
        this.showResolvedWarningMsg=false 
      }
      if((this.currStatus=="RESOLVED")){
        //$('#btnsave').attr("disabled", false);
        this.showPendingWarningMsg=false;
        this.showResolvedWarningMsg=false
      }  
    }

    /*
     *Select Complain Source Name 
    */   
    selectComplainSource(sourceData){ 
      if(sourceData==null)  {
        this.compSourceRequired=true
        return;
      }  
      else{
        this.compSourceRequired=false
        this.complainSource=sourceData.ID 
      }  
    } 
 
   /*
    * clear the all input fields
   */
    newComplain(){ 
      this.ulbModal=null;
      this.showLoadingImgDiv=false;
      this.model = new Complain(null,"","", "", "", "", "","","","","","","",1,1,"");
      this.wardManager=null;
    }

    filterModal(){
      $('#FilterModal').modal('show');
    }
    
  
  /*
  Get Zone By Prj Id
  */
  getZoneByProject(prjid){    
      this.http.get(environment.apiUrl + 'consumer/getZoneByProject?prjid='+prjid+'&oemid=7').subscribe(data =>{ 
               this.ddlZoneData= data.json(); 
          }); 
  } 
  /*
  Get Lat And Lng by Address
  */
  getLatLongByAddress(){    
    this.showLoadingImgDiv=true;
    this.loadingImg="../../assets/img/loading.gif";
    this.getGeoCopdingAddress(this.model.address)  
  }

  getGeoCopdingAddress(address){  
  this.geocoder.geocode({'address': address}, (results, status)=> {
    if (status === 'OK') 
    {
      var lat=results[0].geometry.location.lat();
      var lng=results[0].geometry.location.lng() 
      this.getZoneWardByLatLng(lat,lng); 
    } else{
      //this.showIZoneNotFoundMsg=true;
      this.loadingImg="../../assets/img/wrong.jpg";
      alert('Geocode was not successful for the following reason: '+status);
      this._ngZone.run(() => { console.log('Outside Done!'); });
    }
  });
  }

  getZoneWardByLatLng(lat,lng){
    this.http.get(environment.apiUrl +'entity/getZoneWardByLatLng?lat='+lat+'&lng='+lng).subscribe(data => { 
     var zoneWardData = data.json();
     if(zoneWardData.length>0){
     this.model.zone = zoneWardData[0].zoneID;
     this.model.beat=zoneWardData[0].beatID;  
     this.ulbModal=zoneWardData[0].ulbId 
      if(this.model.zone!="0"){
        this.loadingImg="../../assets/img/ok.png";
        this.showIZoneNotFoundMsg=false;
      } 
      this.getWardByProject(zoneWardData[0].zoneID,zoneWardData[0].wardID)
      this.getBeatByProject(this.zoneId); 
      this.getWardManagerDetails(zoneWardData[0].wardID)  
    }else{
      this.loadingImg="../../assets/img/wrong.jpg";
      this._ngZone.run(() => { console.log('Outside Done!'); });
    }     
    }); 
  } 
  
  /*
   * get ULB by Zone Name
   *
   */
  getUlbByZoneId(zoneId){
      this.http.get(environment.apiUrl +'consumer/getComplainTypeByPrjid?prjid='+zoneId).subscribe(data =>{ 
      this.ulbList= data.json(); 
      console.log("")             
    }); 
  }

   /*
  get Complain Cetegory By Project 
  */
  getComplainTypeByPrjid(prjid){  
      this.http.get(environment.apiUrl +'consumer/getComplainTypeByPrjid?prjid='+prjid).subscribe(data =>{ 
               this.complinTypeData= data.json();              
          }); 
  } 

  

  /*
    get Complain BY Complain Type Id
  */
  getComplainByPrjid(complainType){ 
    if(complainType==null){ 
      this.showCompCatTypeWarningMsg=true; 
      return;
    }
    if(complainType==0||complainType==''||complainType==null){
      this.showCompCatTypeWarningMsg=true; 
      return;
    }
    else{
      this.showCompCatTypeWarningMsg=false; 
    }  
  }


   /*
    get Ward By Project
   */ 
  getWardByProject(entityid,id){  
     this.ddlWordData=null;
     this.model.beat=null;
     this.wardManager=null;
     this.zoneId=entityid; 
     if(this.zoneId==null){
      this.showZoneWarningMsg=true;
      return;
     }else{
      this.showZoneWarningMsg=false;
      this.http.get(environment.apiUrl + "consumer/getZoneByProject?prjid="+this.prjId+"&oemid=8&entityid="+entityid).subscribe(data =>{ 
        this.ddlWordData= data.json();  
        if(id!=null){
          this.model.ward=id
        }
      }); 
     }  
   } 
   /*
    get Beat By Project
   */
   getBeatByProject(entityid){  
      this.wardId=entityid; 
      this.wardManager=null;
      if(this.wardId==null){
        this.showWardWarningMsg=true;
        this.wardManager=null;
        return;
      } else{
        this.showWardWarningMsg=false; 
        this.http.get(environment.apiUrl + "consumer/getZoneByProject?prjid="+this.prjId+"&oemid=9&entityid="+entityid).subscribe(data => {   
                 this.ddlBeatData=0;
                 if(this.ddlBeatData.length==0){ 
                   this.model.beat=null;
                 }else{ 
                   this.ddlBeatData= data.json();
                   this.getWardManagerDetails(this.wardId)
                 } 
                 this._ngZone.run(() => { console.log('Outside Done!'); }); 
            }); 
      } 
    }
    
    /*
    *get Ward Details By Entity Id or Ward Id
    */ 
     getWardManagerDetails(entityId){  
      this.http.get(environment.apiUrl + "consumer/getWardDetailsByEntity?prjid="+this.prjId+"&entityId="+entityId).subscribe(data =>{    
              var wardData= data.json(); 
              console.log("WM BEFORE",this.wardMgrMobile)
              if(wardData.length!=0){
                this.wardMgrMobile=wardData[0].Mobileno 
                console.log("WMAFTER",this.wardMgrMobile)
                var wm=''; 
                for(let item of  wardData){
                  wm= wm +'\n'+ item.WM; 
                } 
                this.wardManager=wm;   
              }  
          }); 
     }




   /*
    get Beat details by Project
   */
    onSelectBeatId(beatDataId){ 
     this.beatId=beatDataId; 
    }
  
    
//**********************Validations*************************// 
 /**
     * mobile No validations
    */
    // onCheckMobileNo()
    // {
    //   this.mobLength=$('#txtMobileNo').val().length
    //   if(this.mobLength<10)
    //   {
    //    this.mobileValidation=true;
    //    //$('#btnsave').attr("disabled", true);  
    //    return;
    //   } 
    //   if(this.mobLength==10)
    //   {
    //     this.mobileValidation=false; 
    //   } 
    // } 
    
    /**
     * name validations
    */
    onCheckName(){
      this.nameLength=$('#txtName').val().length
      if(this.nameLength<=0){
       this.nameValidation=true;
       //$('#btnsave').attr("disabled", true);  
       return;
      }else{
        this.nameValidation=false; 
      } 
    }
//Mobile Number Avaibility from data Base
public restrictNumericForVtsMobileNo(e){
  let input;
  var inputlen;
  if (e.metaKey || e.ctrlKey) {
    return true;
  }
  if (e.which === 32) {
   return false;
  }
  if (e.which === 0) {
   return true;
  }
  if (e.which < 33) {
    return true;
  }
  input = String.fromCharCode(e.which); 
  return !!/[\d\s]/.test(input);
 } 
 
 /*
  * BINd ULB DATA
  */
    getUlbData(prjid){
               this.http.get(environment.apiUrl + "consumer/getUlbDetails?prjid="+prjid).subscribe(data => {   
               this.ulbList=data.json();  
          }); 
    }
    
    /*
     * On select ULB DATA
     */ 
    onSelectUlbData(data){
      if(data!=null){
        this.ulbId=data.ID;  
          this.http.get(environment.apiUrl + "consumer/getZoneIdByULb?entityId="+this.ulbId).subscribe(data => {   
          this.ddlZoneData=data.json();   
        }); 
      } 
    } 

    sendMessage(){
      var mobile = 91 + this.model.mobile
      var content ="Name - " + this.model.name + ",  Mobile -  " + mobile + ",  House No -  " + this.model.homeNo +  ",  Address -  " + this.model.street + ",  Remarks - " +  this.model.remarks
      window.open("https://wa.me/" + 91 + this.wardMgrMobile + "?text=" + content);
    }

 

  copyTextforMessage(){
    var copyText = document.getElementById("myInput"); 
    document.execCommand("copy");
  }

  /*
  Get Time Duration for Complain Filter
  */
  getTimeDurationData(){
    this.http.get(environment.apiUrl + "consumer/getComplainDuration").subscribe(data => {   
      this.complainTypeData=data.json();   
    }); 
  }

  selectTimeDuration(data){ 
    if(data!=null){
      this.rowCount=0;
      this.loaderService.display(true); 
      this.gridDataComplainList=null;  
      this.http.get(environment.apiUrl + "consumer/getComplainByPrjAndHrs?prjId="+this.prjId+"&cmpType="+data.ID+"").subscribe(data => {   
      this.complainTypeHrsList=data.json();
      this.rowCount= this.complainTypeHrsList.length
      if(this.complainTypeHrsList.length>0){
        this.gridDataComplainList = process(this.complainTypeHrsList, this.state);
        this.complainDataExcel = this.gridDataComplainList.data
        this.loaderService.display(false);
      }},
      error=>{ 
      this.loaderService.display(false);
      Swal({
        type: 'error',
        title: 'Oops...',
        text: 'An Error Occurred Please Try Again',
      })
    }); 
    }else{
      this.rowCount=0;
      this.getComplainDetails()
    } 
  }
  







  ngOnInit(){ 
    this.startDate = moment(this.defaultStartDate).format('YYYY-MM-DD');
    this.endDate= moment(this.defaultEndDate).format('YYYY-MM-DD');
    this.geocoder = new google.maps.Geocoder;
    this.prjId = this.auth.getAuthentication().projectId
    this.userId= this.auth.getAuthentication().id
    this.getZoneByProject(this.prjId);
    this.getComplainTypeByPrjid(this.prjId); 
    this.getComplainDetails(); 
    this.getComplainCount(); 
    this.getComplainSource();
    this.bindStatus(); 
    this.getUlbData(this.prjId);
    this.getTimeDurationData();
  }
  
  
}
