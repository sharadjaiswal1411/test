

import { Component } from '@angular/core';




@Component({

    selector: 'complain-cmp',
    templateUrl: './complain.component.html',
    
   
  })
export class ComplainComponent {}