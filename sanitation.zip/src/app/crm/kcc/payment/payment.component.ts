

import { Component } from '@angular/core';




@Component({

    selector: 'payment-cmp',
    templateUrl: './payment.component.html',
   
   
  })
export class PaymentComponent {
  
}