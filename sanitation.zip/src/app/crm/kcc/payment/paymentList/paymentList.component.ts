

import { Component, ViewEncapsulation } from '@angular/core';
import { Http } from '@angular/http'
import { environment } from '../../../../../environments/environment';
import { DomSanitizer, SafeStyle } from '@angular/platform-browser';
import { Observable } from 'rxjs/Observable';
import { ActivatedRoute, Router } from '@angular/router';
import { AuthService } from '../../../../_services';
import Swal from 'sweetalert2'
import { Broadcaster } from '../../../../../environments/broadcaster';

import {DateAdapter, MAT_DATE_FORMATS, MAT_DATE_LOCALE} from '@angular/material/core';//added by kuldeep on 10-03-2018
import {MomentDateAdapter} from '@angular/material-moment-adapter';//added by kuldeep on 10-03-2018
import * as _moment from 'moment'; //added by kuldeep on 10-03-2018
import * as _rollupMoment from 'moment';//added by kuldeep on 10-03-2018

const moment = _rollupMoment || _moment;
import { LoaderService } from '../../../../_services/loader.service';
import { process, State } from '@progress/kendo-data-query';
import { ExcelExportData } from '@progress/kendo-angular-excel-export';
import { GroupDescriptor } from '@progress/kendo-data-query';
import { SelectableSettings } from '@progress/kendo-angular-grid';
import { GridDataResult, DataStateChangeEvent } from '@progress/kendo-angular-grid';

export const MY_FORMATS = {
  parse: {
    dateInput: 'LL',
  },
  display: {
    dateInput: 'LL',
    monthYearLabel: 'MMM YYYY',
    dateA11yLabel: 'LL',
    monthYearA11yLabel: 'MMMM YYYY',
  },
};

declare var $: any;


const distinctZone = data => data
  .filter((x, idx, xs) => xs.findIndex(y => y.zone === x.zone) === idx);
const distinctWard = data => data
  .filter((x, idx, xs) => xs.findIndex(y => y.ward === x.ward) === idx);



@Component({

  selector: 'payment-cmp',
  templateUrl: './paymentList.component.html',
  encapsulation: ViewEncapsulation.None,
  providers: [
    { provide: DateAdapter, useClass: MomentDateAdapter, deps: [MAT_DATE_LOCALE] },
    { provide: MAT_DATE_FORMATS, useValue: MY_FORMATS },
  ],

})

export class PaymentListComponent {
  prjId: any
  public payments: any[];
  showLoader: boolean;
  defaultStartDate: any;
  defaultEndDate: any;
  dataRangeModal: any;
  startDate: any;
  endDate: any;
  receiptNo:any;

  paymentDate:any
  chequeDate:any
  paymentAmount:any;
  transactionNumber:any
  remark:any
  paymentMode:any
  invoiceId:any
  invoiceNo:any
  userId:any
  invalidPaymentReason:any;
  invalidReason:any;

  public state: State = {
    skip: 0,
    take: 100,
    // Initial filter descriptor
    filter: {
      logic: 'and',
      filters: []
    }
  };
  public pageSize: any
  public checkboxOnly = false;
  public mode = 'multiple';
  public selectableSettings: SelectableSettings;
  public distinctZone: any[]
  public distinctWard: any[]

  public groups: GroupDescriptor[] = [];
  public view: Observable<GridDataResult>;
  public gridDataPayments: any;
  public hiddenColumns: string[] = [];
  public isHidden(columnName: string): boolean {
    return this.hiddenColumns.indexOf(columnName) > -1;
  }

  public groupChange(groups: GroupDescriptor[]): void {
    this.groups = groups;
    this.loadProducts();
  }

  private loadProducts(): void {
    this.gridDataPayments = process(this.payments, { group: this.groups });
  }

  public allData(): ExcelExportData {
    const result: ExcelExportData = {
      data: this.payments
    };
    return result;
  }


  constructor(private sanitizer: DomSanitizer ,private broadcaster: Broadcaster, private auth: AuthService, private http: Http, private routes: ActivatedRoute, private router: Router, private loaderService: LoaderService) {
    this.loaderService.status.subscribe((val: boolean) => {
      this.showLoader = val;
    });
    this.allData = this.allData.bind(this);
    var date = new Date();
    var firstDay = new Date(date.getFullYear(), date.getMonth() - 6, 1);

    this.defaultStartDate = (firstDay.getFullYear()) + '-' + (firstDay.getMonth() + 1) + '-' + firstDay.getDate();
    this.defaultEndDate = (date.getFullYear()) + '-' + (date.getMonth() + 1) + '-' + date.getDate();
    this.dataRangeModal = { beginDate: { year: firstDay.getFullYear(), month: firstDay.getMonth() + 1, day: firstDay.getDate() }, endDate: { year: date.getFullYear(), month: date.getMonth() + 1, day: date.getDate() } };
  }


  getPayment(prjId) {
    this.loaderService.display(true);
    if (this.startDate == null || this.endDate == null) {
      this.startDate = this.defaultStartDate
      this.endDate = this.defaultEndDate
    }

    var startDate = moment(this.startDate).format('YYYY-MM-DD')
    var endDate = moment(this.endDate).format('YYYY-MM-DD')
    this.http.get(environment.apiUrl + 'payment/getPayment' + '?prjId=' + prjId + "&startDate=" + startDate + "&endDate=" + endDate).subscribe(data => {
      this.payments = data.json()
      this.distinctZone = distinctZone(this.payments);
      this.distinctWard = distinctWard(this.payments);
      this.gridDataPayments = process(this.payments, this.state);
      this.loaderService.display(false);
    });
  }

  /*
  * filter The Grid Date
  */
  public dataStateChange(state: DataStateChangeEvent): void {
    this.state = state;
    this.gridDataPayments = process(this.payments, this.state);
    //this.selectedInvoiceCount = this.gridData.data.length  
    if (state && state.group) {
      this.gridDataPayments = process(this.payments, this.state);
    }
  }





  /*
   * Select Date range
  */
  onDateRangeChanged(dataRange) {
    if (dataRange.beginDate.day > 0) {
      this.startDate = dataRange.beginDate.year + "-" + dataRange.beginDate.month + "-" + dataRange.beginDate.day
      this.endDate = dataRange.endDate.year + "-" + dataRange.endDate.month + "-" + dataRange.endDate.day
      this.getPayment(this.prjId)
    }
    else if (dataRange.beginDate.day == 0) {
      this.startDate = this.defaultStartDate;
      this.endDate = this.defaultEndDate;
      this.getPayment(this.prjId)
    }
  }



  editPaymentModal(data) {
    $("#editPaymentModal").modal("show")
    this.receiptNo = data.receiptNo
    this.invoiceId = data.invoiceID
    this.invoiceNo = data.invoiceNo
    this.remark = data.remark
    this.chequeDate = data.chequeDate
    this.paymentDate =  moment(new Date(data.receiptDt)).format('YYYY-MM-DD')
    this.paymentAmount = data.amount
    this.transactionNumber = data.trnReference
    this.paymentMode = data.paymentMode
  }

  editPayment(){
    this.loaderService.display(true);
    if(!this.paymentDate){
      Swal({
        type: 'error',
        title: 'Oops...',
        text: 'Please Enter Amount'
      })
    }
    var data = {
      INVOICEID:this.invoiceId,
      INVOICENO:this.invoiceNo,
      RECEIPTNO:this.receiptNo,
      AMOUNT :this.paymentAmount,
      RECEIPTDT :this.paymentDate,
      PAYMENTMODE :this.paymentMode,
      TRANREF :this.transactionNumber,
      USERID :this.userId,
      remark:this.remark,
      CHEQUEDATE:this.chequeDate,
      isValid :1,
      ISDELETED :0,
      reasonInvalid:null
    }
    this.http.post(environment.apiUrl + 'payment/editPayment',data).subscribe(data => {
      var result  = data.json()
        if(result.statusCode == 200){
          $("#editPaymentModal").modal("hide")
           Swal({
            type: 'success',
            title: 'Oops...',
            text: result.msg,
          })

          

        }else{
          Swal({
            type: 'error',
            title: 'Oops...',
            text: 'Some Internal Problem',
          })
        }
      this.getPayment(this.prjId)
      this.loaderService.display(false);
    });

  }

  selectPaymentMode(paymentMode){
    this.paymentMode = paymentMode
  }

  paymentDateChange(){
    this.paymentDate =  moment(new Date(this.paymentDate)).format('YYYY-MM-DD')
  }

  chequetDateChange(){
    if(this.chequeDate){
      this.chequeDate =  moment(new Date(this.chequeDate)).format('YYYY-MM-DD')
    }
  }


  changePaymentStatusModal(data){
    $("#invalidPaymentModal").modal("show")
    this.receiptNo = data.receiptNo
    this.invoiceId = data.invoiceID
    this.invoiceNo = data.invoiceNo
    this.remark = data.remark
    this.chequeDate = data.chequeDate
    this.paymentDate =  moment(new Date(data.receiptDt)).format('YYYY-MM-DD')
    this.paymentAmount = data.amount
    this.transactionNumber = data.trnReference
    this.paymentMode = data.paymentMode
   
  }

  changePaymentStatus(){
    var data = {
      INVOICEID:this.invoiceId,
      INVOICENO:this.invoiceNo,
      RECEIPTNO:this.receiptNo,
      AMOUNT :this.paymentAmount,
      RECEIPTDT :this.paymentDate,
      PAYMENTMODE :this.paymentMode,
      TRANREF :this.transactionNumber,
      USERID :this.userId,
      remark:this.remark,
      CHEQUEDATE:this.chequeDate,
      isValid :0,
      ISDELETED :0,
      reasonInvalid:this.invalidReason
    }
    this.http.post(environment.apiUrl + 'payment/editPayment',data).subscribe(data => {
      var result  = data.json()
        if(result.statusCode == 200){
          $("#invalidPaymentModal").modal("hide")
           Swal({
            type: 'success',
            title: '',
            text: result.msg,
          })

          

        }else{
          Swal({
            type: 'error',
            title: 'Oops...',
            text: 'Some Internal Problem',
          })
        }
      this.getPayment(this.prjId)
      this.loaderService.display(false);
    });

  }

  getInvalidPaymentReason(){
    this.http.get(environment.apiUrl + 'payment/getInvalidPaymentReason' ).subscribe(data => {
      this.invalidPaymentReason = data.json()
    });
  }


  public colorCode(code: string): SafeStyle {
    let result; 
    switch (code) {
     case 'Online' :
       result = '#28B74B';
       break;
     case 'Cash/Cheque' :
       result = '#2028A4';
       break;
     default:
       result = 'transparent';
       break;
    } 
    return this.sanitizer.bypassSecurityTrustStyle(result);
  }


  public colorCodeStatus(code: string): SafeStyle {
    let result; 
    switch (code) {
     case 'Valid' :
       result = '#28B74B';
       break;
     case 'Invalid' :
       result = '#A43220';
       break;
     default:
       result = 'transparent';
       break;
    } 
    return this.sanitizer.bypassSecurityTrustStyle(result);
  }



  ngOnInit() {
    this.prjId = this.auth.getAuthentication().projectId
    this.userId = this.auth.getAuthentication().id
    this.getPayment(this.prjId)
    this.getInvalidPaymentReason()


  }











}


