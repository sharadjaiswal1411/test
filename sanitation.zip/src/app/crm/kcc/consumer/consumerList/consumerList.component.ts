

import { Component,ViewEncapsulation } from '@angular/core';
import { Http } from '@angular/http'
import { environment } from '../../../../../environments/environment';

import { Observable } from 'rxjs/Observable';
import { ActivatedRoute,Router } from '@angular/router';
import { AuthService } from '../../../../_services';

import { Broadcaster } from '../../../../../environments/broadcaster'; 


import { PagerService } from './consumer.pager.service'
import { LoaderService } from '../../../../_services/loader.service'; 
import { process, State } from '@progress/kendo-data-query';
import { ExcelExportData } from '@progress/kendo-angular-excel-export';
import { GroupDescriptor } from '@progress/kendo-data-query'; 
import { SelectableSettings } from '@progress/kendo-angular-grid';
import {GridDataResult,DataStateChangeEvent} from '@progress/kendo-angular-grid';
import { RowClassArgs } from '@progress/kendo-angular-grid';
 


declare var $: any;


const distinctZone = data => data
  .filter((x, idx, xs) => xs.findIndex(y => y.zoneName === x.zoneName) === idx);
  const distinctWard = data => data
  .filter((x, idx, xs) => xs.findIndex(y => y.wardName === x.wardName) === idx);
  const distinctStatus = data => data
  .filter((x, idx, xs) => xs.findIndex(y => y.verifyStatus === x.verifyStatus) === idx);


@Component({

    selector: 'consumerList-cmp',
    templateUrl: './consumerList.component.html', 
    encapsulation: ViewEncapsulation.None,
    styles: ['.green .codeColumn { color: green; font-weight: bold; background-color: #00800038; } .red .codeColumn { color: red; font-weight: bold; background-color: #ff00003b; }'], 
   
  })

  export class ConsumerListComponent {
    prjID:any
    public consumers: any[];
    refID:any
    consumerName:any
    consumerCD: any
    buildingID: any
    buildingName:any
    ownerName: any
    houseNo: any   
    street:any
    landmark:any
    address: any
    pin: any
    mobileNo:any
    email: any
    bldTypeID: any
    BldTypName: any
    buildingCategoryId: any
    buildingCategoryName: any
    UccCategoryID: any
    catCD: any
    UCCCategory: any
    area: any
    UOM: any
    stdRate: any
    agreedRate: any
    billType: any
    verifyStatus: any
    billStartDt: any
    item:any
    pager: any = {};
    pagedItems:any
    showLoader: boolean; 
    defaultStartDate:any;
    defaultEndDate:any;
    dataRangeModal:any;
    startDate:any;
    endDate:any;  
    
    public state: State = {
      skip: 0,
      take: 100, 
      // Initial filter descriptor
      filter: {
        logic: 'and',
        filters: []
      }
    };
    public pageSize :any
    public checkboxOnly = false;
    public mode = 'multiple';
    public selectableSettings: SelectableSettings;
    public distinctZone: any[]
    public distinctWard: any[]
    public distinctStatus:any[]
    public groups: GroupDescriptor[] = [];
    public view: Observable<GridDataResult>;
    public gridDataConsumerList:any;
    public hiddenColumns: string[] = [];
    public isHidden(columnName: string): boolean {
      return this.hiddenColumns.indexOf(columnName) > -1;
    }

    public groupChange(groups: GroupDescriptor[]): void {
      this.groups = groups;
      this.loadProducts();
    } 

    private loadProducts(): void {
      this.gridDataConsumerList = process(this.consumers, { group: this.groups });
    } 

    public allData(): ExcelExportData {
      const result: ExcelExportData =  {
          data: this.consumers
      };
      return result;
  }


    constructor(private broadcaster: Broadcaster,private auth : AuthService,private http: Http, private routes: ActivatedRoute, private router: Router,private pagerService: PagerService,private loaderService: LoaderService) {
        this.loaderService.status.subscribe((val: boolean) =>{
          this.showLoader = val;
        });
        this.allData = this.allData.bind(this);
        var date = new Date(); 
        var firstDay = new Date(date.getFullYear(), date.getMonth()-6, 1); 
        this.defaultStartDate = (firstDay.getFullYear()) + '-' + (firstDay.getMonth() + 1) + '-' + firstDay.getDate();
        this.defaultEndDate = (date.getFullYear()) + '-' + (date.getMonth()+1) + '-' + date.getDate(); 
        this.dataRangeModal= {beginDate: {year: firstDay.getFullYear(), month: firstDay.getMonth()+1, day: firstDay.getDate()}, endDate: {year: date.getFullYear(), month: date.getMonth()+1, day: date.getDate()}};
      }    

      filterModal(){
      $('#FilterModal').modal('show');
      }

      AddConsumerModal()
      {  
        this.broadcaster.broadcast('addnewConsumer',null);  
      }
     
      editConsumer(consumer)
      {
        this.broadcaster.broadcast('addnewConsumer',consumer);
      }
      createInvoice(invoice){
        this.router.navigate(['/home/crm/kcc/createInvoice',invoice.consumerCD,"New"]);

      }

    //async setPage(page: number) 
    // { 
    //   this.loaderService.display(true); 
    //   this.pager = this.pagerService.getPager(10000, page); 
    //   let response = await fetch(environment.apiUrl + 'consumer' + '?prjId=' + this.prjID+'&pageOffset=' + page + "&pageLimit="  + 10000)
    //   this.consumers = await response.json() 
    // }
    /*
    *get Consumer List on page load
    */
      getConsumers(prjID,pageOffset,pageLimit){
            this.loaderService.display(true);
            if(this.startDate==null||this.endDate==null){
              this.startDate=this.defaultStartDate
              this.endDate=this.defaultEndDate 
             } 
            this.http.get(environment.apiUrl + 'consumer' + '?prjId=' + prjID+'&pageOffset=' + pageOffset + "&pageLimit="+pageLimit+"&startDate="+this.startDate+"&endDate="+this.endDate).subscribe(data => {
            this.consumers = data.json() 
            this.distinctZone = distinctZone(this.consumers); 
            this.distinctWard = distinctWard(this.consumers);
            this.distinctStatus = distinctStatus(this.consumers);
            this.gridDataConsumerList = process(this.consumers, this.state); 
            if(this.consumers.length>0){
              this.loaderService.display(false); 
            } 
            else{
              this.loaderService.display(false); 
            } 
            //this.setPage(1); 
            this.loaderService.display(false); 
         });
      }

  /*
  * filter The Grid Date
  */
      public dataStateChange(state: DataStateChangeEvent): void {
      this.state = state;
      this.gridDataConsumerList = process(this.consumers, this.state); 
      //this.selectedInvoiceCount = this.gridData.data.length  
      if (state && state.group) {  
        this.gridDataConsumerList = process(this.consumers, this.state); 
        } 
    } 
     /**
     * Column BG color Change
  //   */
  //  public rowCallback = (context: RowClassArgs) => {  
  //   console.log("data",context.dataItem.verifyStatus)    
  //   switch (context.dataItem.verifyStatus) { 
  //     case 'Verified': 
  //     return {green : true};      
  //     case 'Unverified': 
  //     return {red : true}; 
  //     default:
  //       return {}; 
  //    } 
  //  }



  
    /*
     * Select Date range
    */  
   onDateRangeChanged(dataRange)
   {  
     if(dataRange.beginDate.day>0){ 
       this.startDate= dataRange.beginDate.year + "-"  + dataRange.beginDate.month+ "-" + dataRange.beginDate.day 
       this.endDate = dataRange.endDate.year + "-"  + dataRange.endDate.month  + "-" + dataRange.endDate.day
       this.getConsumers(this.prjID,1,10000)
     }
     else if(dataRange.beginDate.day==0){
       this.startDate=this.defaultStartDate;
       this.endDate=this.defaultEndDate; 
       this.getConsumers(this.prjID,1,10000)
     }  
   }
   
   

    ngOnInit() 
     { 
        this.prjID = this.auth.getAuthentication().projectId
        this.getConsumers(this.prjID,1,10000)
        this.broadcaster.on('consumerSaved').subscribe(message =>{
         this.getConsumers(this.prjID,1,10000) 
        });
     } 
  
    







    

}


