

import { Component } from '@angular/core';




@Component({

    selector: 'consumer-cmp',
    templateUrl: './consumer.component.html',
    styleUrls: ['./consumer.component.css'],
   
  })
export class ConsumerComponent {
  
}