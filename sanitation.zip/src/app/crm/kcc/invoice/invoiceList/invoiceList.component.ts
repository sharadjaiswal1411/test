



import { Component, ViewEncapsulation } from '@angular/core';





import { environment } from '../../../../../environments/environment';

import { DateAdapter, MAT_DATE_FORMATS, MAT_DATE_LOCALE } from '@angular/material/core';//added by kuldeep on 10-03-2018
import { MomentDateAdapter } from '@angular/material-moment-adapter';//added by kuldeep on 10-03-2018
import * as _moment from 'moment'; //added by kuldeep on 10-03-2018
import * as _rollupMoment from 'moment';//added by kuldeep on 10-03-2018

import { CreateInvoiceComponent } from '../createInvoice/createInvoice.component';
import Swal from 'sweetalert2'
import { process, State } from '@progress/kendo-data-query';
import { ExcelExportData } from '@progress/kendo-angular-excel-export';
import { GroupDescriptor, DataResult } from '@progress/kendo-data-query';
import { Observable } from 'rxjs/Observable';
import { SelectableSettings } from '@progress/kendo-angular-grid';
import {
  GridDataResult,
  DataStateChangeEvent
} from '@progress/kendo-angular-grid';

const moment = _rollupMoment || _moment;
export const MY_FORMATS = {
  parse: {
    dateInput: 'LL',
  },
  display: {
    dateInput: 'LL',
    monthYearLabel: 'MMM YYYY',
    dateA11yLabel: 'LL',
    monthYearA11yLabel: 'MMMM YYYY',
  },
};




declare var $: any;
declare var $: any;
const distinct = data => data
  .filter((x, idx, xs) => xs.findIndex(y => y.zone === x.zone) === idx);


  const distinctWard = data => data
  .filter((x, idx, xs) => xs.findIndex(y => y.ward === x.ward) === idx);
  


  const distinctStatus = data => data
  .filter((x, idx, xs) => xs.findIndex(y => y.status === x.status) === idx);

  
@Component({
  selector: 'invoiceList-cmp',
  templateUrl: './invoiceList.component.html',
  encapsulation: ViewEncapsulation.None ,
  providers: [
    { provide: DateAdapter, useClass: MomentDateAdapter, deps: [MAT_DATE_LOCALE] },
    { provide: MAT_DATE_FORMATS, useValue: MY_FORMATS },
  ],

})
export class InvoiceListComponent extends CreateInvoiceComponent {

  

  
  public state: State = {
    skip: 0,
    take: 150,
    // Initial filter descriptor
    filter: {
      logic: 'and',
      filters: []
    }
  };

  public allData(): ExcelExportData {
    const result: ExcelExportData =  {
        data: this.invoiceList
    };
    return result;
}

  public pageSize :any
  public checkboxOnly = false;
  public mode = 'multiple';
  public selectableSettings: SelectableSettings;
  public distinctZone: any[]
  public distinctWard: any[]
  public distinctStatus:any[]
  public groups: GroupDescriptor[] = [];
  public view: Observable<GridDataResult>;
  public gridView: DataResult;
  public hiddenColumns: string[] = [];
  public prjGovCode:any;
  month:any;
  year:any;
  public isHidden(columnName: string): boolean {
    return this.hiddenColumns.indexOf(columnName) > -1;
  }
  public groupChange(groups: GroupDescriptor[]): void {
    this.groups = groups;
    this.loadProducts();
  }

  private loadProducts(): void {
    this.gridView = process(this.invoiceList, { group: this.groups });
  }
 

  public filteredInvoiceData:any;
  public manualSelectedData:any;
  public gridData: GridDataResult
  public invoiceList: any
  public prjId; any
  public invoiceTypeName:any;
  zoneList: any;
  showLoader: any;
  search: any;
  invoiceState: any;
  invoiceId: any
  remark: any;
  userId: any;
  stateLog: any
  invoiceType: any;
  selectedInvoiceCount:any;
  statusData: any
  dispatched: any
  open: any
  delivered: any
  followUp: any
  paymentReadyOnline: any
  paymentReadyCash_Cheque: any
  paymentConfirmed: any
  invalidPaymentCount: any;
  paid: any;
  total: any;
  paymentDate: any
  paymentMode: any;
  transactionNumber: any;
  selectedInvoice: any;
  paymentAmount: any;
  noData: any;
  fromDate1: any;
  invoiceStage: any;
  paymentReadyMode: any;
  nextfollowupDate: any;
  isSaveFolloup: any;
  isPymentReady: any;
  paymentHistory: any;
  noPayment: any;
  isChangestate: any;
  stateChangeErrorMsg: any;
  chequeDate: any;
  itemMasterData:any;
  invoiceDataForPrint:any;
  ADDRESS:any;
  COMPANYNAME:any
  GSTIN :any
  TOLLFREE :any
  IMAGEURL1:any
  PANNO:any
  invoiceTypeArray:any;
  isManualSelection:any;
  fDate:any;
  tDate:any;
  invoiceHtmlContent:any
  invoiceText:any;
  invoiceLable:any;
  invoiceDateLable:any;
  statusRemark:any;
  invoiceCancel:any;
  paidCount:any;
  invDate:any;
  wardList:any;
  piStartDate:any;
  piEndDate:any;
  piDateRange:any;
  tiStartDate:any;
  tiEndDate:any;
  tiDateRange:any;
  employeList:any;
  bulkActionLabel:any;
  clientManagerId:any;
  zoneId:any;
  wardId:any;
  statusList:any;
  followupStatus:any;
  followupStatusName:any;
  filterData:any = {};
  searching:any;
  selectedForDispatch:any;
  isPaymentSaving:any;
  
  filterModal() {
    $('#filterModal').modal('show');
  }
  AddInvoiceModal() {
    $('#InvoiceModal').modal('show');
  }

  getStateLog(invoiceId) {
    this.loaderService.display(true);
    this.http.get(environment.apiUrl + 'invoice/getStateLog?invoiceId=' + invoiceId).subscribe(data => {
      this.stateLog = data.json()
      this.loaderService.display(false);
      $("#stateLog").modal("show")
    });
  }

  changeStateModal(state, item) {
    this.invoiceStage = state
    this.invoiceId = item.invoiceID
    this.stateChangeErrorMsg = null
    $("#changeState").modal("show")
    if (item.statusId > Number(state)) {
      this.isChangestate = true
      if (item.statusId == 7) {
        this.stateChangeErrorMsg = "Can not change the state of paid Invoice"
      }

    } else {
      this.isChangestate = false
    }
  }
  confirmPayment() {
    this.changeState(null,null)
    $("#changeState").modal("hide")
  }

  invalidPayment() {
    this.invoiceStage = 10
    this.changeState(null,null)
  }
  followupModal(item) {
    this.remark = null
    this.invoiceId = item.invoiceID
    this.invoiceStage = 4
    if (item.statusId == 2 || item.statusId == 3 || item.statusId == 4 || item.statusId == 5 || item.statusId == 6) {
      this.isSaveFolloup = false
    } else {
      this.isSaveFolloup = true
    }

    $("#followup").modal("show")
  }

  saveFollowup() {
    var nextfollowupDate = moment(this.nextfollowupDate).format('YYYY-MM-DD')
    this.changeState(nextfollowupDate,this.followupStatusName)
    $("#followup").modal("hide")
  }
  payment(item) {
    this.clearPaymentData()
    this.selectedInvoice = item
    
    this.paymentAmount = this.selectedInvoice.Amount - this.selectedInvoice.paidAmount
    $("#paymentModal").modal("show")
  }
  viewPayment(state, item) {
    var invoiceId = item.invoiceID
    this.invoiceStage = state
    this.invoiceId = item.invoiceID
    this.paymentHistory = []
    this.noPayment = false;
    $("#paymentLogModal").modal("show")
    this.http.get(environment.apiUrl + "invoice/viewPaymentHistory?invoiceid=" + invoiceId).subscribe(data => {
      this.paymentHistory = data.json()
      console.log("paymentHistory", this.paymentHistory)
      if (this.paymentHistory.length == 0) {
        this.noPayment = true;
      } else {
        this.noPayment = false;
      }
    })
  }


  paymentReadyModal(item) {
    this.remark = null
    this.invoiceId = item.invoiceID
    if (item.statusId == 3 || item.statusId == 4 || item.statusId == 5 || item.statusId == 6) {
      this.isPymentReady = false
    } else {
      this.isPymentReady = true
    }
    $("#paymentReadyModal").modal("show")
  }

  changeStatePaymentReady() {
    if (!this.paymentReadyMode) {
      Swal({
        type: 'error',
        title: 'Oops...',
        text: 'Please Select Payment Mode',
      })
      return;
    }
    if (this.paymentReadyMode == "Online") {
      this.invoiceStage = "5"
    } else {
      this.invoiceStage = "6"
    }
    this.changeState(null,null)
    $("#paymentReadyModal").modal("hide")
  }

  clearPaymentData() {
    this.transactionNumber = null;
    this.paymentMode = null;
    this.paymentDate = new Date();
    this.remark = null
    this.paymentAmount = 0;
    
  }
  validatePayment() {
    if (!this.paymentMode) {
      Swal({
        type: 'error',
        title: 'Oops...',
        text: 'Please Select Payment Mode',
      })
      return false
    } else if (!this.transactionNumber) {
      Swal({
        type: 'error',
        title: 'Oops...',
        text: 'Please Enter Transaction No.',
      })
      return false
    } else if (!this.paymentDate) {
      Swal({
        type: 'error',
        title: 'Oops...',
        text: 'Please Choose Payment Date.',
      })
      return false
    }
    return true
  }
   savePayment() {

    this.isPaymentSaving = true
    if (Number(this.selectedInvoice.Amount) - Number(this.selectedInvoice.paidAmount) == 0) {
      Swal({
        type: 'error',
        title: 'Oops...',
        text: 'Payment already done',
      })
      this.isPaymentSaving = false
      return;
    }
    if (Number(this.paymentAmount) > (Number(this.selectedInvoice.Amount) - Number(this.selectedInvoice.paidAmount))) {
      Swal({
        type: 'error',
        title: 'Payment amount is greater then balance amount',
        text: 'Invalid Payment',
      })
      this.isPaymentSaving = false
      return;
    }
    var chequeDate
    if (!this.validatePayment()) {
      this.isPaymentSaving = false
      return;
    }
    $("#paymentModal").modal("hide")
    if (this.paymentMode == "Online") {
      chequeDate = null
    } else {
      chequeDate = moment(this.chequeDate).format('YYYY-MM-DD')
    }
    var data = {
      INVOICENO: this.selectedInvoice.invoiceNo,
      INVOICEID: this.selectedInvoice.invoiceID,
      RECEIPTNO: null,
      AMOUNT: this.paymentAmount,
      RECEIPTDT: moment(this.paymentDate).format('YYYY-MM-DD'),
      PAYMENTMODE: this.paymentMode,
      TRANREF: this.transactionNumber,
      CHEQUEDATE: chequeDate,
      ISDELETED: 0,
      USERID: this.userId
    }

    this.http.post(environment.apiUrl + "invoice/savePayment", data).subscribe(data => {
      var response = data.json()
      var status = response.output[0].RESPONSECODE
      if (status == 200) {
        var msg = response.output[1].RESPONSEMESSAGE
       // this.getAllInvoice(this.prjId, null)

        this.getInvoiceStatusCount(this.prjId)
        this.searchFilter()
        Swal(
          response.output[2].IDRESPONSE,
          msg,
          'success'
        )
        $("#paymentModal").modal("hide")
        this.isPaymentSaving = false
        this.clearPaymentData()
      } else {
        var msg = response.output[1].RESPONSEMESSAGE
       // this.getAllInvoice(this.prjId, null)
        this.getInvoiceStatusCount(this.prjId)
        Swal(
          msg,
          'error'
        )
        this.clearPaymentData()
        $("#paymentModal").modal("hide")
      }
    })
  
  }


  /*
    Convert proforma invoice into real invoice 
  */

  convertInvoice(item) {
    var data = {
      ID: item.invoiceID,
      PRJID: this.prjId,
      USERID: this.userId,
      invoiceType: 1
    }

    Swal({
      title: 'Are you sure?',
      text: "You won't be able to revert this!",
      type: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Yes, Convert it!'
    }).then((result) => {
      if (result.value) {

        this.http.post(environment.apiUrl + "invoice/convertInvoice", data).subscribe(
          data => {
            console.log("d", data)
            var response = data.json()
            var status = response.output[0].RESPONSECODE
            if (status == 200) {
              var msg = response.output[1].RESPONSEMESSAGE
              Swal(
                response.output[2].INVOICENO_RESPONSE,
                msg,
                'success'
              )
              //this.getAllInvoice(this.prjId, this.invoiceState)

            } else {
              var msg = response.output[1].RESPONSEMESSAGE
              Swal(
                msg,
                'error'
              )
            }
          });
      }
    })
  }


  async getInvoiceStatusCount(prjId) {
    let result = await fetch(environment.apiUrl + "invoice/getInvoiceStatusCount?prjId=" + prjId + "&invoiceType=" + this.invoiceType)
    this.statusData = await result.json() 
    this.dispatched = this.statusData.Dispatched
    this.open = this.statusData.OPEN
    this.delivered = this.statusData.Delivered
    this.followUp = this.statusData.Followup
    this.dispatched = this.statusData.Dispatched
    this.paymentReadyOnline = this.statusData.PaymentReadyOnline
    this.paymentReadyCash_Cheque = this.statusData.PaymentReadyCash_Cheque
    this.paymentConfirmed = this.statusData.PaymentConfirmed;
    this.invoiceCancel = this.statusData.cancelCount
    this.paidCount=this.statusData.Paid
    this.invalidPaymentCount = this.statusData.invalidPaymentCount
    this.paid = this.statusData.Paid
    this.total = this.statusData.total
  }

  bulkDispatchModal(){
    var invoice = this.manualSelectedData
    var count = 0
    for(var i = 0;i<invoice.length;i++){
     if(invoice[i].statusId == 1){
      count++;
    }
  }
  if(count == 0){
    Swal({
      type: 'error',
      title:  "Only select invoice which is in Open state ",
      showConfirmButton: false,
      timer: 10000
   })
  }else if(count != this.manualSelectedData.length){
    Swal({
      type: 'error',
      title:  "Some of the selected invoice can not be dispatched because invoice state is not open ",
      showConfirmButton: false,
      timer: 10000
    })
  }else{
    $("#bulkDispatch").modal("show")
  }
 
  this.selectedForDispatch = count
}
  bulkDispatch(){
    var data = []
    var invoice = this.manualSelectedData
    for(var i = 0;i<invoice.length;i++){
     if(invoice[i].statusId == 1){
      data.push({
        INVOICEID: invoice[i].invoiceID,
        DATE: new Date(),
        STAGE: 2,
        REMARK: this.remark,
        USERID: this.userId,
        NEXTACTIONDATE: null,
        SUBSTATUS:null
      })
    }
    }
    this.loaderService.display(true);
    this.http.post(environment.apiUrl + "invoice/bulkDispatch", data).subscribe(data => { 
      var response = data.json();
      this.loaderService.display(false);
      $("#bulkDispatch").modal("hide")
      Swal({
        type: 'success',
        title:  "Total" +" " +  response.total + " " +  "Invoice Dispatched ",
        showConfirmButton: false,
        timer: 10000
      })
    
     
    })

  }

  async changeState(nextfollowupDate,SUBSTATUS) {
    var data = {
      INVOICEID: this.invoiceId,
      DATE: new Date(),
      STAGE: this.invoiceStage,
      REMARK: this.remark,
      USERID: this.userId,
      NEXTACTIONDATE: nextfollowupDate,
      SUBSTATUS:SUBSTATUS
    } 
    this.http.post(environment.apiUrl + "invoice/changeState", data).subscribe(data => { 
      var response = data.json();
      console.log(response)
      $("#changeState").modal("hide")
      if (response.output[0].RESPONSECODE == 400) {
        Swal({
          type: 'warning',
          title: response.output[1].RESPONSEMESSAGE,
          showConfirmButton: false,
          timer: 10000
        })
       // this.getAllInvoice(this.prjId, this.invoiceState)
        this.getInvoiceStatusCount(this.prjId)
      } else {
        Swal({
          type: 'success',
          title: response.output[1].RESPONSEMESSAGE,
          showConfirmButton: false,
          timer: 10000
        })
       // this.getAllInvoice(this.prjId, this.invoiceState)
        this.getInvoiceStatusCount(this.prjId)
      }


    });

  }

  selectInvoiceType(data) {
    if(data == "Proforma Invoice"){
      this.invoiceType = 0
    }else if(data == "Invoice"){
      this.invoiceType = 1
    }else{
      this.invoiceType = 2
    }
    //this.searchFilter()
    //this.getInvoiceStatusCount(this.prjId)
  }
  selectPaymentMode(data) {

  }




  async getAllInvoice(prjId, status) { 

    let result = await fetch(environment.apiUrl + "invoice/getAllInvoice?prjId=" + prjId + "&invoiceType=" + this.invoiceType + "&status=" + status)
    this.invoiceList = await result.json()
    this.gridData = process(this.invoiceList, this.state); 
    this.allData = this.allData.bind(this);  
    if (this.invoiceList.length == 0) {
      this.noData = true
    } else {
      this.noData = false
    }
 
  }
  viewInvoice(invoice) {
    this.router.navigate(['/home/crm/kcc/createInvoice', invoice.CONSMRCD, invoice.invoiceNo]);
  }

    pdf() {
      this.filteredInvoiceData = []
      console.log("manualSelectedData",this.manualSelectedData)
      if(this.invoiceType == 0){
        this.invoiceTypeName = "PERFORMA INVOICE" 
        this.invoiceLable="PI NO :"
        this.invoiceDateLable="PI  DATE :"
        this.invoiceText=null
       }else{
        this.invoiceTypeName = "TAX INVOICE" 
        this.invoiceText="(ORIGINAL COPY)"
        this.invoiceLable="INVOICE NO :"
        this.invoiceDateLable="INVOICE DATE :"
       }
     $("#pInvoiceModal").modal("show")
     if(!this.isManualSelection){
      this.filteredInvoiceData = this.gridData.data
     }else{
      this.filteredInvoiceData = this.manualSelectedData
     }

     console.log(this.filteredInvoiceData)
  }
  

  printSingleInvoice(data){
    if(this.invoiceType == 0){
      this.invoiceTypeName = "PERFORMA INVOICE" 
     }else{
      this.invoiceTypeName = "TAX INVOICE"  
     }
     $("#pInvoiceModal").modal("show")
     this.filteredInvoiceData = [data]
  }

  sendMailModal(data){
    this.filteredInvoiceData = [data]
    //Added by Ram on 17_07_2018
    if(this.invoiceType == 0){
      this.invoiceTypeName = "PERFORMA INVOICE" 
      this.invoiceLable="PI/I NO :"
      this.invoiceDateLable="PI/I DATE :"
      this.invoiceText=null
     }else{
      this.invoiceTypeName = "TAX INVOICE" 
      this.invoiceText="(ORIGINAL COPY)"
      this.invoiceLable="INVOICE NO :"
      this.invoiceDateLable="INVOICE DATE :"
     }
    $("#pInvoiceModal").modal("show")
  }

   sendEmail(){
    if(this.filteredInvoiceData.length == 1){
      var  printContents  =  document.getElementById('print-section').innerHTML;
      this.http.post(environment.apiUrl + 'invoice/sendEmail',{data:printContents,period:this.filteredInvoiceData[0].period}).subscribe(data => {
      });
    }
   
   }

  printPdf(): void {
       
    let printContents, popupWin;
    
    printContents = document.getElementById('print-section').innerHTML;
    console.log(printContents)
    popupWin = window.open('', '_blank', 'top=0,left=0,height=100%,width=auto');
    popupWin.document.open();
    popupWin.document.write(`
      <html>
        <head>
        </head>
    <body onload="window.print();window.close()">${printContents}</body>
      </html>`
    );
    popupWin.document.close();
}


  getItemMasterByPrjid(){
    
    this.http.get(environment.apiUrl + 'invoice/getItem?prjId=' + this.prjId).subscribe(data => {
      this.itemMasterData = data.json();
    });
  }
  getStatusData(stage) {
    this.invoiceState = stage
    this.filterData.statusIds = []
    this.piStartDate = null
    this.piEndDate = null
    this.filterData.statusIds.push({ID:stage})
    this.searchFilter()
  }


  public dataStateChange(state: DataStateChangeEvent): void {
    this.state = state;
    this.gridData = process(this.invoiceList, this.state);
    this.selectedInvoiceCount = this.gridData.data.length
    this.manualSelectedData = []
  }


  getProjectDetail(){
    
    this.http.get(environment.apiUrl + 'project/getProjectDetail?prjId=' + this.prjId).subscribe(data => {
      var projectDetail = data.json().data;
      console.log(projectDetail)
      this.COMPANYNAME = projectDetail[0].COMPANYNAME
      this.GSTIN = projectDetail[0].GSTIN
      this.TOLLFREE = projectDetail[0].TOLLFREE
      this.IMAGEURL1 = projectDetail[0].IMAGEURL1
      this.PANNO = projectDetail[0].PANNO
      this.ADDRESS = projectDetail[0].ADDRESS
    });
  }

  ngOnInit() { 


    this.pageSize = 10
    this.searching = false
    this.invoiceTypeArray = ["Invoice","All"]
    this.selectableSettings = {
      mode: 'multiple',
    };
    this.selectedInvoiceCount = 0
    this.manualSelectedData = []
    this.isManualSelection = false
    this.noData = false
    this.nextfollowupDate = new Date()
    this.paymentDate = new Date()
    this.chequeDate = new Date();
    this.invoiceState = null
    this.prjId = this.auth.getAuthentication().projectId
    this.userId = this.auth.getAuthentication().id
  

   

    var lastDay = new Date();
    var date = new Date()
    var firstDay = new Date(date.getFullYear(), date.getMonth(), 1);
    this.piStartDate = moment(new Date((firstDay.getFullYear()) + '-' + (firstDay.getMonth() + 1) + '-' + firstDay.getDate())).format('YYYY-MM-DD'); 
    this.piEndDate = moment(new Date((lastDay.getFullYear()) + '-' + (lastDay.getMonth() + 1 ) + '-' + lastDay.getDate())).format('YYYY-MM-DD'); 
    this.piDateRange= {beginDate: {year: firstDay.getFullYear(), month: firstDay.getMonth()+1, day: firstDay.getDate()}, endDate: {year: lastDay.getFullYear(), month: lastDay.getMonth()+1, day: lastDay.getDate()}};
    

    this.tiStartDate = moment(new Date((firstDay.getFullYear()) + '-' + (firstDay.getMonth() + 1) + '-' + firstDay.getDate())).format('YYYY-MM-DD'); 
    this.tiEndDate = moment(new Date((lastDay.getFullYear()) + '-' + (lastDay.getMonth() + 1 ) + '-' + lastDay.getDate())).format('YYYY-MM-DD'); 
    this.tiDateRange= {beginDate: {year: firstDay.getFullYear(), month: firstDay.getMonth()+1, day: firstDay.getDate()}, endDate: {year: lastDay.getFullYear(), month: lastDay.getMonth()+1, day: lastDay.getDate()}};

    this.isSaveFolloup = false
    this.isChangestate = false
    this.isPymentReady = false
    this.invoiceType = 0;
    this.noPayment = false

    this.searchFilter()
    this.getEntity(7)
    this.getEntity(8)
    this.getEmploye()
    this.getInvoiceStatus();
    this.getfollowUpStatus();
    this.getInvoiceStatusCount(this.prjId)
    this.getItemMasterByPrjid()
    this.getProjectDetail()
    this.fDate = new Date()
    this.tDate = moment(new Date()).endOf('month');
    if(this.prjId==1){
      this.prjGovCode="MCL"
    }
    if(this.prjId==2){
      this.prjGovCode="MCG"
    }
    if(this.prjId==3){
      this.prjGovCode="MCF"
    }
  }

  statusChange(data){
    console.log("status", data)
  }
  onSelect(data) { 
    if (data.item == "View Payment") {
      this.viewPayment('8', data.dataItem)
    } else if (data.item == "Convert Invoice") {
      this.convertInvoice(data.dataItem)
    } else if (data.item == "Payment") {
      this.payment(data.dataItem)
    } else if (data.item == "Dispatched") {
      this.changeStateModal('2', data.dataItem);
    } else if (data.item == "Delivered") {
      this.changeStateModal('3', data.dataItem)
    }
    else if (data.item == "Follow-up") {
      this.followupModal(data.dataItem)
    }
    else if (data.item == "Payment Ready") {
      this.paymentReadyModal(data.dataItem)
    } 
    else if (data.item == "Cancel Invoice") { 
       this.statusRemark=data.item
       if(data.dataItem.status=="Paid" || data.dataItem.status == "Payment Confirmed"){
        Swal({
          type: 'error',
          title: "You have not permission to cancel this invoice",
          showConfirmButton: false,
          timer: 10000
        }) 
        return;
       }
       else if(data.dataItem.status!="Paid")
         { 
           if(data.dataItem.status=="Cancelled"){  
            Swal({
              type: 'warning',
              title: "This Invoice has allready Cancelled",
              showConfirmButton: false,
              timer: 10000
            }) 
            return
           }
           else 
           {
            this.cancelInvoiceStatus(data.dataItem)
           }
         } 
    } 
  }


  /*
   *cancel Invoice data cr by Ram on 18_07_2018
  */
  cancelInvoiceStatus(item){
    console.log()
    var data = {
      INVOICEID: item.invoiceID,
      DATE: new Date(),
      STAGE: "9",
      REMARK: this.statusRemark,
      USERID: this.userId,
      NEXTACTIONDATE: null
    } 
    this.http.post(environment.apiUrl + "invoice/changeState", data).subscribe(data => {
      var response = data.json(); 
      $("#changeState").modal("hide")
      if (response.output[0].RESPONSECODE == 400) {
        Swal({
          type: 'warning',
          title: response.output[1].RESPONSEMESSAGE,
          showConfirmButton: false,
          timer: 10000
        })
        //this.getAllInvoice(this.prjId, this.invoiceState)
        this.getInvoiceStatusCount(this.prjId)
      } else {
        Swal({
          type: 'success',
          title: response.output[1].RESPONSEMESSAGE,
          showConfirmButton: false,
          timer: 10000
        })
        //this.getAllInvoice(this.prjId, this.invoiceState)
        this.getInvoiceStatusCount(this.prjId)
      } 
    }); 
  }

  
  deselectInvoice(invoiceNo){
    for(var i= 0;i<this.manualSelectedData.length;i++){
      if(this.manualSelectedData[i].invoiceNo == invoiceNo){
        this.manualSelectedData.splice(i,1)
      }
    }
  }


  selectionChange(data){
    console.log(data)
    this.isManualSelection = true
    if(!data.selected){
      if(data.deselectedRows.length>1){
        this.manualSelectedData = []
      }
      this.deselectInvoice(data.deselectedRows[0].dataItem.invoiceNo)
      return;
    }
   
  
    if(data.selectedRows.length>1){
      this.manualSelectedData = []
      for(var i = 0;i<data.selectedRows.length;i++){
        this.manualSelectedData.push(data.selectedRows[i].dataItem)
      }
      return;
    }
    if(!data.ctrlKey){
      this.manualSelectedData = [data.selectedRows[0].dataItem]
    }else{
      this.manualSelectedData.push(data.selectedRows[0].dataItem)
    }
  }



    /* 
       bulk  invoice Creation 
    */


   calculateInvoiceAmount(rate,area){
    var firstDate = moment(new Date(this.fDate));
    var endDate = moment(new Date(this.tDate))
    var month = [31,28,31,30,31,30,31,31,30,31,30,31]
    var amount = 0
    var totalMonth =  endDate.diff(firstDate, 'month');
         var currentDate = new Date(this.fDate).getDate() 
         var period =  month[new Date(this.tDate).getMonth()]
         var days = (period - currentDate)  +1
         var days_rate = (rate/30)*days
          if(totalMonth>0 && days >0){
            if(days == period){
              amount = (rate * area)*(totalMonth +1)
              var totalMonthAndDays = totalMonth + 1  + " " + "Month" 
            }else{
              var totalMonthAndDays = totalMonth + " " + "Month" + days + " " +  "days"
              amount = days_rate*area +  (rate *area)*totalMonth
            }
            
           }
           else if(days == 0){
            var totalMonthAndDays = totalMonth + " " +  "Month" 
          }else if(totalMonth == 0){
             if(period == days){
              var totalMonthAndDays = "1 Month"
              amount = (rate *area)*(totalMonth +1)
             }else{
              var totalMonthAndDays = days + " " +  "days"
               amount = days_rate*area +  (rate *area)*totalMonth
             }
           
          }

          return Number(amount);
   }
   bulkGenerationtTestModal(){
    $("#bulkgeneration").modal("show")
   }

   bulkGenerationtTest(){
    $("#bulkgeneration").modal("show")
   }



   bulkGeneration(){
    this.loaderService.display(true);
    this.http.get(environment.apiUrl + 'invoice/bulkInvoiceGenerationTest?prjId='+this.prjId+'&month=' + this.month + "&year=" + this.year).subscribe(data =>{ 
          var result = data.json(); 
          console.log(result)
          this.loaderService.display(false);
          Swal({
            type: 'success',
            title:  "Total" + result.count + " " +  "Invoice created"  + "errCount" + result.errCount,
            showConfirmButton: false,
            timer: 10000
          })
     }); 
   }
   generateBulkInvoice(){
    this.loaderService.display(true);
    var data = this.manualSelectedData
      var invoice_array = []
      var obj = {}
     
      var d = new Date()
      var year = d.getFullYear()
      var month = d.getMonth()
    
      if(d.getDate() <= 25){
        this.invDate = new Date()
      }else{
         var invDate =  moment([year, month + 1]);
         this.invDate = moment(invDate).format('YYYY-MM-DD')
      }
      var due = moment(new Date(this.invDate), "DD-MM-YYYY").add('days', 15);
      var dueDate  = moment(due).format('YYYY-MM-DD')
      var rate  = 1
      var area = 1

      for(var i=0;i<data.length;i++){
        if(data[i].uom == null){
          area = 1
        }else{
          area = data[i].qty_Area
        }
        var amount = this.calculateInvoiceAmount(data[i].rate,area)
        var invoiceSGST = Number(Number((amount* 9)/100).toFixed(2))
        var invoiceCGST = Number(Number((amount* 9)/100).toFixed(2))
        var taxAmount =  invoiceSGST +  invoiceCGST 
        var totalAmount  = Math.round(amount) + Math.round(Number(taxAmount))
        var taxableAmount= amount
        var roundOff  = Number((totalAmount - Number(invoiceSGST +  invoiceCGST + amount)).toFixed(2));         
         obj = {
          pinvoiceno:null,
          invoiceType:0,
          PRJID : Number(this.prjId),
          INVOICENO:null,
          CONSUMERID :data[i].refid,
          INVOICEDT :this.invDate,
          DUEDATE :dueDate,
          UCCCATID :data[i].UCCCatID,
          STATUS :1,
          USERID:this.userId,
          deleteflag :0,  
          ITEMID :data[i].itemID,
          SGST :invoiceSGST,
          CGST :invoiceCGST,
          IGST :0,
          rate :data[i].rate,
          qty_area :data[i].qty_Area,
          amount :totalAmount,
          taxableAmount:taxableAmount,  
          arrears :0,
          discount :0,
          roundoff :roundOff,
          fromdt :moment(this.fDate).format('YYYY-MM-DD'),
          todt :moment(this.tDate).format('YYYY-MM-DD'),
        }
        invoice_array.push(obj)  
        console.log("AfterPushData",invoice_array)
      }

      this.http.post(environment.apiUrl + 'invoice/bulkInvoice',invoice_array).subscribe(data => {
        var result = data.json().total
        var msg = data.json().msg
        this.loaderService.display(false);
        Swal({
          type: 'success',
          title:  "Total" + result + " " +  "Invoice created ",
          showConfirmButton: false,
          timer: 10000
        })
      });
  }


  tDateChange(data){
    var monthArray = [31,28,31,30,31,30,31,31,30,31,30,31]
    var lastDate = new Date(this.tDate).getDate()
    var month = new Date(this.tDate).getMonth()
    if(monthArray[month] != lastDate ){
        alert("please select last date of month")
        this.tDate = moment(new Date()).endOf('month');
        return;
      }
 }

 getEntity(oemid){
  this.http.get(environment.apiUrl + 'consumer/getZoneByProject?prjid='+this.prjId+'&oemid=' + oemid).subscribe(data =>{ 
    var result = data.json(); 
    if(oemid == 8){
        this.wardList = result
    }else if(oemid == 7){
      this.zoneList = result
    }
   }); 
 } 

 getEmploye(){
  this.http.get(environment.apiUrl + "admin/getEmploye" + "?prjId=" + this.prjId).subscribe(data =>{ 
    this.employeList = data.json();  
    console.log(this.employeList)
  }); 
} 


  getInvoiceStatus(){
     this.http.get(environment.apiUrl + "invoice/getInvoiceStatus").subscribe(data =>{ 
       this.statusList = data.json();  
    }); 
  }

  getfollowUpStatus(){
    this.http.get(environment.apiUrl + "invoice/getfollowUpStatus").subscribe(data =>{ 
      this.followupStatus = data.json();  
   }); 
  }

  selectZone(data){

  }

  selectWard(data){

  }
  selectClientManager(data){

  }

  piDateRangeChanged(dataRange){
    if(dataRange.beginEpoc != 0){ 
      var startDate= dataRange.beginDate.year + "-"  + dataRange.beginDate.month+ "-" + dataRange.beginDate.day 
      var endDate = dataRange.endDate.year + "-"  + dataRange.endDate.month  + "-" + dataRange.endDate.day

      this.piStartDate  = moment(startDate).format('YYYY-MM-DD');
      this.piEndDate = moment(endDate).format('YYYY-MM-DD');
      console.log("PI date",this.piStartDate,this.piEndDate)
  }else{
      this.piStartDate  = null
      this.piEndDate = null
  }
}

  tiDateRangeChanged(dataRange){
    if(dataRange.beginEpoc != 0){ 
      var startDate= dataRange.beginDate.year + "-"  + dataRange.beginDate.month+ "-" + dataRange.beginDate.day 
      var endDate = dataRange.endDate.year + "-"  + dataRange.endDate.month  + "-" + dataRange.endDate.day

      this.tiStartDate  = moment(startDate).format('YYYY-MM-DD');
      this.tiEndDate = moment(endDate).format('YYYY-MM-DD');

      console.log("PI date",this.tiStartDate,this.tiEndDate)
     }else{
      this.tiStartDate  = null
      this.tiEndDate = null
     }
  }

  clearFilter(){
    this.filterData = {}
    this.searchFilter();
  }
  searchFilter(){
    this.loaderService.display(true);
    this.searching = true
    var data = {
      zoneId:this.filterData.zoneId,
      wardId:this.filterData.wardId,
      piStartDate:this.piStartDate,
      piEndDate:this.piEndDate,
      tiStartDate:this.tiStartDate,
      tiEndDate:this.tiEndDate,
      clientManagerId:this.filterData.clientManagerId,
      consumerId:this.filterData.consumerId,
      pInvoiceNo:this.filterData.pInvoiceNo,
      consumerName:this.filterData.consumerName,
      address:this.filterData.address,
      invoiceType:this.invoiceType,
      statusIds:this.filterData.statusIds,
      prjId:this.prjId
    }

    this.http.post(environment.apiUrl + "invoice/getInvoiceByFilter", data).subscribe(data =>{ 
      this.invoiceList = data.json();  
      this.getInvoiceStatusCount(this.prjId)
      console.log(this.invoiceList)
      this.gridData = process(this.invoiceList, this.state); 
      this.searching = false
      this.allData = this.allData.bind(this);
      this.loaderService.display(false);
      $("#filterModal").modal("hide")
    }); 

  }



}


