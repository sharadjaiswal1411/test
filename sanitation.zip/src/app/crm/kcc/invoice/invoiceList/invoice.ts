export class Invoice {

    constructor( 
      public ADDRESS:any,
      public Amount:any,
      public Arrears: any,
      public CATNAME: any,
      public CGST: any,
      public CONSMRCD: any,
      public CONSMRNAME: any,
      public Duedate: any,
      public EMAIL: any,
      public FROMDT: any, 
      public GSTIN:any,
      public IGST:any,
      public Itemdescription: any, 
      public MOBILENO:any,
      public SGST:any,
      public TODT:any,
      public blCatName:any,
      public invoiceDT:any,
      public period:any,
      public qty_Area:any,
      public rate:any,
   
      public roundOff:any,
      public uom:any,

      public ward:any,
      public zone:any,
      public invoiceNo:any
      
    ) {  }
  
  }