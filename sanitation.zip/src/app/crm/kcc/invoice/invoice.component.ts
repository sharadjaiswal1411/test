
import { Component } from '@angular/core';


@Component({

    selector: 'invoice-cmp',
    templateUrl: './invoice.component.html',
    
   
  })
export class InvoiceComponent {}