

import { Component,ViewEncapsulation} from '@angular/core';
import { ActivatedRoute,Router } from '@angular/router';
import { Http } from '@angular/http'

import { environment } from '../../../../../environments/environment';
import {DateAdapter, MAT_DATE_FORMATS, MAT_DATE_LOCALE} from '@angular/material/core';//added by kuldeep on 10-03-2018
import {MomentDateAdapter} from '@angular/material-moment-adapter';//added by kuldeep on 10-03-2018
import * as _moment from 'moment'; //added by kuldeep on 10-03-2018
import * as _rollupMoment from 'moment';//added by kuldeep on 10-03-2018
import {DomSanitizer, SafeStyle} from '@angular/platform-browser';
import { AuthService } from '../../../../_services/index';
import { Broadcaster } from '../../../../../environments/broadcaster';
import { LoaderService } from '../../../../_services/loader.service';
import Swal from 'sweetalert2'
declare var require: any;
var converter = require('number-to-words');
declare var $: any;

const moment = _rollupMoment || _moment;
export const MY_FORMATS = {
  parse: {
    dateInput: 'LL',
  },
  display: {
    dateInput: 'LL',
    monthYearLabel: 'MMM YYYY',
    dateA11yLabel: 'LL',
    monthYearA11yLabel: 'MMMM YYYY',
  },
};

@Component({

    selector: 'createInvoice-cmp',
    templateUrl: './createInvoice.component.html',
    encapsulation: ViewEncapsulation.None ,
    providers: [
      { provide: DateAdapter, useClass: MomentDateAdapter, deps: [MAT_DATE_LOCALE] },
      { provide: MAT_DATE_FORMATS, useValue: MY_FORMATS },
    ],
   
  })


  
export class CreateInvoiceComponent {

  
    public consumers:any
    public BldTypName:any
    totalAmountInWords:any;
    email:any;
    UCCCategory:any;
    area:any;
    address:any
    GSTIN:any;
    consumerName:any;
    mobileNo:any;
    wardName:any;
    zoneName:any;
    ngxDisabled:any;
    consumerCode:any;
    prjID:any;
    buildingCatogery:any;
    uccCategory:any
    buildingCategoryId:any
    uccCategoryId:any
    itemMaster:any;
    itemDescription:any
    agreedRate;any;
    stdRate:any;
    itemRate:any;
    itemAmount:any
    itemQty:any
    itemDetail:any
    invoiceCGST:any
    invoiceSGST:any
    invoiceIGST:any
    arrearsAmt:any
    taxAmount:any
    subTotal:any
    totalAmount:any
    roundOff:any;
    consumerRefID:any
    itemId:any;
    fromDate:any;
    toDate:any
    invoiceDate:any;
    invoiceDueDate:any
    uom:any;
    userId:any;
    date:any;
    dueDate:any;
    invoiceData:any
    invoiceNo:any
    showLoader:any
    CGST:any;
    SGST:any;
    pinvoiceno :any
    invoiceType :any
    invoiceStatus:any
    constructor(public routes: ActivatedRoute, public router: Router,public sanitizer: DomSanitizer,public broadcaster: Broadcaster,public auth : AuthService,public http: Http,public loaderService: LoaderService) {
      this.itemDetail = []
      this.fromDate = new Date();
      this.toDate = new Date()
      var d = new Date()
      var year = d.getFullYear()
      var month = d.getMonth()
      this.date = new Date()
     
      
     
      this.dueDate = new Date()
      this.invoiceNo = null
      this.pinvoiceno = null
      this.invoiceStatus = 1
      this.loaderService.status.subscribe((val: boolean) => {
          this.showLoader = val;
      });

      // this.pinvoiceno :any
       this.invoiceType = 0
    }
 

    initializeDate(){
      this.fromDate = new Date()
      this.toDate = moment(new Date()).endOf('month');
      this.dueDate = moment(this.date, "DD-MM-YYYY").add('days', 15);
    }

    invoiceDateChange(data){
      this.dueDate = moment(this.date, "DD-MM-YYYY").add('days', 15);
    }
   
    fromDateChange(data){
       if(this.itemMaster.length>0){
        this.bindItemData(this.itemMaster)
       }else{
         alert("some internal problem")
       }
       
    }
    toDateChange(data){
      var monthArray = [31,28,31,30,31,30,31,31,30,31,30,31]
      var lastDate = new Date(this.toDate).getDate()
      var month = new Date(this.toDate).getMonth()
      if(monthArray[month] != lastDate ){
          alert("please select last date of month")
          this.toDate = moment(new Date()).endOf('month');
          return;
        }
      if(this.itemMaster.length>0){
        this.bindItemData(this.itemMaster)
       }else{
         alert("some internal problem")
       }
   }


    style(data: string): SafeStyle {
        return this.sanitizer.bypassSecurityTrustStyle(data);
    }
   

    searchConsumer(data){

    }


    selectConsumer(data){
      this.bindconsumerInfo(data)
      this.bindItemData(this.itemMaster)
    }

   





    printInvoice(){
     // $("#InvoiceModal").modal("show")
      this.print()
    }
    print(): void {
       
      let printContents, popupWin;
      printContents = document.getElementById('print-section').innerHTML;
      console.log(printContents)
      popupWin = window.open('', '_blank', 'top=0,left=0,height=100%,width=auto');
      popupWin.document.open();
      popupWin.document.write(`
        <html>
          <head>
          </head>
      <body onload="window.print();window.close()">${printContents}</body>
        </html>`
      );
      popupWin.document.close();
  }
    saveInvoice(){
      this.loaderService.display(true); 
      var data = {
        pinvoiceno:this.pinvoiceno,
        invoiceType:this.invoiceType,
        PRJID :    this.prjID,
        INVOICENO:this.invoiceNo,
        CONSUMERID :this.consumerRefID,
        INVOICEDT :moment(this.date).format('YYYY-MM-DD'),
        DUEDATE :moment(this.dueDate).format('YYYY-MM-DD'),
        UCCCATID :this.uccCategoryId,
        STATUS :this.invoiceStatus,
        USERID:this.userId,
        deleteflag :0,        
        ITEMID :this.itemId,
        SGST :this.invoiceSGST,
        CGST :this.invoiceCGST,
        IGST :this.invoiceIGST,
        rate :this.agreedRate,
        qty_area :this.area,
        amount :this.totalAmount,
        taxableAmount:this.subTotal,
        arrears :0,
        discount :0,
        roundoff :this.roundOff,
        fromdt :moment(this.fromDate).format('YYYY-MM-DD'),
        todt :moment(this.toDate).format('YYYY-MM-DD'), 
      }
      this.http.post(environment.apiUrl + 'invoice/save',data).subscribe(data => {
        this.loaderService.display(false); 
        console.log(data.json())
        var response = data.json()
        if(response.output[0].RESPONSECODE == 400){
          Swal({
            type: 'error',
            title: response.output[1].RESPONSEMESSAGE,
            showConfirmButton: false,
            timer: 10000
          })
        }else{
          Swal({
            type: 'success',
            title: response.output[1].RESPONSEMESSAGE,
            showConfirmButton: false,
            timer: 10000
          })
          if(response.output[2].INVOICENO_RESPONSE == null){
            this.getInvoiceDetails(this.invoiceNo)
          }else{
            this.router.navigate(['/home/crm/kcc/createInvoice',this.consumerCode,response.output[2].INVOICENO_RESPONSE]);
          }
        }
       
       
      });  
    }

    bindconsumerInfo(data){
      console.log(data)
       this.BldTypName = data.BldTypName
       this.consumerRefID = data.refID
       this.email = data.email;
       this.consumerName = data.consumerName
       this.buildingCategoryId = data.buildingCategoryId;
       this.getUccCategoryType(data.buildingCategoryId,data.UccCategoryID);
       this.area = data.area;
       this.uom = data.UOM
       if(data.agreedRate == null){
        this.agreedRate = data.stdRate
       }else{
        this.agreedRate = data.agreedRate;
       }
      
       this.stdRate = data.stdRate;
       this.address = data.address;
       this.GSTIN = data.GSTIN;
       this.mobileNo = data.mobileNo;
       this.wardName = data.wardName;
       this.zoneName = data.zoneName    
  }



    createConsumer(){
      this.broadcaster.broadcast('addnewConsumer',null);
    }
    editConsumer(consumer){
      this.broadcaster.broadcast('addnewConsumer',consumer);
    }

    
  


    getUccCategoryType(buildCatId,uccCategoryID){ 
        this.http.get(environment.apiUrl + 'consumer/getUccTypeByCatId?categoryId='+ buildCatId+'&prjId='+this.prjID).subscribe(data => {
              this.uccCategory=data.json();  
              this.uccCategoryId = uccCategoryID
          });  
   }  
    bindUccCategory(data){
      this.uom = data.UOM
      if(data.UOM == null){
        this.agreedRate = 1
      }else{
        this.agreedRate = data.RATE
      }
      this.bindItemData(this.itemMaster)

   }
    getConsumerBuildingCategory(){
        this.http.get(environment.apiUrl + 'consumer/getConsumerBuildingCategoty?prjId='+ this.prjID).subscribe(data =>{
              this.buildingCatogery=data.json();  
          }); 
    }

    getItemDescription(data){
      console.log(data)
    }

    getMonthDiff(first,last){
      var one = moment(first);
      var two = moment(last);
      var dateDiffs = [];
      var count = Math.round(moment.duration(one.diff(two)).asMonths());

      var month =  two.month() + 1;
      var year  =  two.year();
  for (var i=1; i<=count; i++) {
      if (month > 12) {
        month = 1;
        year++;
      }
      dateDiffs.push(year+"-"+month);
      console.log(month);
      month++;
  }

  console.log(dateDiffs);
    }

    bindItemData(data){
      var rate ;
      this.itemId = data[0].itemId; 
      this.invoiceCGST = 0
      this.invoiceSGST = 0
      this.invoiceIGST = 0
      this.itemDetail = []
      if(this.uom == null){
        rate = 1
        this.area = 1
        rate = this.agreedRate
      }else{
        rate = this.agreedRate
      }

      this.getMonthDiff(new Date(this.fromDate),new Date(this.toDate))
      var firstDate = moment(new Date(this.fromDate));
      var endDate = moment(new Date(this.toDate))
      var month = [31,28,31,30,31,30,31,31,30,31,30,31]
      var totalMonth =  endDate.diff(firstDate, 'month');
           var currentDate = new Date(this.fromDate).getDate() 
           var period =  month[new Date(this.fromDate).getMonth()]
           var days = (period - currentDate)  +1
           var days_rate = (this.agreedRate/30)*days
          //  if(totalMonth == 0 ){
          //    var amount = this.agreedRate*this.area
          //  }else if(currentDate>1){
          //     var amount = days_rate*this.area +  (this.agreedRate *this.area)*totalMonth
          //  }   else if(currentDate == 1){
          //   var amount = (this.agreedRate *this.area)*totalMonth
          //  }
            if(totalMonth>0 && days >0){
              if(days == period){
                var amount = (this.agreedRate *this.area)*(totalMonth +1)
                var totalMonthAndDays = totalMonth + 1  + " " + "Month" 
              }else{
                var totalMonthAndDays = totalMonth + " " + "Month" + days + " " +  "days"
                var amount = days_rate*this.area +  (this.agreedRate *this.area)*totalMonth
              }
              
             }
             else if(days == 0){
              var totalMonthAndDays = totalMonth + " " +  "Month" 
            }else if(totalMonth == 0){
               if(period == days){
                var totalMonthAndDays = "1 Month"
                var amount = (this.agreedRate *this.area)*(totalMonth +1)
               }else{
                var totalMonthAndDays = days + " " +  "days"
                var amount = days_rate*this.area +  (this.agreedRate *this.area)*totalMonth
               }
             
            }
          
        var firstDate = moment(new Date(this.fromDate));
        var endDate = moment(new Date(this.toDate))
        
      for(var i=0;i<data.length;i++){
          this.subTotal = Number(amount.toFixed(2))
          var item  = {
            itemDescription:data[i].description,
            itemRate: rate,
            itemQty:this.area,
            itemAmount: Number(amount.toFixed(2)),
            itemCGST :Number((amount* Number(data[i].CGST)/100).toFixed(2)),
            itemSGST :Number((amount* Number(data[i].SGST)/100).toFixed(2)),
            itemIGST :0,
            hsnCD:data[i].hsnCD,
            days:totalMonthAndDays
          }
          this.invoiceCGST = this.invoiceCGST + item.itemCGST
          this.invoiceSGST = this.invoiceSGST + item.itemSGST
          this.invoiceIGST = this.invoiceIGST + item.itemIGST
          this.itemDetail.push(item)
      }
      this.taxAmount =  this.invoiceCGST +  this.invoiceSGST 
      var total  = Math.round(amount + this.invoiceCGST +  this.invoiceSGST)
      this.roundOff  = (((this.invoiceCGST +  this.invoiceSGST + amount) - total )).toFixed(2);
      
      this.totalAmount = total
      this.totalAmountInWords = converter.toWords(total)
      this.loaderService.display(false); 
    }


    getItem(prjID){
      this.http.get(environment.apiUrl + 'invoice/getItem?prjId='+ prjID).subscribe(data =>{
        this.itemMaster = data.json();
        console.log("itemMaster", this.itemMaster)
        this.bindItemData(this.itemMaster)  
    }); 
    }

    async getConsumersByCode(consumerCode){
      let response = await fetch(environment.apiUrl + "getConsumerByCode?consumerCode=" + consumerCode)
      let consumer  = await response.json()
      let itemResult = await fetch(environment.apiUrl + 'invoice/getItem?prjId='+ this.prjID)
      let item  = await itemResult.json()
      this.bindconsumerInfo(consumer[0])
      this.getItem(this.prjID)
      this.loaderService.display(false); 
    }
    bindInvoiceData(data){
      console.log("invoice",data)
      this.pinvoiceno = data.pInvoiceNo,
      this.invoiceType = data.invoiceType,
      this.address = data.ADDRESS
      this.GSTIN = data.GSTIN
      this.consumerName = data.CONSMRNAME
      this.invoiceStatus = data.statusId
      this.consumerCode = data.CONSMRCD;
      this.BldTypName = data.BldTypName
      this.consumerRefID = data.refid
      this.email = data.EMAIL;
      this.buildingCategoryId = data.bldCatId;
      this.getUccCategoryType(data.bldCatId,data.UCCCatID);
      this.area = Number(data.qty_Area);
      this.uom = data.uom
      this.agreedRate = Number(data.rate);
      this.stdRate = Number(data.stdRate);
      this.mobileNo = data.mobileNo;
      this.wardName = data.ward;
      this.zoneName = data.zone;     
      this.invoiceCGST = data.CGST
      this.invoiceSGST = data.SGST
      this.invoiceIGST = data.IGST
      this.fromDate = data.FROMDT;
      this.toDate = data.TODT;
      this.date = data.invoiceDT;
      this.dueDate = data.Duedate;
      this.arrearsAmt = data.Arrears
    
    
      
    }
    async getInvoiceDetails(invoiceNo){
      console.log(invoiceNo)  
    
      let response = await fetch(environment.apiUrl + "invoice/getInvoiceByNo?invoiceNo=" + invoiceNo)
      let invoiceData  = await response.json()
      let data  = invoiceData[0]
      this.bindInvoiceData(data)
      this.getItem(this.prjID)
    }


  
    


    ngOnInit() {
     
      this.prjID = this.auth.getAuthentication().projectId
      this.userId = this.auth.getAuthentication().id

      this.routes.params.subscribe(params => {
        let invoiceNo = params['invoiceNo']
        if(invoiceNo == "New"){
          this.loaderService.display(true); 
          this.consumerCode = params['consumerCode']
          this.getConsumersByCode(params['consumerCode'])
          this.initializeDate()
        }else{
          this.loaderService.display(true); 
          this.invoiceNo = invoiceNo
          this.getInvoiceDetails(invoiceNo)
        }
       
   });
     
      this.getConsumerBuildingCategory()
    }
     
  }
