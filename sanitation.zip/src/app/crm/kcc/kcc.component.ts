

import { Component } from '@angular/core';


@Component({

    selector: 'kcc-cmp',
    templateUrl: './kcc.component.html', 
   
  })
export class KccComponent{  
    
}


