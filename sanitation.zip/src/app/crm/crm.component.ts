
import { Component } from '@angular/core';


@Component({

    selector: 'crm-cmp',
    templateUrl: './crm.component.html',
    styleUrls: ['./crm.component.css'],
   
  })
export class CRMComponent {

    
}