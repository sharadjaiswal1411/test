import { Component  } from '@angular/core';
import { Http } from '@angular/http'
import { environment } from '../../../environments/environment';
import { AuthService } from '../../_services'; 
import { LoaderService } from '../../_services/loader.service'; 
import * as _moment from 'moment';  
import * as _rollupMoment from 'moment'; 
const moment = _rollupMoment || _moment; 
declare var $: any; 
declare var google: any;

@Component({
  selector: 'app-aggregate',
  templateUrl: './aggregate.component.html',
  styleUrls: ['./aggregate.component.css']
})
export class AggregateComponent  {
showLoader:boolean;
heatmap:any;
heatmap1:any;
heatmap2:any;
map: any;
polygondData: any;
mapLabelArray: any;
mapview:boolean=false;
public canvasWidth = 300;
public canvasSmallWidth = 150;
public primaryNeedleValue = 50;
public secondaryNeedleValue = 78;
public wasteNeedleValue = 65;
public centralLabel = '';
public primary = 'Primary Operations';
public secondary = 'Secondary Operations';
public waste = 'Waste Processing';
public primaryBottomLabel = '50';
public secondaryBottomLabel = '78';
public wasteBottomLabel = '65';
public primaryOpBottomLabel1='57.94%';
public primaryOpBottomLabel2='86.28%';
public primaryOpBottomLabel3='31.8%';
public primaryOpBottomLabel4='31.36%';
public primaryOpBottomLabel5='71.11%';

public secondaryOpBottomLabel1='85%';
public secondaryOpBottomLabel2='72.41%';
public secondaryOpBottomLabel3='69.64%';
public secondaryOpBottomLabel4='86.43%';

public secondaryOperations1 = {
    hasNeedle: true,
    needleColor: '#333333',
    needleUpdateSpeed: 1000,
    arcColors: ['#71B37C', 'lightgray'],
    arcDelimiters: [85],
    rangeLabel: ['0', '100'],
    needleStartValue: 0,
}


public secondaryOperations2 = {
    hasNeedle: true,
    needleColor: '#333333',
    needleUpdateSpeed: 1000,
    arcColors: ['#FABF40', 'lightgray'],
    arcDelimiters: [72.41],
    rangeLabel: ['0', '100'],
    needleStartValue: 0,
}
public secondaryOperations3 = {
    hasNeedle: true,
    needleColor: '#333333',
    needleUpdateSpeed: 1000,
    arcColors: ['#FABF40', 'lightgray'],
    arcDelimiters: [69.64],
    rangeLabel: ['0', '100'],
    needleStartValue: 0,
}
public secondaryOperations4 = {
    hasNeedle: true,
    needleColor: '#333333',
    needleUpdateSpeed: 1000,
    arcColors: ['#71B37C', 'lightgray'],
    arcDelimiters: [86.43],
    rangeLabel: ['0', '100'],
    needleStartValue: 0,
}



public primaryOperations1 = {
    hasNeedle: true,
    needleColor: '#333333',
    needleUpdateSpeed: 1000,
    arcColors: ['#F0AD4E', 'lightgray'],
    arcDelimiters: [57.94],
    rangeLabel: ['0', '100'],
    needleStartValue: 0,
}


public primaryOperations2 = {
    hasNeedle: true,
    needleColor: '#333333',
    needleUpdateSpeed: 1000,
    arcColors: ['#70B27B', 'lightgray'],
    arcDelimiters: [86.28],
    rangeLabel: ['0', '100'],
    needleStartValue: 0,
}
public primaryOperations3 = {
    hasNeedle: true,
    needleColor: '#333333',
    needleUpdateSpeed: 1000,
    arcColors: ['#E04C56', 'lightgray'],
    arcDelimiters: [31.8],
    rangeLabel: ['0', '100'],
    needleStartValue: 0,
}
public primaryOperations4 = {
    hasNeedle: true,
    needleColor: '#333333',
    needleUpdateSpeed: 1000,
    arcColors: ['#E04C56', 'lightgray'],
    arcDelimiters: [31.36],
    rangeLabel: ['0', '100'],
    needleStartValue: 0,
}

public primaryOperations5 = {
    hasNeedle: true,
    needleColor: '#333333',
    needleUpdateSpeed: 1000,
    arcColors: ['#70B27B', 'lightgray'],
    arcDelimiters: [71.11],
    rangeLabel: ['0', '100'],
    needleStartValue: 0,
}

public primaryOptions = {
    hasNeedle: true,
    needleColor: '#333333',
    needleUpdateSpeed: 1000,
    arcColors: ['#d11729', 'lightgray'],
    arcDelimiters: [50],
    rangeLabel: ['0', '100'],
    needleStartValue: 0,
}
public secondaryOptions = {
    hasNeedle: true,
    needleColor: '#333333',
    needleUpdateSpeed: 1000,
    arcColors: ['#058230', 'lightgray'],
    arcDelimiters: [78],
    rangeLabel: ['0', '100'],
    needleStartValue: 0,
}
public wasteOptions = {
    hasNeedle: true,
    needleColor: '#333333',
    needleUpdateSpeed: 1000,
    arcColors: ['#f95700', 'lightgray'],
    arcDelimiters: [65],
    rangeLabel: ['0', '100'],
    needleStartValue: 0,
}
gradient1:any = [
          'rgba(255,0,0,0)',
          'rgba(255,0,0,1)',
          'rgba(255,0,0,1)',
          'rgba(255,0,0,1)',
          'rgba(255,0,0,1)',
          'rgba(255,0,0,1)',
          'rgba(255,0,0,1)',
          'rgba(255,0,0,1)',
          'rgba(255,0,0,1)',
          'rgba(255,0,0,1)',
          'rgba(255,0,0,1)',
          'rgba(255,0,0,1)',
          'rgba(255,0,0,1)',
          'rgba(255,0,0,1)'
          
        ];
gradient2:any = [
           'rgba(0, 255, 0, 0)',
           'rgba(0, 255, 0, 1)',
           'rgba(0, 255, 0, 1)',
           'rgba(0, 255, 0, 1)',
           'rgba(0, 255, 0, 1)',
           'rgba(0, 255, 0, 1)',
           'rgba(0, 255, 0, 1)',
           'rgba(0, 255, 0, 1)',
           'rgba(0, 255, 0, 1)',
           'rgba(0, 255, 0, 1)',
           'rgba(0, 255, 0, 1)',
           'rgba(0, 255, 0, 1)',
           'rgba(0, 255, 0, 1)',
           'rgba(0, 255, 0, 1)'
          
        ];
		
gradient3:any = [
          'rgba(255,255,0,0)',
		  'rgba(255,255,0,1)',
          'rgba(255,255,0,1)',
          'rgba(255,255,0,1)',
          'rgba(255,255,0,1)',
          'rgba(255,255,0,1)',
          'rgba(255,255,0,1)',
          'rgba(255,255,0,1)',
          'rgba(255,255,0,1)',
          'rgba(255,255,0,1)',
          'rgba(255,255,0,1)',
          'rgba(255,255,0,1)',
          'rgba(255,255,0,1)',
          'rgba(255,255,0,1)'
          
        ];

constructor(private http: Http, private auth: AuthService,private loaderService: LoaderService) {

  this.loaderService.status.subscribe((val: boolean) =>{
    this.showLoader = val; 
  }); 
this.mapLabelArray = [];  

}


  
  ngOnInit() {
	 
    this.map = new google.maps.Map(document.getElementById('map'), {
      zoom: 11,
      center: { lat: 28.47769599987369, lng: 77.06160699973178 },
	styles: [{
            "elementType": "geometry",
            "stylers": [{
                "color": "#1d2c4d"
            }]
        },
        {
            "elementType": "labels.text.fill",
            "stylers": [{
                "color": "#8ec3b9"
            }]
        },
        {
            "elementType": "labels.text.stroke",
            "stylers": [{
                "color": "#1a3646"
            }]
        },
        {
            "featureType": "administrative.country",
            "elementType": "geometry.stroke",
            "stylers": [{
                "color": "#4b6878"
            }]
        },
        {
            "featureType": "administrative.land_parcel",
            "elementType": "labels.text.fill",
            "stylers": [{
                "color": "#64779e"
            }]
        },
        {
            "featureType": "administrative.province",
            "elementType": "geometry.stroke",
            "stylers": [{
                "color": "#4b6878"
            }]
        },
        {
            "featureType": "landscape.man_made",
            "elementType": "geometry.stroke",
            "stylers": [{
                "color": "#334e87"
            }]
        },
        {
            "featureType": "landscape.natural",
            "elementType": "geometry",
            "stylers": [{
                "color": "#023e58"
            }]
        },
        {
            "featureType": "poi",
            "elementType": "geometry",
            "stylers": [{
                "color": "#283d6a"
            }]
        },
        {
            "featureType": "poi",
            "elementType": "labels.text.fill",
            "stylers": [{
                "color": "#6f9ba5"
            }]
        },
        {
            "featureType": "poi",
            "elementType": "labels.text.stroke",
            "stylers": [{
                "color": "#1d2c4d"
            }]
        },
        {
            "featureType": "poi.park",
            "elementType": "geometry.fill",
            "stylers": [{
                "color": "#023e58"
            }]
        },
        {
            "featureType": "poi.park",
            "elementType": "labels.text.fill",
            "stylers": [{
                "color": "#3C7680"
            }]
        },
        {
            "featureType": "road",
            "elementType": "geometry",
            "stylers": [{
                "color": "#304a7d"
            }]
        },
        {
            "featureType": "road",
            "elementType": "labels.text.fill",
            "stylers": [{
                "color": "#98a5be"
            }]
        },
        {
            "featureType": "road",
            "elementType": "labels.text.stroke",
            "stylers": [{
                "color": "#1d2c4d"
            }]
        },
        {
            "featureType": "road.highway",
            "elementType": "geometry",
            "stylers": [{
                "color": "#2c6675"
            }]
        },
        {
            "featureType": "road.highway",
            "elementType": "geometry.stroke",
            "stylers": [{
                "color": "#255763"
            }]
        },
        {
            "featureType": "road.highway",
            "elementType": "labels.text.fill",
            "stylers": [{
                "color": "#b0d5ce"
            }]
        },
        {
            "featureType": "road.highway",
            "elementType": "labels.text.stroke",
            "stylers": [{
                "color": "#023e58"
            }]
        },
        {
            "featureType": "transit",
            "elementType": "labels.text.fill",
            "stylers": [{
                "color": "#98a5be"
            }]
        },
        {
            "featureType": "transit",
            "elementType": "labels.text.stroke",
            "stylers": [{
                "color": "#1d2c4d"
            }]
        },
        {
            "featureType": "transit.line",
            "elementType": "geometry.fill",
            "stylers": [{
                "color": "#283d6a"
            }]
        },
        {
            "featureType": "transit.station",
            "elementType": "geometry",
            "stylers": [{
                "color": "#3a4762"
            }]
        },
        {
            "featureType": "water",
            "elementType": "geometry",
            "stylers": [{
                "color": "#0e1626"
            }]
        },
        {
            "featureType": "water",
            "elementType": "labels.text.fill",
            "stylers": [{
                "color": "#4e6d70"
            }]
        }
    ],
    zoomControlOptions: {
        position: google.maps.ControlPosition.RIGHT_CENTER
    },
    fullscreenControlOptions:{
        position: google.maps.ControlPosition.RIGHT_CENTER
    }

    });
    this.map.data.setStyle(function (feature) {
      var color = feature.getProperty('FillColor');
      var strokeColor = "#8B0000"
    
      return ({
        fillColor: color,
        strokeColor: strokeColor,
        strokeWeight: 6
      
      });
    });
 
	
	this.getEntityZoneAndWard(2);
	this.plotMarkers(2);

  }
 mapView($event){
	 
	this.mapview=$event;  
  }
  
   addMarker(location,img) {
      let  marker = new google.maps.Marker({
            position: location,
			icon:'/assets/img/'+img+'.png',
            map: this.map
        });
    }
  
  zoomPolygon(this, map) {
    this.bounds = new google.maps.LatLngBounds();
      map.data.forEach((feature) => {
        this.processPoints(feature.getGeometry(), this.bounds.extend, this.bounds);
      });
     map.fitBounds(this.bounds);
  }
   clearFeature(){
      this.map.data.forEach((feature) => {
          this.map.data.remove(feature);
      })
      
   }
  processPoints(this, geometry, callback, thisArg) {
    if (geometry instanceof google.maps.LatLng) {
      callback.call(thisArg, geometry);
    } else if (geometry instanceof google.maps.Data.Point) {
      callback.call(thisArg, geometry.get());
    } else {
      if(geometry){
      geometry.getArray().forEach((g) => {
        this.processPoints(g, callback, thisArg);
      });
    }
    }
  }
  
  plotMarkers(prjID){
	  this.showLoader=true;
	  
	  

	  
		
		  this.http.get(environment.apiUrl + 'doc/buildingpoints.json').subscribe(data => {
		 
		   let points=data.json()
		  
			 for(let i=0;i<points.length;i++){
				 if(points[i].status==1){
					this.addMarker(new google.maps.LatLng(points[i].LATITUDE, points[i].LONGITUDET),'red');
				 }else if(points[i].status==2){
					  this.addMarker(new google.maps.LatLng(points[i].LATITUDE, points[i].LONGITUDET),'green');
				 }else if(points[i].status==3){
					  this.addMarker(new google.maps.LatLng(points[i].LATITUDE, points[i].LONGITUDET),'yellow');
				 }
			 }
			 this.showLoader=false;
			});
	 
	

	
	  
  }
  getEntityZoneAndWard(prjID) {
    $('#loderImgTab').show()
   
    this.http.get(environment.apiUrl + 'entity/getPolygon' + "?prjid=" + prjID).subscribe(data => {
      this.clearFeature()
      this.map.data.addGeoJson(data.json().geoJson);
   //   this.zoomPolygon(this.map);
     // var date = moment(this.surveyDate).format('YYYY-MM-DD');
     // this.getSurveyData(this.prjId,this.isVerified,date,this.selectedWard,this.surveyType);
      $('#loderImgTab').hide()
	  
	 
     
    });
  } 
  
  
 }


