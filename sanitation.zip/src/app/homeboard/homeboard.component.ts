import { Component ,OnInit} from '@angular/core';
@Component({
  selector: 'homeboard-cmp',
  templateUrl: './homeboard.component.html',
  styleUrls: ['./homeboard.component.css']
})
export class HomeboardComponent implements OnInit {
  
  constructor() { }

  ngOnInit() {
      
}
}