import {Directive, ElementRef, Input, OnInit} from '@angular/core';
import { AuthService } from '../_services/index';
@Directive({
	selector: '[hasPermission]'
})
export class HasPermissionDirective implements OnInit{ 
    @Input('hasPermission') permission: string;
   
   constructor(private _el: ElementRef,private authService: AuthService) { }
   
  
   ngOnInit() {
     if(!this.authService.userHasPermission(this.permission)) {

       this._el.nativeElement.style.display = 'none';
     }
     
   }

}