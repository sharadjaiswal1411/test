import { ElementRef, Input,Component,OnInit, } from '@angular/core';
import { AuthService } from '../_services';
import { Http } from '@angular/http'
import { environment } from '../../environments/environment';


import { Broadcaster } from '../../environments/broadcaster';

 
import {Subscription} from 'rxjs/Subscription';
import { LoaderService } from '../_services/loader.service';


declare var $: any;
declare var google: any;

@Component({
    selector: 'new-consumer',
    templateUrl: 'newConsumer.component.html',
})


export class NewConsumerDirective implements OnInit{ 
  public busy: Subscription;
  @Input() consumer: any;
  public showLoader: boolean; 
   public consumers:any
    map:any
    prjID:any
    userId:any
    consumerCode:any
    city:any
    refID:any
    consumerName:any
    consumerCD: any
    buildingID: any
    buildingName:any
    ownerName: any
    houseNo: any   
    street:any
    //locality:any
    state:any
    landmark:any
    address: any
    shipAddress:any;
    pin: any
    mobileNo:any
    email: any
    bldTypeID: any
    BldTypName: any
    buildingCategoryId: any
    buildingCategoryName: any
    UccCategoryID: any
    catCD: any
    UCCCategory: any
    area: any
    UOM: any
    stdRate: any
    agreedRate: any
    uomDataModal:any;
    billType: any
    verifyStatus: any
    //billStartDt: any 
    buildingCatogery:any
    buildCatId:any 
    buildingCatogeryType:any
    uccType:any
    UccId:any 
    uomType:any; 
    ddlZoneData:any;
    ddlWordData: any;
    ddlZoneModel:any
    latitudeModal:any
    longitudeModal:any
    gstinModal:any 
    public ddlUomTypModal:any
    public ddlWardModel:any
    public search:any
    public entityCodeLoaderDiv=false
    public imgLoaderPath:any
    public billTypeJsonData:any
    public billingTypeModal:any
    public verifyStatusData:any
    public verifiedStatusModal:any
    public crmLocationsData:any;
    public lat:any;
    public lng:any;
    public crmLocations:any;
    public consumerLocanotFound=false;
    public imgCrmPath:any;
    public crmLoaderDiv=false
    public consuSuccessMsg=false;
    public chkConsumerEmailAddress=false;
    isConsuSavebtn=false;
    chkConsumerNameAddress=false;
    //emailRequired=false;
    consuErrorMsg=false;
    requiredBldCategory=false;
    requiredUccCategory=false;
    requiredZone=false;
    requiredWard=false;
    public totalAgreedRate:any;
    public agreedRateValid=false; 
    public agrValue:any; 
    public billStartDt: any  
    public requiredBillType=false;
    public requiredVeriFiedStatus=false;
    public agreedRateRequired=false;
    public areaRequired=false;
    public billDateRequired=false;
    public addressRequired=false;
    public proAgreedRate:any;
    public monthlychargesValid=false;
    public proMonthlyCharge:any; 
    isService:any;
    isBillable:any;

    employeList:any;
    clientManager:any;
    distributionManager:any;
    serviceManager:any
    

   constructor(private broadcaster: Broadcaster,private _el: ElementRef,private auth : AuthService,private http: Http,private loaderService: LoaderService) 
   {  
      this.broadcaster.on('addnewConsumer').subscribe(message => 
      {
        if(message){
            $('#ConsumerModal').modal('show'); 
            this.editConsumer(message)
            this.billTypeDetails(); 
            this.billingTypeModal=this.billTypeJsonData[1].ID; 
            this.consuErrorMsg=false;
            this.consuSuccessMsg=false; 
        }
        else{ 
            $('#ConsumerModal').modal('show');
            this.clearConsumerData()
            this.getConsumersCode();
            this.getZoneByProject();
            this.billTypeDetails(); 
            this.billingTypeModal=this.billTypeJsonData[1].ID; 
            this.verifiedStatusModal=this.verifyStatusData[1].ID; 
            this.consuErrorMsg=false;
            this.consuSuccessMsg=false; 
        }
     });
     this.consuErrorMsg=false;
     this.loaderService.status.subscribe((val: boolean) => 
     {
       this.showLoader = val;
     });
   } 
     
    /*
   ** To bind UOM details Data
  */
  public billTypeDetails()
  {
      this.billTypeJsonData=
      [{  
      "ID":1,
      "VALUE":"Direct", 
      },
      {  
      "ID":2,
      "VALUE":"Invoice", 
      }]
  }

   /*
     To bind UOM details Data
  */
  public verifyStatusDetails()
  {
      this.verifyStatusData=
      [{  
      "ID":1,
      "VALUE":"Verified", 
      },
      {  
      "ID":2,
      "VALUE":"Unverified", 
      }]
  }

    
    AddConsumerModal(){  
         this.clearConsumerData()
         $('#ConsumerModal').modal('show');
        
      }
      clearConsumerData(){
        this.refID = null
        this.consumerName = null
        this.consumerCD = null
        this.buildingID= null
        this.buildingName= null
        this.ownerName= null
        this.houseNo= null
        this.street= null
        //this.locality=null
        this.state=null
        this.landmark= null
        this.address= null
        this.shipAddress=null;
        this.gstinModal=null
        this.latitudeModal=null
        this.longitudeModal=null
        this.city=null
        this.pin= null
        this.mobileNo = null
        this.email= null
        this.bldTypeID= null
        this.BldTypName= null
        this.buildingCategoryId= null
        this.buildCatId=null;
        this.buildingCategoryName= null
        this.UccCategoryID= null
        this.catCD= null
        this.UCCCategory= null
        this.area= null
        this.UOM= null
        this.stdRate= null
        this.agreedRate= null
        this.billType= null
        this.verifyStatus= null
        this.billStartDt= null 
        this.addressRequired=false;
        this.billDateRequired=false;
        this.ddlZoneModel=null;
        this.ddlWardModel=null; 
        this.requiredZone=false;
        this.requiredWard=false;
        this.agreedRateValid=false;
        this.monthlychargesValid=false;
        this.areaRequired=false; 
        this.agreedRate="";  
        this.totalAgreedRate="";
        this.proMonthlyCharge="";       
        this.proAgreedRate="";
        this.uomDataModal="";
      } 
      editConsumer(consumer)
      { 
        console.log('consumer data--',consumer) 
        
        this.isConsuSavebtn=false;
        this.clearConsumerData()
        this.billTypeDetails(); 
        this.getBuildingType(); 
        this.billingTypeModal=this.billTypeJsonData[0].ID;  
        this.refID = consumer.refID
        this.consumerName = consumer.consumerName
        this.consumerCD = consumer.consumerCD
        this.buildingID= consumer.buildingID
        this.bldTypeID= consumer.bldTypeID; 
        this.buildingName= consumer.buildingName
        this.ownerName= consumer.ownerName 
        this.ddlZoneModel=consumer.zoneID
        this.ddlWardModel=consumer.wardId
        this.getZoneByProject()
        this.getWardByProject()
        this.houseNo= consumer.houseNo 
        this.street= consumer.street
        this.landmark= consumer.landmark
        this.address= consumer.address
        this.shipAddress=consumer.ShippingAddress  
        this.pin= consumer.pin
        this.mobileNo = consumer.mobileNo
        this.email= consumer.email 
        this.BldTypName= consumer.BldTypName 
        this.buildingCategoryName= consumer.buildingCategoryId 
        this.selectBuildCatogeryId()  
        this.UCCCategory= consumer.UccCategoryID 
        this.UccCategoryID= consumer.UccCategoryID
        this.catCD= consumer.catCD  
        this.UOM= consumer.UOM
        this.stdRate= consumer.stdRate 
        this.billType= consumer.billType
        if(this.billType=="Direct"){this.billingTypeModal=1}else{this.billingTypeModal=2}  
        this.billStartDt= consumer.billStartDt 
        //this.locality=consumer.locality
        this.state=consumer.state
        this.city=consumer.city
        this.latitudeModal=consumer.lat  
        this.longitudeModal=consumer.lng 
        this.gstinModal=consumer.GSTIN       
        this.verifyStatus=consumer.verifyStatus 
        if(this.verifyStatus=="Verified"){this.verifiedStatusModal=1}else{this.verifiedStatusModal=2} 
        this.uomDataModal=consumer.UOM;
        if(this.uomDataModal==null)
        { 
          this.agreedRate=consumer.agreedRate
          this.totalAgreedRate=consumer.agreedRate;
          this.proAgreedRate=consumer.agreedRate;
          this.proMonthlyCharge=consumer.agreedRate; 
        } 
        if(this.uomDataModal!=null)
        { 
          this.area= consumer.area;
          this.agreedRate= consumer.stdRate;
          this.proAgreedRate=consumer.agreedRate;
          this.totalAgreedRate=(this.area*this.proAgreedRate).toFixed(2); 
          this.proMonthlyCharge=(this.area*this.agreedRate).toFixed(2); 
        } 
          this.clientManager = consumer.CLIENTMGR
          this.distributionManager = consumer.DISTMGR
          this.serviceManager = consumer.SERVICEMGR
          if(consumer.ISBILLABLE){
            this.isBillable = true
          }else{
            this.isBillable = false
          }
          if(consumer.ISSERVICED){
            this.isService = true
          }else{
            this.isService = false
          }
      }
    
      //To save The Consumer Details
      saveConsumer()
      { 

        if(this.isService){
          var isService = 1
        }else{
          var isService = 0
        }

        if(this.isBillable){
          var isBillable = 1
        }else{
          var isBillable = 0
        }
        var billTypName:any
        var verifyedStatus:any 
        if(this.billingTypeModal==1){billTypName="Direct"}  if(this.billingTypeModal==2){billTypName="Invoice"}
        if(this.verifiedStatusModal==1){verifyedStatus="Verified"}  if(this.verifiedStatusModal==2){verifyedStatus="Unverified"} 
        if(this.consumerName==null||this.consumerName==undefined||this.consumerName==''){this.chkConsumerNameAddress=true; return}         
        if(this.buildCatId==null||this.buildCatId==undefined||this.buildCatId==''){this.requiredBldCategory=true;return}       
        if(this.UCCCategory==null||this.UCCCategory==undefined||this.UCCCategory==''){this.requiredUccCategory=true; return}
        if(this.billingTypeModal==null||this.billingTypeModal==undefined||this.billingTypeModal==''){this.requiredBillType=true; return}
        if(this.verifiedStatusModal==null||this.verifiedStatusModal==undefined||this.verifiedStatusModal==''){
          this.requiredVeriFiedStatus=true; 
          return
        } 
        if((this.uomDataModal!=null) && (this.area==null||this.area=="")){
          this.areaRequired=true;           
          return;
        }
        if((this.uomDataModal!=null)&&(this.proAgreedRate==""||this.proAgreedRate<=0))
        {
          this.agreedRateValid=true;
          return
        }
        if(this.uomDataModal==null)
        {
          this.areaRequired=false;
        }  
        if(this.agreedRate<=0||this.agreedRate==undefined||this.agreedRate==null)
        { 
         this.agreedRateValid=true;
         return;
        }  
        if(this.billStartDt==null)
        {
          this.billDateRequired=true;
          return;
        } 
        if(this.ddlZoneModel==null||this.ddlZoneModel==''||this.ddlZoneModel==undefined){
          this.requiredZone=true; return
        }
        if(this.ddlWardModel==null||this.ddlWardModel==''||this.ddlWardModel==undefined){
          this.requiredWard=true; return
        }
        if(this.address==null)
        {
          this.addressRequired=true;
          return;
        } 
        var data = 
        {
          "Prjid":this.prjID,
          "userId":this.userId,
          "consumerCD": this.consumerCD,
          "consumerName":this.consumerName,
          "email":this.email?this.email:null,
          "mobileNo":this.mobileNo?this.mobileNo:null, 
          "BLDTYPEID":this.bldTypeID?this.bldTypeID:null, 
          "UCCCategoryID":this.UCCCategory?this.UCCCategory:null,
          "billingType":billTypName?billTypName:null, 
          "verificationStatus":verifyedStatus?verifyedStatus:null,
          "area": this.area?this.area:0, 
          "uomTypModal":this.uomDataModal?this.uomDataModal:null,
          "agreedRate": this.proAgreedRate?this.proAgreedRate:0,
          "billStartDt": this.billStartDt,
          "ddlZoneModel":this.ddlZoneModel?this.ddlZoneModel:null,
          "ddlWardModel":this.ddlWardModel?this.ddlWardModel:null,
          "houseNo": this.houseNo?this.houseNo:null, 
          "state":this.state?this.state:null,
          "pin": this.pin? this.pin:null, 
          "street":this.street?this.street:null,     
          "landmark":this.landmark?this.landmark:null,
          "city":this.city?this.city:null,
          "address": this.address?this.address:null,
          "shippingaddress": this.shipAddress?this.shipAddress:null,
          "latitude":this.latitudeModal?this.latitudeModal:null,
          "longitude":this.longitudeModal?this.longitudeModal:null,
          "gstin":this.gstinModal?this.gstinModal:null,
          "refId":this.refID?this.refID:null,
          "CLIENTMGR":this.clientManager?this.clientManager:null,
          "DISTMGR":this.distributionManager?this.distributionManager:null,
          "SERVICEMGR":this.serviceManager?this.serviceManager:null,
          "ISSERVICED":isService,
          "ISBILLABLE":isBillable

        } 
        this.loaderService.display(true); 
        this.isConsuSavebtn=true;
        console.log(data)
        this.http.post(environment.apiUrl + 'consumer/saveConsumerDetails',data) 
          .subscribe((data)=>
          {   
            var responceCode=data.json().status;  
            if(responceCode=="200")
            {
              this.broadcaster.broadcast('consumerSaved',"");
              this.consuSuccessMsg=true;
              this.loaderService.display(false); 
            }
            if(responceCode!="200")
            {
              this.consuSuccessMsg=false;
              this.consuErrorMsg=true;
              this.loaderService.display(false); 
            } 
            setTimeout(()=> 
            {
              this.consuSuccessMsg=false;
              this.isConsuSavebtn=false;
              this.loaderService.display(false);  
            }, 5000); 
          });  
      }

      /**
       * consumer Name required
      */
      consNameRequired(consName)
      {
        if(consName==null||consName=='')
        {
          this.chkConsumerNameAddress=true;
          this.isConsuSavebtn=true;
          return;
        }
        if(consName!=null||consName!='')
        {
          this.chkConsumerNameAddress=false;
          this.isConsuSavebtn=false;
        } 
      }

       /* 
      Select Ucc category 
      */ 
      selectUccCategory(uccCatData)
      { 
         if(uccCatData!=null)
         { 
         this.agreedRate=uccCatData.RATE
         this.proAgreedRate=uccCatData.RATE
         this.totalAgreedRate=uccCatData.RATE
         this.proMonthlyCharge=uccCatData.RATE
         this.uomDataModal=uccCatData.UOM  
         if(this.uomDataModal!=null && (this.area!=null||this.area!=0))
         { 
          this.totalAgreedRate=(this.agreedRate*this.area).toFixed(2); 
          this.proMonthlyCharge=(this.area*this.proAgreedRate).toFixed(2);
         } 
         if(this.uomDataModal!=null && (this.area==null))
         { 
          this.totalAgreedRate=this.agreedRate; 
          this.proMonthlyCharge=this.proAgreedRate;
         } 
        } 
        else
         {
           this.requiredUccCategory=true;
         }         
      }


      /*
       * get area valu change
      */
      areaValueChange(value)
      {  
        this.area=value;
        if((this.area== ""||this.area== "0") && (this.uomDataModal!=null))
        {
          this.totalAgreedRate=this.agreedRate;
          this.areaRequired=true; 
        }
        else if((this.area!= "") && (this.uomDataModal!=null))
        {
          this.totalAgreedRate=(this.area*this.agreedRate).toFixed(2);  
          this.proMonthlyCharge=(this.area*this.proAgreedRate).toFixed(2);
          this.areaRequired=false;  
        } 
        if(this.uomDataModal!=null && (this.area==""))
        { 
         this.totalAgreedRate=(this.agreedRate).toFixed(2); 
         this.proMonthlyCharge=(this.proAgreedRate).toFixed(2);
        } 
      }

      /**
       * to chack agreed Value gr. than 0
      */      
      proAgreedValueChange(agreedValue)
      { 
        this.proAgreedRate=agreedValue; 
        if(this.proAgreedRate<=0)
        {
          this.agreedRateValid=true;
        }
        else if(this.proAgreedRate>=0)
        {
          this.agreedRateValid=false;
          if((this.area!=null) && (this.uomDataModal!=null))
          { 
            this.proMonthlyCharge=(this.area*this.proAgreedRate).toFixed(2);  
          }
          if((this.area==null||this.area!=null||this.area=="") && (this.uomDataModal==null))
          { 
            this.proMonthlyCharge=this.proAgreedRate;  
          }           
        } 
      } 
    /* 
    This method is used to get the Building Catogery By Project Id 
    */
      getConsumerBuildingCategory()
      {
        this.busy = this.http.get(environment.apiUrl + 'consumer/getConsumerBuildingCategoty?prjId='+ this.prjID) 
        .subscribe(data => 
            {
                this.buildingCatogery=data.json();
            }); 
      }
    /* 
     Get Bld Type Name
    */
      getBuildingType(){
        this.busy = this.http.get(environment.apiUrl + 'consumer/getBuilType').subscribe(data =>{ 
                this.buildingCatogeryType=data.json();  
            });
      }

    /* 
    This method is used to get the Building Catogery Id on change event 
    */ 
      selectBuildCatogeryId(){
        this.buildCatId=this.buildingCategoryName; 
        if(this.buildCatId==null||this.buildCatId==undefined||this.buildCatId==''){
          this.requiredBldCategory=true;
          return;
        }if(this.buildCatId!=null||this.buildCatId!=undefined){
            this.requiredBldCategory=false;
            this.getConsumerBuildingType();
            this.getUccCategoryType();           
        } 
      } 
      /* 
      Select Billing category 
      */ 
      selectBillingType(billType){ 
        if(billType==null){
          this.requiredBillType=true;
          return;
        }else{
          this.requiredBillType=false;
        }       
      }

      selectVerifiedStatus(verifiedStatus){
        if(verifiedStatus==null){
          this.requiredVeriFiedStatus=true;
          return;
        }else{
          this.requiredVeriFiedStatus=false;
        }
      }



     
    /*
     * Get Consumer Building Type by Building Category Id
    */ 
      getConsumerBuildingType(){
        var buldCatId=this.buildCatId; 
        // this.http.get(environment.apiUrl + 'consumer/getConsumerBuildingTypeByCatId?categoryId='+buldCatId) 
        // .subscribe(data => 
        //     {
        //         this.buildingCatogeryType=data.json();  
        //         console.log("data",this.buildingCatogeryType);
        //     });  
        }
        
     /*
     * Get Consumer Building Type by Building Category Id
    */ 
      getUccCategoryType(){ 
        var buldCatId=this.buildCatId; 
        this.http.get(environment.apiUrl + 'consumer/getUccTypeByCatId?categoryId='+buldCatId+'&prjId='+this.prjID).subscribe(data =>{
                this.uccType=data.json(); 
            });  
     }   
    
  
  /*
   * Mobile Number number Restrict method
  */
public restrictNumericOnly(e){
  let input;
  var inputlen;
  if (e.metaKey || e.ctrlKey){
    return true;
  }
  if (e.which === 32){
   return false;
  }
  if (e.which === 0){
   return true;
  }
  if (e.which < 33){
    return true;
  }
  input = String.fromCharCode(e.which); 
  return !!/[\d\s]/.test(input);
 }
 

public numericOnlyWithDecimal(e){
  let input;
  var inputlen;
  if (e.metaKey || e.ctrlKey) {
    return true;
  }
  if (e.which === 32) {
   return false;
  }
  if (e.which === 0) {
   return true;
  }
  if (e.which < 33) {
    return true;
  }
  //This step for only dot means decimal entry
  if((e.which != 46 || $(this).val().indexOf('.') != -1) && (e.which < 48 || e.which > 57))
  {
    return false;
  } 
  input = String.fromCharCode(e.which); 
  return !!/[\d\s]/.test(input);
 }
 
//To check The Email Address Validations;
onBlurToCheckEmailAddress(){
  var txtEmailData = this.email; 
  var atpos = txtEmailData.indexOf("@");
  var dotpos = txtEmailData.lastIndexOf(".");
  if (atpos<1 || dotpos<atpos+2 || dotpos+2>=txtEmailData.length){ 
    if(this.email==''){ 
      this.chkConsumerEmailAddress=false;
    }else{
      this.chkConsumerEmailAddress=true; 
    } 
  }else{
    this.chkConsumerEmailAddress=false;
  }
} 

     /*
      * create Consumer Code
     */ 
        getConsumersCode(){  
            var consumerCode
            var prjId=this.prjID
            var userId=this.userId
            var source="W"
            this.isConsuSavebtn=true;
            if(this.consumerCD==null||this.consumerCD==undefined||this.consumerCD==''){
              this.entityCodeLoaderDiv=true;
              this.imgLoaderPath="../../assets/img/loading.gif";
            }
            this.http.get(environment.apiUrl + 'consumer/generateConsumerCode?Prjid='+prjId+'&userId='+this.userId+'&source='+source).subscribe(data =>{ 
                    consumerCode= data.json().ConsumerCode; 
                    if(consumerCode!=null||consumerCode!=undefined){
                        this.consumerCD=consumerCode; 
                        if(this.consumerCD==null||this.consumerCD==undefined||this.consumerCD==''){
                          this.imgLoaderPath="../../assets/img/loading.gif";
                        }else{
                          this.imgLoaderPath="../../assets/img/ok.png";
                          this.isConsuSavebtn=false;
                        }                       
                    }else{
                      this.imgLoaderPath="../../assets/img/loading.gif";
                    }
                }); 
        } 

      /*
        get Zone By Project
     */ 
    getZoneByProject()
    {  
        this.http.get(environment.apiUrl + 'consumer/getZoneByProject?prjid='+this.prjID+'&oemid=7').subscribe(data =>{ 
                 this.ddlZoneData= data.json(); 
            }); 
    } 
     /*
        get Zone By Project
     */ 
    getWardByProject(){ 
      if(this.ddlZoneModel==null||this.ddlZoneModel==''||this.ddlZoneModel==undefined){
        this.requiredZone=true;
        return;
      }
      this.requiredZone=false;   
      this.http.get(environment.apiUrl + "consumer/getZoneByProject?prjid="+this.prjID+"&oemid=8&entityid="+this.ddlZoneModel).subscribe(data =>{ 
                 this.ddlWordData= data.json();  
            }); 
     } 
      /*
        get Ward By Project
     */  
      getWardIdByProject(){
          if(this.ddlWardModel==null||this.ddlWardModel==''||this.ddlWardModel==undefined){
            this.requiredWard=true;
            return;
          }else if(this.ddlWardModel!=null||this.ddlWardModel!=''||this.ddlWardModel!=undefined){
            this.requiredWard=false;
          }
      }
 

     //To get The locations on click on map
   public getcrmLocationsByLatLong(prjID,radious,lat,lng){ 
      this.crmLoaderDiv=true  
      this.imgCrmPath="../../assets/img/loading.gif" 
      this.consumerLocanotFound=false;
      this.http.get(environment.apiUrl + "consumer/getLocationByLatlong?prjid="+prjID+"&lat='"+lat+"'&lng='"+lng+"'&radious="+radious).subscribe(data =>{     
               this.crmLocations=data.json(); 
               if(this.crmLocations.length==0){
               this.consumerLocanotFound=true;
               this.crmLoaderDiv=false  
               }else{
               this.consumerLocanotFound=false; 
               this.crmLoaderDiv=false 
               } 
          });  
    } 

    selectServiceManager(data){

      

    }
    selectDistributionManager(data){

    }
    selectClientManager(data){

    }

    getEmploye(){
      this.http.get(environment.apiUrl + "admin/getEmploye" + "?prjId=" + this.prjID).subscribe(data =>{ 
        this.employeList = data.json();  
        console.log(this.employeList)
      }); 
    }

      ngOnInit() 
      {          
       var thisRef = this 
       var myOptions = {
        center: new google.maps.LatLng(28.47769599987369, 77.06160699973178),
        zoom: 13,
        panControl: true,
        styles: [
          {'featureType': 'water', 'stylers': [{'saturation': 43}, {'lightness': -11}, {'hue': '#0088ff'}]},
          {'featureType': 'road', 'elementType': 'geometry.fill', 'stylers': [{'hue': '#ff0000'},
          {'saturation': -100}, {'lightness': 99}]},
          {'featureType': 'road', 'elementType': 'geometry.stroke', 'stylers': [{'color': '#B36C76'},
          {'lightness': 4}]},
          {'featureType': 'landscape.man_made', 'elementType': 'geometry.fill', 'stylers': [{'color': '#ece2d9'}]},
          {'featureType': 'poi.park', 'elementType': 'geometry.fill', 'stylers': [{'color': '#ccdca1'}]},
      
      ],
      zoomControlOptions: {
          position: google.maps.ControlPosition.RIGHT_CENTER
      },
      fullscreenControlOptions:{
          position: google.maps.ControlPosition.RIGHT_CENTER
      }
    };
       this.map = new google.maps.Map(document.getElementById('map'), myOptions);
       //#########To get Lat Long when click on map######
       google.maps.event.addListener(this.map, 'click', (event)=>{          
           var myLatLng = event.latLng;
           this.lat = myLatLng.lat();
           this.lng = myLatLng.lng(); 
          if(this.lat && this.lng)
          {  
           var lat=this.lat
           var lng=this.lng 
           this.getcrmLocationsByLatLong(this.prjID,500,lat,lng) 
          } 
        }) 
      //#########To get Lat Long when click on map######
      /*
          map serch box
      */
        let input = document.getElementById('pac-input');
        let searchBox = new google.maps.places.SearchBox(input);
        this.map.controls[google.maps.ControlPosition.TOP_LEFT].push(input);
        // Bias the SearchBox results towards current map's viewport.
  
         var markers = [];
         // Listen for the event fired when the user selects a prediction and retrieve
        // more details for that place.
        searchBox.addListener('places_changed', function (this) {
        let places = searchBox.getPlaces();
         if (places.length == 0) {
            return;
          }
      // Clear out the old markers.
        markers.forEach(function (marker) {
        marker.setMap(null);
        });
        markers = [];
        // For each place, get the icon, name and location.
        let bounds = new google.maps.LatLngBounds();
        places.forEach(function (place) {
          if (!place.geometry) {
            console.log("Returned place contains no geometry");
            return;
        }
        var icon = {
          url: place.icon,
          size: new google.maps.Size(71, 71),
          origin: new google.maps.Point(0, 0),
          anchor: new google.maps.Point(17, 34),
          scaledSize: new google.maps.Size(25, 25)
        };
        // Create a marker for each place.
        markers.push(new google.maps.Marker({
          map: thisRef.map,
          icon: icon,
          title: place.name,
          position: place.geometry.location
        }));
        
          if (place.geometry.viewport) {
          // Only geocodes have viewport.
          bounds.union(place.geometry.viewport);
        } else {
          bounds.extend(place.geometry.location);
        }
      });
      thisRef.map.fitBounds(bounds);
    }); 
        this.consumerLocanotFound=true;
        this.prjID = this.auth.getAuthentication().projectId  
        this.userId = this.auth.getAuthentication().id
        this.getConsumerBuildingCategory(); 
        this.getBuildingType()
        this.getZoneByProject(); 
        this.getEmploye()
        this.verifyStatusDetails(); 
      } 
}

 
