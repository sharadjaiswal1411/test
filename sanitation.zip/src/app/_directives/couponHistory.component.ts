import { ElementRef, Input, Component, OnInit, } from '@angular/core';
import { AuthService } from '../_services';
import { Http } from '@angular/http'
import { environment } from '../../environments/environment';

import { utils, write, WorkBook } from 'xlsx';
import { saveAs } from 'file-saver';
import { Broadcaster } from '../../environments/broadcaster';


import { Subscription } from 'rxjs/Subscription';
import { LoaderService } from '../_services/loader.service';


declare var $: any;

@Component({
    selector: 'coupon-history',
    templateUrl: 'couponHistory.component.html',
})


export class CouponHistoryDirective implements OnInit {
    public busy: Subscription;
    @Input() consumer: any;
    public showLoader: boolean;
    public consumers: any
    public prjID:any
    public bookletDetail:any
    public statusObject:any;
    public bookletHistoryList:any
    public searchCouponDetail:any
    public searchCouponHistory:any;
    coupon:any;



    constructor(private broadcaster: Broadcaster, private _el: ElementRef, private auth: AuthService, private http: Http, private loaderService: LoaderService) {
        this.loaderService.status.subscribe((val: boolean) => 
        {
          this.showLoader = val;
        });
       
       
       
       
        this.loaderService.status.subscribe((val: boolean) => {
            this.showLoader = val;
        });
    }


    detail(srNo){ 
       
        this.bookletDetail = []
        this.statusObjectInit();
        this.loaderService.display(true);
        this.http.get(environment.apiUrl + 'uccnew/getBookletDetail?srNo=' + srNo).subscribe(data =>{ 
           var dataArray  = data.json()
           this.statusCount(dataArray)
           this.getBookLetHistory(srNo);
           this.loaderService.display(false);
        })
    }

    statusObjectInit(){
        this.statusObject = {
            total:0,
            pending:0,
            collected:0,
            missing:0,
            missingCollected:0
        }
    }
    statusCount(data){
        this.bookletDetail = data
        console.log("data",data)
        this.statusObjectInit()
        for(var i = 0 ;i<this.bookletDetail.length;i++){
            if(this.bookletDetail[i].StatusID ==  0){
               // this.bookletDetail[i].StatusName =  "Pending"
               this.bookletDetail[i].StatusName =  "Pending"
                this.statusObject.pending ++
            }else if(this.bookletDetail[i].StatusID ==  1){
                this.bookletDetail[i].StatusName =  "Collected"
                
                this.statusObject.collected ++
            }else if(this.bookletDetail[i].StatusID ==  2){
                this.bookletDetail[i].StatusName =  "Missing&Collected"
                this.statusObject.missingCollected ++ 
                
            }else if(this.bookletDetail[i].StatusID ==  3){
            this.bookletDetail[i].StatusName =  "Missing"
            this.statusObject.missing ++
        }
            
        }
        this.statusObject.total = this.bookletDetail.length 
    }
 
    getBookLetHistory(srNo){ 
        this.http.get(environment.apiUrl + 'uccnew/getBookletHistory?srNo=' + srNo).subscribe(data =>{ 
           this.bookletHistoryList  = data.json() 
        })
    }
    

    couponDetailExcel(){
        var data = this.bookletDetail
        const ws_name = 'SomeSheet';
        const wb: WorkBook = { SheetNames: [], Sheets: {} };
        const ws: any = utils.json_to_sheet(data);
        wb.SheetNames.push(ws_name);
        wb.Sheets[ws_name] = ws;
        const wbout = write(wb, {
          bookType: 'xlsx', bookSST: true, type:
            'binary'
        });
        saveAs(new Blob([this.s2ab(wbout)], { type: 'application/octet-stream' }), 'couponDetail.xlsx');
      }
    
      couponHistoryExcel(){
        var data = this.bookletHistoryList
        const ws_name = 'SomeSheet';
        const wb: WorkBook = { SheetNames: [], Sheets: {} };
        const ws: any = utils.json_to_sheet(data);
        wb.SheetNames.push(ws_name);
        wb.Sheets[ws_name] = ws;
        const wbout = write(wb, {
          bookType: 'xlsx', bookSST: true, type:
            'binary'
        });
        saveAs(new Blob([this.s2ab(wbout)], { type: 'application/octet-stream' }), 'couponDetailHistory.xlsx');
      } 
      s2ab(s) {
        const buf = new ArrayBuffer(s.length);
        const view = new Uint8Array(buf);
        for (let i = 0; i !== s.length; ++i) {
          view[i] = s.charCodeAt(i) & 0xFF;
        };
        return buf;
      }
    


    ngOnInit() {

        this.prjID = this.auth.getAuthentication().projectId
        this.coupon  =  this.broadcaster.on('couponHistory').subscribe(message => {
            if (message) {
                this.loaderService.display(true);
                $('#couponHistory').modal('show'); 
                console.log("couponHistory",message)
                this.detail(message)
            }
        });
    }

    ngOnDestroy(): void {
        this.coupon.unsubscribe();
      }
}

