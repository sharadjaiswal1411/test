import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'maintenance',
  templateUrl: './maintenance.component.html',
   
})
export class MaintenanceComponent implements OnInit {   
  constructor() { }
  ngOnInit() {     
    }

}
