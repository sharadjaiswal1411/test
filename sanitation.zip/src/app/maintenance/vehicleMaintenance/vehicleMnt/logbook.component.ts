

import { Component} from '@angular/core';
import { Http } from '@angular/http'
import { environment } from '../../../../environments/environment';
import { AuthService } from '../../../_services/index'; 
import { LoaderService } from '../../../_services/loader.service';
import { process, State,aggregateBy } from '@progress/kendo-data-query';
import { GroupDescriptor, DataResult } from '@progress/kendo-data-query';
import {GridDataResult,DataStateChangeEvent} from '@progress/kendo-angular-grid'; 
import { Observable } from 'rxjs/Observable'; 
import { ExcelExportData } from '@progress/kendo-angular-excel-export';
import { utils, write, WorkBook } from 'xlsx';  
import { saveAs } from 'file-saver'; 
import { DomSanitizer, SafeStyle } from '@angular/platform-browser';
import * as _moment from 'moment';  
import * as _rollupMoment from 'moment'; 
const moment = _rollupMoment || _moment; 
import Swal from 'sweetalert2'
import { Router } from '@angular/router';
declare var $: any;
 
const distinctCurrentStatus= data => data.filter((x, idx, xs) => xs.findIndex(y => y.Current_Status === x.Current_Status) === idx); 
const distinctMaintenanceStage= data => data.filter((x, idx, xs) => xs.findIndex(y => y.Status === x.Status) === idx); 
const distinctCurrentZone= data => data.filter((x, idx, xs) => xs.findIndex(y => y.ZoneName === x.ZoneName) === idx); 
const distinctCurrentWard= data => data.filter((x, idx, xs) => xs.findIndex(y => y.WardName === x.WardName) === idx); 

@Component({
    selector: 'logbook-veh',
    templateUrl: './logbook.component.html' 
   
  })
 
  export class LogbookComponent{ 
    public prjId:any;
    showLoader:any;
    vehMaintenanceList:any
    vehicleInfo:any;
    totalVehicle:any;
    dataRangeModal:any;
    defStartDt:any;
    defEndDt:any;
    startDate:any;
    endDate:any;
    runningCount:any;
    aceptedCount:any;
    reportedCount:any;
    inprogressCount:any;
    completedCount:any;
    totalAmount:any;
    vehType:any;
    vtsMobile:any;
    maintStatus:any;
    currImeiNo:any;
    parkLoc:any;
    chasisNo:any;
    vtsStatus:any;
    simNo:any;
    dataStatus:any;
    statusDate:any;
    mntVehId:any;
    dateFilterType:any;
    public aggregates: any[] = [{field: 'amount', aggregate: 'sum'}];
    public state: State = {
      skip: 0,
      take: 12,  
      filter: {
        logic: 'and',
        filters: []
      }
    };  
    
    /*
     * Get all excel data 
    */
    public allData(): ExcelExportData {
      const result: ExcelExportData =  {
          data: this.vehMaintenanceList
      };
      return result;
     } 
    public currentStatus: any[]
    public maintenanceStage: any[]  
    public maintenanceZone: any[] 
    public maintenanceWard: any[] 
    public groups: GroupDescriptor[] = [];
    public view: Observable<GridDataResult>;
    public gridView: DataResult;
    public groupChange(groups: GroupDescriptor[]): void {
      this.groups = groups;
      this.loadProducts();
    }
  
    private loadProducts(): void {
      this.gridDataVehList = process(this.vehMaintenanceList, { group: this.groups });  
    }
      public gridDataVehList: GridDataResult  
      public DateLabelList: Array<string> = ["AcceptedDate", "WipDate","CompletedDate"]; 
      constructor(private sanitizer: DomSanitizer , private auth : AuthService,private http: Http,private loaderService: LoaderService,public router: Router) {
      this.loaderService.status.subscribe((val: boolean) =>{
        this.showLoader = val;
      }); 
      this.runningCount=0;
      this.reportedCount=0;
      this.aceptedCount=0;
      this.inprogressCount=0;
      this.allData = this.allData.bind(this);
      var date = new Date(); 
      var date = new Date(); 
      var firstDay = new Date(date.getFullYear(), date.getMonth(), 1); 
      this.defStartDt = (firstDay.getFullYear()) + '-' + (firstDay.getMonth() + 1) + '-' + firstDay.getDate(); 
      this.defEndDt = (date.getFullYear()) + '-' + (date.getMonth()+1) + '-' + date.getDate(); 
      this.dataRangeModal= {beginDate: {year: firstDay.getFullYear(), month: firstDay.getMonth()+1, day: firstDay.getDate()}, endDate: {year: date.getFullYear(), month: date.getMonth()+1, day: date.getDate()}};
    } 

     
    public colorCode(code: string): SafeStyle {
      let result; 
      switch (code) {
       case 'RUNNING' :
         result = '#28B74B';
         break;
       case 'BREAKDOWN' :
         result = '#DB5D3F';
         break;
       default:
         result = 'transparent';
         break;
      } 
      return this.sanitizer.bypassSecurityTrustStyle(result);
    }





  /*
   * get vehicles Details By Project Id
  */   
 getAllVehicles(dateType){
  this.runningCount=0;
  this.aceptedCount=0;
  this.reportedCount=0;
  this.inprogressCount=0;
  this.completedCount=0 
  this.loaderService.display(true); 
        this.http.get(environment.apiUrl+'maintenance/logbook?prjId='+this.prjId+'&startDate='+this.startDate+'&endDate='+this.endDate+'&dateType='+dateType).subscribe(data =>{       
              this.vehMaintenanceList=data.json();  
              if(this.vehMaintenanceList.length>0){  
                this.gridDataVehList = process(this.vehMaintenanceList, this.state); 
                this.currentStatus = distinctCurrentStatus(this.vehMaintenanceList) 
                this.maintenanceStage=distinctMaintenanceStage(this.vehMaintenanceList)  
                this.maintenanceZone=distinctCurrentZone(this.vehMaintenanceList) 
                this.maintenanceWard=distinctCurrentWard(this.vehMaintenanceList)   
                this.totalVehicle =this.vehMaintenanceList.length 
                for(var i=0;i<this.vehMaintenanceList.length;i++){
                  if(this.vehMaintenanceList[i].Current_Status!=null){ 
                    if(this.vehMaintenanceList[i].Current_Status=="RUNNING"){
                      this.runningCount=this.runningCount+1
                     }if(this.vehMaintenanceList[i].statusId==3 && this.vehMaintenanceList[i].stageID==2){
                      this.aceptedCount= this.aceptedCount+1
                     }if(this.vehMaintenanceList[i].statusId==3 && this.vehMaintenanceList[i].stageID==1){
                      this.reportedCount= this.reportedCount+1
                     }if(this.vehMaintenanceList[i].statusId==3 && this.vehMaintenanceList[i].stageID==3){
                      this.inprogressCount= this.inprogressCount+1
                     }if(this.vehMaintenanceList[i].statusId==3 && this.vehMaintenanceList[i].stageID==4){
                      this.completedCount= this.completedCount+1
                     }
                  } 
                } 
                this.totalAmount = aggregateBy(this.vehMaintenanceList, this.aggregates)["amount"].sum;  
                this.loaderService.display(false); 
                }              
              else { 
                this.runningCount=0;
                this.aceptedCount=0;
                this.reportedCount=0;
                this.inprogressCount=0;
                this.completedCount=0
                this.vehMaintenanceList = []
                this.gridDataVehList = process(this.vehMaintenanceList, this.state); 
                this.loaderService.display(false);
              } 
        })
        error=>{ 
          this.loaderService.display(false);
          Swal({
            type: 'error',
            title: 'Oops...',
            text: 'An Error Occurred Please Try Again',
          });
        }  
  }


/*
* filter The Date
*/
public dataStateChange(state: DataStateChangeEvent): void {
  this.state = state;
  this.gridDataVehList = process(this.vehMaintenanceList, this.state); 
  if (state && state.group) {  
      state.group.map(group => group.aggregates = this.aggregates); 
      this.totalAmount = aggregateBy(this.gridDataVehList.data, this.aggregates)["amount"].sum;  
      this.gridDataVehList = process(this.vehMaintenanceList, this.state); 
    } 
} 

 /*
  *Down Load Excel file 
  */
  downloadExcelFile(vehicleInfoData){
    const ws_name = 'VehicleInfo';
    const wb: WorkBook = { SheetNames: [], Sheets: {} };
    const ws: any = utils.json_to_sheet(vehicleInfoData);
    wb.SheetNames.push(ws_name);
    wb.Sheets[ws_name] = ws;
    const wbout = write(wb, { bookType: 'xlsx', bookSST: true, type:'binary' });
    saveAs(new Blob([this.s2ab(wbout)], { type: 'application/octet-stream' }), 'VehicleInfo.xlsx');
    }
    s2ab(s) 
    {
      const buf = new ArrayBuffer(s.length);
      const view = new Uint8Array(buf);
      for (let i = 0; i !== s.length; ++i) {
      view[i] = s.charCodeAt(i) & 0xFF;
      };
      return buf;
    }


/*
*select start Date Nad To date
*/
onDateRangeChanged(dataRange)
{  
  if(dataRange.beginDate.day>0){ 
    this.startDate= dataRange.beginDate.year + "-"  + dataRange.beginDate.month+ "-" + dataRange.beginDate.day 
    this.endDate = dataRange.endDate.year + "-"  + dataRange.endDate.month  + "-" + dataRange.endDate.day 
    this.getAllVehicles(this.dateFilterType);
  }
  else if(dataRange.beginDate.day==0){
    this.startDate= this.defStartDt
    this.endDate = this.defEndDt
    this.getAllVehicles(this.dateFilterType);
  }  
} 



 /*
   *To get vehicle info 
  */  
 getVehicleInfo(data){  
     this.loaderService.display(true);  
     this.vehType=data.VehType
     this.vtsMobile=data.MobileNo
     this.maintStatus=data.Current_Status
     //this.currImeiNo=data.imei
     //this.parkLoc=data.entityname
     this.chasisNo=data.Chasis
     //this.vtsStatus=data.VTSSTATUS
     //this.simNo=data.SIM 
     //this.dataStatus=data.DataStatus
     //this.statusDate=data.STATUSDATE
     var currVehId=data.VehID
     this.http.get(environment.apiUrl + 'maintenance/getVehicleInfo?ID='+currVehId).subscribe(data =>{
      this.vehicleInfo=data.json();  
      this.loaderService.display(false); 
    });  
    $('#vehicleInfoModal').modal('show'); 
}

 
viewStatus(data){  
  this.mntVehId=data.VehID 
  this.router.navigate(['/home/maintenance/maintenanceStatus', this.mntVehId]);   
}  

    selectFilterType(data){
      console.log("data",data)
      this.dateFilterType=data
      this.getAllVehicles(this.dateFilterType)
    }

 

    ngOnInit(){
      this.startDate = moment(this.defStartDt).format('YYYY-MM-DD');
      this.endDate= moment(this.defEndDt).format('YYYY-MM-DD');
      this.prjId = this.auth.getAuthentication().projectId
      //this.totalVehicle = "( " + 0 + " )"
      if(this.dateFilterType==undefined){
        this.dateFilterType="ReportedDate"
      } 
      console.log("data",this.dateFilterType)
      this.getAllVehicles(this.dateFilterType);
    }
  }
