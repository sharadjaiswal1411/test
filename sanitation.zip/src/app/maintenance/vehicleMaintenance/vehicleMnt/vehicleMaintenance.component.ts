

import { Component} from '@angular/core';
import { Http } from '@angular/http'
import { environment } from '../../../../environments/environment';
import { AuthService } from '../../../_services/index'; 
import { LoaderService } from '../../../_services/loader.service';
import { process, State } from '@progress/kendo-data-query';
import { GroupDescriptor, DataResult } from '@progress/kendo-data-query';
import {GridDataResult,DataStateChangeEvent} from '@progress/kendo-angular-grid';
import { Observable } from 'rxjs/Observable'; 
import { ExcelExportData } from '@progress/kendo-angular-excel-export';
import { utils, write, WorkBook } from 'xlsx';  
import { saveAs } from 'file-saver'; 
import { Router } from '@angular/router';
 

declare var $: any;
const distinctStatus= data => data.filter((x, idx, xs) => xs.findIndex(y => y.maintenanceStatus === x.maintenanceStatus) === idx); 
const distinctStage= data => data.filter((x, idx, xs) => xs.findIndex(y => y.STAGENAME === x.STAGENAME) === idx); 

@Component({
    selector: 'maintenance-veh',
    templateUrl: './vehicleMaintenance.component.html',  
    styleUrls: ['./vehicleMaintenance.component.css']
  })
 
  export class VehicleMaintenanceComponent{ 
    public prjId:any;
    public vehMaintenanceList:any;  
    public userId:any;
    public maintenanceStatus:any;  
    public maintStatusModal:any;
    public maintStatusId:any;
    public currentMaintId:any;
    public maintenanceDate:any;
    public remarkeModal:any;
    public vehId:any;
    public isChangestate=true; 
    public showLoader:boolean
    public maintenanceCount:any;
    public success=false;
    public error=false;
    public totalCount:any;
    public runningCount:any;
    public serviceCount:any;
    public maintDoneCount:any;
    public imeiNo:any;
    public statusModal:any;
    public vehType:any;
    public vtsMobile:any;
    public maintStatus:any;
    public currImeiNo:any;
    public parkLoc:any;
    public chasisNo:any;
    public vtsStatus:any;
    public simNo:any;
    public dataStatus:any;
    public statusDate:any;
    public mentStageList:any;
    public stageModel:any;
    public stageId:any;
    public statusIsRequired=false;
    public stageIsRequired=false;
    public maintStatusCheck:any;
    public underService:any;
    public serviceDone:any;
    public reported:any;
    public accepted:any;
    public progress:any;
    public completed:any; 
    public standByCount:any; 
    vehicleInfo:any;  
    mntVehId:any;
    public state: State = {
      skip: 0,
      take: 12,  
      filter: {
        logic: 'and',
        filters: []
      }
    }; 
    
    /*
     * Get all excel data 
    */
    public allData(): ExcelExportData {
      const result: ExcelExportData =  {
          data: this.vehMaintenanceList
      };
      return result;
     } 
    public distinctStatus: any[]
    public distinctStage: any[]  
    public groups: GroupDescriptor[] = [];
    public view: Observable<GridDataResult>;
    public gridView: DataResult;
    public groupChange(groups: GroupDescriptor[]): void {
      this.groups = groups;
      this.loadProducts();
    }
  
    private loadProducts(): void {
      this.gridDataVehList = process(this.vehMaintenanceList, { group: this.groups });  
    }
    public gridDataVehList: GridDataResult   
      constructor(private auth : AuthService,private http: Http,private loaderService: LoaderService,public router: Router) {
      this.maintenanceDate= new Date(); 
      this.loaderService.status.subscribe((val: boolean) =>{
        this.showLoader = val;
      }); 
      this.allData = this.allData.bind(this); 
  } 

  /*
  * get vehicles Details By Project Id
  */  
  getAllVehiclesDetails(status){  
        this.loaderService.display(true);
        this.http.get(environment.apiUrl+'maintenance/getMaintVehDetails?prjid='+this.prjId+'&status='+status).subscribe(data =>{       
              this.vehMaintenanceList=data.json();  
              if(this.vehMaintenanceList.length>0){  
                this.gridDataVehList = process(this.vehMaintenanceList, this.state); 
                this.distinctStatus =distinctStatus(this.vehMaintenanceList)  
                this.distinctStage=distinctStage(this.vehMaintenanceList) 
                this.loaderService.display(false); 
                }              
              else { 
                this.vehMaintenanceList = []
                this.gridDataVehList = process(this.vehMaintenanceList, this.state); 
                this.loaderService.display(false);
              } 
        });  
  }


/*
*to filter the data as per card click 
*/
 getStatusData(data){ 
  if(data=='All'){
    this.getAllVehiclesDetails('All') 
  } 
  else{
    this.getAllVehiclesDetails(data) 
  }
}



    /*
     * to filter the grid data
    */
   public dataStateChange(state: DataStateChangeEvent): void {
    this.state = state; 
    this.gridDataVehList = process(this.vehMaintenanceList, this.state); 
    if (state && state.group) {  
      this.gridDataVehList = process(this.vehMaintenanceList, this.state);  
      this.distinctStatus = distinctStatus(this.vehMaintenanceList) 
      this.distinctStage=distinctStage(this.vehMaintenanceList)  
      }             
  }


  /*
   *change status open modal popup 
  */
  changeStatus(data){  
    this.mentStageList=null; 
    this.statusModal=data.StatusId 
    this.maintStatusId=data.StatusId  
    this.success=false;
    this.error=false; 
    this.currentMaintId=data.ID
    this.vehId=data.ID 
    this.imeiNo=data.imei  
    this.maintStatusCheck=data.StatusId 
    if(data.StatusId=="2" || data.StatusId=="3"){
      this.getMentenanceDetails(this.statusModal)
      this.stageModel=data.MENTSTAGEID;
    }else{
      this.stageModel=0;
    }  
    this.statusIsRequired=false;
    this.stageIsRequired=false;
    $('#changeMaintenanceStatus').modal('show'); 
  }
  



  



  /*
   * to get Maintenance Status and bind drop down list
  */
  getMaintenanceStatus(){
      this.http.get(environment.apiUrl+'maintenance/getMaintenanceStatus?prjid='+this.prjId).subscribe(data =>{       
      this.maintenanceStatus=data.json();  
    }); 
  }

 /*
  * To select index change event  
 */
 
 
onStatusChanged(data){ 
    if(data!=null){
      this.statusIsRequired=false;
      this.maintStatusId=data.ID  
      this.maintStatusCheck=data.ID  
      if(data.ID==2 || data.ID==3){  
        this.getMentenanceDetails(this.maintStatusId);
      }
      else{
        this.stageId=0;
        this.statusIsRequired=false;
        this.stageIsRequired=false;
        this.mentStageList=null;
        this.stageModel=null;
      } 
    }
    else{
      this.statusIsRequired=true;
      this.stageModel=null;
      this.mentStageList=null; 
    } 
  }

  /**
   * Get Mentnance Stage List
  */
  getMentenanceDetails(statusId){
    this.http.get(environment.apiUrl+'maintenance/getMentStageDetails?statusId='+statusId).subscribe(data =>{       
      this.mentStageList=data.json();  
    }); 
  }


  /*
   *get Maintenance Stage ID list 
  */ 
  onSelectStage(data){  
  if(data!=null){
     this.stageModel=data.ID
     this.stageIsRequired=false;
     }else{
      this.stageModel=0;
      this.stageIsRequired=true;
    } 
  }


  /*
   *change maintenamce status 
  */
  changeMaintStatus(){
    if(this.statusModal==null){this.statusIsRequired=true; return} 
    if(this.maintStatusCheck==2||this.maintStatusCheck==3){ 
       if(!this.stageModel){
        this.stageIsRequired=true
        return; 
       } 
    }  
     var maintenanceData={ 
       "VEHID":this.vehId,
       "maintStatusID":this.maintStatusId?this.maintStatusId:0,
       "PRJID":this.prjId,
       "ID":this.currentMaintId,
       "REAMRKS":this.remarkeModal?this.remarkeModal:null,
       "STATUSDATE":this.maintenanceDate,
       "USERID":this.userId,
       "IMEI":this.imeiNo,
       "STAGEID":this.stageModel?this.stageModel:0
     } 
      this.http.post(environment.apiUrl+'maintenance/changemaintStatus',maintenanceData).subscribe(data =>{       
      var updateStatus=data.json(); 
       if(updateStatus.status=='ok') { 
         this.getAllVehiclesDetails('All');
         this.getMaintenanceStatusCount()
         this.success=true;
         this.clearFields() 
         setTimeout(()=>{ 
          $('#changeMaintenanceStatus').modal('hide');  
          this.success=false; 
         },2000);  
       } 
       else{
         this.error=true; 
       } 
    }); 
  } 
  
  /*
   *Clear the Fileds 
  */
  clearFields(){
    this.maintStatusModal=null;
    this.remarkeModal=null;
    this.stageModel=null;
    this.stageId=0;
  }


  /*
   *get the data from text area. 
  */
  maintenanceData(data){
    if(data.length>0){
      this.remarkeModal=data;  
    } 
  } 

  /*
   *To find the Maintenence Status Count details 
  */  
  getMaintenanceStatusCount(){
    this.http.get(environment.apiUrl + 'maintenance/getMaintenanceStatusCount?PRJID='+this.prjId).subscribe(data =>{
      this.maintenanceCount=data.json(); 
      if(this.maintenanceCount.length>0){
       this.totalCount=this.maintenanceCount[0].Total
       this.runningCount=this.maintenanceCount[0].RUNNING
       this.serviceCount=this.maintenanceCount[0].SERVICE
       this.underService=this.maintenanceCount[0].INSERVICE
       this.serviceDone=this.maintenanceCount[0].SERVICEDONE 
       this.maintDoneCount=this.maintenanceCount[0].MAINTENANCE 
       this.reported=this.maintenanceCount[0].REPORTED  
       this.accepted=this.maintenanceCount[0].ACCEPED  
       this.progress=this.maintenanceCount[0].PROGRESS_WIP
       this.completed=this.maintenanceCount[0].COMPLETED 
       this.standByCount=this.maintenanceCount[0].STANDBY 
      } 
    });
  }

  /*
   *To get vehicle info 
  */ 
  getVehicleInfo(data){  
    this.loaderService.display(true);  
       this.vehType=data.vehTypName
       this.vtsMobile=data.vtsMobileno
       this.maintStatus=data.maintenanceStatus
       this.currImeiNo=data.imei
       this.parkLoc=data.entityname
       this.chasisNo=data.chasisNo
       this.vtsStatus=data.VTSSTATUS
       this.simNo=data.SIM 
       this.dataStatus=data.DataStatus
       this.statusDate=data.STATUSDATE
       var currVehId=data.ID
       this.http.get(environment.apiUrl + 'maintenance/getVehicleInfo?ID='+currVehId).subscribe(data =>{
        this.vehicleInfo=data.json(); 
        console.log("logDate",this.vehicleInfo) 
        this.loaderService.display(false); 
      });  
      $('#vehicleInfoModal').modal('show'); 
  }
 
  viewStatus(data){  
    console.log("vehNo",data) 
    this.mntVehId=data.ID 
    this.router.navigate(['/home/maintenance/maintenanceStatus', this.mntVehId]);   
  }



  downloadExcelFile(vehicleInfoData){
    const ws_name = 'VehicleInfo';
    const wb: WorkBook = { SheetNames: [], Sheets: {} };
    const ws: any = utils.json_to_sheet(vehicleInfoData);
    wb.SheetNames.push(ws_name);
    wb.Sheets[ws_name] = ws;
    const wbout = write(wb, { bookType: 'xlsx', bookSST: true, type:'binary' });
    saveAs(new Blob([this.s2ab(wbout)], { type: 'application/octet-stream' }), 'VehicleInfo.xlsx');
    }
    s2ab(s) 
    {
      const buf = new ArrayBuffer(s.length);
      const view = new Uint8Array(buf);
      for (let i = 0; i !== s.length; ++i) {
      view[i] = s.charCodeAt(i) & 0xFF;
      };
      return buf;
    }


 

    ngOnInit(){ 
      this.prjId = this.auth.getAuthentication().projectId
      this.userId= this.auth.getAuthentication().id 
      this.getAllVehiclesDetails('All');
      this.getMaintenanceStatus(); 
      this.getMaintenanceStatusCount();
    }
  }
