

import { Component} from '@angular/core';
import { Http } from '@angular/http'
import { environment } from '../../../../environments/environment';
import { AuthService } from '../../../_services/index'; 
import { LoaderService } from '../../../_services/loader.service';
import { process, State } from '@progress/kendo-data-query';
import { GroupDescriptor, DataResult } from '@progress/kendo-data-query';
import {GridDataResult} from '@progress/kendo-angular-grid';
import { Observable } from 'rxjs/Observable'; 
import { ExcelExportData } from '@progress/kendo-angular-excel-export';    
import { Router, ActivatedRoute, Params  } from '@angular/router';
import { anyChanged } from '@progress/kendo-angular-grid/dist/es2015/utils';
declare var require: any;
var moment = require('moment');
declare var $: any;
declare var google:any; 
const distinctZone= data => data.filter((x, idx, xs) => xs.findIndex(y => y.zoneName === x.zoneName) === idx); 
const distinctWard= data => data.filter((x, idx, xs) => xs.findIndex(y => y.ward === x.ward) === idx); 

 
@Component({ 
    selector: 'maintenance-Status',
    templateUrl: './vehMaintenanceStatus.component.html', 
    styleUrls: ['./vehicleMaintenance.component.css']
  })
 
  export class VehMaintStatusComponent{ 
    prjId:any;
    userId:any;  
    showLoader:boolean;
    vehMaintStatusList:any;
    maintVehInfo:any;
    reportedJson:any; 
    maintProcessData:any;
    geocoder:any;
    maintLen:any;
    vehicleNo:any;
    vehTempNo:any;
    vehTypName:any;
    mainteAmount:any;
    stageName:any;
    reportedDate:any;
    reportedBy:any;
    maintenanceDays:any;  
    totalMaintDays:any;
    maintLocation:any;
    dataNotFound=false;
    vehicleInfoList:any;
    reportDate:any;
    complaint:any;
    location:any;
    repairBy:any;
    acceptedDate:any;
    observation:any;
    vehName:any;
    maintAmount:any;
    materialPartList:any;
    milageReportList:any;
    defStartDate:any;
    defEndDate:any;
    dataRangeModal:any;
    totalQty:any;
    gpsDistance:any;
    mtrDistance:any;
    gpsMilage:any;
    mtrMilage:any;
    zoneList:any;
    wardList:any; 
    vehChasis:any;
    public href: string = "";
    public state: State = {
      skip: 0,
      take: 12,  
      filter: {
        logic: 'and',
        filters: []
      }
    }; 
    
    /*
     * Get all excel data 
    */
    public allData(): ExcelExportData {
      const result: ExcelExportData =  {
          data: this.vehMaintStatusList
      };
      return result;
     } 
    public distinctZone: any[]
    public distinctWard: any[]  
    public groups: GroupDescriptor[] = [];
    public view: Observable<GridDataResult>;
    public gridView: DataResult;
    public groupChange(groups: GroupDescriptor[]): void {
      this.groups = groups;
      this.loadProducts();
    }
  
    private loadProducts(): void {
      this.gridDataVehStatusList = process(this.vehMaintStatusList, { group: this.groups });  
    }
    public gridDataVehStatusList: GridDataResult   
      constructor(private auth : AuthService,private http: Http,private loaderService: LoaderService,private router: Router) { 
      this.loaderService.status.subscribe((val: boolean) =>{
        this.showLoader = val;
      }); 
      this.allData = this.allData.bind(this);
      this.mainteAmount=0;
      var date = new Date(); 
      var firstDay = new Date(date.getFullYear(), date.getMonth(), 1); 
      this.defStartDate = (firstDay.getFullYear()) + '-' + (firstDay.getMonth() + 1) + '-' + firstDay.getDate();
      this.defEndDate = (date.getFullYear()) + '-' + (date.getMonth()+1) + '-' + date.getDate(); 
      this.dataRangeModal= {beginDate: {year: firstDay.getFullYear(), month: firstDay.getMonth()+1, day: firstDay.getDate()}, endDate: {year: date.getFullYear(), month: date.getMonth()+1, day: date.getDate()}};
     } 

  /*
  * get vehicles Details By Project Id
  */  
  getMaintStatusList(){  
        this.loaderService.display(true);
        this.http.get(environment.apiUrl+'maintenance/getMaintVehDetails?prjid='+this.prjId).subscribe(data =>{       
              this.vehMaintStatusList=data.json();  
              if(this.vehMaintStatusList.length>0){  
                this.gridDataVehStatusList = process(this.vehMaintStatusList, this.state);  
                this.loaderService.display(false); 
                }else {  
                this.gridDataVehStatusList = process(this.vehMaintStatusList, this.state); 
                this.loaderService.display(false);
                } 
        });  
  }
 

  /*
   * Get Maintenance Information
  */  
  getvehicleMaintInfo(maintId){
   this.http.get(environment.apiUrl + 'maintenance/getVehicleInfo?ID='+maintId).subscribe(data =>{
    this.maintVehInfo=data.json(); 
    var totalAmount=0;
    var totalMaintDays=0; 
    var zones='';
    var wards='';
    if(this.maintVehInfo.length>0){ 
      this.mainteAmount=0;  
      this.totalMaintDays=0; 
      this.maintLen=this.maintVehInfo.length
      this.vehicleNo=this.maintVehInfo[0].vehicle_number
      this.vehTempNo=this.maintVehInfo[0].vehTempNo
      this.vehTypName=this.maintVehInfo[0].VehTypName 
      this.maintLocation=this.maintVehInfo[0].Breakdown_Location  
      for(var i=0;i<this.maintVehInfo.length;i++){ 
        totalAmount=Number(totalAmount)+Number(this.maintVehInfo[i].total_amount) 
        totalMaintDays=Number(totalMaintDays)+Number(this.maintVehInfo[i].MaintenanceDays) 
        this.maintVehInfo[i].reported_date1 = moment(new Date(this.maintVehInfo[i].reported_date)).startOf('day').fromNow(); 
        this.vehChasis=this.maintVehInfo[i].CHASISNO; 
       } 
      this.mainteAmount=totalAmount 
      var zone=distinctZone(this.maintVehInfo)
      var ward=distinctWard(this.maintVehInfo)
      for(var i=0;i<zone.length;i++){
        zones=zones+' '+zone[i].zoneName 
      }
      for(var i=0;i<ward.length;i++){ 
        wards=wards+' '+ward[i].ward
      }
      this.zoneList=zones
      this.wardList=wards
      this.getGeoCopdingAddress(this.maintLocation)
     }else{
      this.dataNotFound=true;   
     } 
    });
  }


  /*
   * Get LAT LNg by Address
   */ 
  googleMap(lat, lng) {
    var myLatLng = {lat:lat, lng: lng}; 
    var map = new google.maps.Map(document.getElementById('googleMap'), {
      zoom: 10,
      center: myLatLng
    }); 
    var marker = new google.maps.Marker({
      position: myLatLng,
      map: map,
      title: 'Hello World!'
    });
    }

    getGeoCopdingAddress(address){  
    this.geocoder.geocode({'address': address}, (results, status)=> {
      if (status === 'OK'){
        var lat=results[0].geometry.location.lat();
        var lng=results[0].geometry.location.lng() 
        this.googleMap(lat,lng); 
      }else{ 
        //alert('Geocode was not successful for the following reason: '+status); 
      }
    });
    }

   /*
   * get VEHICLE MAINTENANCE DETAILS
   */  
    vehicleInfoData(data){   
      var totalAmnt=0; 
      this.reportedBy=data.reportedby
      var reportDate=moment(data.reported_date).format('DD-MM-YYYY hh:mm:ss A')
      this.reportDate=reportDate
      this.complaint=data.complaint 
      this.location=data.Breakdown_Location
      this.repairBy=data.RepairedBy
      var acceptDate=moment(data.Accepted_Date).format('DD-MM-YYYY hh:mm:ss A')
      this.acceptedDate=acceptDate
      this.observation=data.observation
      this.vehName=data.VehTypName  
      if(data.json_part_array!=""){
        this.materialPartList=JSON.parse(data.json_part_array) 
        var len=this.materialPartList.length 
      } 
      for(var i=0;i<len;i++){
            totalAmnt=Number(totalAmnt)+this.materialPartList[i].amount
      }
      this.maintAmount=totalAmnt 
      $('#vehInfoModal').modal('show'); 
    }
 


   /*
   * get Fuel Milage Summary Report
   */ 
    getMilageSummary(prjId,vehId,fromDate,toDate){
       this.http.get(environment.apiUrl + 'maintenance/getFuelMilageReport?prjId='+prjId+'&vehId='+vehId+'&fromDate='+fromDate+'&toDate='+toDate).subscribe(data =>{
       this.milageReportList=data.json();
       var totalAmount=0; 
       var gpsDist=0;
       var mtrDisr=0;
       var gpsMilage=0;
       var mtrMilage=0;
       for(var i=0; i<this.milageReportList.length;i++){
         totalAmount=Number(totalAmount)+Number(this.milageReportList[i].qty)
         gpsDist=Number(gpsDist)+Number(this.milageReportList[i].GPSDistance)
         mtrDisr=Number(mtrDisr)+Number(this.milageReportList[i].MeterDistance)
         gpsMilage=Number(gpsMilage)+Number(this.milageReportList[i].GPSMileage)
         mtrMilage=Number(mtrMilage)+Number(this.milageReportList[i].MeterMileage)
       }
       this.totalQty=totalAmount.toFixed(2)+' Liter'
       this.gpsDistance=gpsDist.toFixed(2)+' K.M.'
       this.mtrDistance=mtrDisr.toFixed(2)+' K.M.'
       this.gpsMilage=gpsMilage.toFixed(2)+' Liter'
       this.mtrMilage=mtrMilage.toFixed(2)+' Liter' 
      }); 
    }


   
   
 
    ngOnInit(){
      this.href = this.router.url;
      var vehicleId =this.router.url.split('/') 
      this.getvehicleMaintInfo(vehicleId[4])   
      this.prjId = this.auth.getAuthentication().projectId
      this.userId= this.auth.getAuthentication().id  
      this.getMaintStatusList();  
      this.getMilageSummary(this.prjId,vehicleId[4],this.defStartDate,this.defEndDate)
      this.geocoder = new google.maps.Geocoder;       
    }
  }


































     //  this.http.get(environment.apiUrl + 'maintenance/getVehicleInfo?ID='+this.currentVehId).subscribe(data =>{
      //  this.vehicleInfoList=data.json();  
      //  this.loaderService.display(false); 
      // }); 
