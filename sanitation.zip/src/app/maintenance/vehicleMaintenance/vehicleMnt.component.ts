import { Component } from '@angular/core';
import {HttpClient } from '@angular/common/http'; 
import { AuthService } from '../../_services'; 

@Component({
  selector: 'Maintenance',
  templateUrl: './vehicleMnt.component.html',  
})

 export class VehicleMaintMntComponent {
 public prjId:any
 public userId:any
  constructor(private http: HttpClient,private auth : AuthService) { 
  }  
  ngOnInit() 
  { 
     
  }

}
 