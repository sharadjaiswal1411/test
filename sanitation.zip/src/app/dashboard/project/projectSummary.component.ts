import { Component } from '@angular/core';
import { Http } from '@angular/http'
import { AuthService } from '../../_services/index';
import { LoaderService } from '../../_services/loader.service'; 
import { environment } from '../../../environments/environment';
import * as _moment from 'moment';  
import * as _rollupMoment from 'moment'; 
const moment = _rollupMoment || _moment;  
import Swal from 'sweetalert2'
 
 @Component({
  selector: 'project-Summary',
  templateUrl: './projectSummary.component.html'
 })
 
export class ProjectSummaryComponent{
  prjId:any;
  allCompList:any;
  showLoader:boolean;
  vehicleCountList:any;  
  currentDate:any; 
  currentMonth:any;
  compCountReport:any;
  public gridDataPrjSummary: any[] 
  currentDay:any;
  mswList:any; 
  mswLkoList:any;
  attendanceList:any;
  ggnmonthData:any;
  ggnAvgdata:any;
  ggnTodayData:any;
  fbdMonthData:any;
  fbdAvgData:any;
  fbdTodayData:any;
  gwlMonthData:any;
  gwlAvgData:any;
  gwlTodayData:any; 
  lkdMonthData:any;
  lkdAvgData:any;
  lkdTodayData:any;
  lkdMOnthWastData:any;
  lkdAvgWastData:any;
  lkdTodayWastData:any;
  lkdMonthOutData:any;
  lkdAvgOutData:any;
  lkdTodayOutData:any;
  lkoMonthRfdData:any;
  lkoAvgRfdData:any;
  lkoTodayRfdData:any;
  vehcount:any;
  prmyCount:any;
  secondCount:any;
  prmyRunning:any;
  secdRunning:any;
  prmyStop:any;
  secdStop:any;
  prmyMaint:any;
  secdMaint:any; 
  totalComp:any;
  todayComp:any;
  totalAvg:any;
  totalMobComp:any;
  totalMobToday:any;
  totalMobAvg:any;
  pendMtd:any;
  pendToday:any;
  pendAvg:any;
  reslMtd:any;
  reslvToday:any;
  reslvAvg:any;
  fbMtd:any;
  fbToday:any;
  fbAvg:any;
  UOMtd:any;
  UOToday:any;
  UOAvg:any;
  inTonnageMtd:any;
  inTonnageToday:any;
  inTonnageAvg:any;
  totalEmpCount:any;
  todayActive:any;
  prjName:any;

uccCollMtd:any;
uccCollAvg:any;
uccCollToday:any;
HHInMtd:any;
HHInAvg:any;
HHInToday:any;
kccCollMtd:any;
kccCollAvg:any;
kccCollToday:any;
paidKccMtd:any;
paidKccAvg:any;
paidKccToday:any;
outStndMtd:any;
outStndAvg:any;
outStndToday:any;
fuelPurcMtd:any;
fuelPurcAvg:any;
fuelPurcToday:any;
loosePurcMtd:any;
loosePurcAvg:any;
loosePurcToday:any;
fuesDistVehMtd:any;
fuesDistVehAvg:any;
fuesDistVehToday:any;
fuesDistDGMtd:any;
fuesDistDGAvg:any;
fuesDistDGToday:any;
fuesDistTSMtd:any;
fuesDistTSAvg:any;
fuesDistTSToday:any;

  constructor(private http: Http, private auth: AuthService,private loaderService: LoaderService) {
    this.loaderService.status.subscribe((val: boolean) =>{
      this.showLoader = val; 
      this.currentDate = moment(new Date()).format('DD-MM-YYYY'); 
      this.currentMonth = moment(new Date()).format('MMMM');
      this.currentDay=moment(new Date()).format('DD');
    }); 
   } 


   /*
    * get Current Vehicle count Details
  */ 
  getVehicleCoutReport(){
    this.loaderService.display(true);
     this.http.get(environment.apiUrl+'reports/getVehCountHistory').subscribe(data =>{       
     this.vehicleCountList=data.json();  
     if(this.vehicleCountList.length>0){ 
      if(this.prjId==1){ 
        this.vehcount=this.vehicleCountList[0].TOTAL 
        this.prmyCount= this.vehicleCountList[0].PRIMARY 
        this.secondCount=this.vehicleCountList[0].SECONDARY 
        this.prmyRunning=this.vehicleCountList[0].PRIMARY_RUNNING 
        this.secdRunning=this.vehicleCountList[0].SECONDARY_RUNNING 
        this.prmyStop=this.vehicleCountList[0].PRIMARY_STOP  
        this.secdStop=this.vehicleCountList[0].SECONDARY_STOP  
        this.prmyMaint=this.vehicleCountList[0].PRIMARY_MAINTENANCE 
        this.secdMaint=this.vehicleCountList[0].SECONDARY_MAINTENANCE
      }else if(this.prjId==2){
        this.vehcount=this.vehicleCountList[1].TOTAL 
        this.prmyCount= this.vehicleCountList[1].PRIMARY 
        this.secondCount=this.vehicleCountList[1].SECONDARY 
        this.prmyRunning=this.vehicleCountList[1].PRIMARY_RUNNING 
        this.secdRunning=this.vehicleCountList[1].SECONDARY_RUNNING 
        this.prmyStop=this.vehicleCountList[1].PRIMARY_STOP  
        this.secdStop=this.vehicleCountList[1].SECONDARY_STOP  
        this.prmyMaint=this.vehicleCountList[1].PRIMARY_MAINTENANCE 
        this.secdMaint=this.vehicleCountList[1].SECONDARY_MAINTENANCE
      }else if(this.prjId==3){
        this.vehcount=this.vehicleCountList[2].TOTAL 
        this.prmyCount= this.vehicleCountList[2].PRIMARY 
        this.secondCount=this.vehicleCountList[2].SECONDARY 
        this.prmyRunning=this.vehicleCountList[2].PRIMARY_RUNNING 
        this.secdRunning=this.vehicleCountList[2].SECONDARY_RUNNING 
        this.prmyStop=this.vehicleCountList[2].PRIMARY_STOP  
        this.secdStop=this.vehicleCountList[2].SECONDARY_STOP  
        this.prmyMaint=this.vehicleCountList[2].PRIMARY_MAINTENANCE 
        this.secdMaint=this.vehicleCountList[2].SECONDARY_MAINTENANCE
      } 
      else{
        this.vehcount=this.vehicleCountList[3].TOTAL 
        this.prmyCount= this.vehicleCountList[3].PRIMARY 
        this.secondCount=this.vehicleCountList[3].SECONDARY 
        this.prmyRunning=this.vehicleCountList[3].PRIMARY_RUNNING 
        this.secdRunning=this.vehicleCountList[3].SECONDARY_RUNNING 
        this.prmyStop=this.vehicleCountList[3].PRIMARY_STOP  
        this.secdStop=this.vehicleCountList[3].SECONDARY_STOP  
        this.prmyMaint=this.vehicleCountList[3].PRIMARY_MAINTENANCE 
        this.secdMaint=this.vehicleCountList[3].SECONDARY_MAINTENANCE
      }
      //this.loaderService.display(false); 
     } 
    },
     error=>{  
      //this.loaderService.display(false)
      Swal({
        type: 'error',
        title: 'Oops...',
        text: 'An Error Occurred Please Try Again',
      })
    });  
  } 
   
/*
 *get MSW REPORT 
*/ 
getMswReportDetails(){
  this.http.get(environment.apiUrl+'reports/getMswReportDetails').subscribe(data =>{       
    this.mswList=data.json();  
    this.ggnmonthData=this.mswList[0].GGNMonth;
    this.ggnAvgdata=this.mswList[0].GGNAvg;
    this.ggnTodayData=this.mswList[0].GGNToday;
    this.fbdMonthData=this.mswList[0].FBDMonth; 
    this.fbdAvgData=this.mswList[0].FBDAvg;
    this.fbdTodayData=this.mswList[0].FBDToday;
    this.gwlMonthData=this.mswList[0].GWLMonth;
    this.gwlAvgData=this.mswList[0].GWLAvg;
    this.gwlTodayData=this.mswList[0].GWLToday ; 
    this.getMswForLkoDetails();
  });
}


getMswForLkoDetails(){ 
  if(this.prjId==1){ 
    this.getMswLKOReportDetails() 
  }
  else if(this.prjId==2){ 
   this.inTonnageMtd=this.ggnmonthData
   this.inTonnageAvg=this.ggnAvgdata
   this.inTonnageToday=this.ggnTodayData 
  }
  else if(this.prjId==3){ 
   this.inTonnageMtd=this.fbdMonthData
   this.inTonnageAvg=this.fbdAvgData
   this.inTonnageToday=this.fbdTodayData 
  }
 else if(this.prjId==4){ 
   this.inTonnageMtd=this.gwlMonthData
   this.inTonnageAvg=this.gwlAvgData
   this.inTonnageToday=this.gwlTodayData 
  }
 } 

/*
 *get MSW LKO REPORT 
*/ 
getMswLKOReportDetails(){
  this.http.get(environment.apiUrl+'reports/getMswLKOReportDetails').subscribe(data =>{       
    this.mswLkoList=data.json();
    console.log("MSW DATA FOR LKO",this.mswLkoList)  
    this.lkdMonthData=this.mswLkoList[0].MTD  
    this.lkdAvgData=this.mswLkoList[0].AVG  
    this.lkdTodayData=this.mswLkoList[0].TODAY  
    this.inTonnageMtd=this.lkdMonthData
    this.inTonnageAvg=this.lkdAvgData
    this.inTonnageToday=this.lkdTodayData 
    this.lkdMOnthWastData=this.mswLkoList[1].MTD  
    this.lkdAvgWastData=this.mswLkoList[1].AVG  
    this.lkdTodayWastData=this.mswLkoList[1].TODAY  
    this.lkoMonthRfdData=this.mswLkoList[2].MTD  
    this.lkoAvgRfdData=this.mswLkoList[2].AVG  
    this.lkoTodayRfdData=this.mswLkoList[2].TODAY  
    this.lkdMonthOutData=this.mswLkoList[3].MTD  
    this.lkdAvgOutData=this.mswLkoList[3].AVG  
    this.lkdTodayOutData=this.mswLkoList[3].TODAY  
  });
}



/**
 * get Attendance Summary Report
*/ 
getAttendanceReport(){
  this.http.get(environment.apiUrl+'attendance/getAttendanceSummaryReport').subscribe(data =>{       
    this.attendanceList=data.json(); 
    if(this.prjId==1){
      this.totalEmpCount=this.attendanceList[0].TOTALUSERS
      this.todayActive=this.attendanceList[0].TODAYACTIVE
    }else if(this.prjId==2){
      this.totalEmpCount=this.attendanceList[1].TOTALUSERS
      this.todayActive=this.attendanceList[1].TODAYACTIVE
    }else if(this.prjId==3){
      this.totalEmpCount=this.attendanceList[2].TOTALUSERS
      this.todayActive=this.attendanceList[2].TODAYACTIVE
    }else if(this.prjId==4){
      this.totalEmpCount=this.attendanceList[3].TOTALUSERS
      this.todayActive=this.attendanceList[3].TODAYACTIVE
    } 
  });
}


/**
 * get all Project Dashboard details
*/
getProjectDashBoardData(){
  this.http.get(environment.apiUrl+'reports/getProjectDashBoardDetail').subscribe(data =>{       
     this.allCompList=data.json(); 
     console.log("all Data",this.allCompList)   
     if(this.allCompList.length>0){ 
      this.complainSummaryReport();
      this.loaderService.display(false);  
     }
   });  
} 

//Get all query Result data
complainSummaryReport()
{
  if(this.prjId==2){
    this.totalComp=this.allCompList[0].GGNMonth
    this.totalAvg=(this.totalComp/this.currentDay).toFixed(2)
    this.todayComp=this.allCompList[0].GGNToday
    //For Mobile App
    this.totalMobComp=this.allCompList[5].GGNMonth
    this.totalMobToday=this.allCompList[5].GGNToday
    this.totalMobAvg=(this.totalMobComp/this.currentDay).toFixed(2)
    //PEnding
    this.pendMtd=this.allCompList[1].GGNMonth
    this.pendToday=this.allCompList[1].GGNToday
    this.pendAvg=(this.pendMtd/this.currentDay).toFixed(2)
    //Resolved
    this.reslMtd=this.allCompList[2].GGNMonth
    this.reslvToday=this.allCompList[2].GGNToday
    this.reslvAvg=(this.reslMtd/this.currentDay).toFixed(2)
     //FEEDBACK
    this.fbMtd=this.allCompList[3].GGNMonth
    this.fbToday=this.allCompList[3].GGNToday
    this.fbAvg=(this.fbMtd/this.currentDay).toFixed(2)
      //UNDER OSERVATION
    this.UOMtd=this.allCompList[4].GGNMonth
    this.UOToday=this.allCompList[4].GGNToday
    this.UOAvg=(this.UOMtd/this.currentDay).toFixed(2)
    //*********************UCC************
    this.uccCollMtd=this.allCompList[6].GGNMonth
    this.uccCollAvg=this.allCompList[6].GGNAvg
    this.uccCollToday=this.allCompList[6].GGNToday
    //HOUSE HOLD 
    this.HHInMtd=this.allCompList[7].GGNMonth
    this.HHInAvg=this.allCompList[7].GGNAvg
    this.HHInToday=this.allCompList[7].GGNToday
    //*****************KCC************** */
    this.kccCollMtd=this.allCompList[8].GGNMonth
    this.kccCollAvg=this.allCompList[8].GGNAvg
    this.kccCollToday=this.allCompList[8].GGNToday

    // PAID KCC
    this.paidKccMtd=this.allCompList[9].GGNMonth
    this.paidKccAvg=this.allCompList[9].GGNAvg
    this.paidKccToday=this.allCompList[9].GGNToday

     // OUT standing KCC
     this.outStndMtd=this.allCompList[10].GGNMonth
     this.outStndAvg=this.allCompList[10].GGNAvg
     this.outStndToday=this.allCompList[10].GGNToday 

     //****************FUES PURCHASE********* */
     this.fuelPurcMtd=this.allCompList[11].GGNMonth
     this.fuelPurcAvg=this.allCompList[11].GGNAvg
     this.fuelPurcToday=this.allCompList[11].GGNToday 

     //LOOSE  
     this.loosePurcMtd=this.allCompList[12].GGNMonth
     this.loosePurcAvg=this.allCompList[12].GGNAvg
     this.loosePurcToday=this.allCompList[12].GGNToday 
  

     //******************FUES DIST********************* */
     this.fuesDistVehMtd=this.allCompList[13].GGNMonth
     this.fuesDistVehAvg=this.allCompList[13].GGNAvg
     this.fuesDistVehToday=this.allCompList[13].GGNToday 
     // FOR DG
     this.fuesDistDGMtd=this.allCompList[14].GGNMonth
     this.fuesDistDGAvg=this.allCompList[14].GGNAvg
     this.fuesDistDGToday=this.allCompList[14].GGNToday 

     // FOR TS
     this.fuesDistTSMtd=this.allCompList[15].GGNMonth
     this.fuesDistTSAvg=this.allCompList[15].GGNAvg
     this.fuesDistTSToday=this.allCompList[15].GGNToday 

   }else if(this.prjId==1){
    this.totalComp=this.allCompList[0].LKDMonth
    this.totalAvg=(this.totalComp/this.currentDay).toFixed(2)
    this.todayComp=this.allCompList[0].LKDToday
     //For Mobile App
    this.totalMobComp=this.allCompList[5].LKDMonth
    this.totalMobToday=this.allCompList[5].LKDToday
    this.totalMobAvg=(this.totalMobComp/this.currentDay).toFixed(2)
    //PEnding
    this.pendMtd=this.allCompList[1].LKDMonth
    this.pendToday=this.allCompList[1].LKDToday
    this.pendAvg=(this.pendMtd/this.currentDay).toFixed(2)
    //Resolved
    this.reslMtd=this.allCompList[2].LKDMonth
    this.reslvToday=this.allCompList[2].LKDToday
    this.reslvAvg=(this.reslMtd/this.currentDay).toFixed(2)
    //FEEDBACK
    this.fbMtd=this.allCompList[3].LKDMonth
    this.fbToday=this.allCompList[3].LKDToday
    this.fbAvg=(this.fbMtd/this.currentDay).toFixed(2)
    //UNDER OSERVATION
    this.UOMtd=this.allCompList[4].LKDMonth
    this.UOToday=this.allCompList[4].LKDToday
    this.UOAvg=(this.UOMtd/this.currentDay).toFixed(2)
    //*********************UCC************
    this.uccCollMtd=this.allCompList[6].LKDMonth
    this.uccCollAvg=this.allCompList[6].LKDAvg
    this.uccCollToday=this.allCompList[6].LKDToday
    //HOUSE HOLD 
    this.HHInMtd=this.allCompList[7].LKDMonth
    this.HHInAvg=this.allCompList[7].LKDAvg
    this.HHInToday=this.allCompList[7].LKDToday
    //********************************KCC */ 
    this.kccCollMtd=this.allCompList[8].LKDMonth
    this.kccCollAvg=this.allCompList[8].LKDAvg
    this.kccCollToday=this.allCompList[8].LKDToday
    // PAID KCC
    this.paidKccMtd=this.allCompList[9].LKDMonth
    this.paidKccAvg=this.allCompList[9].LKDAvg
    this.paidKccToday=this.allCompList[9].LKDToday
     // OUT standing KCC
     this.outStndMtd=this.allCompList[10].LKDMonth
     this.outStndAvg=this.allCompList[10].LKDAvg
     this.outStndToday=this.allCompList[10].LKDToday 

     //****************FUES PURCHASE********* */
     this.fuelPurcMtd=this.allCompList[11].LKDMonth
     this.fuelPurcAvg=this.allCompList[11].LKDAvg
     this.fuelPurcToday=this.allCompList[11].LKDToday 

      //LOOSE  
      this.loosePurcMtd=this.allCompList[12].LKDMonth
      this.loosePurcAvg=this.allCompList[12].LKDAvg
      this.loosePurcToday=this.allCompList[12].LKDToday 


    //******************FUES DIST********************* */
     this.fuesDistVehMtd=this.allCompList[13].LKDMonth
     this.fuesDistVehAvg=this.allCompList[13].LKDAvg
     this.fuesDistVehToday=this.allCompList[13].LKDToday 

      // FOR DG
      this.fuesDistDGMtd=this.allCompList[14].LKDMonth
      this.fuesDistDGAvg=this.allCompList[14].LKDAvg
      this.fuesDistDGToday=this.allCompList[14].LKDToday 

         // FOR TS
     this.fuesDistTSMtd=this.allCompList[15].LKDMonth
     this.fuesDistTSAvg=this.allCompList[15].LKDAvg
     this.fuesDistTSToday=this.allCompList[15].LKDToday 

   }else if(this.prjId==3){
    this.totalComp=this.allCompList[0].FBDMonth
    this.totalAvg=(this.totalComp/this.currentDay).toFixed(2)
    this.todayComp=this.allCompList[0].FBDToday
     //For Mobile App
     this.totalMobComp=this.allCompList[5].FBDMonth
     this.totalMobToday=this.allCompList[5].FBDToday
     this.totalMobAvg=(this.totalMobComp/this.currentDay).toFixed(2)
     //PEnding
    this.pendMtd=this.allCompList[1].FBDMonth
    this.pendToday=this.allCompList[1].FBDToday
    this.pendAvg=(this.pendMtd/this.currentDay).toFixed(2)
     //Resolved
     this.reslMtd=this.allCompList[2].FBDMonth
     this.reslvToday=this.allCompList[2].FBDToday
     this.reslvAvg=(this.reslMtd/this.currentDay).toFixed(2)
     //FEEDBACK
    this.fbMtd=this.allCompList[3].FBDMonth
    this.fbToday=this.allCompList[3].FBDToday
    this.fbAvg=(this.fbMtd/this.currentDay).toFixed(2)
     //UNDER OSERVATION
     this.UOMtd=this.allCompList[4].FBDMonth
     this.UOToday=this.allCompList[4].FBDToday
     this.UOAvg=(this.UOMtd/this.currentDay).toFixed(2)
      //*********************UCC************
    this.uccCollMtd=this.allCompList[6].FBDMonth
    this.uccCollAvg=this.allCompList[6].FBDAvg
    this.uccCollToday=this.allCompList[6].FBDToday
    //HOUSE HOLD 
    this.HHInMtd=this.allCompList[7].FBDMonth
    this.HHInAvg=this.allCompList[7].FBDAvg
    this.HHInToday=this.allCompList[7].FBDToday
     //********************************KCC******************/ 
     this.kccCollMtd=this.allCompList[8].FBDMonth
     this.kccCollAvg=this.allCompList[8].FBDAvg
     this.kccCollToday=this.allCompList[8].FBDToday
         // PAID KCC
    this.paidKccMtd=this.allCompList[9].FBDMonth
    this.paidKccAvg=this.allCompList[9].FBDAvg
    this.paidKccToday=this.allCompList[9].FBDToday
     // OUT standing KCC
     this.outStndMtd=this.allCompList[10].FBDMonth
     this.outStndAvg=this.allCompList[10].FBDAvg
     this.outStndToday=this.allCompList[10].FBDToday 

        //****************FUES PURCHASE********* */
        this.fuelPurcMtd=this.allCompList[11].FBDMonth
        this.fuelPurcAvg=this.allCompList[11].FBDAvg
        this.fuelPurcToday=this.allCompList[11].FBDToday 

      //LOOSE  
      this.loosePurcMtd=this.allCompList[12].FBDMonth
      this.loosePurcAvg=this.allCompList[12].FBDAvg
      this.loosePurcToday=this.allCompList[12].FBDToday
      
      
    //******************FUES DIST********************* */
     this.fuesDistVehMtd=this.allCompList[13].FBDMonth
     this.fuesDistVehAvg=this.allCompList[13].FBDAvg
     this.fuesDistVehToday=this.allCompList[13].FBDToday 

      // FOR DG
      this.fuesDistDGMtd=this.allCompList[14].FBDMonth
      this.fuesDistDGAvg=this.allCompList[14].FBDAvg
      this.fuesDistDGToday=this.allCompList[14].FBDToday  
              // FOR TS
     this.fuesDistTSMtd=this.allCompList[15].FBDMonth
     this.fuesDistTSAvg=this.allCompList[15].FBDAvg
     this.fuesDistTSToday=this.allCompList[15].FBDToday 

   }else{
    this.totalComp=this.allCompList[0].GWLMonth
    this.totalAvg=(this.totalComp/this.currentDay).toFixed(2)
    this.todayComp=this.allCompList[0].GWLToday
    //For Mobile App
    this.totalMobComp=this.allCompList[5].GWLMonth
    this.totalMobToday=this.allCompList[5].GWLToday
    this.totalMobAvg=(this.totalMobComp/this.currentDay).toFixed(2)
    //PEnding
    this.pendMtd=this.allCompList[1].GWLMonth
    this.pendToday=this.allCompList[1].GWLToday
    this.pendAvg=(this.totalMobComp/this.currentDay).toFixed(2)
    //Resolved
    this.reslMtd=this.allCompList[2].GWLMonth
    this.reslvToday=this.allCompList[2].GWLToday
    this.reslvAvg=(this.reslMtd/this.currentDay).toFixed(2)
    //FEEDBACK
    this.fbMtd=this.allCompList[3].GWLMonth
    this.fbToday=this.allCompList[3].GWLToday
    this.fbAvg=(this.fbMtd/this.currentDay).toFixed(2)
    //UNDER OSERVATION
    this.UOMtd=this.allCompList[4].GWLMonth
    this.UOToday=this.allCompList[4].GWLToday
    this.UOAvg=(this.UOMtd/this.currentDay).toFixed(2)
     //*********************UCC************
     this.uccCollMtd=this.allCompList[6].GWLMonth
     this.uccCollAvg=this.allCompList[6].GWLAvg
     this.uccCollToday=this.allCompList[6].GWLToday
     //HOUSE HOLD
     this.HHInMtd=this.allCompList[7].GWLMonth
     this.HHInAvg=this.allCompList[7].GWLAvg
     this.HHInToday=this.allCompList[7].GWLToday
     //********************************KCC******************/ 
     this.kccCollMtd=this.allCompList[8].GWLMonth
     this.kccCollAvg=this.allCompList[8].GWLAvg
     this.kccCollToday=this.allCompList[8].GWLToday
       // PAID KCC
    this.paidKccMtd=this.allCompList[9].GWLMonth
    this.paidKccAvg=this.allCompList[9].GWLAvg
    this.paidKccToday=this.allCompList[9].GWLToday
     // OUT standing KCC
     this.outStndMtd=this.allCompList[10].GWLMonth
     this.outStndAvg=this.allCompList[10].GWLAvg
     this.outStndToday=this.allCompList[10].GWLToday 
    //****************FUES PURCHASE********* */
    this.fuelPurcMtd=this.allCompList[11].GWLMonth
    this.fuelPurcAvg=this.allCompList[11].GWLAvg
    this.fuelPurcToday=this.allCompList[11].GWLToday  
    //LOOSE  
    this.loosePurcMtd=this.allCompList[12].GWLMonth
    this.loosePurcAvg=this.allCompList[12].GWLAvg
    this.loosePurcToday=this.allCompList[12].GWLToday
    
  //******************FUES DIST********************* */
  this.fuesDistVehMtd=this.allCompList[13].GWLMonth
  this.fuesDistVehAvg=this.allCompList[13].GWLAvg
  this.fuesDistVehToday=this.allCompList[13].GWLToday 

    // FOR DG
    this.fuesDistDGMtd=this.allCompList[14].GWLMonth
    this.fuesDistDGAvg=this.allCompList[14].GWLAvg
    this.fuesDistDGToday=this.allCompList[14].GWLToday 

    // FOR TS
    this.fuesDistTSMtd=this.allCompList[15].GWLMonth
    this.fuesDistTSAvg=this.allCompList[15].GWLAvg
    this.fuesDistTSToday=this.allCompList[15].GWLToday 

   }
}



   ngOnInit(){ 
    this.prjId = this.auth.getAuthentication().projectId 
    this.getVehicleCoutReport();  
    this.getMswReportDetails(); 
    this.getAttendanceReport();
    this.getProjectDashBoardData();
    if(this.prjId==1){
      this.prjName="LUCKNOW PROJECT"
    }else if(this.prjId==2){
      this.prjName="GURGAON PROJECT"
    }else if(this.prjId==3){
      this.prjName="FARIDABAD PROJECT"
    }else if(this.prjId==4){
      this.prjName="GWALIOR PROJECT"
    }
    } 
}




 
/*
 * Bind UCC SUMMARY REPORT
*/
// bindAllPrjDataData(data){ 
//   this.gridDataPrjSummary = [
//                 {
//                 "ProjectType": "CRM",
//                 "ProjectTypeDetail": "Total Complaints(Toll Free)", 
//                 "GGNMonth":data[0].GGNMonth?data[0].GGNMonth:0,
//                 "GGNAvg":(data[0].GGNAvg).toFixed(2)?(data[0].GGNAvg).toFixed(2):0.00, 
//                 "GGNToday":data[0].GGNToday?data[0].GGNToday:0, 
//                 "FBDMonth":data[0].FBDMonth?data[0].FBDMonth:0,
//                 "FBDAvg":(data[0].FBDAvg).toFixed(2)?(data[0].FBDAvg).toFixed(2):0.00, 
//                 "FBDToday":(data[0].FBDToday)?(data[0].FBDToday):0,
//                 "GWLMonth":data[0].GWLMonth?data[0].GWLMonth:0,
//                 "GWLAvg":(data[0].GWLAvg).toFixed(2)?(data[0].GWLAvg).toFixed(2):0.00, 
//                 "GWLToday":data[0].GWLToday?data[0].GWLToday:0,
//                 "LKDMonth":data[0].LKDMonth?data[0].LKDMonth:0,
//                 "LKDAvg":(data[0].LKDAvg).toFixed(2)?(data[0].LKDAvg).toFixed(2):0.00, 
//                 "LKDToday":data[0].LKDToday?data[0].LKDToday:0,
//                 }, 
//                 {
//                   "ProjectType": "",
//                   "ProjectTypeDetail": "Total Complaints(Mobile App)", 
//                   "GGNMonth":data[5].GGNMonth?data[5].GGNMonth:0,
//                   "GGNAvg":(data[5].GGNAvg).toFixed(2)?(data[5].GGNAvg).toFixed(2):0.00, 
//                   "GGNToday":data[5].GGNToday?data[5].GGNToday:0, 
//                   "FBDMonth":data[5].FBDMonth?data[5].FBDMonth:0,
//                   "FBDAvg":(data[5].FBDAvg).toFixed(2)?(data[5].FBDAvg).toFixed(2):0.00, 
//                   "FBDToday":(data[5].FBDToday)?(data[5].FBDToday):0,
//                   "GWLMonth":data[5].GWLMonth?data[5].GWLMonth:0,
//                   "GWLAvg":(data[5].GWLAvg).toFixed(2)?(data[5].GWLAvg).toFixed(2):0.00, 
//                   "GWLToday":data[5].GWLToday?data[5].GWLToday:0,
//                   "LKDMonth":data[5].LKDMonth?data[5].LKDMonth:0,
//                   "LKDAvg":(data[5].LKDAvg).toFixed(2)?(data[5].LKDAvg).toFixed(2):0.00, 
//                   "LKDToday":data[5].LKDToday?data[5].LKDToday:0,
//                   },
//                 {
//                 "ProjectType": "",
//                 "ProjectTypeDetail": "Pending", 
//                 "GGNMonth":data[1].GGNMonth?data[1].GGNMonth:0,
//                 "GGNAvg":(data[1].GGNAvg).toFixed(2)?(data[1].GGNAvg).toFixed(2):0.00, 
//                 "GGNToday":data[1].GGNToday?data[1].GGNToday:0, 
//                 "FBDMonth":data[1].FBDMonth?data[1].FBDMonth:0,
//                 "FBDAvg":(data[1].FBDAvg).toFixed(2)?(data[1].FBDAvg).toFixed(2):0.00, 
//                 "FBDToday":data[1].FBDToday?data[1].FBDToday:0,
//                 "GWLMonth":data[1].GWLMonth?data[1].GWLMonth:0,
//                 "GWLAvg":(data[1].GWLAvg).toFixed(2)?(data[1].GWLAvg).toFixed(2):0.00, 
//                 "GWLToday":data[1].GWLToday?data[1].GWLToday:0,
//                 "LKDMonth":data[1].LKDMonth?data[1].LKDMonth:0,
//                 "LKDAvg":(data[1].LKDAvg).toFixed(2)?(data[1].LKDAvg).toFixed(2):0.00, 
//                 "LKDToday":data[1].LKDToday?data[1].LKDToday:0,
//                 },
//                 {
//                   "ProjectType": "",
//                   "ProjectTypeDetail": "Resolved", 
//                   "GGNMonth":data[2].GGNMonth?data[2].GGNMonth:0,
//                   "GGNAvg":(data[2].GGNAvg).toFixed(2)?(data[2].GGNAvg).toFixed(2):0.00, 
//                   "GGNToday":data[2].GGNToday?data[2].GGNToday:0, 
//                   "FBDMonth":data[2].FBDMonth?data[2].FBDMonth:0,
//                   "FBDAvg":(data[2].FBDAvg).toFixed(2)?(data[2].FBDAvg).toFixed(2):0.00, 
//                   "FBDToday":(data[2].FBDToday)?(data[2].FBDToday):0,
//                   "GWLMonth":data[2].GWLMonth?data[2].GWLMonth:0,
//                   "GWLAvg":(data[2].GWLAvg).toFixed(2)?(data[2].GWLAvg).toFixed(2):0.00, 
//                   "GWLToday":data[2].GWLToday?data[2].GWLToday:0,
//                   "LKDMonth":data[2].LKDMonth?data[2].LKDMonth:0,
//                   "LKDAvg":(data[2].LKDAvg).toFixed(2)?(data[2].LKDAvg).toFixed(2):0.00, 
//                   "LKDToday":data[2].LKDToday?data[2].LKDToday:0,
//                 },
//                 {
//                   "ProjectType": "",
//                   "ProjectTypeDetail": "FeedBack", 
//                   "GGNMonth":data[3].GGNMonth?data[3].GGNMonth:0,
//                   "GGNAvg":(data[3].GGNAvg).toFixed(2)?(data[3].GGNAvg).toFixed(2):0.00, 
//                   "GGNToday":data[3].GGNToday?data[3].GGNToday:0, 
//                   "FBDMonth":data[3].FBDMonth?data[3].FBDMonth:0,
//                   "FBDAvg":(data[3].FBDAvg).toFixed(2)?(data[3].FBDAvg).toFixed(2):0.00, 
//                   "FBDToday":(data[3].FBDToday)?(data[3].FBDToday):0,
//                   "GWLMonth":data[3].GWLMonth?data[3].GWLMonth:0,
//                   "GWLAvg":(data[3].GWLAvg).toFixed(2)?(data[3].GWLAvg).toFixed(2):0.00, 
//                   "GWLToday":data[3].GWLToday?data[3].GWLToday:0,
//                   "LKDMonth":data[3].LKDMonth?data[3].LKDMonth:0,
//                   "LKDAvg":(data[3].LKDAvg).toFixed(2)?(data[3].LKDAvg).toFixed(2):0.00, 
//                   "LKDToday":data[3].LKDToday?data[3].LKDToday:0,
//                   },
//                   {
//                     "ProjectType": "",
//                     "ProjectTypeDetail": "Under Observation", 
//                     "GGNMonth":data[4].GGNMonth?data[4].GGNMonth:0,
//                     "GGNAvg":(data[4].GGNAvg).toFixed(2)?(data[4].GGNAvg).toFixed(2):0.00, 
//                     "GGNToday":data[4].GGNToday?data[4].GGNToday:0, 
//                     "FBDMonth":data[4].FBDMonth?data[4].FBDMonth:0,
//                     "FBDAvg":(data[4].FBDAvg).toFixed(2)?(data[4].FBDAvg).toFixed(2):0.00, 
//                     "FBDToday":(data[4].FBDToday)?(data[4].FBDToday):0,
//                     "GWLMonth":data[4].GWLMonth?data[4].GWLMonth:0,
//                     "GWLAvg":(data[4].GWLAvg).toFixed(2)?(data[4].GWLAvg).toFixed(2):0.00, 
//                     "GWLToday":data[4].GWLToday?data[4].GWLToday:0,
//                     "LKDMonth":data[4].LKDMonth?data[4].LKDMonth:0,
//                     "LKDAvg":(data[4].LKDAvg).toFixed(2)?(data[4].LKDAvg).toFixed(2):0.00, 
//                     "LKDToday":data[4].LKDToday?data[4].LKDToday:0,
//                     },  
//                      {
//                       "ProjectType": "MSW",
//                       "ProjectTypeDetail": "[Intake] Tonnage",
//                       "GGNMonth":this.ggnmonthData?this.ggnmonthData:0,
//                       "GGNAvg":this.ggnAvgdata?this.ggnAvgdata:0,
//                       "GGNToday":this.ggnTodayData?this.ggnTodayData:0,
//                       "FBDMonth":this.fbdMonthData?this.fbdMonthData:0,
//                       "FBDAvg":this.fbdAvgData?this.fbdAvgData:0,
//                       "FBDToday":this.fbdTodayData?this.fbdTodayData:0,
//                       "GWLMonth":this.gwlMonthData?this.gwlMonthData:0,
//                       "GWLAvg":this.gwlAvgData?this.gwlAvgData:0,
//                       "GWLToday":this.gwlTodayData?this.gwlTodayData:0, 
//                       "LKDMonth":this.lkdMonthData?this.lkdMonthData:0,
//                       "LKDAvg":this.lkdAvgData?this.lkdAvgData:0.00,
//                       "LKDToday":this.lkdTodayData?this.lkdTodayData:0,
//                   }, 
//                   {
//                     "ProjectType": "",
//                     "ProjectTypeDetail": "Excluded waste",
//                     "FBDMonth":"",
//                     "FBDAvg": "",
//                     "FBDToday": "",
//                     "GGNMonth": "",
//                     "GGNAvg": "",
//                     "GGNToday": "",
//                     "GWLMonth": "",
//                     "GWLAvg": "",
//                     "GWLToday": "",
//                     "LKDMonth":this.lkdMOnthWastData?this.lkdMOnthWastData:0,
//                     "LKDAvg": this.lkdAvgWastData?this.lkdAvgWastData:0.00,
//                     "LKDToday":this.lkdTodayWastData?this.lkdTodayWastData:0, 
//                   },
//                   {
//               "ProjectType": "",
//               "ProjectTypeDetail": "[Out] Compost Sale (Tons)",
//               "FBDMonth":"",
//               "FBDAvg": "",
//               "FBDToday": "",
//               "GGNMonth": "",
//               "GGNAvg": "",
//               "GGNToday": "",
//               "GWLMonth": "",
//               "GWLAvg": "",
//               "GWLToday": "",
//               "LKDMonth":this.lkdMonthOutData?this.lkdMonthOutData:0,
//               "LKDAvg": this.lkdAvgOutData?this.lkdAvgOutData:0.00,
//               "LKDToday":this.lkdTodayOutData?this.lkdTodayOutData:0, 
//             },
//             {
//               "ProjectType": "",
//                 "ProjectTypeDetail": "[Out] RDF Sale (Tons)",
//                 "FBDMonth":"",
//                 "FBDAvg": "",
//                 "FBDToday": "",
//                 "GGNMonth": "",
//                 "GGNAvg": "",
//                 "GGNToday": "",
//                 "GWLMonth": "",
//                 "GWLAvg": "",
//                 "GWLToday": "",
//                 "LKDMonth":this.lkoMonthRfdData?this.lkoMonthRfdData:0,
//                 "LKDAvg": this.lkoAvgRfdData?this.lkoAvgRfdData:0.00,
//                 "LKDToday":this.lkoTodayRfdData?this.lkoTodayRfdData:0, 
//               },
//               {
//                 "ProjectType": "UCC",
//                 "ProjectTypeDetail": "Total Collection (Rs)", 
//                 "GGNMonth":data[6].GGNMonth?data[6].GGNMonth:0,
//                 "GGNAvg": data[6].GGNAvg?data[6].GGNAvg:0.00,
//                 "GGNToday": data[6].GGNToday?data[6].GGNToday:0,
//                 "FBDMonth":data[6].FBDMonth?data[6].FBDMonth:0,
//                 "FBDAvg": data[6].FBDAvg?data[6].FBDAvg:0.00,
//                 "FBDToday": data[6].FBDToday?data[6].FBDToday:0,
//                 "GWLMonth": data[6].GWLMonth?data[6].GWLMonth:0,
//                 "GWLAvg":  data[6].GWLAvg? data[6].GWLAvg:0.00,
//                 "GWLToday": data[6].GWLToday?data[6].GWLToday:0,
//                 "LKDMonth":data[6].LKDMonth?data[6].LKDMonth:0,
//                 "LKDAvg": data[6].LKDAvg?data[6].LKDAvg:0.00,
//                 "LKDToday": data[6].LKDToday?data[6].LKDToday:0,
//                 }, 
//                 {
//                   "ProjectType": "",
//                   "ProjectTypeDetail": "Total HH Touched",
//                   "GGNMonth":data[7].GGNMonth?data[7].GGNMonth:0,
//                   "GGNAvg": data[7].GGNAvg?data[7].GGNAvg:0.00,
//                   "GGNToday": data[7].GGNToday?data[7].GGNToday:0,
//                   "FBDMonth":data[7].FBDMonth?data[7].FBDMonth:0,
//                   "FBDAvg": data[7].FBDAvg?data[7].FBDAvg:0.00,
//                   "FBDToday": data[7].FBDToday?data[7].FBDToday:0,
//                   "GWLMonth": data[7].GWLMonth?data[7].GWLMonth:0,
//                   "GWLAvg":  data[7].GWLAvg?data[7].GWLAvg:0.00,
//                   "GWLToday": data[7].GWLToday?data[7].GWLToday:0,
//                   "LKDMonth":data[7].LKDMonth?data[7].LKDMonth:0,
//                   "LKDAvg": data[7].LKDAvg?data[7].LKDAvg:0.00,
//                   "LKDToday": data[7].LKDToday?data[7].LKDToday:0,
//                   }, 
//                 {
//                   "ProjectType": "KCC",
//                   "ProjectTypeDetail": "Total Collection (Rs)", 
//                   "GGNMonth":data[8].GGNMonth?data[8].GGNMonth:0,
//                   "GGNAvg": data[8].GGNAvg?data[8].GGNAvg:0.00,
//                   "GGNToday": data[8].GGNToday?data[8].GGNToday:0,
//                   "FBDMonth":data[8].FBDMonth?data[8].FBDMonth:0,
//                   "FBDAvg": data[8].FBDAvg?data[8].FBDAvg:0.00,
//                   "FBDToday": data[8].FBDToday? data[8].FBDToday:0,
//                   "GWLMonth": data[8].GWLMonth?data[8].GWLMonth:0,
//                   "GWLAvg":  data[8].GWLAvg?data[8].GWLAvg:0.00,
//                   "GWLToday": data[8].GWLToday?data[8].GWLToday:0,
//                   "LKDMonth":data[8].LKDMonth?data[8].LKDMonth:0,
//                   "LKDAvg": data[8].LKDAvg?data[8].LKDAvg:0.00,
//                   "LKDToday": data[8].LKDToday?data[8].LKDToday:0,
//                   }, 
//                   {
//                   "ProjectType": "",
//                   "ProjectTypeDetail": "Paid Amount(Rs)",
//                   "GGNMonth":data[9].GGNMonth?data[9].GGNMonth:0,
//                   "GGNAvg": data[9].GGNAvg?data[9].GGNAvg:0.00,
//                   "GGNToday": data[9].GGNToday?data[9].GGNToday:0,
//                   "FBDMonth":data[9].FBDMonth?data[9].FBDMonth:0,
//                   "FBDAvg": data[9].FBDAvg?data[9].FBDAvg:0.00,
//                   "FBDToday": data[9].FBDToday?data[9].FBDToday:0,
//                   "GWLMonth": data[9].GWLMonth?data[9].GWLMonth:0,
//                   "GWLAvg":  data[9].GWLAvg?data[9].GWLAvg:0.00,
//                   "GWLToday": data[9].GWLToday?data[9].GWLToday:0,
//                   "LKDMonth":data[9].LKDMonth?data[9].LKDMonth:0,
//                   "LKDAvg": data[9].LKDAvg?data[9].LKDAvg:0.00,
//                   "LKDToday": data[9].LKDToday?data[9].LKDToday:0,
//               },
//               {
//                 "ProjectType": "",
//                 "ProjectTypeDetail": "Out Standing Amount(Rs)",
//                 "GGNMonth":data[10].GGNMonth?data[10].GGNMonth:0,
//                 "GGNAvg": data[10].GGNAvg?data[10].GGNAvg:0.00,
//                 "GGNToday": data[10].GGNToday?data[10].GGNToday:0,
//                 "FBDMonth":data[10].FBDMonth?data[10].FBDMonth:0,
//                 "FBDAvg": data[10].FBDAvg?data[10].FBDAvg:0.00,
//                 "FBDToday": data[10].FBDToday?data[10].FBDToday:0,
//                 "GWLMonth": data[10].GWLMonth?data[10].GWLMonth:0,
//                 "GWLAvg":  data[10].GWLAvg?data[10].GWLAvg:0.00,
//                 "GWLToday": data[10].GWLToday?data[10].GWLToday:0,
//                 "LKDMonth":data[10].LKDMonth?data[10].LKDMonth:0,
//                 "LKDAvg": data[10].LKDAvg?data[10].LKDAvg:0.00,
//                 "LKDToday": data[10].LKDToday?data[10].LKDToday:0,
//             }, 
//               {
//               "ProjectType": "ATTENDANCE",
//               "ProjectTypeDetail": "Total Employee",
//               "GGNMonth":this.attendanceList[1].TOTALUSERS?this.attendanceList[1].TOTALUSERS:0,
//               "GGNAvg":"-",
//               "GGNToday":this.attendanceList[1].TODAYACTIVE?this.attendanceList[1].TODAYACTIVE:0,
//               "FBDMonth":this.attendanceList[2].TOTALUSERS?this.attendanceList[2].TOTALUSERS:0,
//               "FBDAvg": "-",
//               "FBDToday":this.attendanceList[2].TODAYACTIVE?this.attendanceList[2].TODAYACTIVE:0,
//               "GWLMonth": this.attendanceList[3].TOTALUSERS?this.attendanceList[3].TOTALUSERS:0,
//               "GWLAvg":  "-",
//               "GWLToday":this.attendanceList[3].TODAYACTIVE?this.attendanceList[3].TODAYACTIVE:0,
//               "LKDMonth":this.attendanceList[0].TOTALUSERS?this.attendanceList[0].TOTALUSERS:0,
//               "LKDAvg":"-",
//               "LKDToday":this.attendanceList[0].TODAYACTIVE?this.attendanceList[0].TODAYACTIVE:0,
//             },
//             {
//                 "ProjectType": "FUEL PURCHASE",
//                 "ProjectTypeDetail": "Vehicle",
//                 "GGNMonth":data[11].GGNMonth,
//                 "GGNAvg":data[11].GGNAvg,
//                 "GGNToday":data[11].GGNToday,
//                 "FBDMonth":data[11].FBDMonth,
//                 "FBDAvg": data[11].FBDAvg,
//                 "FBDToday":data[11].FBDToday,
//                 "GWLMonth":data[11].GWLMonth,
//                 "GWLAvg": data[11].GWLAvg,
//                 "GWLToday":data[11].GWLToday,
//                 "LKDMonth": data[11].LKDMonth,
//                 "LKDAvg":data[11].LKDAvg,
//                 "LKDToday":data[11].LKDToday
//               },
//               {
//                 "ProjectType": "",
//                 "ProjectTypeDetail": "Loose",
//                 "GGNMonth":data[12].GGNMonth,
//                 "GGNAvg":data[12].GGNAvg,
//                 "GGNToday":data[12].GGNToday,
//                 "FBDMonth":data[12].FBDMonth,
//                 "FBDAvg":data[12].FBDAvg,
//                 "FBDToday": data[12].FBDToday,
//                 "GWLMonth":data[12].GWLMonth,
//                 "GWLAvg": data[12].GWLAvg,
//                 "GWLToday": data[12].GWLToday,
//                 "LKDMonth":data[12].LKDMonth,
//                 "LKDAvg":data[12].LKDAvg,
//                 "LKDToday": data[12].LKDToday
//               },
//               {
//                 "ProjectType": "FUEL DISTRIBUTION",
//                 "ProjectTypeDetail": "Vehicle(Litre)",
//                 "GGNMonth":data[13].GGNMonth,
//                 "GGNAvg":data[13].GGNAvg,
//                 "GGNToday":data[13].GGNToday,
//                 "FBDMonth":data[13].FBDMonth,
//                 "FBDAvg":data[13].FBDAvg,
//                 "FBDToday": data[13].FBDToday,
//                 "GWLMonth":data[13].GWLMonth,
//                 "GWLAvg": data[13].GWLAvg,
//                 "GWLToday": data[13].GWLToday,
//                 "LKDMonth":data[13].LKDMonth,
//                 "LKDAvg":data[13].LKDAvg,
//                 "LKDToday": data[13].LKDToday
//               },
//               {
//                 "ProjectType": "",
//                 "ProjectTypeDetail": "DG(Litre)",
//                 "GGNMonth":data[14].GGNMonth,
//                 "GGNAvg":data[14].GGNAvg,
//                 "GGNToday":data[14].GGNToday,
//                 "FBDMonth":data[14].FBDMonth,
//                 "FBDAvg":data[14].FBDAvg,
//                 "FBDToday": data[14].FBDToday,
//                 "GWLMonth":data[14].GWLMonth,
//                 "GWLAvg": data[14].GWLAvg,
//                 "GWLToday": data[14].GWLToday,
//                 "LKDMonth":data[14].LKDMonth,
//                 "LKDAvg":data[14].LKDAvg,
//                 "LKDToday": data[14].LKDToday
//               },
//               {
//                 "ProjectType": "",
//                 "ProjectTypeDetail": "TS(Litre)",
//                 "GGNMonth":data[15].GGNMonth,
//                 "GGNAvg":data[15].GGNAvg,
//                 "GGNToday":data[15].GGNToday,
//                 "FBDMonth":data[15].FBDMonth,
//                 "FBDAvg":data[15].FBDAvg,
//                 "FBDToday": data[15].FBDToday,
//                 "GWLMonth":data[15].GWLMonth,
//                 "GWLAvg": data[15].GWLAvg,
//                 "GWLToday": data[15].GWLToday,
//                 "LKDMonth":data[15].LKDMonth,
//                 "LKDAvg":data[15].LKDAvg,
//                 "LKDToday": data[15].LKDToday
//               },
//           ]; 
//     } 






























































 
