import { Component } from '@angular/core';
import { Http } from '@angular/http'
import { AuthService } from '../../_services/index';
import { LoaderService } from '../../_services/loader.service'; 
import { environment } from '../../../environments/environment';
import * as _moment from 'moment';  
import * as _rollupMoment from 'moment'; 
const moment = _rollupMoment || _moment;  
import Swal from 'sweetalert2'
 
 @Component({
  selector: 'project-dashboard',
  templateUrl: './project.component.html'
 })
 
export class ProjectComponent  {
  allCompList:any;
  showLoader:boolean;
  vehicleCountList:any;
  ggnVehCount:any;
  lkoVehCount:any;
  fbdVehCount:any;
  gwlVehCount:any;
  prmyGgnTotal:any;
  prmyGgnMaintenance:any;
  prmyGgnRunning:any;
  prmyGgnStop:any;
  secndGgnTotal:any;
  secndGgnMaintenance:any;
  secndGgnRunning:any;
  secndGgnStop:any; 
  prmyFbdTotal:any;
  prmyFbdMaintenance:any;
  prmyFbdRunning:any;
  prmyFbdStop:any;
  secndFbdTotal:any;
  secndFbdMaintenance:any;
  secndFbdRunning:any;
  secndFbdStop:any;  
  prmyLkoTotal:any;
  prmyLkoMaintenance:any;
  prmyLkoRunning:any;
  prmyLkoStop:any;
  secndLkoTotal:any;
  secndLkoMaintenance:any;
  secndLkoRunning:any;
  secndLkoStop:any;  
  prmyGwlTotal:any;
  prmyGwlMaintenance:any;
  prmyGwlRunning:any;
  prmyGwlStop:any;
  secndGwlTotal:any;
  secndGwlMaintenance:any;
  secndGwlRunning:any;
  secndGwlStop:any;
  currentDate:any; 
  currentMonth:any;
  compCountReport:any;
  public gridData: any[] 
  currentDay:any;
  mswList:any; 
  mswLkoList:any;
  attendanceList:any;
  ggnmonthData:any;
  ggnAvgdata:any;
  ggnTodayData:any;
  fbdMonthData:any;
  fbdAvgData:any;
  fbdTodayData:any;
  gwlMonthData:any;
  gwlAvgData:any;
  gwlTodayData:any;  
  lkdMonthOutData:any;
  lkdAvgOutData:any;
  lkdTodayOutData:any;
 

  constructor(private http: Http, private auth: AuthService,private loaderService: LoaderService) {
    this.loaderService.status.subscribe((val: boolean) =>{
      this.showLoader = val; 
      this.currentDate = moment(new Date()).format('DD-MM-YYYY');
      this.currentMonth = moment(new Date()).format('MMMM');
      this.currentDay=moment(new Date()).format('DD');
    }); 
   } 


   /*
    * get Current Vehicle count Details
  */
  getVehicleCoutReport(){
    this.loaderService.display(true);
     this.http.get(environment.apiUrl+'reports/getVehCountHistory').subscribe(data =>{       
     this.vehicleCountList=data.json();  
     if(this.vehicleCountList.length>0){
      this.getLkoProject();
      this.getGgnProject();
      this.getFbdProject(); 
      this.getGwlProject();
      //this.loaderService.display(false)
     }
     else{
      //this.loaderService.display(false)
     }  
    },
     error=>{ 
      //this.loaderService.display(false);
      Swal({
        type: 'error',
        title: 'Oops...',
        text: 'An Error Occurred Please Try Again',
      })
    });  
  }


/*
* Get FBD Proiject Details
*/
getLkoProject(){ 
  this.lkoVehCount=this.vehicleCountList[0].TOTAL
  this.prmyLkoTotal=this.vehicleCountList[0].PRIMARY
  this.prmyLkoMaintenance=this.vehicleCountList[0].PRIMARY_MAINTENANCE
  this.prmyLkoRunning=this.vehicleCountList[0].PRIMARY_RUNNING
  this.prmyLkoStop=this.vehicleCountList[0].PRIMARY_STOP 
  this.secndLkoTotal=this.vehicleCountList[0].SECONDARY
  this.secndLkoMaintenance=this.vehicleCountList[0].SECONDARY_MAINTENANCE
  this.secndLkoRunning=this.vehicleCountList[0].SECONDARY_RUNNING
  this.secndLkoStop=this.vehicleCountList[0].SECONDARY_STOP 
}


  /**
   * Get ggn Proiject Details
  */
  getGgnProject(){ 
    this.ggnVehCount=this.vehicleCountList[1].TOTAL
    this.prmyGgnTotal=this.vehicleCountList[1].PRIMARY
    this.prmyGgnMaintenance=this.vehicleCountList[1].PRIMARY_MAINTENANCE
    this.prmyGgnRunning=this.vehicleCountList[1].PRIMARY_RUNNING
    this.prmyGgnStop=this.vehicleCountList[1].PRIMARY_STOP 
    this.secndGgnTotal=this.vehicleCountList[1].SECONDARY
    this.secndGgnMaintenance=this.vehicleCountList[1].SECONDARY_MAINTENANCE
    this.secndGgnRunning=this.vehicleCountList[1].SECONDARY_RUNNING
    this.secndGgnStop=this.vehicleCountList[1].SECONDARY_STOP 
  }
  

/*
* Get FBD Proiject Details
*/
 getFbdProject(){ 
  this.fbdVehCount=this.vehicleCountList[2].TOTAL
  this.prmyFbdTotal=this.vehicleCountList[2].PRIMARY
  this.prmyFbdMaintenance=this.vehicleCountList[2].PRIMARY_MAINTENANCE
  this.prmyFbdRunning=this.vehicleCountList[2].PRIMARY_RUNNING
  this.prmyFbdStop=this.vehicleCountList[2].PRIMARY_STOP 
  this.secndFbdTotal=this.vehicleCountList[2].SECONDARY
  this.secndFbdMaintenance=this.vehicleCountList[2].SECONDARY_MAINTENANCE
  this.secndFbdRunning=this.vehicleCountList[2].SECONDARY_RUNNING
  this.secndFbdStop=this.vehicleCountList[2].SECONDARY_STOP 
} 

/*
* Get FBD Proiject Details
*/
getGwlProject(){ 
  this.gwlVehCount=this.vehicleCountList[3].TOTAL
  this.prmyGwlTotal=this.vehicleCountList[3].PRIMARY
  this.prmyGwlMaintenance=this.vehicleCountList[3].PRIMARY_MAINTENANCE
  this.prmyGwlRunning=this.vehicleCountList[3].PRIMARY_RUNNING
  this.prmyGwlStop=this.vehicleCountList[3].PRIMARY_STOP 
  this.secndGwlTotal=this.vehicleCountList[3].SECONDARY
  this.secndGwlMaintenance=this.vehicleCountList[3].SECONDARY_MAINTENANCE
  this.secndGwlRunning=this.vehicleCountList[3].SECONDARY_RUNNING
  this.secndGwlStop=this.vehicleCountList[3].SECONDARY_STOP 
} 

/**
 * get all Project Dashboard details
*/
getProjectDashBoardData(){
  this.http.get(environment.apiUrl+'reports/getProjectDashBoardDetail').subscribe(data =>{       
     this.allCompList=data.json();
     console.log("all Data",this.allCompList)  
     this.bindAllPrjDataData(this.allCompList);
     this.loaderService.display(false);
   });  
} 

/*
 *get MSW REPORT 
*/ 
getMswReportDetails(){
  this.http.get(environment.apiUrl+'reports/getMswReportDetails').subscribe(data =>{       
    this.mswList=data.json();  
    console.log("this.mswList",this.mswList)
    this.ggnmonthData=this.mswList[0].GGNMonth;
    this.ggnAvgdata=this.mswList[0].GGNAvg;
    this.ggnTodayData=this.mswList[0].GGNToday;
    this.fbdMonthData=this.mswList[0].FBDMonth; 
    this.fbdAvgData=this.mswList[0].FBDAvg;
    this.fbdTodayData=this.mswList[0].FBDToday;
    this.gwlMonthData=this.mswList[0].GWLMonth;
    this.gwlAvgData=this.mswList[0].GWLAvg;
    this.gwlTodayData=this.mswList[0].GWLToday ;
    this.lkdMonthOutData=this.mswList[0].LKDMonth  
    this.lkdAvgOutData=this.mswList[0].LKDAvg  
    this.lkdTodayOutData=this.mswList[0].LKDToday  
  });
}


/*
 *get MSW LKO REPORT 
*/ 
// getMswLKOReportDetails(){
//   this.http.get(environment.apiUrl+'reports/getMswLKOReportDetails').subscribe(data =>{  
//     this.mswLkoList=data.json();
//     console.log("this.mswList",this.mswLkoList)
//     this.lkdMonthData=this.mswLkoList[0].MTD  
//     this.lkdAvgData=this.mswLkoList[0].AVG  
//     this.lkdTodayData=this.mswLkoList[0].TODAY  
//     this.lkdMOnthWastData=this.mswLkoList[1].MTD  
//     this.lkdAvgWastData=this.mswLkoList[1].AVG  
//     this.lkdTodayWastData=this.mswLkoList[1].TODAY  
//     this.lkoMonthRfdData=this.mswLkoList[2].MTD  
//     this.lkoAvgRfdData=this.mswLkoList[2].AVG  
//     this.lkoTodayRfdData=this.mswLkoList[2].TODAY  
//     this.lkdMonthOutData=this.mswLkoList[3].MTD  
//     this.lkdAvgOutData=this.mswLkoList[3].AVG  
//     this.lkdTodayOutData=this.mswLkoList[3].TODAY  
//   });
// }

/**
 * get Attendance Summary Report
*/ 
getAttendanceReport(){
  this.http.get(environment.apiUrl+'attendance/getAttendanceSummaryReport').subscribe(data =>{       
    this.attendanceList=data.json(); 
  });
}

 
/*
 * Bind UCC SUMMARY REPORT
*/
bindAllPrjDataData(data){ 
  this.gridData = [
                {
                "ProjectType": "CRM",
                "ProjectTypeDetail": "Total Complaints(Toll Free)", 
                "GGNMonth":data[0].GGNMonth?data[0].GGNMonth:0,
                "GGNAvg":(data[0].GGNAvg).toFixed(2)?(data[0].GGNAvg).toFixed(2):0.00, 
                "GGNToday":data[0].GGNToday?data[0].GGNToday:0, 
                "FBDMonth":data[0].FBDMonth?data[0].FBDMonth:0,
                "FBDAvg":(data[0].FBDAvg).toFixed(2)?(data[0].FBDAvg).toFixed(2):0.00, 
                "FBDToday":(data[0].FBDToday)?(data[0].FBDToday):0,
                "GWLMonth":data[0].GWLMonth?data[0].GWLMonth:0,
                "GWLAvg":(data[0].GWLAvg).toFixed(2)?(data[0].GWLAvg).toFixed(2):0.00, 
                "GWLToday":data[0].GWLToday?data[0].GWLToday:0,
                "LKDMonth":data[0].LKDMonth?data[0].LKDMonth:0,
                "LKDAvg":(data[0].LKDAvg).toFixed(2)?(data[0].LKDAvg).toFixed(2):0.00, 
                "LKDToday":data[0].LKDToday?data[0].LKDToday:0,
                }, 
                {
                  "ProjectType": "",
                  "ProjectTypeDetail": "Total Complaints(Mobile App)", 
                  "GGNMonth":data[5].GGNMonth?data[5].GGNMonth:0,
                  "GGNAvg":(data[5].GGNAvg).toFixed(2)?(data[5].GGNAvg).toFixed(2):0.00, 
                  "GGNToday":data[5].GGNToday?data[5].GGNToday:0, 
                  "FBDMonth":data[5].FBDMonth?data[5].FBDMonth:0,
                  "FBDAvg":(data[5].FBDAvg).toFixed(2)?(data[5].FBDAvg).toFixed(2):0.00, 
                  "FBDToday":(data[5].FBDToday)?(data[5].FBDToday):0,
                  "GWLMonth":data[5].GWLMonth?data[5].GWLMonth:0,
                  "GWLAvg":(data[5].GWLAvg).toFixed(2)?(data[5].GWLAvg).toFixed(2):0.00, 
                  "GWLToday":data[5].GWLToday?data[5].GWLToday:0,
                  "LKDMonth":data[5].LKDMonth?data[5].LKDMonth:0,
                  "LKDAvg":(data[5].LKDAvg).toFixed(2)?(data[5].LKDAvg).toFixed(2):0.00, 
                  "LKDToday":data[5].LKDToday?data[5].LKDToday:0,
                  },
                {
                "ProjectType": "",
                "ProjectTypeDetail": "Pending", 
                "GGNMonth":data[1].GGNMonth?data[1].GGNMonth:0,
                "GGNAvg":(data[1].GGNAvg).toFixed(2)?(data[1].GGNAvg).toFixed(2):0.00, 
                "GGNToday":data[1].GGNToday?data[1].GGNToday:0, 
                "FBDMonth":data[1].FBDMonth?data[1].FBDMonth:0,
                "FBDAvg":(data[1].FBDAvg).toFixed(2)?(data[1].FBDAvg).toFixed(2):0.00, 
                "FBDToday":data[1].FBDToday?data[1].FBDToday:0,
                "GWLMonth":data[1].GWLMonth?data[1].GWLMonth:0,
                "GWLAvg":(data[1].GWLAvg).toFixed(2)?(data[1].GWLAvg).toFixed(2):0.00, 
                "GWLToday":data[1].GWLToday?data[1].GWLToday:0,
                "LKDMonth":data[1].LKDMonth?data[1].LKDMonth:0,
                "LKDAvg":(data[1].LKDAvg).toFixed(2)?(data[1].LKDAvg).toFixed(2):0.00, 
                "LKDToday":data[1].LKDToday?data[1].LKDToday:0,
                },
                {
                  "ProjectType": "",
                  "ProjectTypeDetail": "Resolved", 
                  "GGNMonth":data[2].GGNMonth?data[2].GGNMonth:0,
                  "GGNAvg":(data[2].GGNAvg).toFixed(2)?(data[2].GGNAvg).toFixed(2):0.00, 
                  "GGNToday":data[2].GGNToday?data[2].GGNToday:0, 
                  "FBDMonth":data[2].FBDMonth?data[2].FBDMonth:0,
                  "FBDAvg":(data[2].FBDAvg).toFixed(2)?(data[2].FBDAvg).toFixed(2):0.00, 
                  "FBDToday":(data[2].FBDToday)?(data[2].FBDToday):0,
                  "GWLMonth":data[2].GWLMonth?data[2].GWLMonth:0,
                  "GWLAvg":(data[2].GWLAvg).toFixed(2)?(data[2].GWLAvg).toFixed(2):0.00, 
                  "GWLToday":data[2].GWLToday?data[2].GWLToday:0,
                  "LKDMonth":data[2].LKDMonth?data[2].LKDMonth:0,
                  "LKDAvg":(data[2].LKDAvg).toFixed(2)?(data[2].LKDAvg).toFixed(2):0.00, 
                  "LKDToday":data[2].LKDToday?data[2].LKDToday:0,
                },
                {
                  "ProjectType": "",
                  "ProjectTypeDetail": "FeedBack", 
                  "GGNMonth":data[3].GGNMonth?data[3].GGNMonth:0,
                  "GGNAvg":(data[3].GGNAvg).toFixed(2)?(data[3].GGNAvg).toFixed(2):0.00, 
                  "GGNToday":data[3].GGNToday?data[3].GGNToday:0, 
                  "FBDMonth":data[3].FBDMonth?data[3].FBDMonth:0,
                  "FBDAvg":(data[3].FBDAvg).toFixed(2)?(data[3].FBDAvg).toFixed(2):0.00, 
                  "FBDToday":(data[3].FBDToday)?(data[3].FBDToday):0,
                  "GWLMonth":data[3].GWLMonth?data[3].GWLMonth:0,
                  "GWLAvg":(data[3].GWLAvg).toFixed(2)?(data[3].GWLAvg).toFixed(2):0.00, 
                  "GWLToday":data[3].GWLToday?data[3].GWLToday:0,
                  "LKDMonth":data[3].LKDMonth?data[3].LKDMonth:0,
                  "LKDAvg":(data[3].LKDAvg).toFixed(2)?(data[3].LKDAvg).toFixed(2):0.00, 
                  "LKDToday":data[3].LKDToday?data[3].LKDToday:0,
                  },
                  {
                    "ProjectType": "",
                    "ProjectTypeDetail": "Under Observation", 
                    "GGNMonth":data[4].GGNMonth?data[4].GGNMonth:0,
                    "GGNAvg":(data[4].GGNAvg).toFixed(2)?(data[4].GGNAvg).toFixed(2):0.00, 
                    "GGNToday":data[4].GGNToday?data[4].GGNToday:0, 
                    "FBDMonth":data[4].FBDMonth?data[4].FBDMonth:0,
                    "FBDAvg":(data[4].FBDAvg).toFixed(2)?(data[4].FBDAvg).toFixed(2):0.00, 
                    "FBDToday":(data[4].FBDToday)?(data[4].FBDToday):0,
                    "GWLMonth":data[4].GWLMonth?data[4].GWLMonth:0,
                    "GWLAvg":(data[4].GWLAvg).toFixed(2)?(data[4].GWLAvg).toFixed(2):0.00, 
                    "GWLToday":data[4].GWLToday?data[4].GWLToday:0,
                    "LKDMonth":data[4].LKDMonth?data[4].LKDMonth:0,
                    "LKDAvg":(data[4].LKDAvg).toFixed(2)?(data[4].LKDAvg).toFixed(2):0.00, 
                    "LKDToday":data[4].LKDToday?data[4].LKDToday:0,
                    },  
                     {
                      "ProjectType": "MSW",
                      "ProjectTypeDetail": "[Intake] Tonnage",
                      "GGNMonth":this.ggnmonthData?this.ggnmonthData:0,
                      "GGNAvg":this.ggnAvgdata?this.ggnAvgdata:0,
                      "GGNToday":this.ggnTodayData?this.ggnTodayData:0,
                      "FBDMonth":this.fbdMonthData?this.fbdMonthData:0,
                      "FBDAvg":this.fbdAvgData?this.fbdAvgData:0,
                      "FBDToday":this.fbdTodayData?this.fbdTodayData:0,
                      "GWLMonth":this.gwlMonthData?this.gwlMonthData:0,
                      "GWLAvg":this.gwlAvgData?this.gwlAvgData:0,
                      "GWLToday":this.gwlTodayData?this.gwlTodayData:0, 
                      "LKDMonth":this.lkdMonthOutData?this.lkdMonthOutData:0,
                      "LKDAvg":this.lkdAvgOutData?this.lkdAvgOutData:0.00,
                      "LKDToday":this.lkdTodayOutData?this.lkdTodayOutData:0,
                  }, 
                  {
                    "ProjectType": "",
                    "ProjectTypeDetail": "Excluded waste",
                    "FBDMonth":"",
                    "FBDAvg": "",
                    "FBDToday": "",
                    "GGNMonth": "",
                    "GGNAvg": "",
                    "GGNToday": "",
                    "GWLMonth": "",
                    "GWLAvg": "",
                    "GWLToday": "",
                    "LKDMonth":"",
                    "LKDAvg": "",
                    "LKDToday":"", 
                  },
                  {
              "ProjectType": "",
              "ProjectTypeDetail": "[Out] Compost Sale (Tons)",
              "FBDMonth":"",
              "FBDAvg": "",
              "FBDToday": "",
              "GGNMonth": "",
              "GGNAvg": "",
              "GGNToday": "",
              "GWLMonth": "",
              "GWLAvg": "",
              "GWLToday": "",
              "LKDMonth":"",
              "LKDAvg": "",
              "LKDToday":"", 
            },
            {
              "ProjectType": "",
                "ProjectTypeDetail": "[Out] RDF Sale (Tons)",
                "FBDMonth":"",
                "FBDAvg": "",
                "FBDToday": "",
                "GGNMonth": "",
                "GGNAvg": "",
                "GGNToday": "",
                "GWLMonth": "",
                "GWLAvg": "",
                "GWLToday": "",
                "LKDMonth":"",
                "LKDAvg": "",
                "LKDToday":"", 
              },
              {
                "ProjectType": "UCC",
                "ProjectTypeDetail": "Total Collection (Rs)", 
                "GGNMonth":data[6].GGNMonth?data[6].GGNMonth:0,
                "GGNAvg": data[6].GGNAvg?data[6].GGNAvg:0.00,
                "GGNToday": data[6].GGNToday?data[6].GGNToday:0,
                "FBDMonth":data[6].FBDMonth?data[6].FBDMonth:0,
                "FBDAvg": data[6].FBDAvg?data[6].FBDAvg:0.00,
                "FBDToday": data[6].FBDToday?data[6].FBDToday:0,
                "GWLMonth": data[6].GWLMonth?data[6].GWLMonth:0,
                "GWLAvg":  data[6].GWLAvg? data[6].GWLAvg:0.00,
                "GWLToday": data[6].GWLToday?data[6].GWLToday:0,
                "LKDMonth":data[6].LKDMonth?data[6].LKDMonth:0,
                "LKDAvg": data[6].LKDAvg?data[6].LKDAvg:0.00,
                "LKDToday": data[6].LKDToday?data[6].LKDToday:0,
                }, 
                {
                  "ProjectType": "",
                  "ProjectTypeDetail": "Total HH Touched",
                  "GGNMonth":data[7].GGNMonth?data[7].GGNMonth:0,
                  "GGNAvg": data[7].GGNAvg?data[7].GGNAvg:0.00,
                  "GGNToday": data[7].GGNToday?data[7].GGNToday:0,
                  "FBDMonth":data[7].FBDMonth?data[7].FBDMonth:0,
                  "FBDAvg": data[7].FBDAvg?data[7].FBDAvg:0.00,
                  "FBDToday": data[7].FBDToday?data[7].FBDToday:0,
                  "GWLMonth": data[7].GWLMonth?data[7].GWLMonth:0,
                  "GWLAvg":  data[7].GWLAvg?data[7].GWLAvg:0.00,
                  "GWLToday": data[7].GWLToday?data[7].GWLToday:0,
                  "LKDMonth":data[7].LKDMonth?data[7].LKDMonth:0,
                  "LKDAvg": data[7].LKDAvg?data[7].LKDAvg:0.00,
                  "LKDToday": data[7].LKDToday?data[7].LKDToday:0,
                  }, 
                {
                  "ProjectType": "KCC",
                  "ProjectTypeDetail": "Total Consumers", 
                  "GGNMonth":data[8].GGNMonth?data[8].GGNMonth:0,
                  "GGNAvg": data[8].GGNAvg?data[8].GGNAvg:0.00,
                  "GGNToday": data[8].GGNToday?data[8].GGNToday:0,
                  "FBDMonth":data[8].FBDMonth?data[8].FBDMonth:0,
                  "FBDAvg": data[8].FBDAvg?data[8].FBDAvg:0.00,
                  "FBDToday": data[8].FBDToday? data[8].FBDToday:0,
                  "GWLMonth": data[8].GWLMonth?data[8].GWLMonth:0,
                  "GWLAvg":  data[8].GWLAvg?data[8].GWLAvg:0.00,
                  "GWLToday": data[8].GWLToday?data[8].GWLToday:0,
                  "LKDMonth":data[8].LKDMonth?data[8].LKDMonth:0,
                  "LKDAvg": data[8].LKDAvg?data[8].LKDAvg:0.00,
                  "LKDToday": data[8].LKDToday?data[8].LKDToday:0,
                  }, 
                  {
                  "ProjectType": "",
                  "ProjectTypeDetail": "Consumers (Paid)",
                  "GGNMonth":data[9].GGNMonth?data[9].GGNMonth:0,
                  "GGNAvg": data[9].GGNAvg?data[9].GGNAvg:0.00,
                  "GGNToday": data[9].GGNToday?data[9].GGNToday:0,
                  "FBDMonth":data[9].FBDMonth?data[9].FBDMonth:0,
                  "FBDAvg": data[9].FBDAvg?data[9].FBDAvg:0.00,
                  "FBDToday": data[9].FBDToday?data[9].FBDToday:0,
                  "GWLMonth": data[9].GWLMonth?data[9].GWLMonth:0,
                  "GWLAvg":  data[9].GWLAvg?data[9].GWLAvg:0.00,
                  "GWLToday": data[9].GWLToday?data[9].GWLToday:0,
                  "LKDMonth":data[9].LKDMonth?data[9].LKDMonth:0,
                  "LKDAvg": data[9].LKDAvg?data[9].LKDAvg:0.00,
                  "LKDToday": data[9].LKDToday?data[9].LKDToday:0,
              },
              {
                "ProjectType": "",
                "ProjectTypeDetail": "Collection Amount(Rs)",
                "GGNMonth":data[10].GGNMonth?data[10].GGNMonth:0,
                "GGNAvg": data[10].GGNAvg?data[10].GGNAvg:0.00,
                "GGNToday": data[10].GGNToday?data[10].GGNToday:0,
                "FBDMonth":data[10].FBDMonth?data[10].FBDMonth:0,
                "FBDAvg": data[10].FBDAvg?data[10].FBDAvg:0.00,
                "FBDToday": data[10].FBDToday?data[10].FBDToday:0,
                "GWLMonth": data[10].GWLMonth?data[10].GWLMonth:0,
                "GWLAvg":  data[10].GWLAvg?data[10].GWLAvg:0.00,
                "GWLToday": data[10].GWLToday?data[10].GWLToday:0,
                "LKDMonth":data[10].LKDMonth?data[10].LKDMonth:0,
                "LKDAvg": data[10].LKDAvg?data[10].LKDAvg:0.00,
                "LKDToday": data[10].LKDToday?data[10].LKDToday:0,
            }, 
              {
              "ProjectType": "ATTENDANCE",
              "ProjectTypeDetail": "Total Employee",
              "GGNMonth":this.attendanceList[1].TOTALUSERS?this.attendanceList[1].TOTALUSERS:0,
              "GGNAvg":"-",
              "GGNToday":this.attendanceList[1].TODAYACTIVE?this.attendanceList[1].TODAYACTIVE:0,
              "FBDMonth":this.attendanceList[2].TOTALUSERS?this.attendanceList[2].TOTALUSERS:0,
              "FBDAvg": "-",
              "FBDToday":this.attendanceList[2].TODAYACTIVE?this.attendanceList[2].TODAYACTIVE:0,
              "GWLMonth": this.attendanceList[3].TOTALUSERS?this.attendanceList[3].TOTALUSERS:0,
              "GWLAvg":  "-",
              "GWLToday":this.attendanceList[3].TODAYACTIVE?this.attendanceList[3].TODAYACTIVE:0,
              "LKDMonth":this.attendanceList[0].TOTALUSERS?this.attendanceList[0].TOTALUSERS:0,
              "LKDAvg":"-",
              "LKDToday":this.attendanceList[0].TODAYACTIVE?this.attendanceList[0].TODAYACTIVE:0,
            },
            {
              "ProjectType": "FUEL PURCHASE",
              "ProjectTypeDetail": "Vehicle",
              "GGNMonth":data[11].GGNMonth,
              "GGNAvg":data[11].GGNAvg,
              "GGNToday":data[11].GGNToday,
              "FBDMonth":data[11].FBDMonth,
              "FBDAvg": data[11].FBDAvg,
              "FBDToday":data[11].FBDToday,
              "GWLMonth":data[11].GWLMonth,
              "GWLAvg": data[11].GWLAvg,
              "GWLToday":data[11].GWLToday,
              "LKDMonth": data[11].LKDMonth,
              "LKDAvg":data[11].LKDAvg,
              "LKDToday":data[11].LKDToday
            },
            {
              "ProjectType": "",
              "ProjectTypeDetail": "Loose",
              "GGNMonth":data[12].GGNMonth,
              "GGNAvg":data[12].GGNAvg,
              "GGNToday":data[12].GGNToday,
              "FBDMonth":data[12].FBDMonth,
              "FBDAvg":data[12].FBDAvg,
              "FBDToday": data[12].FBDToday,
              "GWLMonth":data[12].GWLMonth,
              "GWLAvg": data[12].GWLAvg,
              "GWLToday": data[12].GWLToday,
              "LKDMonth":data[12].LKDMonth,
              "LKDAvg":data[12].LKDAvg,
              "LKDToday": data[12].LKDToday
            },
            {
              "ProjectType": "FUEL DISTRIBUTION",
              "ProjectTypeDetail": "Vehicle(Litre)",
              "GGNMonth":data[13].GGNMonth,
              "GGNAvg":data[13].GGNAvg,
              "GGNToday":data[13].GGNToday,
              "FBDMonth":data[13].FBDMonth,
              "FBDAvg":data[13].FBDAvg,
              "FBDToday": data[13].FBDToday,
              "GWLMonth":data[13].GWLMonth,
              "GWLAvg": data[13].GWLAvg,
              "GWLToday": data[13].GWLToday,
              "LKDMonth":data[13].LKDMonth,
              "LKDAvg":data[13].LKDAvg,
              "LKDToday": data[13].LKDToday
            },
            {
              "ProjectType": "",
              "ProjectTypeDetail": "DG(Litre)",
              "GGNMonth":data[14].GGNMonth,
              "GGNAvg":data[14].GGNAvg,
              "GGNToday":data[14].GGNToday,
              "FBDMonth":data[14].FBDMonth,
              "FBDAvg":data[14].FBDAvg,
              "FBDToday": data[14].FBDToday,
              "GWLMonth":data[14].GWLMonth,
              "GWLAvg": data[14].GWLAvg,
              "GWLToday": data[14].GWLToday,
              "LKDMonth":data[14].LKDMonth,
              "LKDAvg":data[14].LKDAvg,
              "LKDToday": data[14].LKDToday
            },
            {
              "ProjectType": "",
              "ProjectTypeDetail": "TS(Litre)",
              "GGNMonth":data[15].GGNMonth,
              "GGNAvg":data[15].GGNAvg,
              "GGNToday":data[15].GGNToday,
              "FBDMonth":data[15].FBDMonth,
              "FBDAvg":data[15].FBDAvg,
              "FBDToday": data[15].FBDToday,
              "GWLMonth":data[15].GWLMonth,
              "GWLAvg": data[15].GWLAvg,
              "GWLToday": data[15].GWLToday,
              "LKDMonth":data[15].LKDMonth,
              "LKDAvg":data[15].LKDAvg,
              "LKDToday": data[15].LKDToday
            }, 
          ]; 
    }           
   ngOnInit(){ 
    this.getVehicleCoutReport();  
    this.getMswReportDetails();
    //this.getMswLKOReportDetails();
    this.getAttendanceReport();
    this.getProjectDashBoardData();
    } 
}

































































//  {
      //   "ProjectType": "MSW",
      //   "ProjectTypeDetail": "[Intake] Tonnage",
      //   "FBDMonth": 2488,
      //   "FBDAvg": 138.20,
      //   "FBDToday": 0,
      //   "GGNMonth": 4481,
      //   "GGNAvg": 248.93,
      //   "GGNToday": 0,
      //   "GWLMonth": 2304,
      //   "GWLAvg": 128.01,
      //   "GWLToday": 76,
      //   "LKDMonth": 21714,
      //   "LKDAvg": 1206.33,
      //   "LKDToday": 695,
      //   },
        // {
        //     "ProjectType": "",
        //       "ProjectTypeDetail": "[Out] Compost Sale (Tons)",
        //       "FBDMonth":"",
        //       "FBDAvg": "",
        //       "FBDToday": "",
        //       "GGNMonth": "",
        //       "GGNAvg": "",
        //       "GGNToday": "",
        //       "GWLMonth": "",
        //       "GWLAvg": "",
        //       "GWLToday": "",
        //       "LKDMonth": 234,
        //       "LKDAvg": 13.02,
        //       "LKDToday": 3,
        //     },
        //     {
        //       "ProjectType": "",
        //         "ProjectTypeDetail": "[Out] RDF Sale (Tons)",
        //         "FBDMonth":"",
        //         "FBDAvg": "",
        //         "FBDToday": "",
        //         "GGNMonth": "",
        //         "GGNAvg": "",
        //         "GGNToday": "",
        //         "GWLMonth": "",
        //         "GWLAvg": "",
        //         "GWLToday": "",
        //         "LKDMonth": 373,
        //         "LKDAvg": 20.04,
        //         "LKDToday": 0,
        //       },
        //       {
        //         "ProjectType": "",
        //           "ProjectTypeDetail": "Inert (Tons)",
        //           "FBDMonth":"",
        //           "FBDAvg": "",
        //           "FBDToday": "",
        //           "GGNMonth": "",
        //           "GGNAvg": "",
        //           "GGNToday": "",
        //           "GWLMonth": "",
        //           "GWLAvg": "",
        //           "GWLToday": "",
        //           "LKDMonth": 234,
        //           "LKDAvg": 13.02,
        //           "LKDToday": 3,
        //         },
        //         {
        //             "ProjectType": "Vehicles",
        //             "ProjectTypeDetail": "Total",
        //             "FBDMonth":168,
        //             "FBDAvg": 0.00,
        //             "FBDToday": 168,
        //             "GGNMonth": 276,
        //             "GGNAvg": 0.00,
        //             "GGNToday": 276,
        //             "GWLMonth": 651,
        //             "GWLAvg": 0.00,
        //             "GWLToday": 651,
        //             "LKDMonth": 137,
        //             "LKDAvg": 0.00,
        //             "LKDToday": 137,
        //           },
        //           {
        //             "ProjectType": "",
        //             "ProjectTypeDetail": "Working",
        //             "FBDMonth":159,
        //             "FBDAvg": 0.00,
        //             "FBDToday": 159,
        //             "GGNMonth": 135,
        //             "GGNAvg": 0.00,
        //             "GGNToday": 112,
        //             "GWLMonth": 534,
        //             "GWLAvg": 0.00,
        //             "GWLToday": 534,
        //             "LKDMonth": 135,
        //             "LKDAvg": 0.00,
        //             "LKDToday": 135,
        //           },
        //           {
        //             "ProjectType": "",
        //             "ProjectTypeDetail": "Primary Distance Travelled (Kms)",
        //             "FBDMonth":"",
        //           "FBDAvg": "",
        //           "FBDToday": "",
        //           "GGNMonth": "",
        //           "GGNAvg": "",
        //           "GGNToday": "",
        //           "GWLMonth": "",
        //           "GWLAvg": "",
        //           "GWLToday": "",
        //           "LKDMonth": "",
        //           "LKDAvg": "",
        //           "LKDToday": "",
        //           },
        //           {
        //             "ProjectType": "",
        //             "ProjectTypeDetail": "Secondary Distance Travelled (Kms)",
        //             "FBDMonth":"",
        //           "FBDAvg": "",
        //           "FBDToday": "",
        //           "GGNMonth": "",
        //           "GGNAvg": "",
        //           "GGNToday": "",
        //           "GWLMonth": "",
        //           "GWLAvg": "",
        //           "GWLToday": "",
        //           "LKDMonth": "",
        //           "LKDAvg": "",
        //           "LKDToday": "",
        //           },
        //           {
        //             "ProjectType": "UCC/KCC",
        //             "ProjectTypeDetail": "Total Collection (Rs)",
        //             "FBDMonth":"NULL",
        //           "FBDAvg": "NULL",
        //           "FBDToday": "NULL",
        //           "GGNMonth": 803.139,
        //           "GGNAvg": "NULL",
        //           "GGNToday": "NULL",
        //           "GWLMonth": "",
        //           "GWLAvg": "",
        //           "GWLToday": "",
        //           "LKDMonth": 104040,
        //           "LKDAvg": 52020.00,
        //           "LKDToday": 54580,
        //           },
        //           {
        //             "ProjectType": "",
        //             "ProjectTypeDetail": "Total hh tOUCHED",
        //             "FBDMonth":"NULL",
        //           "FBDAvg": "NULL",
        //           "FBDToday": "NULL",
        //           "GGNMonth": 20.547,
        //           "GGNAvg": "NULL",
        //           "GGNToday": "NULL",
        //           "GWLMonth": "",
        //           "GWLAvg": "",
        //           "GWLToday": "",
        //           "LKDMonth": 665,
        //           "LKDAvg": 332.00,
        //           "LKDToday": 382,
        //           },
        //           {
        //             "ProjectType": "",
        //             "ProjectTypeDetail": "Total Staff",
        //             "FBDMonth":"",
        //           "FBDAvg": "",
        //           "FBDToday": "",
        //           "GGNMonth":"",
        //           "GGNAvg": "NULL",
        //           "GGNToday": "NULL",
        //           "GWLMonth": "",
        //           "GWLAvg": "",
        //           "GWLToday": "",
        //           "LKDMonth": 34,
        //           "LKDAvg": 17.00,
        //           "LKDToday": 27,
        //           },
        //           {
        //             "ProjectType": "Fuel Purchase",
        //             "ProjectTypeDetail": "Lit",
        //             "FBDMonth":"",
        //           "FBDAvg": "",
        //           "FBDToday": "",
        //           "GGNMonth":13797,
        //           "GGNAvg": 766.49,
        //           "GGNToday":298,
        //           "GWLMonth": "",
        //           "GWLAvg": "",
        //           "GWLToday": "",
        //           "LKDMonth": 40720,
        //           "LKDAvg": 2262.23,
        //           "LKDToday": 1877,
        //           },
        //           {
        //             "ProjectType": "",
        //             "ProjectTypeDetail": "Cost (Rs)",
        //             "FBDMonth":"",
        //           "FBDAvg": "",
        //           "FBDToday": "",
        //           "GGNMonth":1005632,
        //           "GGNAvg": 55868.44,
        //           "GGNToday":20686,
        //           "GWLMonth": "",
        //           "GWLAvg": "",
        //           "GWLToday": "",
        //           "LKDMonth": 2778892,
        //           "LKDAvg": 154382.89,
        //           "LKDToday": 128599,
        //           },
        //           {
        //             "ProjectType": "",
        //             "ProjectTypeDetail": "Mileage",
        //             "FBDMonth":"",
        //           "FBDAvg": "",
        //           "FBDToday": "",
        //           "GGNMonth":"",
        //           "GGNAvg": "",
        //           "GGNToday":"",
        //           "GWLMonth": "",
        //           "GWLAvg": "",
        //           "GWLToday": "",
        //           "LKDMonth": "",
        //           "LKDAvg": "",
        //           "LKDToday": "",
        //           },
        //           {
        //             "ProjectType": "Manpower",
        //             "ProjectTypeDetail": "Offline",
        //             "FBDMonth":"",
        //           "FBDAvg": "",
        //           "FBDToday": "",
        //           "GGNMonth":"",
        //           "GGNAvg": "",
        //           "GGNToday":"",
        //           "GWLMonth": "",
        //           "GWLAvg": "",
        //           "GWLToday": "",
        //           "LKDMonth": "",
        //           "LKDAvg": "",
        //           "LKDToday": "",
        //           },
        //           {
        //             "ProjectType": "",
        //             "ProjectTypeDetail": "Online",
        //             "FBDMonth":"",
        //           "FBDAvg": "",
        //           "FBDToday": "",
        //           "GGNMonth":"",
        //           "GGNAvg": "",
        //           "GGNToday":"",
        //           "GWLMonth": "",
        //           "GWLAvg": "",
        //           "GWLToday": "",
        //           "LKDMonth": "",
        //           "LKDAvg": "",
        //           "LKDToday": "",
        //           },
        //           {
        //           "ProjectType": "CRM",
        //           "ProjectTypeDetail": "Total Complaints",
        //           "FBDMonth":54,
        //           "FBDAvg": 2.00,
        //           "FBDToday": 3,
        //           "GGNMonth":"",
        //           "GGNAvg": "",
        //           "GGNToday":"",
        //           "GWLMonth": 32,
        //           "GWLAvg": 1.00,
        //           "GWLToday": 4,
        //           "LKDMonth": 100,
        //           "LKDAvg": 5.00,
        //           "LKDToday": 0,
        //           },
        //           {
        //             "ProjectType": "",
        //             "ProjectTypeDetail": "Pending",
        //             "FBDMonth":21,
        //           "FBDAvg": 1.00,
        //           "FBDToday": 3,
        //           "GGNMonth":"",
        //           "GGNAvg": "",
        //           "GGNToday":"",
        //           "GWLMonth": 6,
        //           "GWLAvg": 0.00,
        //           "GWLToday": 4,
        //           "LKDMonth": 78,
        //           "LKDAvg": 5.00,
        //           "LKDToday": 0,
        //           },
        //           {
        //             "ProjectType": "",
        //             "ProjectTypeDetail": "Resolved",
        //             "FBDMonth":33,
        //           "FBDAvg": 1.00,
        //           "FBDToday": 0,
        //           "GGNMonth":"",
        //           "GGNAvg": "",
        //           "GGNToday":"",
        //           "GWLMonth": 26,
        //           "GWLAvg": 1.00,
        //           "GWLToday": 0,
        //           "LKDMonth": 22,
        //           "LKDAvg": 1.00,
        //           "LKDToday": 0,
        //           }
