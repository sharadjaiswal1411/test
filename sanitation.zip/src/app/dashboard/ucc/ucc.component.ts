



import { Component  } from '@angular/core';
import { Http } from '@angular/http'
import { environment } from '../../../environments/environment';
import { AuthService } from '../../_services'; 
import { LoaderService } from '../../_services/loader.service'; 
import * as _moment from 'moment';  
import * as _rollupMoment from 'moment'; 
const moment = _rollupMoment || _moment; 
declare var $: any; 

@Component({
  selector: 'app-ucc',
  templateUrl: './ucc.component.html',
  styleUrls: ['./ucc.component.css']
})
export class UccComponent  {
showLoader:boolean 
prjId:any; 
zoneList:any;
totalAchievedCount:any;
totalTargetCount:any
totalTodayCount:any
totalAchievedAmount:any;
totalTargetAmount:any;
totalTodayAmount:any; 
totalCount:any
totalAmount:any;
dataTarget:any;
totalAchievedCountPrct:any;
totalAchievedAmountPrct:any;
reportLevel:any;
zoneId:any;
selectedEntity:any;
category:any
totalAchievedCountPrevDay:any;
totalAchievedAmountPrevDay:any;
totalAchievedCountPrevMonth:any;
totalAchievedAmountPrevMonth:any;
totalAchievedCountPrctPrevMonth:any;
totalAchievedAmountPrctPrevMonth:any; 
currentdate:any;
defStartDate:any;
defEndDate:any;
constructor(private http: Http, private auth: AuthService,private loaderService: LoaderService) {
  this.zoneList = [] 
  this.category = "ZONENAME"
  this.reportLevel = "zone"
  this.zoneId = null
  this.loaderService.status.subscribe((val: boolean) =>{
    this.showLoader = val; 
  });  
  var firstDay = new Date(new Date().getFullYear(), new Date().getMonth(), 1); 
  this.defStartDate = firstDay.getDate() + '-' + (firstDay.getMonth() + 1) + '-' + firstDay.getFullYear();  
  this.defEndDate = (new Date().getDate()) + '-' + (new Date().getMonth()+1) + '-' + new Date().getFullYear(); 
  console.log("startDate",this.defStartDate,'endDate',this.defEndDate)
}


getUccTargetData(prjId){
  this.loaderService.display(true);
  var date = new Date();
  var month = date.getMonth() + 1
  var obj = {
    prjId:prjId,
    reportLevel:this.reportLevel,
    zoneId:this.zoneId,
    wardId:null,
    beatId:null,
    targetMonth:month,
    targetYear:2018,
    fromDate:null,
    toDate:null,
    reportType:"household"
  }
  this.http.post(environment.apiUrl + 'reports/uccTarget',obj).subscribe(data =>{ 
     var dataTarget = data.json()
     this.dataTarget = dataTarget
     console.log("data",dataTarget)
     this.aggregateTotal()
     this.loaderService.display(false);
 }); 
} 
public onSeriesClick(e): void {
  // access e.dataItem.url of the bound item; use window.location or router from there
   if(e.category && this.reportLevel == "zone"){
     this.selectedEntity = e.category
     this.zoneId = e.dataItem.ZONEID
     this.reportLevel = "ward"
     this.category = "WARDNAME"
     this.dataTarget = []
     this.getUccTargetData(this.prjId)
   }
   console.log(e)
}


  resetChart(){
    this.dataTarget = []
    this.zoneId = null
    this.reportLevel = "zone"
    this.category = "ZONENAME"
    this.selectedEntity = null
    this.getUccTargetData(this.prjId)
  }
  aggregateTotal(){
    var data =  this.dataTarget
    this.totalAchievedCount = 0
    this.totalTargetCount = 0
    this.totalTodayCount = 0
    this.totalAchievedAmount = 0
    this.totalTargetAmount = 0
    this.totalTodayAmount = 0
    this.totalAchievedCountPrevDay = 0
    this.totalAchievedAmountPrevDay = 0
    this.totalAchievedCountPrevMonth = 0
    this.totalAchievedAmountPrevMonth = 0
     for(var i= 0;i<data.length;i++){
      this.totalAchievedCount = this.totalAchievedCount +  data[i].AchievedCount;
      if(data[i].AchievedCount>0 && data[i].TargetCount>0){
        data[i].achievedCountPrct =  ((100 * data[i].AchievedCount)/ data[i].TargetCount) + '%'
        data[i].CountPrct =  ((100 * data[i].AchievedCount)/ data[i].TargetCount)/100
      }else{
        data[i].achievedCountPrct =  0 + '%'
        data[i].CountPrct = 0
      }
    
       if(data[i].AchivedAmount>0){
        data[i].AmountPrct =  ((100 * data[i].AchievedAmount)/ data[i].TargetAmount)/100
        data[i].achievedAmountPrct =  ((100 * data[i].AchivedAmount)/ data[i].TargetAmount) + '%'
       }else{
        data[i].AmountPrct = 0
        data[i].achievedAmountPrct = 0 + '%'
       }
       
      this.totalAchievedCountPrevDay = this.totalAchievedCountPrevDay +  data[i].AchivedCountYesterday;
      this.totalTargetCount = this.totalTargetCount +  data[i].TargetCount;
      this.totalTodayCount = this.totalTodayCount +  data[i].AchivedCountToday;
      this.totalAchievedCountPrevMonth = this.totalAchievedCountPrevMonth + data[i].AchievedCountPrevMonth


      this.totalAchievedAmount = this.totalAchievedAmount +  data[i].AchivedAmount;
      this.totalAchievedAmountPrevDay = this.totalAchievedAmountPrevDay +  data[i].AchivedAmountYesterday;
      this.totalTargetAmount = this.totalTargetAmount +  data[i].TargetAmount;
      this.totalTodayAmount = this.totalTodayAmount +  data[i].AchivedAmountToday; 
      this.totalAchievedAmountPrevMonth = this.totalAchievedAmountPrevMonth + data[i].AchivedAmountPrevMonth
     }
     
     this.totalAchievedCountPrct = ((100 *this.totalAchievedCount)/this.totalTargetCount)/100
     this.totalAchievedCountPrctPrevMonth = ((100 *this.totalAchievedCountPrevMonth)/this.totalTargetCount)/100

     this.totalAchievedAmountPrct = ((100 *this.totalAchievedAmount)/this.totalTargetAmount)/100

     this.totalAchievedAmountPrctPrevMonth = ((100 *this.totalAchievedAmountPrevMonth)/this.totalTargetAmount)/100

     this.dataTarget = data
  }

  
  ngOnInit() {
      this.selectedEntity = null
      this.prjId = this.auth.getAuthentication().projectId
      this.getUccTargetData(this.prjId)

      
  }
 }


