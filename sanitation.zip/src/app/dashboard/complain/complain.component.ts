import { Component} from '@angular/core'; 
import { Http } from '@angular/http' 
import { environment } from '../../../environments/environment'; 
import { DateAdapter, MAT_DATE_FORMATS, MAT_DATE_LOCALE } from '@angular/material/core';
import { MomentDateAdapter } from '@angular/material-moment-adapter'; 
import { utils, write, WorkBook } from 'xlsx';  
import { saveAs } from 'file-saver';
import { AuthService } from '../../_services';
import { process, State,aggregateBy} from '@progress/kendo-data-query'; 
import { GroupDescriptor, DataResult } from '@progress/kendo-data-query';
import { Observable } from 'rxjs/Observable';
import { SelectableSettings,DataStateChangeEvent,GridDataResult} from '@progress/kendo-angular-grid'; 
import { LoaderService } from '../../_services/loader.service';
import Swal from 'sweetalert2'
import * as _moment from 'moment';
import * as _rollupMoment from 'moment';
const moment = _rollupMoment || _moment;

const distinctZone = data => data.filter((x, idx, xs) => xs.findIndex(y => y.zone === x.zone) === idx); 
const distinctWard = data => data.filter((x, idx, xs) => xs.findIndex(y => y.ward === x.ward) === idx); 
export const MY_FORMATS = {
  parse: {
    dateInput: 'LL',
  },
  display: {
    dateInput: 'LL',
    monthYearLabel: 'MMM YYYY',
    dateA11yLabel: 'LL',
    monthYearA11yLabel: 'MMMM YYYY',
  },
};
@Component({
  selector: 'complain-DashBoard',
  templateUrl: './complain.component.html', 
  providers: [
    { provide: DateAdapter, useClass: MomentDateAdapter, deps: [MAT_DATE_LOCALE] },
    { provide: MAT_DATE_FORMATS, useValue: MY_FORMATS },
  ], 
}) 


export class ComplainDashBoardComponent {  
  labelContent:any
  public netWeight = 0
  public totalCNT = 0
  public total=0
  public totalPending=0
  public totalResolved=0
  public prjcd:any
  public totalToday=0
  public totalPendingToday=0
  public totalResolvedToday=0
  public totalMTD=0
  public totalPendingMTD=0
  public totalResolvedMTD=0
  public startDateMTD:any
  public todayFeedBack=0
  public todayObser=0
  public today:any
  complainData: any
  complainDataList:any;
  defaultStartDate:any
  defaultEndDate:any
  dateRangeModal:any
  public todayData: any
  public customData:any
  public mtdData:any  
  prjId:any; 
  totalComplain:any; 
  todayTotal:any;
  totPending:any;
  totResolved:any;
  public totalCustFeedBack=0;
  public totalCustUnderOb=0;
  complainChartList:any;
  public startDate:any;
  public endDate:any;
  dataNotFound=false;
  chartNotFound=false;
  public showLoader: boolean
  customDataNotFound=false;
  customChartNotFound=false
  custMtdFeedBack=0
  custMtdUnderObser=0
  public aggregates: any[] = [{field: 'Total', aggregate: 'sum'},{field: 'Today', aggregate: 'sum'},{field: 'Pending', aggregate: 'sum'},{field: 'Resolved', aggregate: 'sum'},{field: 'FeedBack', aggregate: 'sum'},{field: 'UnderObservation', aggregate: 'sum'}];
  public state: State = {  
    filter: {
      logic: 'and',
      filters: []
    }
  };
  public pageSize :any
  public checkboxOnly = false;
  public mode = 'multiple';
  public selectableSettings: SelectableSettings; 
  public groups: GroupDescriptor[] = [];
  public view: Observable<GridDataResult>;  
  public gridDataComplainReport: DataResult;
  public groupChange(groups: GroupDescriptor[]): void {
    this.groups = groups;
    this.loadProducts();
  } 
  public distinctZone: any[]
  public distinctWard: any[]
  public complainTypeData :any
  public complainZoneWiseData :any
  public complainMonthWiseData :any
  private loadProducts(): void {
    this.gridDataComplainReport = process(this.complainData, { group: this.groups });  
  }
   constructor(private http: Http,private auth : AuthService,private loaderService: LoaderService) { 
    this.loaderService.status.subscribe((val: boolean) =>{
      this.showLoader = val;
    }); 
    var date = new Date();
    var firstDay = new Date(date.getFullYear(), date.getMonth(), 1); 
    this.defaultStartDate = (firstDay.getFullYear()) + '-' + (firstDay.getMonth() + 1) + '-' + firstDay.getDate(); 
    this.defaultEndDate = (date.getFullYear()) + '-' + (date.getMonth()+1) + '-' + date.getDate(); 
    this.dateRangeModal= {beginDate: {year: firstDay.getFullYear(), month: firstDay.getMonth()+1, day: firstDay.getDate()}, endDate: {year: date.getFullYear(), month: date.getMonth()+1, day: date.getDate()}};
    this.startDateMTD = (firstDay.getFullYear()) + '-' + (firstDay.getMonth() + 1) + '-' + firstDay.getDate(); 
    this.today =  (date.getFullYear()) + '-' + (date.getMonth()+1) + '-' + date.getDate(); 
   }

  ngOnInit(): void { 
    var ss=window.location.pathname.split("/")
    this.prjcd=ss[2] 
    this.prjId = this.auth.getAuthentication().projectId  
    this.bindComplainResults("web")
    this.bindTodayCount("web")  
    this.getComplainChartData(); 
    this.complainCountByType();
    this.complainCountZoneWise();
    this.complainCountMonthWise();
  }

   
/*
 * Bind All complain Chart
*/ 
bindComplainResults(type) { 
  let stdate = moment(this.defaultStartDate).format('YYYY-MM-DD');
  let enddate = moment(this.defaultEndDate).format('YYYY-MM-DD');  
  if(type == "web"){
  this.http.get(environment.apiUrl + "reports/getComplainDashBoardSummary?reportType="+type+"&prjId=" + this.prjId +"&frdt=" + stdate + "&todt=" + enddate).subscribe(data => {
    this.complainData = data.json() 
    this.distinctZone=distinctZone(this.complainData)
    this.distinctWard=distinctWard(this.complainData)
    this.totalComplain = aggregateBy(this.complainData, this.aggregates)["Total"].sum;  
    this.todayTotal = aggregateBy(this.complainData, this.aggregates)["Today"].sum; 
    this.totPending = aggregateBy(this.complainData, this.aggregates)["Pending"].sum; 
    this.totResolved = aggregateBy(this.complainData, this.aggregates)["Resolved"].sum; 
    this.custMtdFeedBack=aggregateBy(this.complainData, this.aggregates)["FeedBack"].sum;
    this.custMtdUnderObser=aggregateBy(this.complainData, this.aggregates)["UnderObservation"].sum;
    this.gridDataComplainReport = process(this.complainData, this.state); 
    var total = 0
    var totalResolved = 0
    var totalPending = 0
    var totalFeedBack = 0
    var totalObs = 0 
    var cnt = 0
    this.complainData.forEach(element => {
      total += Number(element.Total)
      totalPending += Number(element.Pending)
      totalResolved += Number(element.Resolved)
      totalFeedBack += Number(element.FeedBack)
      totalObs += Number(element.UnderObservation)
      cnt += 1;
    });
    this.total = total 
    this.totalPending=totalPending
    this.totalResolved=totalResolved   
    this.custMtdFeedBack=totalFeedBack
    this.custMtdUnderObser=totalObs
    this.totalCNT = cnt
    if(this.total>0 || this.totalPending>0 || this.totalResolved>0){
      this.customChartNotFound=true
      this.customData = [
        { category: 'Total', value: this.total },
        { category: 'Pending', value: this.totalPending },
        { category: 'Resolved', value: this.totalResolved },
        { category: 'FeedBack', value: this.custMtdFeedBack },
        { category: 'UnderObservation', value: this.custMtdUnderObser }
      ]
    }
    else{
      this.customDataNotFound=true;
    } 
  }); 
}
// else 
// { 
//   alert('Alert')
//   window.open(environment.apiUrl + "reports/getComplainDashBoardSummary?prjid="+this.prjId+"&reportType=" + type +"&frdt=" + stdate + "&todt=" + enddate);
// } 
} 
/*
 * filter The Grid Data
*/
public dataStateChange(state: DataStateChangeEvent): void {
  this.state = state;
  this.gridDataComplainReport = process(this.complainData, this.state);  
  if (state && state.group) { 
    this.distinctZone=distinctZone(this.complainData)
    this.distinctWard=distinctWard(this.complainData)
    this.gridDataComplainReport = process(this.complainData, this.state); 
    this.totalComplain = aggregateBy(this.gridDataComplainReport.data, this.aggregates)["Total"].sum; 
    this.todayTotal = aggregateBy(this.complainData, this.aggregates)["Today"].sum; 
    this.totPending = aggregateBy(this.gridDataComplainReport.data, this.aggregates)["Pending"].sum; 
    this.totResolved = aggregateBy(this.gridDataComplainReport.data, this.aggregates)["Resolved"].sum;  
    } 
} 

/*
 * bind Today Data
*/ 
bindTodayCount(type) {
  let stdate = moment(this.startDateMTD).format('YYYY-MM-DD'); 
  let enddate = moment(this.today).format('YYYY-MM-DD'); 
  this.http.get(environment.apiUrl + "reports/getComplainDashBoardSummary?reportType=" +type +"&prjId="+this.prjId +"&frdt=" + enddate + "&todt=" + enddate).subscribe(data => {
    var complainData = data.json();   
    var total = 0
    var totalResolved = 0
    var totalPending = 0
    var todayFeedBack=0;
    var todayObs=0;
    var cnt = 0
      complainData.forEach(element => {
      total += Number(element.Total)
      totalPending += Number(element.Pending)
      totalResolved += Number(element.Resolved)
      todayFeedBack += Number(element.FeedBack)
      todayObs += Number(element.UnderObservation)
      cnt += 1;
    });
    this.totalToday = total
    this.totalPendingToday = totalPending
    this.totalResolvedToday = totalResolved
    this.todayFeedBack = todayFeedBack
    this.todayObser = todayObs
    this.totalCNT = cnt 
    if(this.totalToday>0 || this.totalPendingToday>0 || this.totalResolvedToday>0){
      this.chartNotFound=true
      this.todayData = [
        { category: 'Total', value: this.totalToday },
        { category: 'Pending', value: this.totalPendingToday },
        { category: 'Resolved', value: this.totalResolvedToday },
        { category: 'FeedBack', value: this.todayFeedBack },
        { category: 'UnderObservation', value: this.todayObser}
        ] 
       } 
     else{ 
        this.dataNotFound=true; 
      }
  }); 
  // this.http.get(environment.apiUrl + "reports/getComplainDashBoardSummary?reportType=" +type +"&prjId="+this.prjId +"&frdt=" + stdate + "&todt=" + enddate).subscribe(data => {
  //  this.complainData = data.json()  
  //  this.gridDataComplainReport = process(this.complainData, this.state); 
  //   var total = 0
  //   var totalResolved = 0
  //   var totalPending = 0
  //   var totalcustFeedBack=0;
  //   var totalcustObs=0;
  //   var cnt = 0
  //   this.complainData.forEach(element => {
  //     total += Number(element.Total)
  //     totalPending += Number(element.Pending)
  //     totalResolved += Number(element.Resolved)
  //     totalcustFeedBack += Number(element.FeedBack)
  //     totalcustObs += Number(element.UnderObservation)
  //     cnt += 1;
  //   });
  //   this.totalMTD = total
  //   this.totalPendingMTD = totalPending
  //   this.totalResolvedMTD = totalResolved
  //   this.totalCustFeedBack = totalcustFeedBack
  //   this.totalCustUnderOb = totalcustObs
  //   this.totalCNT = cnt
  //   if(this.totalMTD>0 ||this.totalPendingMTD>0 || this.totalResolvedMTD>0){
  //     this.mtdData = [
  //       { category: 'Total', value: this.totalMTD },
  //       { category: 'Pending', value: this.totalPendingMTD },
  //       { category: 'Resolved', value: this.totalResolvedMTD },
  //       { category: 'FeedBack', value: this.totalCustFeedBack },
  //       { category: 'UnderObservation', value: this.totalCustUnderOb}
  //     ] 
  //   }else{ 
  //     this.customDataNotFound=true; 
  //   }
  // }); 
} 



/**
 * Filter Data details
*/
  onDateRangeChanged(dateRange){  
    if(dateRange.beginDate.day>0){ 
      this.defaultStartDate= dateRange.beginDate.year + "-"  + dateRange.beginDate.month+ "-" + dateRange.beginDate.day 
      this.defaultEndDate = dateRange.endDate.year + "-"  + dateRange.endDate.month  + "-" + dateRange.endDate.day 
      this.bindComplainResults("web") ;
    }else if(dateRange.beginDate.day==0){
      this.defaultStartDate= this.defaultStartDate
      this.defaultEndDate = this.defaultEndDate
      this.bindComplainResults("web") ;
    } 
  } 

   
/*
 * get Complain Chart data
*/
  getComplainChartData(){ 
    this.loaderService.display(true); 
      this.http.get(environment.apiUrl + 'reports/getComplainChartData?prjId='+this.prjId).subscribe(data =>{ 
      this.complainChartList = data.json()
      if(this.complainChartList.length>0){
        this.loaderService.display(false);
      }}, 
      error=>{ 
        this.loaderService.display(false);
        Swal({
          type: 'error',
          title: 'Oops...',
          text: 'An Error Occurred Please Try Again',
        })
      });  
  } 


/*
 * get Complain Chart Zone Wise
*/
  complainCountByType(){
    this.http.get(environment.apiUrl + 'reports/complainCountByType?prjId='+this.prjId).subscribe(data =>{ 
      this.complainTypeData = data.json()
      if(this.complainChartList.length>0){
        this.loaderService.display(false);
      }}, 
      error=>{ 
        this.loaderService.display(false);
        Swal({
          type: 'error',
          title: 'Oops...',
          text: 'An Error Occurred Please Try Again',
        })
      });  
  }

  
/*
 * get Complain Chart Zone Wise
*/
complainCountZoneWise(){
  this.http.get(environment.apiUrl + 'reports/complainCountZoneWise?prjId='+this.prjId).subscribe(data =>{ 
    this.complainZoneWiseData = data.json()  
    if(this.complainChartList.length>0){
      this.loaderService.display(false);
    }}, 
    error=>{ 
      this.loaderService.display(false);
      Swal({
        type: 'error',
        title: 'Oops...',
        text: 'An Error Occurred Please Try Again',
      })
    });  
}



/*
 * get Complain Chart Zone Wise
*/
complainCountMonthWise(){
  this.http.get(environment.apiUrl + 'reports/complainCountMonthWise?prjId='+this.prjId).subscribe(data =>{ 
    this.complainMonthWiseData = data.json()  
    if(this.complainChartList.length>0){
      this.loaderService.display(false);
    }}, 
    error=>{ 
      this.loaderService.display(false);
      Swal({
        type: 'error',
        title: 'Oops...',
        text: 'An Error Occurred Please Try Again',
      })
    });  
}




}








