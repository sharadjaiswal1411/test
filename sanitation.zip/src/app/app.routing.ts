  
import { NgModule } from '@angular/core';
import { CommonModule, } from '@angular/common';
import { BrowserModule  } from '@angular/platform-browser';
import { Routes, RouterModule } from '@angular/router';
import { AuthGuard } from './_guards';
import { LoginComponent } from './login/login.component';
import { HomeComponent } from './home/home.component';
import { DashboardComponent } from './dashboard/dashboard.component';

import { UccComponent } from './dashboard/ucc/ucc.component';  

import { AlarmComponent } from './alarm/alarm.component'

import { AlarmFuelComponent } from './alarm/alarmFuel/alarmFuel.component'
import { FuelAlertComponent } from './alarm/fuelAlert/fuelAlert.component'

import { AlarmSummaryComponent } from './alarm/alarmSummary/alarmSummary.component'

//KCC
import {KccComponent} from './crm/kcc/kcc.component';
import {ComplainComponent} from './crm/complain/complain.component';
import {ProjectComponent} from './dashboard/project/project.component';

 import {ComplainDashBoardComponent} from './dashboard/complain/complain.component';
 import {TargetDashBoardComponent} from './dashboard/target/targetDashboard.component';

import { ReportsComponent } from './reports/reports.component';

import {StopComponent} from './maptracker/stop/stop.component';
import { MaptrackerComponent } from './maptracker/maptracker.component';
import { AreaComponent } from './maptracker/area/area.component';
import { BeatComponent } from './maptracker/area/beat.component';


import { VehiclesComponent } from './maptracker/vehicles/vehicles.component';
import {mcgVehiclesComponent} from './maptracker/vehicles/mcgVehicles.component';
import {SecondaryOpsComponent} from './maptracker/vehicles/secondaryOps.component';
//import { KccComponent } from './maptracker/kcc/kcc.component';




import { AdminComponent } from './admin/admin.component';
import { EmployeeComponent } from './admin/employee/empMngt/employee.component';
import { EmpComponent } from './admin/employee/emp.component'; 
import { SuperAdminComponent } from './superAdmin/superAdmin.component';
import { ServerMonitoring } from './superAdmin/users/serverMonitoring.component'; 
import { UsersComponent } from './superAdmin/users/users.component';
//for admin
//import{vehicleComponent} from './admin/employee/vehicles/vehicles.component';
import{EntityComponent} from './admin/entity/entityMngt/entity.component';
import { EntityMapComponent } from  './admin/entity/entityMapping/entityMap.component';
import { EntComponent } from  './admin/entity/ent.component';
import { HrmsComponent } from  './admin/hrms/hrms.component';
import { HrmsEmployeeComponent } from  './admin/hrms/hrmsMnt/hrmsEmployee.component';

import { TargetComponent } from  './admin/target/target.component'
import { TargetMasterComponent } from  './admin/target/targetMaster/targetMaster.component'
//Khatta Component

//import{newVehiclesComponent} from './admin/employee/newVehicles/newVehicles.component';
//import{addNewVehiclesComponent} from './admin/user/vehicles/addVehicles/addVehicles.componont'
import { AddNewVehiclesComponent  } from './admin/vehicles/vehicleMngt/vehicles.AddNewVehicles';
import { VehicleComponent } from './admin/vehicles/vehicleMngt/vehicles.component';
import { VehComponent  } from './admin/vehicles/veh.component';

 
//Report 

import { UccReportsComponent } from './reports/uccReport/uccReport.Component'; 
import { BulkCollectionReportComponent } from './reports/uccReport/bulkCollectionReport.Component';
import { CollectionAnalysisReport } from './reports/uccReport/collectionAnalysisReport.Component';

import { CollectionSummaryComponent } from './reports/uccReport/collectionSummaryReport.Component';
// CRM
import { CRMComponent} from './crm/crm.component';
import { EntitySummaryReportComponent} from './reports/entityReport/entitySummaryReport.component';

// consumer
import { ConsumerListComponent} from './crm/kcc/consumer/consumerList/consumerList.component';
// invoice

//invoiceList
import { InvoiceListComponent} from './crm/kcc/invoice/invoiceList/invoiceList.component';
import { CreateInvoiceComponent} from './crm/kcc/invoice/createInvoice/createInvoice.component';               
   
import { ComplainListComponent} from './crm/complain/complainList/complainList.component'; 



import { PaymentListComponent} from './crm/kcc/payment/paymentList/paymentList.component';

//import { ConsumerUccListComponent} from 'app/crm/ucc/uccList/uccList.component'; 


//KCC Report
import { KccReportsComponent } from './reports/kccReport/kccReport.component';
import { KccSummaryReportComponent} from './reports/kccReport/kccSummaryReport.component';
import { KccCustomerReportComponent} from './reports/kccReport/kccCustomerReport.component';
import { KccDetailReportComponent} from './reports/kccReport/kccDetailReport.component';

//Maintenance
import {VehicleMaintenanceComponent} from './maintenance/vehicleMaintenance/vehicleMnt/vehicleMaintenance.component'; 
//import {MaintMntComponent} from './maintenance/maintMaster/maintMnt.component';
//import {VehMaintenanceMasterComponent} from './maintenance/maintMaster/master/maintenanceMaster.component';
import {MaintenanceComponent} from './maintenance/maintenance.component';
import {LogbookComponent} from './maintenance/vehicleMaintenance/vehicleMnt/logbook.component'; 
import {VehicleMaintMntComponent} from './maintenance/vehicleMaintenance/vehicleMnt.component'; 

import { KccConsolidatedReportComponent} from './reports/kccReport/kccConsolidatedReport.component';

import {EntitysComponent} from './reports/entityReport/entity.component';
/*
   ucc old route
*/ 
//Mobility Report cr by ram on 24-08-2018
import { MobilityReportComponent} from './reports/mobilityReport/mobility.component';
import { ServiceReportComponent} from './reports/mobilityReport/serviceReport.component';
import { SurveyReportComponent} from './reports/mobilityReport/surveyReport.component';
import {MobilityComponent} from './mobility/mobility.component';
import {MobilityUserComponent} from './mobility/user/mobilityUser.component';
import {KhattaServiceReportComponent} from './mobility/khattaService/khattaServiceReport.component';
import {MappingReportComponent} from './reports/mobilityReport/mappingReport.component';


// vts report 

import { VtsReportsComponent} from './reports/vtsReport/vtsReport.component';
import { TripReportComponent} from './reports/vtsReport/tripReport.component';
import { DistanceComponent} from './reports/vtsReport/distanceReport.component';
import { VtsDailyReportComponent} from './reports/vtsReport/vtsDailyReport.component';

//crm report

import { CrmReportComponent} from './reports/crmReport/crmReport.component';
import { ComplainReportComponent} from './reports/crmReport/complainReport.component';

//Report
import { VehiclePlantComponent} from './reports/plant/plant.component';
import { MaterialInReportComponent} from './reports/plant/materialInReport.component';
import { MaterialOutReportComponent } from './reports/plant/materialOutReport.component';

import { VehicleReport} from './reports/vehicleReport/vehicleReport.component';
import { PrimaryVehicleReport} from './reports/vehicleReport/primaryVehicleReport.component';
import { PrimaryAssignmentComponent} from './reports/vehicleReport/primaryVehicleAssignment';

import { PrimaryliveTrackingReport} from './reports/vehicleReport/primaryLiveTracking.component';
import { PrimaryVehicleTripReport} from './reports/vehicleReport/primaryVehicleTrip.component';
import { PrimaryUnservedAreaReport} from './reports/vehicleReport/primaryUnservedArea.component';

import { SecondaryReport} from './reports/secondary/secondaryReport.component';
import { SecondaryliveTrackingReport} from './reports/secondary/secondaryLiveTracking.component'; 
import { SecondaryAssignmentComponent} from './reports/secondary/secondaryAssignment.componant';
import {FuelReportComponent} from './reports/fuel/fuel.component';
import {FuelPurchaseReportComponent} from './reports/fuel/fuelPurchase.component';
import {FuelLooseReportComponent} from './reports/fuel/fuelLoose.component';
import {FuelDistributionReportComponent} from './reports/fuel/fuelDistribution.component';
import {CollectionReportComponent} from './reports/uccReport/couponCollection.component';
import {AttendComponent} from './reports/attendance/attend.component';
import {AttendanceReportComponent} from './reports/attendance/attendance.component';
import {AttendanceDeatilComponent} from './reports/attendance/attendanceDetail.component';
import {ProjectSummaryComponent} from './dashboard/project/projectSummary.component';
//comment

//NEW  CRM UCC
import {CrmUccComponent} from './crm/ucc/ucc.component';
import {GrnComponent} from './crm/ucc/grn/grnList.component';
import {CouponAssignComponent} from './crm/ucc/couponAssignment/couponAssignment.component'; 
import {CouponCollectionComponent} from './crm/ucc/couponCollection/couponCollection.component';
import {CouponReturnComponent} from './crm/ucc/couponReturn/couponReturn.component';
import {CouponMissingComponent} from './crm/ucc/missingCoupon/missingCoupon.component';
import { InventorySummaryComponent } from './crm/ucc/inventory/inventorySummary.component';
import { InventoryDetailComponent } from './crm/ucc/inventory/inventoryDetail.component';
import {CollectionReceivedComponent} from './crm/ucc/couponReceived/collectionReceived.component';
import {BulkCouponCollectionComponent} from './crm/ucc/bulkCouponCollection/bulkCouponCollection.component';
import {WmDispatchComponent} from './reports/mobilityReport/wmDispatch.component';  



import {MileageReportComponent} from './reports/fuel/fuelMileage.component'; 
/*
 * Maintenance Status
 */
import {VehMaintStatusComponent} from './maintenance/vehicleMaintenance/vehicleMnt/vehMaintenanceStatus.component'; 
//import {PartCategoryComponent} from './maintenance/maintMaster/partMnt/partCategoryMstr.component'; 
const routes: Routes =[

    { path: 'login',   component: LoginComponent },
    { path: 'home',    component: HomeComponent,
    children: [    
      { path: '',  redirectTo: 'maptracker/vehicles', pathMatch: 'full'},
      { path: 'maptracker',  component: MaptrackerComponent,canActivate: [AuthGuard] ,data: {permission: 'maptracker.active' },
     
       children: [
        { path: '',  redirectTo: 'vehicles', pathMatch: 'full' },
       
        { path: 'beat', component: BeatComponent ,canActivate: [AuthGuard],data: {permission: 'maptracker.beat.active' }},
      
        { path: 'area', component: AreaComponent,canActivate: [AuthGuard],data: {permission: 'maptracker.area.active' }},
        { path: 'vehicles', component: VehiclesComponent,canActivate: [AuthGuard] ,data: {permission: 'maptracker.vehicles.active' }},
        { path: 'vehicle', component: mcgVehiclesComponent},
        
        { path: 'secondaryOps', component: SecondaryOpsComponent},
        { path: 'stop', component: StopComponent,canActivate: [AuthGuard] ,data: {permission: 'maptracker.vehicles.active' }},
     
      
     
      ] 
    },  
    { path: 'dashboard',  component: DashboardComponent,canActivate: [AuthGuard] ,data: {permission: 'dashboard.active' },
      children: [
        { path: '', redirectTo: 'ucc', pathMatch: 'full' },
     
        { path: 'ucc',         component: UccComponent ,canActivate: [AuthGuard], data: {permission: 'dashboard.ucc.active'}},
    
        { path: 'complain',    component: ComplainDashBoardComponent,canActivate: [AuthGuard], data: {permission: 'dashboard.complain.active'}},
      
        { path: 'project',     component: ProjectComponent ,canActivate: [AuthGuard],data: {permission: 'dashboard.project.active'}},
        { path: 'projectSummary',     component: ProjectSummaryComponent ,canActivate: [AuthGuard],data: {permission: 'dashboard.projectSummary.active'}},

        { path: 'targetDashboard',    component: TargetDashBoardComponent,canActivate: [AuthGuard], data: {permission: 'dashboard.complain.active'}},
      ] 
    },

  
    { path: 'alarm',  component: AlarmComponent,canActivate: [AuthGuard] ,data: {permission: 'alarm.active' },
    children: [
      { path: '', redirectTo: 'alarmFuel', pathMatch: 'full' },
      //{ path: 'alarmSummary',  component:  AlarmSummaryComponent,canActivate: [AuthGuard] },
      { path: 'alarmFuel', component: AlarmFuelComponent ,canActivate: [AuthGuard], data: {permission: 'alarm.alarmFuel.active'}},
    
      { path: 'fuelAlert',         component: FuelAlertComponent ,canActivate: [AuthGuard], data: {permission: 'alarm.alarmFuel.active'}},
     
    ] 
  },
    //Admin Management
    { path: 'admin',  component: AdminComponent,canActivate: [AuthGuard],data: {permission: 'admin.active'},   
      children: [ 
                { path: '', redirectTo: 'vehicles', pathMatch: 'full', }, 
                { path: 'vehicles', component: VehComponent, canActivate: [AuthGuard],
                 children:[ 
                           { path: '', redirectTo: 'vehicles', pathMatch: 'full', }, 
                           { path: 'vehicles', component: VehicleComponent, canActivate: [AuthGuard],data :{permission: 'admin.vehicles.vehicles.active'} },  
                          ]
                },
          {path: 'employee', component: EmpComponent ,canActivate: [AuthGuard],
          children:[ 
                    { path: '', redirectTo: 'employee', pathMatch: 'full', },
                    { path: 'employee',component: EmployeeComponent , canActivate: [AuthGuard],data :{permission: 'admin.employee.employee.active' } },  
                   ]
                },   
           { path: 'entity', component: EntComponent,canActivate: [AuthGuard], 
            children:[ 
                     { path: '', redirectTo: 'entity', pathMatch: 'full', },
                     { path: 'entity',component: EntityComponent , canActivate: [AuthGuard],data :{permission: 'admin.entity.entity.active' } }, 
                     { path: 'entityMap',component: EntityMapComponent , canActivate: [AuthGuard],data :{permission: 'admin.entity.entityMap.active' }},  
                     ]
                }, 
            { path: 'hrms', component: HrmsComponent,canActivate: [AuthGuard],data: {permission: 'admin.hrms.active'} , 
                children:[  
                         { path: '', redirectTo: 'hrmsEmployee', pathMatch: 'full', },
                         { path: 'hrmsEmployee',component: HrmsEmployeeComponent, canActivate: [AuthGuard],data :{permission: 'admin.hrms.hrmsEmployee.active' }  },
                         ]
                    },  

                    { path: 'target', component: TargetComponent,canActivate: [AuthGuard],data: {permission: 'admin.target.active'} ,
                    children:[  
                             { path: '', redirectTo: 'targetMaster', pathMatch: 'full', },
                             { path: 'targetMaster',component: TargetMasterComponent, canActivate: [AuthGuard],data :{permission: 'admin.target.targetMaster.active' }  },
                             ]
                        },  
           ]
     }, 
//########This Router for Super Admin Management START###########//
     { 
        path: 'superAdmin',  component: SuperAdminComponent,canActivate:[AuthGuard],data: {permission: 'superAdmin.active' },
        children: [ 
                   { path: '', redirectTo: 'users', pathMatch: 'full', },
                   { path: 'users', component: UsersComponent,canActivate: [AuthGuard],data: {permission: 'superAdmin.users.active' } }, 
                   { path: 'serverMonitoring', component: ServerMonitoring,canActivate: [AuthGuard],data: {permission: 'superAdmin.users.active' } }, 
                  ]
      }, 
//########This Router for Super Admin Management END###########//





      { path: 'reports',  component: ReportsComponent,
      
      children: [
                 { path: '',  redirectTo: 'uccReport', pathMatch: 'full' },
                 { path: 'uccReport', component: UccReportsComponent,
                    children:[
                      { path: '', redirectTo: 'bulkCollectionReport', pathMatch: 'full'},
                      { path: 'bulkCollectionReport', component: BulkCollectionReportComponent,canActivate: [AuthGuard] ,data :{permission: 'reports.uccReport.bulkCollectionReport.active' }},
                      { path: 'collectionAnalysisReport', component: CollectionAnalysisReport,canActivate: [AuthGuard] ,data :{permission: 'reports.uccReport.collectionAnalysisReport.active' }},
                      { path: 'collectionSummary', component: CollectionSummaryComponent,canActivate: [AuthGuard] ,data :{permission: 'reports.uccReport.collectionSummary.active' }}, 
                      { path: 'couponCollection', component: CollectionReportComponent,canActivate: [AuthGuard] ,data :{permission: 'reports.uccReport.couponCollection.active' }}, 
                    ]
                  }, 
                 //{ path: 'reports', component: ReportsComponent ,canActivate: [AuthGuard]},  
                 { path: 'kccReport', component: KccReportsComponent,canActivate: [AuthGuard],
                 children:[
                   { path: '',  redirectTo: 'kccSummaryReport', pathMatch: 'full' }, 
                   { path: 'kccSummaryReport', component: KccSummaryReportComponent,canActivate: [AuthGuard] ,data :{permission: 'reports.kccReport.kccSummaryReport.active' }},
                   {path: 'kccCustomerReport', component: KccCustomerReportComponent,canActivate: [AuthGuard] ,data :{permission: 'reports.kccReport.kccCustomerReport.active' }},
                   { path: 'kccDetailReport', component: KccDetailReportComponent,canActivate: [AuthGuard] ,data :{permission: 'reports.kccReport.kccDetailReport.active' }},
                   { path: 'kccConsolidatedReport', component: KccConsolidatedReportComponent,canActivate: [AuthGuard] ,data :{permission: 'reports.kccReport.kccConsolidatedReport.active' }},
                 ]
               }, 
               { path: 'entityReport', component: EntitysComponent,
               children:[
                 { path: '',  redirectTo: 'entitySummary', pathMatch: 'full'}, 
                 { path: 'entitySummary', component: EntitySummaryReportComponent,canActivate: [AuthGuard] ,data :{permission: 'reports.entityReport.entitySummary.active' }}
               ]
             },
             //Mobility Report cr by ram on 24-08-2018
             { path: 'mobilityReport', component: MobilityReportComponent,
               children:[
                   { path: '',  redirectTo: 'serviceReport', pathMatch: 'full'}, 
                   { path: 'serviceReport', component: ServiceReportComponent,canActivate: [AuthGuard],data :{permission: 'reports.mobilityReport.serviceReport.active' }},
                   { path: 'surveyReport', component: SurveyReportComponent,canActivate: [AuthGuard],data :{permission: 'reports.mobilityReport.surveyReport.active' }},
                   { path: 'mappingReport', component: MappingReportComponent,canActivate: [AuthGuard],data :{permission: 'reports.mobilityReport.mappingReport.active' }} ,
                   { path: 'wmDispatchReport', component: WmDispatchComponent,canActivate: [AuthGuard],data :{permission: 'reports.mobilityReport.wmDispatchReport.active' }}                                                                           
               ]
             },
             { path: 'vtsReport', component: VtsReportsComponent,
             children:[
               { path: '',  redirectTo: 'distanceReport', pathMatch: 'full'}, 
               { path: 'tripReport', component: TripReportComponent,canActivate: [AuthGuard],data :{permission: 'reports.vtsReport.tripReport.active'}},
               { path: 'distanceReport', component: DistanceComponent,canActivate: [AuthGuard],data :{permission: 'reports.vtsReport.distanceReport.active' }},
               { path: 'vtsDailyReport', component: VtsDailyReportComponent,canActivate: [AuthGuard],data :{permission: 'reports.vtsReport.vtsDailyReport.active' }},
            ]
            },

            { path: 'crmReport', component: CrmReportComponent,
            children:[
              { path: '',  redirectTo: 'complainReport', pathMatch: 'full'}, 
              { path: 'complainReport', component: ComplainReportComponent,canActivate: [AuthGuard],data :{permission: 'reports.crmReport.complainReport.active'}}
              
           ]
           },



             { path: 'plant', component: VehiclePlantComponent,
               children:[
                   { path: '',  redirectTo: 'materialIn', pathMatch: 'full'},
                   { path: 'materialIn', component: MaterialInReportComponent,canActivate: [AuthGuard],data :{permission: 'reports.plantReport.materialIn.active' }} ,
                   { path: 'materialOut', component: MaterialOutReportComponent,canActivate: [AuthGuard],data :{permission: 'reports.plantReport.materialOut.active' }} ,
                   
               ]
             },
             { path: 'vehicleReport', component: VehicleReport,
             children:[
               { path: '',  redirectTo: 'primaryVehicleReport', pathMatch: 'full'}, 
              //{ path: 'tripReport', component: TripReportComponent,canActivate: [AuthGuard],data :{permission: 'reports.vtsReport.tripReport.active' ' }},
               { path: 'primaryVehicleReport', component: PrimaryVehicleReport,canActivate: [AuthGuard],data :{permission: 'reports.vehicleReport.primaryVehicleReport.active'}},
               { path: 'primaryLiveTrackingReport', component: PrimaryliveTrackingReport},
               { path: 'primaryVehicleTripReport', component: PrimaryVehicleTripReport},
               { path: 'primaryUnservedAreaReport', component: PrimaryUnservedAreaReport},   
               { path: 'primaryVehAssignment', component: PrimaryAssignmentComponent,canActivate: [AuthGuard],data :{permission: 'reports.vehicleReport.primaryVehAssignment.active'}},                
             ]
            },
            { path: 'secondary', component: SecondaryReport,
              children:[
              { path: '',  redirectTo: 'secondaryLiveTrackingReport', pathMatch: 'full'}, 
              { path: 'secondaryLiveTrackingReport', component: SecondaryliveTrackingReport,canActivate: [AuthGuard],data :{permission: 'reports.secondary.secondaryLiveTrackingReport.active'}},
              { path: 'secondaryAssignment', component: SecondaryAssignmentComponent,canActivate: [AuthGuard],data :{permission: 'reports.secondary.secondaryAssignment.active'}},  
            ]
           } ,
            { path: 'fuel', component: FuelReportComponent,canActivate: [AuthGuard] ,data :{permission: 'reports.fuel.active'},
              children:[
                        { path: '',  redirectTo: 'vehicleFuel', pathMatch: 'full'},  
                        { path: 'vehicleFuel', component: FuelPurchaseReportComponent, canActivate: [AuthGuard] ,data :{permission: 'reports.fuel.vehicleFuel.active' }}, 
                        { path: 'looseFuel', component: FuelLooseReportComponent, canActivate: [AuthGuard] ,data :{permission: 'reports.fuel.looseFuel.active' }}, 
                        { path: 'fuelDistribution', component: FuelDistributionReportComponent, canActivate: [AuthGuard] ,data :{permission: 'reports.fuel.fuelDistribution.active' }}, 
                        { path: 'fuelMileageReport', component: MileageReportComponent, canActivate: [AuthGuard] ,data :{permission: 'reports.fuel.fuelMileageReport.active' }}, 
                       ]
            } ,
            { path: 'attendance', component: AttendComponent,canActivate: [AuthGuard],data :{permission: 'reports.attendance.active'},
              children:[
                        { path: '',  redirectTo: 'attendanceReport', pathMatch: 'full'},  
                        { path: 'attendanceDeatil', component: AttendanceDeatilComponent, canActivate: [AuthGuard],data :{permission: 'reports.attendance.attendanceReport.active' }},  
                        { path: 'attendanceReport', component: AttendanceReportComponent, canActivate: [AuthGuard],data :{permission: 'reports.attendance.attendanceReport.active' }},  
                       ]
            }     
           ]    
    },  
    { path: 'crm',  component: CRMComponent,
    children: [ 
               //KCC Route KccComponent  
               { path: '', redirectTo: 'kcc', pathMatch: 'full'},
               { path: 'kcc', component: KccComponent,
                 children:[ 
                           { path: '', redirectTo: 'consumerList', pathMatch: 'full'},
                           { path: 'consumerList', component: ConsumerListComponent,canActivate: [AuthGuard] ,data :{permission: 'crm.kcc.consumerList.active' }},
                          
                           { path: 'invoiceList', component: InvoiceListComponent ,canActivate: [AuthGuard] ,data :{permission: 'crm.kcc.invoiceList.active' }},   
                           { path: 'createInvoice/:consumerCode/:invoiceNo', component: CreateInvoiceComponent}, 
                           { path: 'paymentList', component: PaymentListComponent ,canActivate: [AuthGuard] ,data :{permission: 'crm.kcc.payment.active' }},                          
                        ] 
                },  
                { path: 'complain', redirectTo: 'complainList', pathMatch: 'full'},
                { path: 'complain', component: ComplainComponent,
                  children:[ 

                            { path: '', redirectTo: 'complainList', pathMatch: 'full'},
                            { path: 'complainList', component: ComplainListComponent,canActivate: [AuthGuard] ,data :{permission: 'crm.complain.active' }},          
                         ] 
                 },  
              //New CRM UCC (24-102018)
              { path: 'ucc', component: CrmUccComponent,
               children:[
                         { path: '', redirectTo: 'grn', pathMatch: 'full'},
                         { path: 'grn', component: GrnComponent,canActivate: [AuthGuard] ,data :{permission: 'crm.ucc.grn.active' }}, 
                         { path: 'couponAssignment', component: CouponAssignComponent,canActivate: [AuthGuard] ,data :{permission: 'crm.ucc.couponAssignment.active' }}, 
                         { path: 'couponCollection', component: CouponCollectionComponent,canActivate: [AuthGuard] ,data :{permission: 'crm.ucc.couponCollection.active' }}, 
                         { path: 'couponReturn', component: CouponReturnComponent,canActivate: [AuthGuard] ,data :{permission: 'crm.ucc.couponReturn.active' }}, 
                         { path: 'couponMissing', component: CouponMissingComponent,canActivate: [AuthGuard] ,data :{permission: 'crm.ucc.couponMissing.active' }}, 
                         { path: 'inventorySummary', component: InventorySummaryComponent,canActivate: [AuthGuard] ,data :{permission: 'crm.ucc.inventorySummary.active' }}, 
                         { path: 'inventoryDetail', component: InventoryDetailComponent,canActivate: [AuthGuard] ,data :{permission: 'crm.ucc.inventoryDetail.active' }}, 
                         { path: 'collectionReceived', component: CollectionReceivedComponent,canActivate: [AuthGuard] ,data :{permission: 'crm.ucc.collectionReceived.active' }},
                         { path: 'bulkCouponCollection', component: BulkCouponCollectionComponent,canActivate: [AuthGuard] ,data :{permission: 'crm.ucc.bulkCouponCollection.active' }},                       
                        ] 
                     },  
                ] 
            }, 
            
            { path: 'maintenance',  component: MaintenanceComponent, 
            children: [ 
              { path: '', redirectTo: 'vehicleMaintenance', pathMatch: 'full'},
              { path: 'vehicleMaintenance', component: VehicleMaintMntComponent,
                children:[ 
                          { path: '', redirectTo: 'vehicleMaintenance', pathMatch: 'full'},
                          { path: 'vehicleMaintenance', component: VehicleMaintenanceComponent,canActivate: [AuthGuard] ,data :{permission: 'maintenance.active' }},
                          { path: 'logbook', component: LogbookComponent , canActivate: [AuthGuard],data :{permission: 'maintenance.logbook.active' }},
                          //{ path: 'maintenanceStatus/:vehicleNo', component:VehMaintStatusComponent},              
                        ]  
               },
               { path: 'maintenanceStatus/:vehicleNo', component:VehMaintStatusComponent},              
              
              ] 
              }, 
          
              



              

         
          { path: 'mobility',  component: MobilityComponent,canActivate: [AuthGuard],
          children: [ 
                     { path: '', redirectTo: 'khattaReport', pathMatch: 'full' }, 
                     { path: 'khattaReport', component: KhattaServiceReportComponent ,canActivate: [AuthGuard],data :{permission: 'mobility.khattaReport.active' }}, 
                     { path: 'user', component: MobilityUserComponent ,canActivate: [AuthGuard], data :{permission: 'mobility.user.active' }}, 
                    ]
        }, 


    ]
    
  },{path: '',  redirectTo: 'login', pathMatch: 'full' }
];              
@NgModule({
  imports: [
    CommonModule,
    BrowserModule,
    RouterModule.forRoot(routes)
  ],
  exports: [
  ],
})
export class AppRoutingModule { }
