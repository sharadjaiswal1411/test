import { Component } from '@angular/core';


import { AuthGuard } from '../_guards/index';
import { Router, ActivatedRoute } from '@angular/router';
import { NgForm } from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { environment } from '../../environments/environment';
import { VERSION } from '../../environments/version';

@Component({
    selector: 'login-cmp',
    templateUrl: './login.component.html',
    styleUrls: ['./login.component.css']
})
export class LoginComponent {
    version = VERSION;
    model: any = {};
    loading = false;
    returnUrl: string;
    alertMessage: string
    constructor(
        private route: ActivatedRoute,
        private authGuard: AuthGuard,
        private router: Router,

        private http: HttpClient) { }

    ngOnInit() {
        // reset login status

        if (localStorage.getItem('authData') && localStorage.getItem('projectId')) {
            //   this.router.navigate(['/home']);

            var authData = JSON.parse(localStorage.getItem('authData'))
            var route = JSON.parse(authData.permissions)
            if (route.default) {
                this.router.navigate([route.default]);
            } else {
                this.router.navigate(['/home']);
            }
        }
        // get return url from route parameters or default to '/'
        //this.returnUrl = this.route.snapshot.queryParams['returnUrl'] || '/';
    }




    login(f: NgForm) {
       
        if (!f.value.username) {
            return;
        } else if (!f.value.password) {
            return;
        }
        this.loading = true;
        let data = {
            userName: f.value.username,
            password: f.value.password
        }
        this.http.post(environment.apiUrl + 'login', data).subscribe(response => {
            if (response) {
                if (response[0].error_code == '200') {
                    localStorage.setItem("authData", JSON.stringify(response[0]))
                    var permissions = JSON.parse(response[0].permissions);
                    if (permissions) {
                        var projects = Object.keys(permissions)
                        for (var i = 0; i < projects.length; i++) {
                            if (permissions[projects[i]].active == true) {
                                localStorage.setItem("projectId", permissions[projects[i]].ID)
                            }
                        }
                    }
                    var authData = JSON.parse(localStorage.getItem('authData'))
                    var route = JSON.parse(authData.permissions)
                    if (route.default) {
                        this.router.navigate([route.default]);
                    } else {
                        this.router.navigate(['/home']);
                    }
                } else {
                    this.loading = false;
                    this.alertMessage = response[0].msg
                }
            } else {
                this.loading = false;
                this.alertMessage = "Invalid User Name Or Password"
            }
        });
    }
}
