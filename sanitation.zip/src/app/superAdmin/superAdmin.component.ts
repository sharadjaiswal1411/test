import { Component, OnInit } from '@angular/core';


@Component({
  selector: 'admin-cmp',
  templateUrl: './superAdmin.component.html',
  styleUrls: ['./superAdmin.component.css']
})
export class SuperAdminComponent implements OnInit {     
  constructor() { }
  ngOnInit() 
      { 
      }; 
}
