import { Component, OnInit, ViewEncapsulation} from '@angular/core';
import { Http } from '@angular/http'



import { Broadcaster } from '../../../environments/broadcaster';

import { AuthService } from '../../_services/index'; 
import { LoaderService } from '../../_services/loader.service'; 

declare var $:any; 
const distinctStatus = data => data.filter((x, idx, xs) => xs.findIndex(y => y.ISACTIVE === x.ISACTIVE) === idx); 

@Component({
  selector: 'server-cmp',
  templateUrl: './serverMonitoring.component.html',
  encapsulation: ViewEncapsulation.None,
  styles: ['.green .codeColumn { color: green; font-weight: bold} .red .codeColumn { color: red; font-weight: bold}'], 
})

export class ServerMonitoring implements OnInit 
{ 

    prjId:any
    serverData:any;
    showLoader:any
//Variable Sections.

 constructor(private http: Http,private broadcaster: Broadcaster,private auth:AuthService,private loaderService: LoaderService){
    
   this.serverData = []
 }


 
   serverInfo = async () => {

    
      let ecocleanAPI = await fetch("http://52.77.45.69:5000/memoryUsage")
      var ecocleanAPIData = await ecocleanAPI.json()
      console.log("ecocleanAPIData",ecocleanAPIData)
      this.serverData.push({"APIName":"ecocleanAPI",IP:"52.77.45.69","stdout": ecocleanAPIData.stdout,"process":ecocleanAPIData.process,status:"OK"})
       
      let mobileAPI = await fetch("http://13.232.60.37:4000/memoryUsage")
      var mobileAPIData = await mobileAPI.json()
      this.serverData.push({APIName:"mobileAPI",IP:"13.232.60.37",stdout: mobileAPIData.stdout,process:mobileAPIData.process,status:"OK"})
      console.log("mobileAPIData",mobileAPIData)
  }


    ngOnInit()
    {
        this.prjId = this.auth.getAuthentication().projectId
       
        this.serverInfo()
    }
}


