import { Component, OnInit, ViewEncapsulation} from '@angular/core';
import { Http } from '@angular/http'

import { environment } from '../../../environments/environment';

import { Broadcaster } from '../../../environments/broadcaster';
import * as JSONEditor from 'jsoneditor';
import { AuthService } from '../../_services/index'; 
import { LoaderService } from '../../_services/loader.service'; 
import { process, State } from '@progress/kendo-data-query';
import { GroupDescriptor, DataResult } from '@progress/kendo-data-query';
import {GridDataResult,DataStateChangeEvent} from '@progress/kendo-angular-grid';
import { Observable } from 'rxjs/Observable'; 
import { ExcelExportData } from '@progress/kendo-angular-excel-export';
import Swal from 'sweetalert2'
import { RowClassArgs } from '@progress/kendo-angular-grid';

declare var $:any; 
const distinctStatus = data => data.filter((x, idx, xs) => xs.findIndex(y => y.ISACTIVE === x.ISACTIVE) === idx); 

@Component({
  selector: 'app-users',
  templateUrl: './users.component.html',
  styleUrls: ['./users.component.css'],
  encapsulation: ViewEncapsulation.None,
  styles: ['.green .codeColumn { color: green; font-weight: bold} .red .codeColumn { color: red; font-weight: bold}'], 
})

export class UsersComponent implements OnInit 
{ 
//Variable Sections.
public showLoader:boolean;
public data: any = {}
public prjId:any;
public usersData:any;
public search:any;
public permission:any;
public editor:any
public userCd :any
public container:any
public options:any
public user:any
nameModal:any;
mobileModal:any;
EmailModal:any;
PasswordModal:any;
responceMessage:any;
public setclaimSuccess:any
success=false;
error=false;
userId:any;
newPassModal:any;
passdSuccess=false;
passdError=false;
reNewPassModal:any;
addressModal:any;
currentUsrId:any;
updtSuccess=false;
updtError=false; 
changeStatus:any;
status:any; 
titleData:any;
successMsg:any;
userCdModal:any;
confPassModal:any;
public state: State = { 
    skip: 0,
    take: 15,  
    filter: { 
      logic: 'and',
      filters: []
    }
  };
  public groups: GroupDescriptor[] = [];
  public view: Observable<GridDataResult>;
  public gridView: DataResult;
  public groupChange(groups: GroupDescriptor[]): void {
    this.groups = groups;
    this.loadProducts();
  }
  public distinctRole: any[]
  public distinctStatus: any[]
  private loadProducts(): void {
    this.gridDataUserList = process(this.usersData, { group: this.groups }); 
  }
  public gridDataUserList: GridDataResult  
    /*
     * Get all excel data 
    */
   public allData(): ExcelExportData {
    const result: ExcelExportData =  {
        data: this.usersData
    };
    return result;
   } 
 constructor(private http: Http,private broadcaster: Broadcaster,private auth:AuthService,private loaderService: LoaderService){
    this.setclaimSuccess = false
    this.loaderService.status.subscribe((val: boolean) =>{
        this.showLoader = val;
        this.allData = this.allData.bind(this);
        }); 
 } 
 newUserbtn(){
    this.success=false;
    this.error=false;  
    this.nameModal=null,
    this.mobileModal=null,
    this.EmailModal=null,
    this.PasswordModal=null
    $('#NewUserModal').modal('show');
 }  
   
   //To get The All User Details
   getAllUsersDetails(){
    this.loaderService.display(true);
       this.http.get(environment.apiUrl+'userManagement/users').subscribe((data)=> {
         this.usersData = data.json();
         if(this.usersData.length>0){
            this.distinctStatus=distinctStatus(this.usersData)
            this.gridDataUserList = process(this.usersData, this.state); 
            this.loaderService.display(false); 
         }else{
            this.usersData=[];
            this.gridDataUserList = process(this.usersData, this.state); 
            this.loaderService.display(false);
         }  
       }); 
   } 
   
   public dataStateChange(state: DataStateChangeEvent): void { 
    this.state = state;
    this.gridDataUserList = process(this.usersData, this.state); 
    if (state && state.group) {   
      this.gridDataUserList = process(this.usersData, this.state); 
      this.distinctStatus=distinctStatus(this.usersData) 
    } 
  }



   //This method is used to Open Users Modal Popup
   editClaims(user)
   {   
       this.user = user
       this.userCd = user.USERCD
       this.setclaimSuccess = false
       this.editor.set(JSON.parse(user.permissions));
       $("#UserEditModal").modal("show");
   }
   changeOptions(){
    this.editor.destroy();
    this.options.mode = this.options.mode =='tree' ? 'code' : 'tree';
    this.editor = new JSONEditor(this.container, this.options);
    this.editor.set(JSON.parse(this.user.permissions));
   }
   setClaims(){
       var json = this.editor.get();
       $("#save-loader").show()
       this.http.post(environment.apiUrl+'userManagement/setClaims?USERCD=' + this.userCd,json).subscribe((data)=>{
           if(data.json().status == 'OK'){
               $("#save-loader").hide()
               this.setclaimSuccess = true
            //    $('#UserEditModal').modal('hide');
           }else{
            this.setclaimSuccess = false
           }
       });  
   }
   public restrictNumericOnly(e){
    let input;
    var inputlen;
    if (e.metaKey || e.ctrlKey){
      return true;
    }
    if (e.which === 32){
     return false;
    }
    if (e.which === 0){
     return true;
    }
    if (e.which < 33){
      return true;
    }
    input = String.fromCharCode(e.which); 
    return !!/[\d\s]/.test(input);
   }

  
   //Create new users Credentials
   createNewUser(){
       if(!this.nameModal){
           alert("User name is required!")
           return;
       } 
       else if(!this.userCdModal){
        alert("User code is required!")
        return;
       } 
       else if(!this.mobileModal){
        alert("Mobile is required!")
        return;
       }else if(this.mobileModal.length!=10){
        alert("Invalid Mobile No!")
        return;
       }else if(!this.PasswordModal){
        alert("Password is required!")
        return;
       }else if(this.PasswordModal!=this.confPassModal){
        alert("Password does not match with confirm password!")
        return;
       } 
    var newStr = this.userCdModal.replace(/\s+/g, ''); 
    var newUsers={
        "USERCD":newStr,
        "NAME":this.nameModal,
        "MOBNO":this.mobileModal,
        "EMAIL":this.EmailModal,
        "PASSWORD":this.PasswordModal
        } 
        this.http.post(environment.apiUrl+'userManagement/createUser',newUsers).subscribe((data)=>{
            var code=data.json();
            var message=code.output[0].msg
            if(code.output[1].error_code==200){
             this.error=false; 
             this.success=true; 
             this.responceMessage=message   
             setTimeout(()=>{ 
                this.nameModal=null,
                this.userCdModal=null,
                this.mobileModal=null,
                this.EmailModal=null,
                this.PasswordModal=null
                this.confPassModal=null;
                this.success=false;
                this.getAllUsersDetails();
               },2000);          
            }else{
                this.responceMessage=message
                this.error=true;
                this.success=false;               
            }
        });  
    } 

    /*
     *Reset Password
     */ 
    changePassword(data){
     this.error=false;
     this.success=false;  
     this.userId=data.ID
     $("#changePassModal").modal("show");
    }

    /*
     * Reset Password
     */
    resetPassword(){
        if(this.newPassModal!=this.reNewPassModal){
            alert("Password and confirm password does not match")
            return;
        }
        this.http.get(environment.apiUrl+'userManagement/resetPassword?userId='+this.userId+'&newPassword='+this.newPassModal).subscribe((data)=>{
            var code=data.json(); 
            if(code.status == 'OK'){
              this.passdSuccess=true;  
              this.passdError=false; 
              setTimeout(()=>{ 
                this.newPassModal=null;
                this.reNewPassModal=null;
                this.passdSuccess=false; 
                $("#changePassModal").modal("hide"); 
               },2500);  
            }else{
                this.passdSuccess=false;
                this.passdError=true
            }
        });  
    }


    /*
     * Edit User Info 
     */
    editUserInfo(data){ 
    this.currentUsrId=data.ID
    this.nameModal=data.USERNAME
    this.mobileModal=data.MOBNO
    this.EmailModal=data.EMAIL
    this.addressModal=data.ADDRESS
    $("#editUserInfo").modal("show"); 
    }

    /*
     * Update Users Details
     */
    updateUsers(){
        if(!this.nameModal){
            alert("Name is required!")
            return;
        }
        var userDetails={
            "ID":this.currentUsrId,
            "USERNAME":this.nameModal, 
            "MOBNO":this.mobileModal,
            "EMAIL":this.EmailModal,
            "ADDRESS":this.addressModal
            } 
        this.http.post(environment.apiUrl+'userManagement/updateUserInfo',userDetails).subscribe((data)=>{
            var code=data.json(); 
            if(code.status == 'OK'){
              this.updtSuccess=true;  
              this.updtError=false; 
              setTimeout(()=>{  
                this.updtSuccess=false; 
                $("#editUserInfo").modal("hide"); 
                this.getAllUsersDetails();
               },2500);  
            }else{
                this.updtSuccess=false;
                this.updtError=true
            }
        }); 
    }
    

   /*
    *To Bind the User Active and Inactive status in drop down list
    */
    bindStatus(data){ 
        var status=data.ISACTIVE
        if(status=="Active"){
           this.changeStatus="Inactive"  
        }else{
            this.changeStatus="Active"   
        }
    }


    /*
     * De activate Users Login
    */ 
    userDisable(data){
        var status=data.ISACTIVE
        if(status=="Active"){
            this.status=0 
            this.titleData="Are you sure to Inactive this user?"
            this.successMsg="User Inactive successfully."
        }else{
            this.status=1 
            this.titleData="Are you sure to Active this user?"
            this.successMsg="User Active successfully."
        }
        var dataJason={
            "ID":data.ID,
            "STATUS":this.status
        }
          
        Swal({
            title: this.titleData, 
            type: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Yes, Convert it!'
          }).then((result) => {
            if (result.value) { 
              this.http.post(environment.apiUrl + "userManagement/disableUser", dataJason).subscribe(data =>{ 
                  var response = data.json() 
                  var status = response.status 
                  if (status == "OK") { 
                      this.getAllUsersDetails();
                    Swal( 
                      this.successMsg,
                      'success'
                      ) 
                      } else 
                      { 
                      Swal(
                      "Error During user Active/Inactive operation!",
                      'error'
                      ) 
                  }
                });
            }
          })
    }


    /**
     * Column BG color Change
    */
   public rowCallback = (context: RowClassArgs) => { 
    switch (context.dataItem.ISACTIVE) {
      case 'Active': 
        return {green : true}; 
      case 'Inactive': 
        return {red : true}; 
      default:
        return {}; 
     } 
   }

    


   ngOnInit()
    {
        this.prjId = this.auth.getAuthentication().projectId
        this.container = document.getElementById("jsoneditor");
        this.options = {};
        this.editor = new JSONEditor(this.container, this.options);
        $("#progress-bar").hide();
        $("#save-loader").hide()
        this.getAllUsersDetails(); 
    
    }
}


