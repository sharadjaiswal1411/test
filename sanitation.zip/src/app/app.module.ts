import { BrowserModule } from '@angular/platform-browser';
import { UiSwitchModule } from 'ngx-toggle-switch';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';
import {RouterModule } from '@angular/router';
import {NgSelectModule} from '@ng-select/ng-select'; 
import {HashLocationStrategy, LocationStrategy } from '@angular/common';
import {MatInputModule} from '@angular/material/input';
import {MatNativeDateModule} from '@angular/material';
import {MatDatepickerModule} from '@angular/material/datepicker';
import {HttpClientModule } from '@angular/common/http';
import {AppRoutingModule } from './app.routing';
import { SidebarComponent } from './shared/sidebar/sidebar.component';
import {MatCheckboxModule} from '@angular/material/checkbox';
import {MatProgressSpinnerModule} from '@angular/material/progress-spinner';
import {MatChipsModule} from '@angular/material/chips';
//import {MatCardModule} from '@angular/material/card';
import {MatFormFieldModule} from '@angular/material/form-field';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
//import { LbdModule } from './lbd/lbd.module';
import {MatProgressBarModule} from '@angular/material/progress-bar';
import { AppComponent } from './app.component';
import {MatButtonToggleModule} from '@angular/material/button-toggle';
import {MatSlideToggleModule} from '@angular/material/slide-toggle';
import { AlertComponent ,HasPermissionDirective,NewConsumerDirective, SearchPipe,CouponHistoryDirective,GridContextMenuComponent,DropDownListFilterComponent  } from './_directives';
import { AuthGuard } from './_guards';

import { AlertService,AuthService } from './_services';
import { LoginComponent } from './login/login.component';
import { Broadcaster } from '../environments/broadcaster';

import { DashboardComponent } from './dashboard/dashboard.component'
import { HomeboardComponent } from './homeboard/homeboard.component'

import { AlarmComponent } from './alarm/alarm.component'

import { AlarmFuelComponent } from './alarm/alarmFuel/alarmFuel.component'

import { AlarmSummaryComponent } from './alarm/alarmSummary/alarmSummary.component'

import { FuelAlertComponent } from './alarm/fuelAlert/fuelAlert.component'

import { UccComponent } from './dashboard/ucc/ucc.component';
import { AggregateComponent } from './homeboard/aggregate/aggregate.component';


import { ProjectComponent } from './dashboard/project/project.component';
import { PrimaryComponent } from './homeboard/primary/primary.component';

import {MaptrackerComponent} from './maptracker/maptracker.component';
import {VehiclesComponent} from './maptracker/vehicles/vehicles.component';
import {mcgVehiclesComponent} from './maptracker/vehicles/mcgVehicles.component';
import {SecondaryOpsComponent} from './maptracker/vehicles/secondaryOps.component';

import {AreaComponent} from './maptracker/area/area.component';
import {BeatComponent} from './maptracker/area/beat.component';



//import {KccComponent} from 'app/maptracker/kcc/kcc.component';

import {StopComponent} from './maptracker/stop/stop.component';



import { NavbarComponent } from './shared/navbar/navbar.component'; 

import { ComplainDashBoardComponent } from './dashboard/complain/complain.component';
import { SecondaryComponent } from './homeboard/secondary/secondary.component';


import { TargetDashBoardComponent } from './dashboard/target/targetDashboard.component';
import { WasteProcessingComponent } from './homeboard/wasteProcessing/wasteProcessing.component';


import { AdminComponent } from './admin/admin.component';
import { EmployeeComponent } from './admin/employee/empMngt/employee.component';
import { EmpComponent } from './admin/employee/emp.component'; 
import { VehicleComponent } from './admin/vehicles/vehicleMngt/vehicles.component';
import { EntityComponent } from  './admin/entity/entityMngt/entity.component';
import { EntityMapComponent } from  './admin/entity/entityMapping/entityMap.component';
import { EntComponent } from  './admin/entity/ent.component';
//HRMS COMPONENT
import { HrmsComponent } from  './admin/hrms/hrms.component'
import { HrmsEmployeeComponent } from  './admin/hrms/hrmsMnt/hrmsEmployee.component'
 

import { TargetComponent } from  './admin/target/target.component'
import { TargetMasterComponent } from  './admin/target/targetMaster/targetMaster.component'

import {OrderBy} from './maptracker/vehicles/vehicles.component';

/*
  Khatta Component
*/


import { AddNewVehiclesComponent  } from './admin/vehicles/vehicleMngt/vehicles.AddNewVehicles';
import { VehComponent  } from './admin/vehicles/veh.component';

import { ReportsComponent } from './reports/reports.component';
import { HomeComponent } from './home/home.component'; 
import { NgDatepickerModule } from 'ng2-datepicker';

//Added by Ram on 15_03_2018 For Loading message popup
import { ImageUploadModule } from "angular2-image-upload"; //Added by Ram on 19_03_2018 For uploading image in add user model popup page
import {MatRadioModule} from '@angular/material/radio';
//this component for add new vehicles only. 
//For Report cr by ram on )8_03_2018
import { UccReportsComponent } from './reports/uccReport/uccReport.Component';
import { BulkCollectionReportComponent } from './reports/uccReport/bulkCollectionReport.Component';
import { CollectionAnalysisReport } from './reports/uccReport/collectionAnalysisReport.Component';
import { CollectionSummaryComponent } from './reports/uccReport/collectionSummaryReport.Component';

//CRM
import { CRMComponent} from './crm/crm.component';
import { ConsumerComponent} from './crm/kcc/consumer/consumer.component';

//KCC
import { KccComponent} from './crm/kcc/kcc.component';


/*
   ucc old route
*/ 
// consumer
import { ConsumerListComponent} from './crm/kcc/consumer/consumerList/consumerList.component';
 // invoice
import { InvoiceComponent} from './crm/kcc/invoice/invoice.component';
//invoiceList


import { InvoiceListComponent} from './crm/kcc/invoice/invoiceList/invoiceList.component';
import { CreateInvoiceComponent} from './crm/kcc/invoice/createInvoice/createInvoice.component';   

//commentstat

//KCC
import { ComplainComponent} from './crm/complain/complain.component';  
import { ComplainListComponent} from './crm/complain/complainList/complainList.component';   

import { PaymentComponent} from './crm/kcc/payment/payment.component';
import { PaymentListComponent} from './crm/kcc/payment/paymentList/paymentList.component';


//FireBase

//

import { SuperAdminComponent } from './superAdmin/superAdmin.component'; 


import { ServerMonitoring } from './superAdmin/users/serverMonitoring.component'; 
import { UsersComponent } from './superAdmin/users/users.component';
//This Library Added for Multiselect

//This is for Table Paginations.
//import {MatPaginatorModule} from '@angular/material/paginator'; 
//for data Table
//import { DataTablesModule } from 'angular-datatables'; 





import { PagerService } from './crm/kcc/consumer/consumerList/consumer.pager.service';
import { LightboxModule } from 'angular2-lightbox';
///Date and Time Picker
import { AngularDateTimePickerModule } from 'angular2-datetimepicker'; 

//Loader service
import { LoaderService } from './_services/loader.service';

//import { DaterangepickerModule } from 'angular-2-daterangepicker';
//import { PopoverModule } from 'ng2-popover'; 
import { MyDateRangePickerModule } from 'mydaterangepicker';  
//import { PDFExportModule } from '@progress/kendo-angular-pdf-export';
import { GridModule ,ExcelModule ,PDFModule } from '@progress/kendo-angular-grid';
import { PopupModule } from '@progress/kendo-angular-popup';
import { DropDownListModule } from '@progress/kendo-angular-dropdowns';
//import { DateInputsModule } from '@progress/kendo-angular-dateinputs';

//import { ToolBarModule } from '@progress/kendo-angular-toolbar';
import { MenuModule } from '@progress/kendo-angular-menu';
import { DropDownsModule } from '@progress/kendo-angular-dropdowns';
//UCC 








//Ucc collection Received Section cr by ram on 10_07_2018 

import { ChartsModule } from '@progress/kendo-angular-charts'; 

//KCC report--KccSummaryReportComponent
import { KccReportsComponent} from './reports/kccReport/kccReport.component'; 
import { KccSummaryReportComponent} from './reports/kccReport/kccSummaryReport.component';
import { KccCustomerReportComponent} from './reports/kccReport/kccCustomerReport.component';
import { KccDetailReportComponent} from './reports/kccReport/kccDetailReport.component';
import { EntitySummaryReportComponent} from './reports/entityReport/entitySummaryReport.component';
import { EntitysComponent} from './reports/entityReport/entity.component';

import { KccConsolidatedReportComponent} from './reports/kccReport/kccConsolidatedReport.component';

import { NgxSelectModule } from 'ngx-select-ex';

import {MaintenanceComponent} from './maintenance/maintenance.component';
import {VehicleMaintenanceComponent} from './maintenance/vehicleMaintenance/vehicleMnt/vehicleMaintenance.component';

//import {MaintMntComponent} from './maintenance/maintMaster/maintMnt.component';
//import {VehMaintenanceMasterComponent} from './maintenance/maintMaster/master/maintenanceMaster.component';
 

import {LogbookComponent} from './maintenance/vehicleMaintenance/vehicleMnt/logbook.component'; 

import {VehicleMaintMntComponent} from './maintenance/vehicleMaintenance/vehicleMnt.component'; 

//import {PartCategoryComponent} from './maintenance/maintMaster/partMnt/partCategoryMstr.component'; 


//Mobility Import cr by Ram on 24-08-2018
import { MobilityReportComponent} from './reports/mobilityReport/mobility.component';
import { ServiceReportComponent} from './reports/mobilityReport/serviceReport.component';
import { SurveyReportComponent} from './reports/mobilityReport/surveyReport.component';
import {MobilityComponent} from './mobility/mobility.component';
import {MobilityUserComponent} from './mobility/user/mobilityUser.component';
import {KhattaServiceReportComponent} from './mobility/khattaService/khattaServiceReport.component';
import {MappingReportComponent} from './reports/mobilityReport/mappingReport.component';

// Reports 
import { VehiclePlantComponent} from './reports/plant/plant.component';
import { MaterialInReportComponent} from './reports/plant/materialInReport.component';
import { MaterialOutReportComponent } from './reports/plant/materialOutReport.component';

import { VtsReportsComponent} from './reports/vtsReport/vtsReport.component';
import { TripReportComponent} from './reports/vtsReport/tripReport.component';
import { DistanceComponent} from './reports/vtsReport/distanceReport.component';
import { VtsDailyReportComponent} from './reports/vtsReport/vtsDailyReport.component';



import { CrmReportComponent} from './reports/crmReport/crmReport.component';
import { ComplainReportComponent} from './reports/crmReport/complainReport.component';
import { VehicleReport} from './reports/vehicleReport/vehicleReport.component';
import { PrimaryVehicleReport} from './reports/vehicleReport/primaryVehicleReport.component';

import { PrimaryAssignmentComponent} from './reports/vehicleReport/primaryVehicleAssignment';

import { PrimaryliveTrackingReport} from './reports/vehicleReport/primaryLiveTracking.component';

import { PrimaryVehicleTripReport} from './reports/vehicleReport/primaryVehicleTrip.component';

import { PrimaryUnservedAreaReport} from './reports/vehicleReport/primaryUnservedArea.component';

import { SecondaryReport} from './reports/secondary/secondaryReport.component';
import { SecondaryliveTrackingReport} from './reports/secondary/secondaryLiveTracking.component';
import { SecondaryAssignmentComponent} from './reports/secondary/secondaryAssignment.componant';
import {FuelReportComponent} from './reports/fuel/fuel.component';
import {FuelPurchaseReportComponent} from './reports/fuel/fuelPurchase.component';
import {FuelLooseReportComponent} from './reports/fuel/fuelLoose.component';
import {FuelDistributionReportComponent} from './reports/fuel/fuelDistribution.component'; 
import {CollectionReportComponent} from './reports/uccReport/couponCollection.component';
import {AttendComponent} from './reports/attendance/attend.component';
import {AttendanceReportComponent} from './reports/attendance/attendance.component';

import {AttendanceDeatilComponent} from './reports/attendance/attendanceDetail.component';
import {ProjectSummaryComponent} from './dashboard/project/projectSummary.component';
//New UCC 
import {CrmUccComponent} from './crm/ucc/ucc.component';
import {GrnComponent} from './crm/ucc/grn/grnList.component';
import {CouponAssignComponent} from './crm/ucc/couponAssignment/couponAssignment.component'; 
import {CouponCollectionComponent} from './crm/ucc/couponCollection/couponCollection.component';
import {CouponReturnComponent} from './crm/ucc/couponReturn/couponReturn.component';
import {CouponMissingComponent} from './crm/ucc/missingCoupon/missingCoupon.component';
import { InventorySummaryComponent } from './crm/ucc/inventory/inventorySummary.component';
import { InventoryDetailComponent } from './crm/ucc/inventory/inventoryDetail.component';
import {CollectionReceivedComponent} from './crm/ucc/couponReceived/collectionReceived.component';
import {BulkCouponCollectionComponent} from './crm/ucc/bulkCouponCollection/bulkCouponCollection.component'; 
import {WmDispatchComponent} from './reports/mobilityReport/wmDispatch.component'; 
import {MileageReportComponent} from './reports/fuel/fuelMileage.component'; 
import {VehMaintStatusComponent} from './maintenance/vehicleMaintenance/vehicleMnt/vehMaintenanceStatus.component'; 
import { GaugeChartModule } from 'angular-gauge-chart'; 


@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    LoginComponent,
    UccComponent,

    ComplainComponent,
    ComplainDashBoardComponent,
    TargetDashBoardComponent,
	WasteProcessingComponent,
	AggregateComponent,
	SecondaryComponent,
	PrimaryComponent,
    AdminComponent,
    ProjectComponent,
    DashboardComponent,
	HomeboardComponent,
    AlarmComponent,
    AlarmFuelComponent,
    AlarmSummaryComponent,
    FuelAlertComponent,
    //Employee
    EmployeeComponent,
    EmpComponent,
    AreaComponent,
    BeatComponent,

   
    VehiclesComponent,
    mcgVehiclesComponent,
    SecondaryOpsComponent,
    VehComponent,
    StopComponent,
    MaptrackerComponent,
    AlertComponent,
    SearchPipe, 
    OrderBy,
    CRMComponent,
    ConsumerComponent,
    ConsumerListComponent,
    InvoiceComponent,
    InvoiceListComponent,
    PaymentComponent,
    PaymentListComponent,
    CreateInvoiceComponent,
    ComplainListComponent, 
    EntityComponent,
    EntityMapComponent, //Admin
    EntComponent,//Admin
    AddNewVehiclesComponent, 
    VehicleComponent,
    ReportsComponent,  
    UccReportsComponent,
    SidebarComponent,
    NavbarComponent,     
    HasPermissionDirective,
    NewConsumerDirective,
    CouponHistoryDirective,
    SuperAdminComponent, 
    ServerMonitoring,
    UsersComponent,   
    KccComponent,
    BulkCollectionReportComponent,
    CollectionAnalysisReport,
    CollectionSummaryComponent,
    GridContextMenuComponent,
    DropDownListFilterComponent,
    KccReportsComponent,
    KccSummaryReportComponent,
    KccCustomerReportComponent,
    KccDetailReportComponent,
    KccConsolidatedReportComponent,
    EntitySummaryReportComponent,
    EntitysComponent,
    MaintenanceComponent,
    LogbookComponent,
    VehicleMaintenanceComponent, 
    VehicleMaintMntComponent,
   // VehMaintenanceMasterComponent,
   // PartCategoryComponent,
   //Mobility Report
   MobilityReportComponent,
   ServiceReportComponent,
   SurveyReportComponent,
   MobilityComponent, 
   MobilityUserComponent,
   KhattaServiceReportComponent,
   CrmReportComponent,
   ComplainReportComponent,
   MappingReportComponent,
   VtsReportsComponent,
   TripReportComponent,
   DistanceComponent,
   VtsDailyReportComponent,
   VehicleReport,
   PrimaryVehicleReport,
   PrimaryAssignmentComponent,
   PrimaryliveTrackingReport,
   PrimaryVehicleTripReport,
   PrimaryUnservedAreaReport,
   SecondaryReport,
   SecondaryliveTrackingReport,
   SecondaryAssignmentComponent,
   //Plant report
   VehiclePlantComponent,
   MaterialInReportComponent,
   MaterialOutReportComponent,
   FuelReportComponent, 
   FuelPurchaseReportComponent,
   FuelLooseReportComponent,
   FuelDistributionReportComponent,
   CollectionReportComponent,
   AttendComponent,
   AttendanceReportComponent,
   AttendanceDeatilComponent,
   ProjectSummaryComponent,
   //New UCC (24-10-2018)
   CrmUccComponent,
   GrnComponent,
   CouponAssignComponent, 
   CouponCollectionComponent,
   CouponReturnComponent,
   CouponMissingComponent,
   InventorySummaryComponent,
   InventoryDetailComponent,
   CollectionReceivedComponent,
   BulkCouponCollectionComponent, 
   WmDispatchComponent, 
   MileageReportComponent,
   VehMaintStatusComponent,
   HrmsComponent,
   HrmsEmployeeComponent,
   TargetComponent,
   TargetMasterComponent,
  ],
  
  imports: [
    GaugeChartModule,
    MatInputModule,
    LightboxModule,
    DropDownListModule,
    DropDownsModule,
   // PDFExportModule,
    PopupModule,
    ExcelModule ,
    PDFModule,
    MenuModule,
    //ToolBarModule,
    GridModule,
    //DateInputsModule,
    MatDatepickerModule,
    BrowserModule,
	UiSwitchModule,
    FormsModule,
    HttpModule,
    HttpClientModule,
    RouterModule,
    AppRoutingModule,
    //LbdModule,
    NgSelectModule,
    NgDatepickerModule,
    MatFormFieldModule,
    BrowserAnimationsModule,
    MatChipsModule,
    //MatCardModule,
    MatProgressSpinnerModule,
    MatProgressBarModule,
  
    // imports firebase/firestore, only needed for database features
     // imports firebase/auth, only needed for auth features,
    
    MatNativeDateModule,
    MatSlideToggleModule,
    MatButtonToggleModule,
    MatProgressBarModule,
    ImageUploadModule ,//for Image upload;
    MatRadioModule, //For Radio button in employee Page
    MatCheckboxModule,
    AngularDateTimePickerModule,
    MyDateRangePickerModule ,
    ChartsModule,
    NgxSelectModule,
    //PopoverModule
 
  ],
  entryComponents: [],
  providers: [
    AlertService,
    AuthService,
    AuthGuard,
    Broadcaster,
    PagerService, 
    LoaderService,   
    {provide: LocationStrategy, useClass: HashLocationStrategy}
  ],
 
  bootstrap: [AppComponent]
})
export class AppModule{ 

}
