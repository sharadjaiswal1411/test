import { Component, OnInit } from '@angular/core';



@Component({
  selector: 'mobility',
  templateUrl: './mobility.component.html',
   
})
export class MobilityComponent implements OnInit { 
  constructor() { }
  ngOnInit(){
    } 
}
