

import { Component,ViewEncapsulation} from '@angular/core';
import { Http } from '@angular/http'
import { environment } from '../../../environments/environment';
import { AuthService } from '../../_services'; 
import { LoaderService } from '../../_services/loader.service'; 
import { process, State } from '@progress/kendo-data-query';
import { GroupDescriptor, DataResult } from '@progress/kendo-data-query';
import {GridDataResult,DataStateChangeEvent} from '@progress/kendo-angular-grid';
import { Observable } from 'rxjs/Observable';  
import { DomSanitizer, SafeStyle } from '@angular/platform-browser';
import * as _moment from 'moment';  
import * as _rollupMoment from 'moment'; 
const moment = _rollupMoment || _moment; 

declare var $: any; 
@Component({
    selector: 'khattaService',
    encapsulation: ViewEncapsulation.None,
    templateUrl: './khattaServiceReport.component.html', 
    styles: [`
      .k-grid .no-padding {
        padding: 0;
      }
        .whole-cell {
         display: block; 
         font-weight: bold;
         padding: 8px 13px;
       }
   `],
     
  })

  export class KhattaServiceReportComponent{ 
    public prjId:any; 
    public userId:any;
    public khattaReportList:any;
    public showLoader:Boolean;
    public firstColumn=[]; 
    public secondColumn= [];
    public currentDay:any;
    public currentMonth:any;
    public currMonthId:any; 
    public selectedValue:any;
    public state: State = { 
      filter: {
        logic: 'and',
        filters: []
      }
    };
    public groups: GroupDescriptor[] = [];
    public view: Observable<GridDataResult>;
    public gridView: DataResult;
    public groupChange(groups: GroupDescriptor[]): void {
      this.groups = groups;
      this.loadProducts();
    }
    private loadProducts(): void {
      this.gridDataKhServiceReport = process(this.khattaReportList, { group: this.groups }); 
    }  
      public monthList: Array<string> = ["January", "February", "March","April","May","June","July","August","September","October","November","December"]; 
      public gridDataKhServiceReport: GridDataResult 
      constructor(private auth : AuthService,private http: Http,private loaderService: LoaderService,private sanitizer: DomSanitizer) {     
      this.loaderService.status.subscribe((val: boolean) =>{
      this.showLoader = val;  
      }); 
     } 

    /*
     * Pick the headre Color
    */
    headerColorStyle(monthId)
    {  
        if(monthId==this.currentMonth)
        {
            let date = moment(new Date()).format('DD');
            this.currentDay=Number(date)  
        }
        else if(monthId>this.currentMonth){
            this.currentDay=Number(0) 
        } 
        else{
            this.currentDay=Number(32) 
        }  
    }
    

  /*
  * get vkhatta details
  */  
  getKhattaServiceList(monthId){   
        this.loaderService.display(true); 
        this.http.get(environment.apiUrl+'mobility/getKhattaServiceReport?prjid='+this.prjId+'&monthId='+monthId).subscribe(data =>{       
              this.khattaReportList=data.json();   
              if(this.khattaReportList.length>0){  
               this.gridDataKhServiceReport = process(this.khattaReportList, this.state);  
               this.loaderService.display(false);
               }  
               else{
                this.loaderService.display(false);
               } 
        });
    }  
    /*
     *styling grid cell 
    */
   public colorCode(code: string): SafeStyle {
    let result; 
    if(code == '0'){
        result = 'hsl(0, 100%, 90%)'; 
    }else if(code >= '1'){
        result = '#42f4cb';  
    }else{
        result = 'transparent'; 
    } 
    return this.sanitizer.bypassSecurityTrustStyle(result);
  } 
  
  /*
   *select Month ddl  
  */
  selectMonth(data){
       if(data=="January"){
        this.currMonthId=1
        this.getKhattaServiceList(this.currMonthId)
       }
       if(data=="February"){
        this.currMonthId=2
        this.getKhattaServiceList(this.currMonthId)
       }
       if(data=="March"){
        this.currMonthId=3
        this.getKhattaServiceList(this.currMonthId)
       }
       if(data=="April"){
        this.currMonthId=4
        this.getKhattaServiceList(this.currMonthId)
       }
       if(data=="May"){
        this.currMonthId=5
        this.getKhattaServiceList(this.currMonthId)
       }
       if(data=="June"){
        this.currMonthId=6
        this.getKhattaServiceList(this.currMonthId)
       }
       if(data=="July"){
        this.currMonthId=7
        this.getKhattaServiceList(this.currMonthId)
       }
       if(data=="August"){
        this.currMonthId=8
        this.getKhattaServiceList(this.currMonthId)
       }
       if(data=="September"){
        this.currMonthId=9
        this.getKhattaServiceList(this.currMonthId)
       }
       if(data=="October"){
        this.currMonthId=10
        this.getKhattaServiceList(this.currMonthId)
       }
       if(data=="November"){
        this.currMonthId=11
        this.getKhattaServiceList(this.currMonthId)
       }
       if(data=="December"){
        this.currMonthId=12
        this.getKhattaServiceList(this.currMonthId)
       } 
       this.headerColorStyle(this.currMonthId);
  } 
  
  
  selectDefaultMonth(){
    if(this.currentMonth==1){
      this.selectedValue = "January";
    }
    else if(this.currentMonth==2){
      this.selectedValue = "February";
    }
    else if(this.currentMonth==3){
      this.selectedValue = "March";
    }
    else if(this.currentMonth==4){
      this.selectedValue = "April";
    }
    else if(this.currentMonth==5){
      this.selectedValue = "May";
    }
    else if(this.currentMonth==6){
      this.selectedValue = "June";
    }
    else if(this.currentMonth==7){
      this.selectedValue = "July";
    }
    else if(this.currentMonth==8){
      this.selectedValue = "August";
    }
    else if(this.currentMonth==9){
      this.selectedValue = "September";
    }
    else if(this.currentMonth==10){
      this.selectedValue = "October";
    }
    else if(this.currentMonth==11){
      this.selectedValue = "November";
    }
    else{
      this.selectedValue = "December";
    } 
  } 
  
  public dataStateChange(state: DataStateChangeEvent): void { 
    this.state = state;
    this.gridDataKhServiceReport = process(this.khattaReportList, this.state);  
  } 
  
    ngOnInit(){
      this.prjId = this.auth.getAuthentication().projectId
      this.userId= this.auth.getAuthentication().id 
      this.currentMonth=new Date().getMonth()+1 
      this.selectDefaultMonth()
      this.headerColorStyle(this.currentMonth); 
      this.getKhattaServiceList(this.currentMonth)
    }
  }
