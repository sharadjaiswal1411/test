

import { Component, NgZone} from '@angular/core';
import { Http } from '@angular/http'
import { environment } from '../../../environments/environment';
import { AuthService } from '../../_services/index'; 
import { LoaderService } from '../../_services/loader.service';

import { process, State } from '@progress/kendo-data-query';
import { GroupDescriptor, DataResult } from '@progress/kendo-data-query';
import {GridDataResult,DataStateChangeEvent} from '@progress/kendo-angular-grid';
import { Observable } from 'rxjs/Observable'; 
 
import * as JSONEditor from 'jsoneditor';
declare var $: any; 
const distinctRole = data => data.filter((x, idx, xs) => xs.findIndex(y => y.ROLENAME === x.ROLENAME) === idx); 
const distinctStatus = data => data.filter((x, idx, xs) => xs.findIndex(y => y.STATUS === x.STATUS) === idx); 

@Component({
    selector: 'mobilityUser',
    templateUrl: './mobilityUser.component.html',  
     
  })


  export class MobilityUserComponent{ 
    userPermissionData:any;
    container:any;
    options:any;
    editor:any;
    DEVICEID:any;
    public prjId:any; 
    public userId:any;
    public mobilityUsersList:any;
    public showLoader:Boolean; 
    public roleList:any;
    public statusList:any;
    public usrId:any;
    public roleId:any;
    public statusId:any;
    public success=false;
    public error=false;
    public roleModal:any;
    public statusModal:any;
    roleRequired=false;
    statusRequired=false;
    MOBILE:any
    public state: State = { 
      filter: {
        logic: 'and',
        filters: []
      }
    };
    public groups: GroupDescriptor[] = [];
    public view: Observable<GridDataResult>;
    public gridView: DataResult;
    public groupChange(groups: GroupDescriptor[]): void {
      this.groups = groups;
      this.loadProducts();
    }
    public distinctRole: any[]
    public distinctStatus: any[]
    private loadProducts(): void {
      this.gridDataUsersList = process(this.mobilityUsersList, { group: this.groups }); 
    }
    public gridDataUsersList: GridDataResult 
      constructor(private auth : AuthService,private http: Http,private loaderService: LoaderService) {
      //this.maintenanceDate= new Date(); 
      this.loaderService.status.subscribe((val: boolean) =>{
      this.showLoader = val;
      }); 
     } 

  /*
  * get vehicles Details By Project Id
  */  
  getMobilityUsers(){   
        this.loaderService.display(true);
        this.http.get(environment.apiUrl+'mobility/getMobilityUsersList?prjid='+this.prjId).subscribe(data =>{       
              this.mobilityUsersList=data.json();  
              if(this.mobilityUsersList.length>0){ 
              this.distinctRole = distinctRole(this.mobilityUsersList)
              this.distinctStatus = distinctStatus(this.mobilityUsersList)  
               this.gridDataUsersList = process(this.mobilityUsersList, this.state);  
               this.loaderService.display(false);
               }              
             else if(this.mobilityUsersList==0){ 
               this.loaderService.display(false);
             }  
        });
    }

    public dataStateChange(state: DataStateChangeEvent): void { 
      this.state = state;
      this.gridDataUsersList = process(this.mobilityUsersList, this.state);  
      if (state && state.group) {   
        this.gridDataUsersList = process(this.mobilityUsersList, this.state);  
        this.distinctRole = distinctRole(this.mobilityUsersList)
        this.distinctStatus = distinctStatus(this.mobilityUsersList)  
      } 
    }


  /**
   * Get all Role By Project Id
  */
  getRole()
  {   
      this.http.get(environment.apiUrl+'admin/getAllStaffRoleNameByPrjId?prjid='+this.prjId).subscribe((data)=>{
      this.roleList=data.json(); 
    });
  }  

  openUserUpdateModal(data){
       this.roleModal=data.ROLEID
       this.statusModal=data.ISACTIVE 
       this.roleId=this.roleModal
       this.statusId=this.statusModal 
       this.usrId=data.ID;
       this.success=false;
       this.error=false;  
       this.statusRequired=false;
       this.roleRequired=false;
       $('#changeUserStatus').modal('show');  
    }
   
    /*
 * Bind Owner List drop down list 
*/
public bindStatusList()
{
this.statusList=
      [{  
      "ID":1,
      "VALUE":"ACTIVE", 
      },
      {  
        "ID":2,
        "VALUE":"INACTIVE", 
      }]
}  

/*
 * Select USER ROLE
*/
onSelectRole(data){  
 if(data!=null){
  this.roleId=data.ID 
  this.roleRequired=false;
 }
 else{
  this.roleRequired=true;
 }
}

/*
 *Select USER STATUS 
*/
onSelectStatus(data){ 
  if(data!=null){
    this.statusId=data.ID 
    this.statusRequired=false;
  }
  else{
    this.statusRequired=true;
  } 
}
 
/*
  Update User Details
*/
updateUserDetail(){ 
  if(this.roleModal==null){
    this.roleRequired==true;
    return;
  }
  else if(this.statusModal==null){
    this.statusRequired=true;
    return;
  }
  this.http.get(environment.apiUrl+'mobility/updateMobUserDetails?ID='+this.usrId+'&role='+this.roleId+'&status='+this.statusId).subscribe((data)=>{
    this.roleList=data.json();
    if(this.roleList.status=="ok") {
      this.success=true; 
      this.getMobilityUsers(); 
      setTimeout(()=>{
        $('#changeUserStatus').modal('hide'); 
      }, 2000); 
    }
    else{
      this.error=true;
    }  
  });

}


userPermission(data){
  console.log(data)
  this.DEVICEID  = data.DEVICEID
  this.http.get(environment.apiUrl+'mobility/mobilityPermission' + "?DEVICEID=" + data.DEVICEID).subscribe((data)=>{
       this.userPermissionData=data.json();
       console.log(this.userPermissionData.Permission_Json)
       this.editor.set(this.userPermissionData.Permission_Json);
       $("#UserEditModal").modal("show");
    })
}


locationPermission(data){
  console.log(data)
  this.MOBILE  = data.MOBILE
  this.http.get(environment.apiUrl +'mobility/locationPermission' + "?MOBILE=" + data.MOBILE).subscribe((data)=>{
       this.userPermissionData=data.json();
       ///console.log(this.userPermissionData)
       this.editor.set(this.userPermissionData);
       $("#userLocationModal").modal("show");
    })
}

setLocationPermission(){
  var json = this.editor.get();
  $("#save-loader").show()
  $("#save-loader").show()
  this.http.post(environment.apiUrl+'mobility/setLocationPermission' + "?MOBILE=" + this.MOBILE,json).subscribe((data)=>{
    $("#save-loader").hide()
 })
}
changeOptions(){
  this.editor.destroy();
  this.options.mode = this.options.mode =='tree' ? 'code' : 'tree';
  this.editor = new JSONEditor(this.container, this.options);
  this.editor.set(JSON.parse(this.userPermissionData.permissions));
 }

 editClaims(user)
 {   
     this.userPermissionData = user
     this.editor.set(JSON.parse(user.permissions));
     $("#UserEditModal").modal("show");
 }

 setPermission(){
  var json = this.editor.get();
  $("#save-loader").show()
  $("#save-loader").show()
  this.http.post(environment.apiUrl+'mobility/mobilityPermissionPost' + "?DEVICEID=" + this.DEVICEID,json).subscribe((data)=>{
    $("#save-loader").hide()
 }) 
}






getEntityMaster(){ 
  //maintenance/logbook?prjId= 
    this.http.get(environment.apiUrl+'mobility/getEntityMaster' + "?prjid=" + this.prjId).subscribe((data)=>{
    var json = data.json();
    console.log("data",json)
 })
}




    
    ngOnInit(){
      this.prjId = this.auth.getAuthentication().projectId
      this.userId= this.auth.getAuthentication().id 
      this.container = document.getElementById("jsoneditor");
      this.options = {};
      this.editor = new JSONEditor(this.container, this.options);
      this.getRole();
      this.bindStatusList()
      this.getMobilityUsers();
      this.getEntityMaster();
    }
  }
