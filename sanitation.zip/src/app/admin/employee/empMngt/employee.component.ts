import { Component,OnInit } from '@angular/core';
import {Http} from "@angular/http";
import { environment } from '../../../../environments/environment';
import { Broadcaster } from '../../../../environments/broadcaster';  
import { AuthService } from '../../../_services/index'; 
import { utils, write, WorkBook } from 'xlsx';  
import { saveAs } from 'file-saver'; 
import { LoaderService } from '../../../_services/loader.service';
import Swal from 'sweetalert2' 
declare var google:any; 
declare var $:any; 
export class Upload { 
  $key: string;
  file:File;
  name:string;
  url:string;
  progress:number;
  createdAt: Date = new Date(); 
  constructor(file:File) 
  {
    this.file = file;
  }
}

@Component({
  selector: 'emp-cmp',
  templateUrl: './employee.component.html',
  styleUrls: ['./employee.component.css']
})
export class EmployeeComponent implements OnInit{
  
  showLoader: boolean;
  public data:any;
  public Employeedata:any;
  public getUserMstData:any;
  selectedRow : Number;
  selectEmployeeMstrDetailsRow :Function;
  selectEmployeeAreaEntityDetailsRowData:Function; 
  public empUpdtData:any;
  public empId:any;
  public prjId:any;
  public empNameModel:any;
  public empCodeModel:any;
  public empGenderModel:any;
  public empMobileNo:any;
  public empEmailId:any;
  public empAddress1Model:any;
  public empAddress2Model:any;
  public empCityModel:any;
  public empStatusActive:any;
  public empStatusInActive:any; 
  public selectSalutationDdlmodel:any
  public selectGenderDdlmodel:any
  public empAddNameModel:any;
  public empAddCodeModel:any;
  public empAddGenderModel:any;
  public empAddMobileNo:any;
  public empAddEmailId:any;
  public empCorraddAddress1Model:any;
  public empPermaddAddress2Model:any;
  public empAddCityModel:any;
  public empAddStatusActive:any;
  public empAddStatusInActive:any; 
  public employeeSaluctionsJsonData:any;
  public employeeGenderJsonData:any;
  public saveEmpData:any;
  public entryDate:any;
  public updtDate:any;
  public imgUrl:any;
  public currentDate:any;
  public empUploadImgModel:any;
  public chkEmpCodeExist:any;

  //Message sections
  public empAddmessageStatus=false; 
  public checkEmpName=false;
  public checkEmpNameUpdt=false;
  public checkGenderName=false;
  public checkEmpCdStatus=false;
  public chkEmpEmailAddress=false;;
  public updtUserMaster=false; 
  public empAreaEntity=false;
  public empEntityAreaStatus=false;
  public saveEmployeeAreaAssignData=false; 
  public empRoleRoleCatStatus=false; 
  public saveStaffNameStatusSucess=false;
  public empAddErrorMessage=false; 
  public updtuserMstUpdtError=false;
  public vehAreaEntityModel:any;
  public empAreaAsignStatus:any
  public empAreaAssignDetails:any;
  public empRoleAssignDetails:any;
  public empAreaAssignData:any;
  public search:any;
  public showDialog:any; 
  public checkImageExtension=false;
  public showHideAreaLoadDiv=false; 
  public imageEmpAreaLoader:any; 

  //Staff role var
  public empAssignmtStaffRole:any;
  public roleNameId:any;
  public empStaffRoleModelddl:any;
  public empStaffRoleNameData:any;
  public empRoleAssignStaffData:any;
  public empStaffRoleNameDataModelDdl:any;
  public empStaffRoleId:any;
  public empRoleDeleteData:any; 
  public emproleId:any;
  public isSubmmit=false;
  public isEmpUpdate=false;
  public loading = false;
  public isEmpAreaEntSave=false;
  public isEmpRoleSave=true;
  public imageEmpStaffLoader:any;
  public showHideEmpCdStatus=false;
  public chooseFileUpdt=false;

  //Emp update Sections Variables
  public empNameModelUpdt:any;
  public empCodeModelUpdt:any;
  public selectGenderDdlmodelUpdt:any;
  public empMobileNoUpdt:any;
  public empAddEmailIdUpdt:any;
  public empAddEmailIdUpdtStatus=false;
  public empAddress1ModelUpdt:any;
  public empAddress2ModelUpdt:any;
  public empCityModelUpdt:any;
  public empIsActiveModelUpdt:any;
  public empIsActiveModelAdd:any;
  public empUploadImgModelUpdt:any;
  public empArealabelAssign:any;
  public empAreaAssignment:any;
  public EmployeeAreaModelDdl:any;
  public empAreaEntityModelDdl:any;
  public employeeStatusData:any;
  selectedFiles: FileList;
  currentUpload: Upload;
  public imageDownloadUrl:any;
  public downloadPath:any;
  public imagePathStatus:any; 
  public imagePath:any;
  public activeStatus:any;
  public employeeRecordNotFound=false;
  public userId:any;
  public empAreaAssignReNotFound=false;
  public empRoleAssignReNotFound=false;
  public empAreaId:any;
  public empSaveError=false;
  
   //To bind Gender Data
   public BindGenderDdldata()
   {
     this.employeeGenderJsonData=
     [{  
     "ID":1,
     "VALUE":"Male", 
     },
     {  
       "ID":2,
       "VALUE":"FeMale", 
     }]
   }
   public BindEmployeeStatus()
   {
     this.employeeStatusData=
     [{  
     "ID":1,
     "VALUE":"ACTIVE", 
     },
     {  
       "ID":2,
       "VALUE":"INACTIVE", 
     }]
   }    
constructor(private http: Http,private broadcaster: Broadcaster,private auth:AuthService,private loaderService: LoaderService){ 
    this.loaderService.status.subscribe((val: boolean) =>{
      this.showLoader = val;
    }); 
    this.selectEmployeeMstrDetailsRow = function(data,index){ 
     this.selectedRow = index;
     this.empId=data.ID;
     //this.getEmployeeAreaAssignmentDetails(this.empId) //To bind Area assignment Table on assignment button click event
     //this.getEmployeeRoleAssignmentDetailsByEmpId(this.empId) //To bind Employee Role assignment Table on assignment button click event
     this.empNameModelUpdt=data.EMPNAME; 
     this.empCodeModelUpdt=data.EMPCD;  
     this.empMobileNoUpdt=data.MOBILENO;
     this.empAddEmailIdUpdt=data.EMAIL;
     this.empAddress1ModelUpdt=data.ADDRESS1;
     this.empAddress2ModelUpdt=data.ADDRESS2;
     this.empCityModelUpdt=data.CITY; 
     this.empIsActiveModelUpdt=data.ISACTIVE;  
     if(this.empIsActiveModelUpdt=="Active")
      { 
      this.empIsActiveModelUpdt=1; 
      }
     if(this.empIsActiveModelUpdt=="Inactive")
      {
        this.empIsActiveModelUpdt=2; 
      }
     this.empUploadImgModelUpdt=data.imgurl;
     if(data.imgurl!="null"||data.imgurl!=null||data.imgurl!=undefined)
      {
        this.imagePath=data.imgurl;
      }
      if(data.imgurl=="null"||data.imgurl==null||data.imgurl==undefined)
      {
        this.imagePath="https://firebasestorage.googleapis.com/v0/b/ecogreen-citizen-app.appspot.com/o/static%2FUCC_Team_IMG%2FGGN%2Fblank_Profile.jpg?alt=media&token=7609609e-a8d8-4784-89f1-f0fe1a9e3245";
      } 
    }
  }  
  ngOnInit(): void 
  {    
    this.prjId = this.auth.getAuthentication().projectId 
    this.userId= this.auth.getAuthentication().id 
    this.getAllVehiclesAreaLable(this.prjId);
    this.getAllStaffRoleByPrjId(this.prjId)
    this.BindGenderDdldata(); 
    this.BindEmployeeStatus();
    this.selectGenderDdlmodel = this.employeeGenderJsonData[0].ID;//This Line to select Default Male Gender ib add employee DDl
    this.empIsActiveModelAdd=this.employeeStatusData[0].ID;
    this.getAllUserMasterDetails(); 
  } 
  //To bind the all city List
  GetAllIndianCities(){
     var inputAdd;
     var inputUpdt;
     var options = {
       types: ['(cities)'],
       componentRestrictions: {country: "in"}
      }; 
      inputAdd = document.getElementById('txtCity'); 
      inputUpdt = document.getElementById('txtCityUpdt'); 
      var autocompleteAdd = new google.maps.places.SearchBox(inputAdd);
      var autocompleteUpdt = new google.maps.places.SearchBox(inputUpdt)  
  }   

//To show the Add Master Details Modal popup windows. 
shoEmployeeAddModelPopup(){
  $("#userMasterAddModelPopup").modal("show");
  var empCode=new Date().getTime(); 
  if(this.prjId==1){
    this.empAddCodeModel="LKO"+empCode;
  }
  else if(this.prjId==2){
    this.empAddCodeModel="GGN"+empCode;
  }
  else if(this.prjId==3){
    this.empAddCodeModel="FBD"+empCode;
  }
  else{
    this.empAddCodeModel="GWL"+empCode;
  } 
  this.onBlurToCheckEmployeeCodeExist();
  this.showHideEmpCdStatus=false;
  this.GetAllIndianCities();
  this.selectGenderDdlmodel = this.employeeGenderJsonData[0].ID;//This Line to select Default Male Gender ib add employee DDl
  this.empIsActiveModelAdd=this.employeeStatusData[0].ID; 
    
}
 
//##########This method is used to Get The All Employee Deatails START#######################//
  getAllUserMasterDetails() {
    this.loaderService.display(true); 
    this.http.get(environment.apiUrl+'admin/getUserMasterDetailsByPrjId?Prjid='+this.prjId).subscribe((data)=>{
            this.Employeedata = data.json();  
            if(this.Employeedata.length==0){
              this.employeeRecordNotFound=true
            }else{
              this.employeeRecordNotFound=false
            } 
            this.loaderService.display(false);
    }); 
 } 
 //##########This method is used to Get The All Employee Deatails END#######################//

 //To check Employee Code availability from API
onBlurToCheckEmployeeCodeExist(){
  if(this.empAddCodeModel==undefined||this.empAddCodeModel==null||this.empAddCodeModel==''){ 
    this.showHideEmpCdStatus=false;
    this.isSubmmit=true;
    return
  } 
  this.showHideEmpCdStatus=true;   
  this.imagePathStatus="../../assets/img/loading.gif";
  this.http.get(environment.apiUrl+'admin/checkEmployeeCodeAvailability?EMPCD='+this.empAddCodeModel).subscribe((data)=>{   
    this.chkEmpCodeExist=data.json();
    if(this.chkEmpCodeExist[0].result=="Available"){  
      this.isSubmmit=false;
      this.showHideEmpCdStatus=true;
      this.imagePathStatus="../../assets/img/ok.png";
    }
    if(this.chkEmpCodeExist[0].result=="All ready exist"){  
      this.isSubmmit=true;
      this.showHideEmpCdStatus=true;
      this.imagePathStatus="../../assets/img/wrong.jpg";
    }   
  }) 
}  
//To select The Upload file then deleted the previous File in add employee Management
detectFiles(event){
     this.selectedFiles = event.target.files; 
     if ( /\.(jpe?g|png)$/i.test(this.selectedFiles[0].name) === false ){
      this.checkImageExtension=true;
      return;
     }else{
      this.checkImageExtension=false;
     }
} 
//#####################Upload Image on Fire Base###############################################// 
onClickToSaveUserMasterDetails(){ 
  if(this.empAddNameModel==null||this.empAddNameModel==''||this.empAddNameModel==undefined){
    this.checkEmpName=true;
    return;
  }
  if(this.selectGenderDdlmodel==null||this.selectGenderDdlmodel==undefined||this.selectGenderDdlmodel==''){
    this.checkGenderName=true;
    return;
  }
  if(this.empAddCodeModel==null||this.empAddCodeModel==undefined||this.empAddCodeModel==''){
    this.checkEmpCdStatus=true;
    return;
  }  
  if(this.chkEmpCodeExist[0].result=="All ready exist"){  
    alert('Please Choose Other Employee Code');
    return;
  }   
    this.downloadPath="https://firebasestorage.googleapis.com/v0/b/ecogreen-citizen-app.appspot.com/o/static%2FUCC_Team_IMG%2FGGN%2Fblank_Profile.jpg?alt=media&token=7609609e-a8d8-4784-89f1-f0fe1a9e3245";
    this.saveEmployeeDetails(); 

}
//To Save Employee Details
saveEmployeeDetails(){ 
  var empStatus;
  var empGenderName; 
  this.isSubmmit=true; //disable the button after the submit button click
  var city=$("#txtCity").val()  
  this.currentDate=new Date(); 
  this.loaderService.display(true); 
  if(this.empIsActiveModelAdd==1){empStatus=1;}if(this.empIsActiveModelAdd==2||this.empIsActiveModelAdd==null||this.empIsActiveModelAdd==undefined){empStatus=0;} 
  if(this.selectGenderDdlmodel==1){empGenderName="M";}if(this.selectGenderDdlmodel==2){empGenderName="F";}   
  var jsonEmpSaveData={   
    "PRJID":this.prjId,
    "EMPNAME":this.empAddNameModel,
    "EMPCD":this.empAddCodeModel,
    "SALUTATION":'MR',
    "GENDER":empGenderName?empGenderName:null,
    "MOBILENO":this.empAddMobileNo?this.empAddMobileNo:null,
    "EMAIL":this.empAddEmailId?this.empAddEmailId:"",
    "ADDRESS1":this.empCorraddAddress1Model?this.empCorraddAddress1Model:"",
    "ADDRESS2":this.empPermaddAddress2Model?this.empPermaddAddress2Model:"",
    "CITY":city?city:"",
    "ISACTIVE":empStatus?empStatus:0, 
    "ENTRYDT":this.currentDate, 
    "imgurl":this.downloadPath?this.downloadPath:null
  } 
  this.http.post(environment.apiUrl+'admin/saveEmployeeMasterDetails',jsonEmpSaveData).subscribe((data)=>{  
    this.empAddmessageStatus=true;
    this.getAllUserMasterDetails(); 
    this.showHideEmpCdStatus=false;  
    setTimeout(() =>{      
        this.empAddmessageStatus=false;  
        this.clearEmployeeControlAterSave();  
       },1000); 
      },error=>{ 
        this.clearEmployeeControlAterSave();
        this.empAddErrorMessage=true;  
      });
    this.loaderService.display(false);   
}
//This method is used to clear the control after saved the Employee data
clearEmployeeControlAterSave(){
this.empAddNameModel=undefined;
this.checkEmpName=false;
this.checkGenderName = false;
this.checkEmpCdStatus = false
this.chkEmpEmailAddress = false;
this.showHideEmpCdStatus =false;
this.empAddCodeModel=undefined;
this.empAddMobileNo=undefined;
this.empAddEmailId=undefined;
this.empCorraddAddress1Model=undefined;
this.empPermaddAddress2Model=undefined;
this.empAddCityModel=undefined;
this.empUploadImgModel=undefined;
if(this.selectedFiles){
    this.currentUpload.name="";
    this.currentUpload.progress=0;
  }
} 


//to validate the choose image files in employee Update
chosseFileValidation(event){
  this.selectedFiles = event.target.files; 
  if ( /\.(jpe?g|png)$/i.test(this.selectedFiles[0].name) === false ){
   this.chooseFileUpdt=true;
   return;
  } else{
   this.chooseFileUpdt=false;
  }
}

//To Update The Employee Details
onClickToUpdateUserMasterDetails(){   
    this.downloadPath=this.empUploadImgModelUpdt;
    this.updateEmployeeDetails();  
  
} 
//On click to update model pop up button and update the User Master Details.
updateEmployeeDetails(){   
  this.currentDate=new Date();
  var empStatus:any 
  var city=$("#txtCityUpdt").val()  
  this.isEmpUpdate=true; 
  if(this.empNameModelUpdt==null||this.empNameModelUpdt==undefined||this.empNameModelUpdt==""||this.empNameModelUpdt=="null"){  
    this.checkEmpNameUpdt=true;
    return;
  }else{
    this.checkEmpNameUpdt=false; 
  }
  if(this.empIsActiveModelUpdt==true){empStatus=1;}
  if(this.empIsActiveModelUpdt==false||this.empIsActiveModelUpdt==null||this.empIsActiveModelUpdt==undefined){empStatus=0;} 
  var jsonEmpUpdtData={  
    "ID":this.empId,
    "PRJID":this.prjId,
    "EMPNAME":this.empNameModelUpdt,
    "EMPCD":this.empCodeModelUpdt,
    "SALUTATION":'MR', 
    "MOBILENO":this.empMobileNoUpdt?this.empMobileNoUpdt:null,
    "EMAIL":this.empAddEmailIdUpdt?this.empAddEmailIdUpdt:"",
    "ADDRESS1":this.empAddress1ModelUpdt?this.empAddress1ModelUpdt:"",
    "ADDRESS2":this.empAddress2ModelUpdt?this.empAddress2ModelUpdt:"",
    "CITY":city?city:"",
    "ISACTIVE":empStatus?empStatus:0,  
    "UPDTEDT":this.currentDate,
    "imgurl":this.downloadPath    
  }  
    this.http.post(environment.apiUrl+'admin/updateUserMasterDetails',jsonEmpUpdtData).subscribe((data)=>{ 
      this.updtUserMaster=true;
      this.updtuserMstUpdtError=false;
      this.getAllUserMasterDetails(); 
      setTimeout(() =>{ 
          this.updtuserMstUpdtError=false;
          this.updtUserMaster=false; 
          this.getUserMstData=data.json(); 
          $("#userMasterUpdtModelPopup").modal("hide");
          this.isEmpUpdate=false;
          this.clearEmployeeControlAterUpdate();
         },1000); 
        },
        error=>
        {
          this.clearEmployeeControlAterUpdate();
          this.updtuserMstUpdtError=true; 
          this.isEmpUpdate=true; 
       });
} 
//To clear The Control After Update 
clearEmployeeControlAterUpdate(){
this.empNameModelUpdt=null;
this.empCodeModelUpdt=null;
this.empMobileNoUpdt=null;
this.empAddEmailIdUpdt=null;
this.empAddress1ModelUpdt=null;
this.empAddress2ModelUpdt=null;
this.empCityModelUpdt=null;
this.empUploadImgModelUpdt=null; 
 if(this.selectedFiles){
   this.currentUpload[0].name="";
   this.currentUpload[0].progress=0;
 } 
} 

 
  //Get the All vehicles Area label details.
  getAllVehiclesAreaLable(prjId){  
   this.http.get(environment.apiUrl+'admin/getAllVehicalAreaByPrjId?prjid='+this.prjId).subscribe((data)=>{
     setTimeout(() => {
       this.empArealabelAssign=data.json();  
     }, 1000);  
 });
 }  

 //****************************************Area And Staff assignment Sections*************************** */

//To click The assignmnet button open the Area assignment Model popup
// areaEmpStaffAssignment(){ 
//   this.isEmpAreaEntSave=true;
//   this.isEmpRoleSave=true;
//   this.showHideAreaLoadDiv=false; 
//   $("#myEmployeeAssignmtModal").modal("show");
//  }

 //to get Oem Id on select Change event
 OnChangeEmployeeGetEntity(){  
   var OemId;
   OemId=this.EmployeeAreaModelDdl;  
   this.getAllVehiclesAreaEntityByOemId(OemId,this.prjId); 
   if(this.EmployeeAreaModelDdl==null||this.EmployeeAreaModelDdl==undefined){
    this.empAreaEntity=true; 
    this.isEmpAreaEntSave=true; 
    return; 
   } 
   if(this.EmployeeAreaModelDdl!=null||this.EmployeeAreaModelDdl!=undefined){
    this.empAreaEntity=false; 
    this.isEmpAreaEntSave=true; 
   }  
 }
 //on Change to Get Entity ID Check Employee Assignment For this particular Locations.
 OnChangeToGetEntityId(){ 
  if(this.empAreaEntityModelDdl==null||this.empAreaEntityModelDdl==undefined||this.EmployeeAreaModelDdl==null||this.EmployeeAreaModelDdl==undefined){  
    this.empEntityAreaStatus=false;
    this.showHideAreaLoadDiv=false;
    this.isEmpAreaEntSave=true; 
    return;  
  }
  this.showHideAreaLoadDiv=true;
  this.imageEmpAreaLoader="../../assets/img/loading.gif";
   this.http.get(environment.apiUrl+'admin/getEmployeeAssignAvailability?EMPID='+this.empId+'&ENTITYID='+this.empAreaEntityModelDdl).subscribe((data)=>{ 
      this.empAreaAsignStatus=data.json(); 
      if(this.empAreaAsignStatus[0].result=="Available"){
        this.isEmpAreaEntSave=false; 
        this.showHideAreaLoadDiv=true;
        this.imageEmpAreaLoader="../../assets/img/ok.png";
      }
      if(this.empAreaAsignStatus[0].result=="Already exists"){
        this.isEmpAreaEntSave=true; 
        this.showHideAreaLoadDiv=true;
        this.imageEmpAreaLoader="../../assets/img/wrong.jpg";
      } 
   }); 
 } 
   //Get the All vehicles/Employee Assign Area details to bind the Drop downlist
   getAllVehiclesAreaEntityByOemId(OemId,prjId){  
    this.http.get(environment.apiUrl+'admin/getAllVehicalAreaEntityByOemId?oemid='+OemId+'&PRJID='+this.prjId).subscribe((data)=>{
      setTimeout(() => {
        this.empAreaAssignment=data.json();  
      }, 1000);  
  });
  } 
  
//getAllAreaAssignmentDetails(selectPrjId)(Bind Area Assignemnet Grid)
getEmployeeAreaAssignmentDetails(empId){ 
  this.http.get(environment.apiUrl+'admin/getEmployeeAreaAssignmentDetailsByEmpId?EMPID='+this.empId).subscribe((data)=> { 
         this.empAreaAssignDetails = data.json(); 
         if(this.empAreaAssignDetails.length==0){
          this.empAreaAssignReNotFound=true;
         }else{ 
           this.empAreaAssignDetails=null
           this.empAreaAssignReNotFound=false; 
         } 
  }); 
}  
 
  //To Select The Employee Area Assignement ID on select 
  setClkSelectStaffEmployeeAreaDetailsRowData(){
    this.selectEmployeeAreaEntityDetailsRowData = function(empAreaAssignDetails){  
      this.empAreaId=empAreaAssignDetails.ID;  
    } 
  } 

 
  
  //To save The Employee Details into The EMPENTITYMAP Table
  onClickToSaveEmployeeEntityDeta(){ 
    this.currentDate=new Date();
    var empStatus;
    this.isEmpAreaEntSave=true;
    if(this.empIsActiveModelUpdt==true){empStatus=1;} 
    if(this.EmployeeAreaModelDdl==null||this.EmployeeAreaModelDdl==undefined||this.EmployeeAreaModelDdl==""||this.EmployeeAreaModelDdl=="null"){ 
      this.empAreaEntity=true;
      this.isEmpAreaEntSave=true;
      return;
    } 
    if(this.empAreaAsignStatus[0].result=="Already exists"){
      alert('This Employee is alreadt Assign For This Location');
      return;
    }  
  var jsonEmpAssignData={  
    "EMPID":this.empId, 
    "ENTITYID":this.empAreaEntityModelDdl,  
    "ISACTIVE":empStatus?empStatus:0, 
    "ENTRYDT":this.currentDate,
    "USERID":this.userId 
  } 
  this.loaderService.display(true);  
    this.http.post(environment.apiUrl+'admin/saveEmployeeAssignDetails',jsonEmpAssignData).subscribe((data)=>{ 
      this.saveEmployeeAreaAssignData=true; 
      this.getEmployeeAreaAssignmentDetails(this.empId);
      this.EmployeeAreaModelDdl=undefined;
      this.empAreaEntityModelDdl=undefined;
      setTimeout(() =>{  
         this.empAreaAssignData=data.json(); 
         this.saveEmployeeAreaAssignData=false; 
         this.showHideAreaLoadDiv=false;
         },1000); 
     });
     this.loaderService.display(false); 
  }

 
  //Get the All vehicles Area label details.
  getAllStaffRoleByPrjId(prjId){   
   this.http.get(environment.apiUrl+'admin/getAllStaffRoleNameByPrjId?prjid='+this.prjId).subscribe((data)=>{
     setTimeout(() => {
       this.empAssignmtStaffRole=data.json();  
     }, 1000);  
 });
 } 
 //To select The Role Name ID on select Role Catogery Drop down list.
 OnChangeToSelectStaffRoleName(){
    if(!this.empStaffRoleModelddl){
      this.empRoleRoleCatStatus=true;
      this.isEmpRoleSave=true; 
      return;
    }else{ 
      this.empRoleRoleCatStatus=false;
      this.isEmpRoleSave=false; 
    }
  this.roleNameId=this.empStaffRoleModelddl; 
  this.getAllStaffNameByRoleId(this.roleNameId)
 } 

 
 //Get the All Employee Role Name Area label details.(bind Role Name ddl)
 getAllStaffNameByRoleId(roleNameId){  
  this.http.get(environment.apiUrl+'admin/getAllStaffNameByRoleId?roleid='+this.roleNameId).subscribe((data)=>{
    setTimeout(() => {
      this.empStaffRoleNameData=data.json();  
    }, 1000);  
});
}  

//This Method Is use to Download the Vehicles Report into Excel File 
importVehiclesExcelReport(Employeedata)
{
  const ws_name = 'EmployeeReport';
  const wb: WorkBook = { SheetNames: [], Sheets: {} };
  const ws: any = utils.json_to_sheet(Employeedata);
  wb.SheetNames.push(ws_name);
  wb.Sheets[ws_name] = ws;
  const wbout = write(wb, { bookType: 'xlsx', bookSST: true, type: 
'binary' });
saveAs(new Blob([this.s2ab(wbout)], { type: 'application/octet-stream' }), 'exported.xlsx');
}
s2ab(s) 
  {
    const buf = new ArrayBuffer(s.length);
    const view = new Uint8Array(buf);
    for (let i = 0; i !== s.length; ++i) {
      view[i] = s.charCodeAt(i) & 0xFF;
    };
    return buf;
  }
 


Update(){  
  $('showHideProgressDiv').hide();
  $("#userMasterUpdtModelPopup").modal("show");
  this.GetAllIndianCities();  
}
 

 

//===================================================Validations Sections START=========================================//
 onBlurToCheckEmployeeNameUpdt()
 { 
   if(this.empNameModelUpdt==null||this.empNameModelUpdt==undefined||this.empNameModelUpdt==''||this.empNameModelUpdt=='null')
   {
     this.checkEmpNameUpdt=true;  
     return;
   }
   else
   {
     this.checkEmpNameUpdt=false;  
  } 
 }

onBlurToCheckEmployeeName()
{
  if(this.empAddNameModel==undefined||this.empAddNameModel==null||this.empAddNameModel=='')
  {
    this.checkEmpName=false;
    this.isSubmmit=true;
    return;
  }
  else
  {
    this.isSubmmit=false; 
  }
}

//To check The Email Address Validations;
onBlurToCheckEmailAddress() 
{
  var txtEmailData = this.empAddEmailId; 
  var atpos = txtEmailData.indexOf("@");
  var dotpos = txtEmailData.lastIndexOf(".");
  if (atpos<1 || dotpos<atpos+2 || dotpos+2>=txtEmailData.length) 
  { 
      this.chkEmpEmailAddress=true;
      return;
  }
  else
  {
    this.chkEmpEmailAddress=false;
  }
} 

//To check The Email Address Validations;
onBlurToCheckEmailAddressUpdt() 
{
  var txtEmailDataUpdt = this.empAddEmailIdUpdt; 
  var atpos = txtEmailDataUpdt.indexOf("@");
  var dotpos = txtEmailDataUpdt.lastIndexOf(".");
  if (atpos<1 || dotpos<atpos+2 || dotpos+2>=txtEmailDataUpdt.length) 
  {  
      this.empAddEmailIdUpdtStatus=true;
      return;
  }
  else
  { 
    this.empAddEmailIdUpdtStatus=false;
  }
}  
  
//Select Gender Drop downlist Selections
onChangeToSelectGenderDdlTitle()
{  
  if(this.selectGenderDdlmodel==null||this.selectGenderDdlmodel==undefined||this.selectGenderDdlmodel=='')
  {
    this.checkGenderName=true;
    // this.isSubmmit=true;
    return;
  }
  if(this.selectGenderDdlmodel!=null||this.selectGenderDdlmodel!=undefined && (this.empAddCodeModel!=null||this.empAddCodeModel!=undefined||this.empAddCodeModel!=''))
  {
    this.checkGenderName=false; 
    // this.isSubmmit=false;
  }
} 
//Mobile Number Avaibility from data Base
public restrictNumericForVtsMobileNo(e) 
{
  let input;
  var inputlen;
  if (e.metaKey || e.ctrlKey) {
    return true;
  }
  if (e.which === 32) {
   return false;
  }
  if (e.which === 0) {
   return true;
  }
  if (e.which < 33) {
    return true;
  }
  input = String.fromCharCode(e.which); 
  return !!/[\d\s]/.test(input);
 }
 


 
 /*
  * Delete Employee Details
  */
 deleteModalPopup(data){  
  var empId=data.ID 
  Swal({
    title: "Are You sure to delete this employee details ?", 
    type: 'warning',
    showCancelButton: true,
    confirmButtonColor: '#3085d6',
    cancelButtonColor: '#d33',
    confirmButtonText: 'Yes, Convert it!'
  }).then((result) => {
    if (result.value) { 
      this.http.get(environment.apiUrl+'admin/deleteEmployeeMasterDetails?ID='+empId).subscribe((data)=>{  
          var respStatus = data.json()  
          if (respStatus.status == "ok") {
            this.getAllUserMasterDetails();
            Swal( 
              "Employee deleted successfully.",
              'success'
               ) 
              } else{ 
              Swal(
              "Error during employee deletion.",
              'error'
              ) 
          }
        });
    }
  })
}   

/*
 * get Employee Details
 */
areaEmpStaffAssignment(data){
  $("#myEmployeeAssignmtModal").modal("show"); 
  var empId=data.ID
  this.empRoleAssignment(empId)
}

/*
 * set/Assignment Employee Role 
 */
empRoleAssignment(empId){ 
  this.http.get(environment.apiUrl+'admin/getEmployeeRoleAssignmentDetailsByEmpId?EMPID='+empId).subscribe((data)=> { 
         this.empRoleAssignDetails = data.json(); 
         if(this.empRoleAssignDetails.length==0) {
          this.empRoleAssignReNotFound=true;
         }
         else{
          this.empRoleAssignReNotFound=false;
         } 
  }); 
}  

/*
* Delete Assigned Role
 */
saveRoleAssigned(){ 
  this.currentDate=new Date();
  var empStatus; 
  this.isEmpRoleSave=true;  
  if(this.empIsActiveModelUpdt==true){empStatus=1;} 
  if(this.empStaffRoleModelddl==null||this.empStaffRoleModelddl==undefined||this.empStaffRoleModelddl==""||this.empStaffRoleModelddl=="null"){ 
    this.empRoleRoleCatStatus=true; 
    this.isEmpRoleSave=true; 
    return;
  } 
  var roleAssigned={  
    "EMPID":this.empId, 
    "ROLEID":this.roleNameId,  
    "USERID":this.userId,
    "STATUS":1,
  }  
   this.http.post(environment.apiUrl+'admin/saveRoleAssigned',roleAssigned).subscribe((data)=>{  
    this.empStaffRoleModelddl=null;
    this.empStaffRoleNameDataModelDdl=null; 
    var statusCode=data.json().status;  
    this.empRoleAssignment(this.empId)  
    if(statusCode=="200"){
      this.empSaveError=false;;
      this.saveStaffNameStatusSucess=true;
      setTimeout(() => 
      {  
       this.isEmpRoleSave=false; 
       this.saveStaffNameStatusSucess=false; 
      },2000);  
    }else{
     this.empSaveError=true;
     this.saveStaffNameStatusSucess=false; 
      } 
   });
}   

 


/*
*  Delete Assigned Role
*/
deleteEmpRoleAssigned(data){ 
  this.emproleId=data.roleid;
  var assignedRole=
  {  
    "EMPID":this.empId, 
    "ROLEID":this.emproleId,  
    "USERID":this.userId,
    "STATUS":0,
  } 
  Swal({
    title: "Are You sure to remove this employee Role ?", 
    type: 'warning',
    showCancelButton: true,
    confirmButtonColor: '#3085d6',
    cancelButtonColor: '#d33',
    confirmButtonText: 'Yes, Convert it!'
  }).then((result) => {
    if (result.value) { 
      this.http.post(environment.apiUrl+'admin/saveRoleAssigned',assignedRole).subscribe((data)=>{  
           this.empStaffRoleModelddl=null;
           this.empStaffRoleNameDataModelDdl=null; 
           var statusCode=data.json().status;  
          if (statusCode == "200") {
            this.empRoleAssignment(this.empId)  
            Swal( 
              "Employee Role Removed successfully.",
              'success'
               ) 
              } else{ 
              Swal(
              "Error during employee Role deletion.",
              'error'
              ) 
          }
        });
    }
  })
} 



  

}
