import { Component } from '@angular/core';
import {HttpClient } from '@angular/common/http'; 
 

@Component({
  selector: 'emp',
  templateUrl: './emp.component.html',  
})

export class EmpComponent {
 
  constructor(private http: HttpClient) { 
  }  
  ngOnInit() 
  { 
    
  }

}
 