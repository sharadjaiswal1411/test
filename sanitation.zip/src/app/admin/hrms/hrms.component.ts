import { Component } from '@angular/core';
import {HttpClient } from '@angular/common/http'; 
import { AuthService } from '../../_services'; 

@Component({
  selector: 'Hrms',
  templateUrl: './hrms.component.html',  
})

 export class HrmsComponent {
 public prjId:any
 public userId:any
  constructor(private http: HttpClient,private auth : AuthService) { 
  }  
  ngOnInit() 
  { 
     
  }

}
 