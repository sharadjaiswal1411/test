import { Component,OnInit } from '@angular/core';
import {Http} from "@angular/http";
import { environment } from '../../../../environments/environment'; 
import { AuthService } from '../../../_services/index'; 
import { LoaderService } from '../../../_services/loader.service'; 
import { count } from 'rxjs/operator/count';
import { utils, write, WorkBook } from 'xlsx';  
import { saveAs } from 'file-saver';

declare var $: any;
@Component({
  selector: 'Hrms',
  templateUrl: './hrmsEmployee.component.html', 
})
export class HrmsEmployeeComponent implements OnInit{  
  employeeData:any;
  prjId:any;
  userId:any;
  userName:any;
  employeeCard:any
  showLoader: boolean;
  categoryList:any;
  departmentList:any;
  ddlZoneList:any;
  ddlWardList:any;
  empRoleList:any;
  zoneId:any;
  zoneName:any;
  wardId:any;
  wardName:any;
  roleId:any;
  roleName:any;
  empName:any;
  empFatherName:any;
  deptName:any;
  categoryName:any;
  zone:any;
  ward:any;
  location:any;
  empRole:any;
  remark:any;
  empCode:any;
  empId:any;
  empAssignDate:any;
  responceMsg:any;
  assignSuccess=false;
  assignFail=false;
  isbtnDisable=false
  deptId:any;
  total:any;
  allotted:any;
  unallotted:any;
  search:any;
  currentId:any;
  constructor(private http: Http,private auth:AuthService,private loaderService: LoaderService){
    this.loaderService.status.subscribe((val: boolean) =>{
      this.showLoader = val;
    });
    this.empAssignDate=new Date();   
      this.total=0,
      this.allotted=0,
      this.unallotted=0 
  }  
  
  
  /*
   Get Employee List
   */
  getHrmsEmployeeList(prjId,emptype) { 
    this.loaderService.display(true); 
    this.http.get(environment.apiUrl+'attendance/getHrmsEmpList?Prjid='+prjId+"&status="+emptype+"").subscribe((data)=>{
            this.employeeData = data.json(); 
            if(this.employeeData.length>0) {  
              this.loaderService.display(false);
            }else{
              this.employeeData=null;
              this.loaderService.display(false);
            } 
    }); 
 }


 selectDepartment(data){
  this.deptName=data.ID
 }



 /*
   Get Employee List
   */
  empCategoryList() { 
    this.loaderService.display(true);
    this.http.get(environment.apiUrl+'attendance/empCategoryList').subscribe((data)=>{
            this.categoryList = data.json();  
    }); 
 }
 
 selectCategory(data){
  this.categoryName=data.ID 
 }



   /*
   Get Employee List
   */
  empDepartmentList(prjid) {  
    this.http.get(environment.apiUrl+'attendance/empDepartmentList?prjId='+prjid).subscribe((data)=>{
            this.departmentList = data.json(); 
            console.log("dept",this.departmentList) 
    }); 
 }


/*
Get Zone By Prj Id
*/
 getZoneByProject(prjid){    
  this.http.get(environment.apiUrl + 'consumer/getZoneByProject?prjid='+prjid+'&oemid=7').subscribe(data =>{ 
           this.ddlZoneList= data.json(); 
      }); 
} 

/*
Get Ward By Zone Id
*/

selectZone(data){ 
    this.zoneId=data.id
    this.zoneName=data.entityname
    this.http.get(environment.apiUrl + "consumer/getZoneByProject?prjid="+this.prjId+"&oemid=8&entityid="+data.id).subscribe(data =>{ 
    this.ddlWardList= data.json(); 
  }); 
}

getWardByZone(entityId){
  this.http.get(environment.apiUrl + "consumer/getZoneByProject?prjid="+this.prjId+"&oemid=8&entityid="+entityId).subscribe(data =>{ 
    this.ddlWardList= data.json(); 
  }); 
}


selectWard(data){
 this.wardId=data.id
 this.wardName=data.entityname
}

empAlloted(empTypeData){ 
  this.getHrmsEmployeeList(this.prjId,empTypeData) 
}


  
  getAllStaffRoleByPrjId(prjId){   
    this.http.get(environment.apiUrl+'admin/getAllStaffRoleNameByPrjId?prjid='+prjId).subscribe((data)=>{ 
        this.empRoleList=data.json(); 
    });
  } 


 
  selectRole(data){ 
    if(data){
      this.isbtnDisable=false;
      this.roleId=data.ID
      this.roleName=data.ROLENAME
    }
  }




 /*
  * Edit Employee Details
  */  
 editInfoBtn(data){ 
   this.currentId=data.Id  
   this.assignSuccess=false
   this.assignFail=false
   this.isbtnDisable=false; 
   this.deptName=data.DEPTID
   this.categoryName=data.CATID
   this.zone=data.ZONEID
   this.ward=data.WARDID
   this.empRole=data.ROLEID
   this.empId=data.EmployeeId
   this.empCode=data.EmployeeCode
   this.empName=data.EmployeeName
   this.empFatherName=data.FatherName 
   this.location=data.Location  
   this.remark=data.REMARK
   $('#EditInfoModal').modal('show');
   this.getWardByZone(this.zone)
 } 

 
 saveEmployeeAssignment(){ 
  this.isbtnDisable=true;
  if(!this.deptName){
    alert("Department is Required!")
    this.isbtnDisable=false;
    return;
  }
  else if(!this.categoryName){
    alert("Employee Category is Required!")
    this.isbtnDisable=false;
    return;
  } 
  var assigneJson={  
    "ID":this.currentId,
    "PRJID":this.prjId,
    "EMPID":this.empId,
    "DEPTID":this.deptName,
    "CATID":this.categoryName,
    "ZONEID":this.zoneId,
    "ZONENAME":this.zoneName,
    "WARDID":this.wardId,
    "WARDNAME":this.wardName,
    "LOCATION":this.location,
    "REMARK":this.remark,
    "ROLEID":this.roleId,
    "ROLENAME":this.roleName,
    "ASSIGNDATE":this.empAssignDate,
    "USERID":this.userId,
    "USERNAME":this.userName,
    "FATHERNAME":this.empFatherName, 
    "ALLOTEDSTATUS":1
    }  
    this.http.post(environment.apiUrl+'attendance/saveEmployeeAssignment',assigneJson).subscribe((data)=>{ 
      var statusCode=data.json(); 
      if(statusCode.output[0].RESPONSECODE=="200"){ 
       this.assignSuccess=true
       this.responceMsg=statusCode.output[1].RESPONSEMESSAGE
       this.getAssignEmpCount(this.prjId)
       this.getHrmsEmployeeList(this.prjId,'All') 
       setTimeout(()=>{
         this.assignSuccess=false
         $('#EditInfoModal').modal('hide');
         this.isbtnDisable=false;
      }, 1500);
      }else{
        this.assignSuccess=false;
        this.assignFail=true
        this.isbtnDisable=false;
        this.responceMsg=statusCode.output[1].RESPONSEMESSAGE 
      }
  });
 } 

 /*
  * Clear all Fields
  */
 clearAllFields(){  
  this.deptName=null;
  this.categoryName=null;
  this.zone=null;
  this.ward=null;
  this.empRole=null;
  this.remark=null;
 }


  
 getAssignEmpCount(prjId){   
  this.http.get(environment.apiUrl+'attendance/assignEmployee?prjid='+prjId).subscribe((data)=>{ 
      var allotedCount=data.json(); 
      if(allotedCount.length>0){ 
        this.total=allotedCount[0].Total
        this.allotted=allotedCount[0].Alloted
        this.unallotted=allotedCount[0].UnAlloted
      } 
  });
} 



employeeExcel(data){
  const ws_name = 'EmployeeReport';
  const wb: WorkBook = { SheetNames: [], Sheets: {} };
  const ws: any = utils.json_to_sheet(data);
  wb.SheetNames.push(ws_name);
  wb.Sheets[ws_name] = ws;
  const wbout = write(wb, { bookType: 'xlsx', bookSST: true, type:'binary' });
  saveAs(new Blob([this.s2ab(wbout)], { type: 'application/octet-stream' }), 'exportedEmpReport.xlsx');
  }s2ab(s){
    const buf = new ArrayBuffer(s.length);
    const view = new Uint8Array(buf);
    for (let i = 0; i !== s.length; ++i) {
      view[i] = s.charCodeAt(i) & 0xFF;
    };
    return buf;
  }

  ngOnInit(): void{    
    this.prjId = this.auth.getAuthentication().projectId 
    this.userId= this.auth.getAuthentication().id  
    this.userName= this.auth.getAuthentication().userName  
    this.getHrmsEmployeeList(this.prjId,'All') 
    this.empDepartmentList(this.prjId);
    this.empCategoryList(); 
    this.getZoneByProject(this.prjId);
    this.getAllStaffRoleByPrjId(this.prjId);
    this.getAssignEmpCount(this.prjId)
  }  
}
