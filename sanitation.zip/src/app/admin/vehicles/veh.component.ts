import { Component } from '@angular/core';
import {HttpClient } from '@angular/common/http'; 
import { AuthService } from '../../_services'; 

@Component({
  selector: 'vehicle',
  templateUrl: './veh.component.html',  
})

export class VehComponent {
 public prjId:any
 public userId:any
  constructor(private http: HttpClient,private auth : AuthService) { 
  }  
  ngOnInit() 
  { 
     
  }

}
 