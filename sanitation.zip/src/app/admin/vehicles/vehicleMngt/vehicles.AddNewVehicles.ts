//import {Http} from "@angular/http";
import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { trigger, style, animate, transition } from '@angular/animations';
import { environment } from '../../../../environments/environment'; 


import {Http} from "@angular/http";


import { Broadcaster } from '../../../../environments/broadcaster';

import { AuthService } from '../../../_services/index';
import { LoaderService } from '../../../_services/loader.service';

 declare var $: any;
@Component({
  selector: 'app-dialog',
  templateUrl: './vehicles.AddNewVehicles.html',
  styleUrls: ['./vehicles.AddNewVehicles.css'],
  animations: [
    trigger('dialog', [
      transition('void => *', [
        style({ transform: 'scale3d(.3, .3, .3)' }),
        animate(100)
      ]),
      transition('* => void', [
        animate(100, style({ transform: 'scale3d(.0, .0, .0)' }))
      ])
    ])
  ]
})
export class AddNewVehiclesComponent implements OnInit {  
  public PrjId:any;
  public userId:any;
  public VehiclesNo:any
  public vehTypeId:any
  public chachishNoModal:any
  public vstDeviceNo:any
  public VtsMobileNoModal:any
  public simNoModal:any
  public vtsModel:any
  public ImeiNoModal:any
  public gsmOperator:any
  public ParkingLocations:any
  public InstalationsDate:any
  public ActivationsDate:any
  public jingalStatus:any
  public dataStatus:any
  public isActive:any
  public entryDate:any
  public updatedDate:any
  public vehiclesData:any  
  public jingleStatus:any 
  public selectDataStatus:any
  public vehDataStatus:any 
  public isActiveStatus:any
  public selectjingleStatus:any 
  public projectData:any
  public edited = false; 
  public edited1=false;
  public edited2=false;  
  public msgdataStatus=false;
  public selectPrjName=false;
  public error=false;
  public vehiclesCatogery;
  public vehiclesType;
  public VehiclesDataStatus:any
  public DataStatus:any
  public VehiclesNoModal:any
  public projectModel:any
  public vehTypId:any
  public vehType:any
  public vehCotegaryId:any
  public checkVehnoAvl:any
  public checkVehMobileImeiNoAvt:any
  public checkVehChasisNoAvt:any
  public checkVtsMobileNoAvt:any
  public checkSimNoAvt:any
  public project:any 
  public VehicleParkLocation:any 
  public projectMaster:any;
  public vehiclesno:any 
  public vehDetails:any
  public imagePathStatus:any;
  public imageImeiPath:any;
  public imageVehChasisPath:any;
  public imageVtsMobilePath:any;
  public imageSimNoPath:any;
  public showHideVehnoLoderDiv=false;
  public showHideVehImeiLoderDiv=false;
  public showHideVehChasisNoLoderDiv=false;
  public showHideVtsMobileNoLoderDiv=false;
  public showHideSimNoLoderDiv=false; 
  public vtsModalaData:any;
  public vtsModal:any;
  public vtsData:any;
  public vehTempNoModal:any;
  public vehOwnerTypeList:any;
  public ownerType:any;
  public ownerNameModal:any;
  public vehOwnerTypeData:any;
  public ownerTypeRequired=false;
  public vtsModalRequired=false; 
  public responceMessage:any;
  public errorMessage:any;
  isSubmmit:any
  showLoader: boolean;
  @Input() closable = true;
  @Input() visible: boolean;
  @Output() visibleChange: EventEmitter<boolean> = new EventEmitter<boolean>();
 
  
  constructor(private http:Http,private broadcaster: Broadcaster,private auth:AuthService,private loaderService: LoaderService) 
  { 
    this.ActivationsDate=new Date();
    this.InstalationsDate=new Date();
    this.loaderService.status.subscribe((val: boolean) =>{
      this.showLoader = val;
    }); 
  }   
  close() 
  {
    this.visible = false;
    this.visibleChange.emit(this.visible);
  }  
  ngOnInit(): void  
      {
        this.isSubmmit=true; 
        this.PrjId = this.auth.getAuthentication().projectId;
        this.userId = this.auth.getAuthentication().id;  
        this.getVehiclesParkLocations(); 
        this.getAllProject();  
        this.getAllVehiclesCategory();
        this.getAllVehiclesType(0); 
        this.getVehiclesDataStatus(); //To Select The Data Status drop downlist on init load  
        this.isActiveStatus=true;
        this.jingleStatus=true; 
        this.getVtsModalData();
        this.bindOwnerList(); 
      } 
  //Get the All vehicles Catogery details.
  getAllVehiclesCategory(){   
   this.http.get(environment.apiUrl+'admin/getVehiclesCatogeryType').subscribe((data)=>{     
       this.vehiclesCatogery=data.json();
     
 });
}  
 
//To change the Vehicles Type as per Vehicles Categary chnage event 
onChangeVehiclesCategory()
{  
  if(this.vehCotegaryId==undefined||this.vehCotegaryId==null||this.vehCotegaryId=='')
  {
    this.edited1=true;
    this.vehTypeId=undefined;
  }
  else{
    this.edited1=false;
    this.getAllVehiclesType(this.vehCotegaryId);  
  }

} 
//To get vehicles Type Name into the Add new Vehicleas   

getAllVehiclesType(selectCotegaryID){
   this.http.get(environment.apiUrl+'admin/getVehiclesType?catId='+selectCotegaryID).subscribe((data)=>{ 
       this.vehiclesType=data.json(); 
 });
} 

//To get the Total Project Name and bind the drop downlist
getAllProject(){
 this.http.get(environment.apiUrl+'admin/getProjectName').subscribe((data)=>{ 
     this.projectData=data.json(); 
});
}  

//To submit the Vehicles Details into the VEHMSTDEMO table. 
onClickToSubmitVehiclesDetails()
{  
  this.isSubmmit=true;
 if(this.vehCotegaryId==undefined) 
  {
    this.isSubmmit=true;
    this.edited1=true; 
    return;
  } 
  if(this.vehTypeId==undefined) 
  {  
    this.isSubmmit=true;
    this.edited2=true; 
    return;
  } 
  if(this.VehiclesNoModal==undefined||this.VehiclesNoModal==null)
  { 
    this.isSubmmit=true;
    return;
  } 
  if(this.vehDataStatus==undefined||this.vehDataStatus==null||this.vehDataStatus=="")
  {  
    this.msgdataStatus=true; 
    return
  } 
  this.postVehiclesDetail();  
}  
//To post Vehicles Details into the Database
postVehiclesDetail()
 {  
  var currentDate=new Date(); 
  this.loaderService.display(true); 
  if(this.jingleStatus==true){ 
    this.selectjingleStatus=1; 
   } 
   if(this.isActiveStatus==true){ 
     this.isActive=1;
   }  
   if(this.vtsModal==null){
     this.vtsModalRequired=true;
     return
    }
   if(this.vehOwnerTypeData==null){
     this.ownerTypeRequired=true;
     return
    }  
  var jsonData={  
             "PRJID":this.PrjId,
             "VEHNO":this.VehiclesNoModal?this.VehiclesNoModal:null,
             "VEHTEMPNO":this.vehTempNoModal?this.vehTempNoModal:null,
             "VEHTYPID":this.vehTypeId?this.vehTypeId:null,            
             "CHASISNO":this.chachishNoModal?this.chachishNoModal:'', 
             "VTSDEVICENO":this.vstDeviceNo?this.vstDeviceNo:null,
             "VTSMOBILENO":this.VtsMobileNoModal?this.VtsMobileNoModal:null, 
             "IMEI":this.ImeiNoModal?this.ImeiNoModal:null,
             "SIM":this.simNoModal?this.simNoModal:'',
             "VTSMODEL":this.vtsData?this.vtsData:'',
             "GSMOPERATOR":this.gsmOperator?this.gsmOperator:null,
             "PARKLOCID":this.ParkingLocations?this.ParkingLocations:null,
             "INSTALLDT":this.InstalationsDate?this.InstalationsDate:currentDate,  
             "ACTIVEDT":this.ActivationsDate?this.ActivationsDate:currentDate,
             "JINGLESTATUS":this.selectjingleStatus?this.selectjingleStatus:0,
             "DATASTATUS":this.vehDataStatus?this.vehDataStatus:0, 
             "ISACTIVE":this.isActive?this.isActive:0, 
             "ENTRYDT":currentDate?currentDate:null,           
             "UPDATEDT":"",
             "USERID": this.userId,
             "OWNERTYPE":this.ownerType,
             "OWNERNAME":this.ownerNameModal, 
           } 
        this.http.post(environment.apiUrl+'admin/addNewVehiclesDetails',jsonData).subscribe((data)=>{  
                 this.updatedDate=data.json(); 
                 if(this.updatedDate.output[0].RESPONSECODE=='200'){
                   this.edited = true; 
                   this.responceMessage=this.updatedDate.output[1].RESPONSEMESSAGE 
                   this.clearVehiclesDataField();  
                 }
                 else if(this.updatedDate.output[0].RESPONSECODE!='200'){
                  this.edited = false;
                  this.error=true;  
                  this.errorMessage=this.updatedDate.output[1].RESPONSEMESSAGE
                 }
                 setTimeout(() =>{ 
                               this.edited = false; 
                               this.visible = false; 
                            },5000);
                            this.broadcaster.broadcast('vehicleInserted',{ststus:'OK'});//To refresh the Table Data after Status find Ok for new vehicle add
                            this.clearVehiclesDataField(); 
                  },
                  error=>
                  {
                    this.error=true;  
                    this.clearVehiclesDataField(); 
                  }); 
          this.loaderService.display(false);
 } 

   


//tHis method is used to clear the form after form submited.
clearVehiclesDataField()
{ 
  this.projectModel=null;
  this.vehCotegaryId=null;
  this.vehTypeId=null;
  this.VehiclesNoModal=null;
  this.chachishNoModal=null;
  this.vstDeviceNo=null;
  this.VtsMobileNoModal=null;
  this.ImeiNoModal=null;
  this.simNoModal=null;
  this.vtsModel=null;
  this.gsmOperator=null;
  this.ParkingLocations=null;
  this.InstalationsDate=null;
  this.ActivationsDate=null;
  this.selectjingleStatus=false;
  this.vehDataStatus=false;
  this.isActive=false;
  this.ActivationsDate=null;
  this.updatedDate=null;
  this.vehDataStatus=null;
  this.showHideVehnoLoderDiv=false;
  this.showHideVehImeiLoderDiv=false;
  this.showHideVehChasisNoLoderDiv=false;
  this.showHideVtsMobileNoLoderDiv=false;
  this.showHideSimNoLoderDiv=false;
  this.vehTempNoModal=null;
  this.vehOwnerTypeData=null;
  this.ownerNameModal=null;
}

  //===================To get Vehicles Details on behalf of Vehicles no===================

    getVehiclesByVehNo(){ 
      this.http.get(environment.apiUrl+'admin/getVehicalDetailsByVehiclesNo?vehno='+this.VehiclesNoModal)
       .subscribe((data)=>{
        setTimeout(() => {
          this.vehDetails=data.json();
        }, 1000);     
    });
   }  
   //To fill the data Status Drop Downlist
   getVehiclesDataStatus(){
    this.http.get(environment.apiUrl+'admin/getVehiclesStatus')
     .subscribe((data)=>{
      setTimeout(() => {
        this.VehiclesDataStatus=data.json();
      }, 1000);     
  });
} 

 //To fill the Parking Locations Drop Downlist 
 getVehiclesParkLocations(){ 
   this.http.get(environment.apiUrl+'admin/getVehiclesParkingLocations?prjid='+this.PrjId)  
   .subscribe((data)=>{
    setTimeout(() => {
      this.VehicleParkLocation=data.json();
    }, 1000);     
});
}  

onBlurToCheckVehNoExist(){  
  if(this.VehiclesNoModal==undefined||this.VehiclesNoModal==null||this.VehiclesNoModal==''){ 
    this.isSubmmit=true;
    this.showHideVehnoLoderDiv=false;
    return;
  } 
 this.isSubmmit=true;
 this.showHideVehnoLoderDiv=true;   
 this.imagePathStatus="../../assets/img/loading.gif";
 this.http.get(environment.apiUrl+'admin/checkVehNoAvailability?vehiclesNo='+this.VehiclesNoModal)
.subscribe((data)=>{  
    this.checkVehnoAvl=data.json(); 
    console.log(this.checkVehnoAvl);
    if(this.checkVehnoAvl[0].result=="Available"){  
      this.isSubmmit=false;
      this.showHideVehnoLoderDiv=true;
      this.imagePathStatus="../../assets/img/ok.png";
    }
    if(this.checkVehnoAvl[0].result=="All ready exist"){  
      this.isSubmmit=true;
      this.showHideVehnoLoderDiv=true;
      this.imagePathStatus="../../assets/img/wrong.jpg";
    }       
}) 
}

//Check avialibility for Imei No 
  
onBlurToCheckImeiNoExist(){  
    if(this.ImeiNoModal==undefined||this.ImeiNoModal==null||this.ImeiNoModal==''){ 
      this.isSubmmit=true;
      this.showHideVehImeiLoderDiv=false;
      return;
    }
    this.isSubmmit=true; 
    this.showHideVehImeiLoderDiv=true;   
    this.imageImeiPath="../../assets/img/loading.gif";
    this.http.get(environment.apiUrl+'admin/checkVehMobileImeiAvailability?IMEI='+this.ImeiNoModal)
    .subscribe((data)=>{  
                this.checkVehMobileImeiNoAvt=data.json(); 
                if(this.checkVehMobileImeiNoAvt[0].result=="Available"){  
                  this.isSubmmit=false;
                  this.showHideVehImeiLoderDiv=true;
                  this.imageImeiPath="../../assets/img/ok.png";
                }
                if(this.checkVehMobileImeiNoAvt[0].result=="All ready exist"){  
                  this.isSubmmit=true;
                  this.showHideVehImeiLoderDiv=true;
                  this.imageImeiPath="../../assets/img/wrong.jpg";
                } 
    }) 
  }
//To check Chasis No availability
  onBlurToCheckChasisNoExist()
  {  
    if(this.chachishNoModal==undefined||this.chachishNoModal==null||this.chachishNoModal==''){ 
      this.isSubmmit=true;
      this.showHideVehChasisNoLoderDiv=false;
      return;
    } 
    this.isSubmmit=true;
    this.showHideVehChasisNoLoderDiv=true;   
    this.imageVehChasisPath="../../assets/img/loading.gif";
    this.http.get(environment.apiUrl+'admin/checkVehChasisNoAvailability?CHASISNO='+this.chachishNoModal)
    .subscribe((data)=>{  
                this.checkVehChasisNoAvt=data.json(); 
                console.log(this.checkVehChasisNoAvt);
                if(this.checkVehChasisNoAvt[0].result=="Available")
                {  
                  this.isSubmmit=false;
                  this.showHideVehChasisNoLoderDiv=true;
                  this.imageVehChasisPath="../../assets/img/ok.png";
                }
                if(this.checkVehChasisNoAvt[0].result=="All ready exist")
                {  
                  this.isSubmmit=true;
                  this.showHideVehChasisNoLoderDiv=true;
                  this.imageVehChasisPath="../../assets/img/wrong.jpg";
                } 
                
    }) 
  }
//To check VTS Mobile No availability
onBlurToCheckVtsMobileNoExist()
{
  if(this.VtsMobileNoModal==undefined||this.VtsMobileNoModal==null||this.VtsMobileNoModal=='')
  { 
    this.isSubmmit=true;
    this.showHideVtsMobileNoLoderDiv=false;
    return;
  } 
  this.isSubmmit=true;
  this.showHideVtsMobileNoLoderDiv=true;   
  this.imageVtsMobilePath="../../assets/img/loading.gif"; 
  this.http.get(environment.apiUrl+'admin/checkVtsMobileAvailability?VTSMOBILENO='+this.VtsMobileNoModal)
  .subscribe((data)=>{   
              this.checkVtsMobileNoAvt=data.json();  
              if(this.checkVtsMobileNoAvt[0].result=="Available")
              {  
                this.isSubmmit=false;
                this.showHideVtsMobileNoLoderDiv=true;
                this.imageVtsMobilePath="../../assets/img/ok.png";
              }
              if(this.checkVtsMobileNoAvt[0].result=="All ready exist")
              {  
                this.isSubmmit=true;
                this.showHideVtsMobileNoLoderDiv=true;
                this.imageVtsMobilePath="../../assets/img/wrong.jpg";
              }  
  }) 
} 

//To check VTS Mobile No availability
onBlurToCheckSimNoExist()
{
  if(this.simNoModal==undefined||this.simNoModal==null||this.simNoModal=='')
  { 
    this.isSubmmit=true;
    this.showHideSimNoLoderDiv=false;
    return;
  } 
  this.isSubmmit=true;
  this.showHideSimNoLoderDiv=true;   
  this.imageSimNoPath="../../assets/img/loading.gif";  
  this.http.get(environment.apiUrl+'admin/checkSimNoAvailability?SIM='+this.simNoModal)
  .subscribe((data)=>{  
              this.checkSimNoAvt=data.json(); 
              if(this.checkSimNoAvt[0].result=="Available")
              {  
                this.isSubmmit=false;
                this.showHideSimNoLoderDiv=true;
                this.imageSimNoPath="../../assets/img/ok.png";
              }
              if(this.checkSimNoAvt[0].result=="All ready exist")
              {  
                this.isSubmmit=true;
                this.showHideSimNoLoderDiv=true;
                this.imageSimNoPath="../../assets/img/wrong.jpg";
              }  
  }) 
} 
//==================================Validations of=============================//
public restrictNumeric(e) 
{
  let input;
  var inputlen;
  if (e.metaKey || e.ctrlKey) {
    return true;
  }
  if (e.which === 32) {
   return false;
  }
  if (e.which === 0) {
   return true;
  }
  if (e.which < 33) {
    return true;
  }
  input = String.fromCharCode(e.which); 
  return !!/[\d\s]/.test(input);
 } 

 //To validations for only Vehicles Catogery and Type============
 public ChackValidationsVehCatogery()
 {
  if(this.vehCotegaryId==undefined) 
  {
    this.edited1=true;  
    return;
  } 
  if(this.vehTypeId==undefined) 
  {  
    this.edited2=true; 
    return;
  } 
  if(this.VehiclesNoModal==undefined||this.VehiclesNoModal==null||this.VehiclesNoModal=="")
  { 
    this.isSubmmit = true
    return ;
  }
  if(this.vehDataStatus==undefined||this.vehDataStatus==null||this.vehDataStatus=="")
  {  
    this.msgdataStatus=true; 
    return;
  } 
 }
 //To Show the Erroe Message when vehicles type is not selecte ram99
 onChangeVehiclesTYpe()
 {
  if(this.vehTypeId==undefined||this.vehTypeId==undefined||this.vehTypeId=='') 
  {   
    this.edited2=true;
    return;
  }
  else
  {
    this.edited2=false;
  } 
 } 

 ///Validations for the Data Status DRop downlist
onChangeDataStatus()
{ 
  if(this.vehDataStatus==null||this.vehDataStatus==undefined)
   { 
     this.msgdataStatus=true;
     this.isSubmmit=true;
     return;
   }
   if(this.vehDataStatus!=null) 
   {
    this.isSubmmit=false;
    this.msgdataStatus=false;
   }
}   
 
//======================================VTS MODAl DDL BIND CR DATE-21-08-2018---------------------------------------/
//Created by RAM on 21-08-2018

getVtsModalData(){
    this.http.get(environment.apiUrl+'admin/getVtsModalDetails?prjid='+this.PrjId).subscribe((data)=>{
    this.vtsModalaData=data.json()   
   });
}
/**
 * On select change event VTS Modal 
*/

onChangeVtsModal(data){ 
  if(data==null){
    this.vtsModalRequired=true;
    return;
  }
  else{
    this.vtsModalRequired=false;
    this.vtsData=data.VTSMODALNO 
  } 
}

/*
 *Bind Owner List drop down list 
*/
public bindOwnerList()
{
  this.vehOwnerTypeList=
  [{  
  "ID":1,
  "VALUE":"Ecogreen", 
  },
  {  
    "ID":2,
    "VALUE":"Contractor", 
  }]
}   

/*
 * To select the vehicle owner Type
*/
onChangeVehTypOwner(data){
  if(data==null){
    this.ownerTypeRequired=true;
    return;
  }
  else{
    this.ownerTypeRequired=false;
    this.ownerType=data.VALUE 
  } 
} 


}


