import { Component, OnInit } from '@angular/core';
import {Http} from "@angular/http";
import { environment } from '../../../../environments/environment'; 
import { Broadcaster } from '../../../../environments/broadcaster';
import { AuthService } from '../../../_services/index';
import { LoaderService } from '../../../_services/loader.service';
import { utils, write, WorkBook } from 'xlsx';  
import { saveAs } from 'file-saver';
declare var $: any; 

@Component({
  selector: 'app-vehicles',  
  templateUrl: './vehicles.component.html',
  styleUrls: ['./vehicles.component.css'],  
})  

   export class VehicleComponent implements OnInit{ 
    showLoader: boolean;
    public Id;
    public data;
    public userId:any;
    public areaEntityData;
    public staffEntityData;
    public prjData; 
    public vehNo;
    public VehiclesByID;
    public VehiclesDataStatus; 
    selectedRow : Number;
    selectedAreaRow: Number;
    setClickedRow : Function; 
    selectAreaEntityDetailsRow :Function;
    //selectStaffEntityDetailsRow :Function;
    public vehiclesCatogery;
    public vehiclesArealabel:any;
    public stdate:any
    public enddate:any
    public selectPrjId:any
    public SelectVehno:any
    public deleted = false;
    public delwarning =false;
    public updtVehDataSuccess=false;
    public VehicleParkLocation:any
    public selectProjectmodel:any 
    public vehAreaModel:any 
    public vehiclesAreaEntity:any
    public vehAssignmtStaffRole:any
    public vehStaffRoleModel:any
    public staffRole:any
    public staffNameData:any
    public areaAssignDetails:any
    public staffAssignDetails:any
    public vehStaffNameModel:any
    public vehStaffAsignStatus:any
    search:any;
    showDialog:any
    visible:any
    //---------------vehicles Update Details-------------
    //For Update validations  
    public udptVehTypename=false;  
    public updtImeiNo=false; 
    public udptParkLocation=false;
    public udptDataStatus=false;
    public saveAreaEntityStatus=false;
    public saveStaffNameStatus=false;
    public deleteAreaEntity=false;
    public vehStaffRoleStatus=false;
    public vehStaffRoleNameStatus=false;
    public isVehAssignSave=false;
    public isStaffAssignSave=false; 
    public vehiclesNo:any
    public vehTypId:any
    public vehType:any
    public vehCotegaryId:any
    public vehiclesType:any;  
    public inActiveVehiclesLst:any;
    public SelectProjectName:any
    public vehCotId:any
    public vehTypeId:any
    public VehiclesNo:any
    public imeidNo:any
    public chaChihNo:any
    public vtsMobileNo:any
    public simNo:any
    public vtsModel:any
    public parkLocations:any
    public installDate:any
    public activationsDate:any
    public vehDataStatus:any
    public isjingleActive:any
    public isActiveStatus:any  
    public selectedRowData:any 
    public Prjid:any 
    public updtCheckVehnoAvl:any
    public updtCheckVehMobileImeiNoAvl:any
    public updtCheckVtsMobileNoAvt:any
    public updtCheckVehChasisNoAvt:any
    public updtCheckSimNoAvt:any
    public vehCatArea:any
    public vehlabelId:any
    public vehEntityArea=false;
    public vehStaffStatus=false;
    public vehAreaEntityModel:any
    public vehEntityData:any
    public vehAreaAsignStatus:any
    public vehStaffRoleId:any  
    public project:any 
    public updateData:any
    public updtVstDeviceNo:any
    public updtGsmOperator:any
    public updtEntryDate:any
    public currentDate:any
    public projectMaster:any;
    public showHideVehAssignLoadDiv=false;
    public showHideStaffAssignLoadDiv=false
    public imageVehAssignLoader:any;
    public imageStaffAssignLoader:any;
    public vehUpdateBtnDiv=false; 
    public vehDeleteBtnDiv=false; 
    public vehAssignmentBtnDiv=false;
    public vehActiveBtnDiv=false;
    public makeActiveVehDetails:any;
    public vehActiMessagePopup=false;
    public showHideVehNoDiv=false;
    public isVehicleUpdtbtn=false;
    public showHideImeiNoDiv=false;
    public imgVehNoPath:any;
    public imgVehImeiNoPath:any;
    public showHideChasisNoDiv:any;
    public imgChasisNoPath:any; 
    public imgVtsMobilNoPath:any;
    public showHideVtsMobileDiv=false;
    public imgSimNoPath:any;
    public showHideSimNoDiv=false;
    public employeeRecordNotFound=false;
    public vehAreaRecordNotFound=false;
    public staffAssignReNotFound=false;
    public vehID:any;
    //public staffSelectionsId:any;
    public vtsModalaData:any;
    public vtsData:any;
    public vehOwnerTypeList:any;
    public ownerType:any;
    public VehiclesTempNo:any;
    public vehOwnerTypeData:any;
    public ownerNameModal:any;
    public vtsModal:any;
    public vehOwnerRequired=false;
    public vtsModelRequired=false;
    public updtResponceMsg:any;
    public updtVehDataError=false;
    public saveAreaEntityError=false
    public saveStaffNameError=false; 
    constructor(private http: Http,private broadcaster: Broadcaster,private auth:AuthService,private loaderService: LoaderService)
    {  
      this.loaderService.status.subscribe((val: boolean)=>{
        this.showLoader = val;
      }); 
      this.vehOwnerTypeList=[{"ID":1,"VALUE":"Ecogreen"},{"ID":2,"VALUE":"Contractor"}] 
      //this.setClickedRow = function(data,index){  
        //this.vehOwnerTypeList=[{"ID":1,"VALUE":"Ecogreen"},{"ID":2,"VALUE":"Contractor"}] 
        //this.selectedRow = index;   
        //this.selectedRowData = data;  
        //this.Id=this.selectedRowData.ID;  
        //this.getAllAreaAssignmentDetails(this.Id); 
        //this.getAllStaffAssignmentDetails(this.Id); 
       //}  
    } 
    ngOnInit(): void 
    {  
        this.broadcaster.on('vehicleInserted').subscribe(message =>{
          this.allVehicles();      
        });
        $("#progress-bar").hide() 
        this.Prjid = this.auth.getAuthentication().projectId
        this.userId=this.auth.getAuthentication().id; 
        if(this.Prjid==1){
          this.SelectProjectName="LUCKNOW";
         }else if(this.Prjid==2){
          this.SelectProjectName="GURUGRAM";
         }else if(this.Prjid==3){
          this.SelectProjectName="FARIDABAD";
         }else if(this.Prjid==4){
          this.SelectProjectName="GWALIOR";
         }   
        this.getAllVehiclesAreaLable(this.Prjid);
        this.allVehicles();
        this.getAllStaffRoleByPrjId(this.Prjid);
        this.getVehiclesParkLocations(this.Prjid); 
        this.getVehiclesDataStatus();  
        this.getVtsModalData();
        this.getAllVehiclesCategory();  
        this.getAllVehiclesType(1);  
        this.getVehiclesParkLocations(this.Prjid);  
    }  

  /*
   * get all Vehicle List
  */
  getAllVehiclesDetails(project){
    this.loaderService.display(true);
    this.http.get(environment.apiUrl+'admin/getVehicalsDetails?prjid='+project).subscribe((data)=>{  
        this.data = data.json(); 
         if(this.data.length>0){
          this.employeeRecordNotFound=false; 
          this.loaderService.display(false);  
         }
         else{
          this.employeeRecordNotFound=true;
          this.loaderService.display(false);  
         } 
     }); 
 }  
  //Get the All vehicles Catogery details.
  getAllVehiclesCategory(){   
   this.http.get(environment.apiUrl+'admin/getVehiclesCatogeryType').subscribe((data)=>{
    this.vehiclesCatogery=data.json() 
 });
}
//###############################get All Active and Inactive Vehicles List START###############################//
 

allVehicles(){ 
  this.vehActiveBtnDiv=false;
  this.vehUpdateBtnDiv=true; 
  this.vehDeleteBtnDiv=true; 
  this.vehAssignmentBtnDiv=true; 
  this.loaderService.display(true);
  this.http.get(environment.apiUrl+'admin/getAllVehiclesByProject?prjid='+this.Prjid).subscribe((data)=>{ 
     this.data=data.json();  
     if(this.data.length==0){
      this.employeeRecordNotFound=true;
     }
     if(this.data.length!=0){
      this.employeeRecordNotFound=false;
     } 
     this.loaderService.display(false); 
  });
} 
//Active Vehicles; 
activeVehicles(){  
  this.vehActiveBtnDiv=false;
  this.vehUpdateBtnDiv=true; 
  this.vehDeleteBtnDiv=true; 
  this.vehAssignmentBtnDiv=true;  
  this.getAllVehiclesDetails(this.Prjid);
} 
inActiveVehicles(){  
  this.vehActiveBtnDiv=true;
  this.vehUpdateBtnDiv=false; 
  this.vehDeleteBtnDiv=false; 
  this.vehAssignmentBtnDiv=false;
  this.loaderService.display(true); 
  this.http.get(environment.apiUrl+'admin/getAllInactiveVehicles?prjid='+this.Prjid).subscribe((data)=>{ 
     this.inActiveVehiclesLst=data.json(); 
     this.data=this.inActiveVehiclesLst;
     if(this.inActiveVehiclesLst.length==0){
      this.employeeRecordNotFound=true;
     }
     if(this.inActiveVehiclesLst.length!=0){
      this.employeeRecordNotFound=false;
     } 
     this.loaderService.display(false);   
  });
}


makeVehicleActive(data){ 
  this.Id=data.ID;
  $("#vehActivationsModal").modal("show");
}


vehicleActiveConfom(){
  this.http.get(environment.apiUrl+'admin/inactiveToActiveVehDetailsById?ID='+this.Id).subscribe((data)=>{
    this.makeActiveVehDetails=data.json(); 
    this.vehActiMessagePopup=true; 
    this.inActiveVehicles();
   setTimeout(() => { 
     this.vehActiMessagePopup=false;
     $("#vehActivationsModal").modal("hide");
   }, 1000);  
  }); 
}

//###############################Inactive Vehicles List END###############################//

//To change the Vehicles Type as per Vehicles Categary chnage event 
SelectVehiclesTypeName(){   
  var selectCotegaryID=this.vehCotId; 
  this.getAllVehiclesType(selectCotegaryID); 
}  

//To get vehicles Type Name into the Add new Vehicleas   
getAllVehiclesType(selectCotegaryID){
   this.http.get(environment.apiUrl+'admin/getVehiclesType?catId='+selectCotegaryID).subscribe((data)=>{
    this.vehiclesType=data.json(); 
 });
}  
   //To select The Parking locations accroding to the selected Project ID  
   getVehiclesParkLocations(Prjid){  
     this.http.get(environment.apiUrl+'admin/getVehiclesParkingLocations?prjid='+this.Prjid).subscribe((data)=>{
      setTimeout(() => {
        this.VehicleParkLocation=data.json();
      }, 1000);     
  });
  } 
   
   getVehiclesDataStatus(){
    this.http.get(environment.apiUrl+'admin/getVehiclesStatus').subscribe((data)=>{
      setTimeout(() => {
        this.VehiclesDataStatus=data.json();
      }, 1000);     
  });
} 
//=============================Blur Method availibility validations on Updated Model popup=================================//
  

onBlurToCheckVehNoExistUpdt(){  
    if(this.VehiclesNo==null||this.VehiclesNo==undefined||this.VehiclesNo==''){   
      this.showHideVehNoDiv=false;
      this.isVehicleUpdtbtn=true; 
      return;  
    } 
    this.showHideVehNoDiv=true;
    this.imgVehNoPath="../../assets/img/loading.gif";
   this.http.get(environment.apiUrl+'admin/checkVehNoAvailability?vehiclesNo='+this.VehiclesNo).subscribe((data)=>{ 
    this.updtCheckVehnoAvl=data.json();    
    if(this.updtCheckVehnoAvl[0].result=="Available")
       {
         this.isVehicleUpdtbtn=false; 
         this.showHideVehNoDiv=true;
         this.imgVehNoPath="../../assets/img/ok.png";
       }
       if(this.updtCheckVehnoAvl[0].result=="All ready exist")
       {
         this.isVehicleUpdtbtn=true; 
         this.showHideVehNoDiv=true;
         this.imgVehNoPath="../../assets/img/wrong.jpg";
       }
    }) 
  }
  
  //Check avialibility for Imei No 
onBlurToCheckimeImeiNoExistUpdt(){  
  if(this.imeidNo==null||this.imeidNo==undefined||this.imeidNo==''){   
    this.showHideImeiNoDiv=false;
    this.isVehicleUpdtbtn=false; 
    return;  
  } 
  this.showHideImeiNoDiv=true;
  this.imgVehImeiNoPath="../../assets/img/loading.gif";
   this.http.get(environment.apiUrl+'admin/checkVehMobileImeiAvailability?IMEI='+this.imeidNo).subscribe((data)=>{  
              this.updtCheckVehMobileImeiNoAvl=data.json(); 
              if(this.updtCheckVehMobileImeiNoAvl[0].result=="Available"){
                this.isVehicleUpdtbtn=false; 
                this.showHideImeiNoDiv=true;
                this.imgVehImeiNoPath="../../assets/img/ok.png";
              }
              if(this.updtCheckVehMobileImeiNoAvl[0].result=="All ready exist"){
                this.isVehicleUpdtbtn=true; 
                this.showHideImeiNoDiv=true;
                this.imgVehImeiNoPath="../../assets/img/wrong.jpg";
              }
              
  }) 
}

//To check Chasis No availability
onBlurToCheckChasisNoExistUpdt(){ 
  if(this.chaChihNo==null||this.chaChihNo==undefined||this.chaChihNo==""){   
      this.showHideChasisNoDiv=false; 
      this.isVehicleUpdtbtn=false; 
      return;
  } 
  this.showHideChasisNoDiv=true;
  this.imgChasisNoPath="../../assets/img/loading.gif";
  this.http.get(environment.apiUrl+'admin/checkVehChasisNoAvailability?CHASISNO='+this.chaChihNo).subscribe((data)=>{   
              this.updtCheckVehChasisNoAvt=data.json();
              if(this.updtCheckVehChasisNoAvt[0].result=="Available"){
                this.isVehicleUpdtbtn=false; 
                this.showHideChasisNoDiv=true;
                this.imgChasisNoPath="../../assets/img/ok.png";
              }
              if(this.updtCheckVehChasisNoAvt[0].result=="All ready exist"){
                //this.isVehicleUpdtbtn=true; 
                this.showHideChasisNoDiv=true;
                this.imgChasisNoPath="../../assets/img/wrong.jpg";
              } 
   }) 
}


//To check VTS Mobile No availability
onBlurToCheckVtsMobileNoExistUpdt(){
  if(this.vtsMobileNo==null||this.vtsMobileNo==undefined||this.vtsMobileNo==''){   
    this.showHideVtsMobileDiv=false;
    this.isVehicleUpdtbtn=false; 
    return;  
  } 
  this.showHideVtsMobileDiv=true; 
  this.imgVtsMobilNoPath="../../assets/img/loading.gif";
  this.http.get(environment.apiUrl+'admin/checkVtsMobileAvailability?VTSMOBILENO='+this.vtsMobileNo).subscribe((data)=>{    
              this.updtCheckVtsMobileNoAvt=data.json();
              if(this.updtCheckVtsMobileNoAvt[0].result=="Available"){
                this.isVehicleUpdtbtn=false; 
                this.showHideVtsMobileDiv=true;
                this.imgVtsMobilNoPath="../../assets/img/ok.png";
              }
              if(this.updtCheckVtsMobileNoAvt[0].result=="All ready exist"){
                //this.isVehicleUpdtbtn=true; 
                this.showHideVtsMobileDiv=true;
                this.imgVtsMobilNoPath="../../assets/img/wrong.jpg";
              }  
     }) 
} 
 


//To check VTS Mobile No availability
onBlurToCheckVtsMobSimNoExistUpdt(){
  if(this.simNo==null||this.simNo==undefined||this.simNo==''){   
    this.showHideSimNoDiv=false;
    this.isVehicleUpdtbtn=false; 
    return;  
  } 
  this.showHideSimNoDiv=true; 
  this.imgSimNoPath="../../assets/img/loading.gif";
  this.http.get(environment.apiUrl+'admin/checkSimNoAvailability?SIM='+this.simNo).subscribe((data)=>{ 
              this.updtCheckSimNoAvt=data.json();
              if(this.updtCheckSimNoAvt[0].result=="Available"){
                this.isVehicleUpdtbtn=false; 
                this.showHideSimNoDiv=true;
                this.imgSimNoPath="../../assets/img/ok.png";
              }
              if(this.updtCheckSimNoAvt[0].result=="All ready exist"){
                //this.isVehicleUpdtbtn=true; 
                this.showHideSimNoDiv=true;
                this.imgSimNoPath="../../assets/img/wrong.jpg";
              }
               
  }) 
}  
 
/*
 * Update Vehicle Details Opem Modal popup
 */
updateVehicle(data){ 
  console.log("dataitem",data)
  this.Id=data.ID
  this.vehCotId=data.vehCatId;
  if(this.vehCotId==1){this.vehCatArea="Primary"} if(this.vehCotId==2){this.vehCatArea="Secondary"}
  this.vehTypeId=data.vehtypid;   
  this.VehiclesNo=data.vehno; 
  this.imeidNo=data.imei;  
  this.chaChihNo=data.chasisNo; 
  this.vtsMobileNo=data.vtsMobileno; 
  this.simNo=data.SIM;
  this.parkLocations=data.parkLocId; 
  this.installDate=data.installdt; 
  this.activationsDate=data.activedt;
  this.isActiveStatus=data.isactive; 
  if(this.isActiveStatus=="Active"){this.isActiveStatus=true;}
  if(this.isActiveStatus=="InActive"){this.isActiveStatus=false;} 
  this.vehDataStatus=data.dataStatusId;  
  this.isjingleActive=data.jinglestatus;  
  if(data.vtsmodel=="RP01N"){this.vtsModal=1} else if(data.vtsmodel=="RP05"){this.vtsModal=2}else if(data.vtsmodel=="EMPTY") {this.vtsModal=3}
  if(data.OWNERTYPE=="Ecogreen"){this.vehOwnerTypeData=1}else if(data.OWNERTYPE=="Contractor"){this.vehOwnerTypeData=2}         
  this.VehiclesTempNo=data.VEHTEMPNO; 
  this.ownerNameModal=data.OWNERNAME;
  this.updtVehDataError=false
  this.updtVehDataSuccess=false
  $("#exampleModal").modal("show");
  this.isVehicleUpdtbtn=false;  
  this.showHideVehNoDiv=false; 
  this.showHideImeiNoDiv=false;
  this.showHideChasisNoDiv=false;
  this.showHideVtsMobileDiv=false;
  this.showHideSimNoDiv=false;
  this.vtsModelRequired=false;
  this.vehOwnerRequired=false; 
}
/*
 * Update Vehicle Details
 */
onClickToUpdateVehiclesDetails(){   
  var activeStatus;
  var jingalStatus; 
  if(this.isActiveStatus==true){activeStatus=1} 
  if(this.isjingleActive==true){jingalStatus=1} 
  if(this.vtsModal=="1"){this.vtsModal="RP01N"} else if(this.vtsModal=="2"){this.vtsModal="RP05"} else if(this.vtsModal=="3") {this.vtsModal="EMPTY"}
  if(this.vehOwnerTypeData=="1"){this.vehOwnerTypeData="Ecogreen"}else if(this.vehOwnerTypeData=="2"){this.vehOwnerTypeData="Contractor"}
  if(this.vehOwnerTypeData==null||this.vehOwnerTypeData==undefined){
    this.vehOwnerRequired=true
    return;
  }
  if(this.vtsModal==null||this.vtsModal==undefined){
    this.vtsModelRequired=true;
    return;
  }
  this.currentDate=new Date(); 
  var jsonUpdateData=
  {  
    "ID":this.Id, 
    "PRJID":this.Prjid,  
    "VEHNO":this.VehiclesNo,
    "VEHTEMPNO":this.VehiclesTempNo,
    "VEHTYPID":this.vehTypeId?this.vehTypeId:null,            
    "CHASISNO":this.chaChihNo, 
    "VTSDEVICENO":this.updtVstDeviceNo?this.updtVstDeviceNo:null,
    "VTSMOBILENO":this.vtsMobileNo?this.vtsMobileNo:null, 
    "IMEI":this.imeidNo?this.imeidNo:null,
    "SIM":this.simNo,
    "VTSMODEL":this.vtsModal?this.vtsModal:null,
    "GSMOPERATOR":this.updtGsmOperator?this.updtGsmOperator:"",
    "PARKLOCID":this.parkLocations?this.parkLocations:null,
    "INSTALLDT":this.installDate?this.installDate:this.currentDate,  
    "ACTIVEDT":this.activationsDate?this.activationsDate:this.currentDate,
    "JINGLESTATUS":jingalStatus?jingalStatus:0,
    "DATASTATUS":this.vehDataStatus?this.vehDataStatus:0, 
    "ISACTIVE":activeStatus?activeStatus:0, 
    "ENTRYDT":"",           
    "UPDATEDT":this.currentDate,
    "USERID":this.userId,
    "OWNERTYPE":this.vehOwnerTypeData,
    "OWNERNAME":this.ownerNameModal 
  } 
  this.isVehicleUpdtbtn=true;  
  this.loaderService.display(true);
  this.http.post(environment.apiUrl+'admin/updateVehiclesDetails',jsonUpdateData).subscribe((data)=>{  
        this.updateData=data.json(); 
        console.log("updateData",this.updateData)
        if(this.updateData.output[0].RESPONSECODE==200){
          this.updtVehDataError=false;
          this.updtResponceMsg=this.updateData.output[1].RESPONSEMESSAGE
          this.updtVehDataSuccess=true;  
          this.allVehicles();  
          setTimeout(()=>{
            $("#exampleModal").modal("hide"); 
            this.updtVehDataSuccess=false;
            this.isVehicleUpdtbtn=false; 
            this.loaderService.display(false);  
          }, 1000);
          
        }else{
          this.updtVehDataError=true;
          this.updtResponceMsg=this.updateData.output[1].RESPONSEMESSAGE
          this.isVehicleUpdtbtn=false;  
          this.loaderService.display(false);  
        } 
  }); 
} 

clearAllfields(){
  this.vehCotId=null; 
  this.vehTypeId=null;
  this.VehiclesTempNo=null;
  this.imeidNo=null;
  this.chaChihNo=null;
  this.vtsMobileNo=null;
  this.simNo=null;
  this.parkLocations=null;
  this.vehDataStatus=null;
  this.VehiclesNo=null;
  this.ownerNameModal=null;
}

//==============To delete the VEhicles Details START===============================// 
onClickToDeleteVehicles(){  
  this.http.get(environment.apiUrl+'admin/deleteVehiclesDetails?vehiclesNo='+this.VehiclesNo).subscribe((data)=>{ 
    this.data = data.json(); 
      this.deleted = true; 
      setTimeout(()=>{ 
          this.deleted = false;
          $("#myModal").modal("hide");
      }, 1000);
  });
  this.allVehicles();  
}
//==============To delete the VEhicles Details END====================================== =//


 //===========================================For Vehicles Assigmant Details Code Start(13_03_2018)===========================================//
 //Get the All vehicles Area label details.
 getAllVehiclesAreaLable(prjid) {  
  this.http.get(environment.apiUrl+'admin/getAllVehicalAreaByPrjId?prjid='+prjid).subscribe((data)=>{
    this.vehiclesArealabel=data.json(); 
});
} 

//on change the Area label and select the Label cotegory Entity Name details..
OnChangeAreaLabelGetEntity()
{  
  this.vehlabelId=this.vehAreaModel;
  this.getAllVehiclesAreaEntityByOemId(this.vehlabelId,this.Prjid); 
   if(this.vehAreaModel==null||this.vehAreaModel==undefined||this.vehAreaModel==""||this.vehAreaModel=="null"){ 
    this.isVehAssignSave=true; 
    this.vehEntityArea=true;
    this.showHideVehAssignLoadDiv=false; 
   }
   else
   {
    this.vehEntityArea=false;
    this.isVehAssignSave=true;
    this.showHideVehAssignLoadDiv=false;  
   }  
} 
//To check the Avialability of Vehicles avaibility
OnChangeToGetEntityId(){  
  if(this.vehAreaEntityModel==null||this.vehAreaEntityModel==undefined||this.vehAreaModel==null||this.vehAreaModel==undefined){ 
    this.showHideVehAssignLoadDiv=false; 
    this.vehStaffStatus=false;
    this.isVehAssignSave=true;
    return; 
  }
  this.showHideVehAssignLoadDiv=true;
  this.imageVehAssignLoader="../../assets/img/loading.gif";
   this.vehEntityData=this.vehAreaEntityModel; 
   this.http.get(environment.apiUrl+'admin/getVehicalAssignAvailability?VEHID='+this.Id+'&ENTITYID='+this.vehEntityData)
   .subscribe((data)=>{ 
    this.vehAreaAsignStatus=data.json();
    if(this.vehAreaAsignStatus[0].result=="Available"){  
      this.isVehAssignSave=false;
      this.vehStaffStatus=false;
      this.imageVehAssignLoader="../../assets/img/ok.png";
    }
    if(this.vehAreaAsignStatus[0].result=="Already exists"){  
      this.isVehAssignSave=false;
      this.vehStaffStatus=false;
      this.isVehAssignSave=true;
      this.imageVehAssignLoader="../../assets/img/wrong.jpg";
    }  
  }); 
} 
 //Get the All vehicles Area label details.
 getAllVehiclesAreaEntityByOemId(vehlabelId,Prjid){  
  this.http.get(environment.apiUrl+'admin/getAllVehicalAreaEntityByOemId?oemid='+vehlabelId+'&PRJID='+this.Prjid).subscribe((data)=>{
    this.vehiclesAreaEntity=data.json();  
});
}  
  //Get the All vehicles Area label details.
  getAllStaffRoleByPrjId(Prjid){   
   this.http.get(environment.apiUrl+'admin/getAllStaffRoleNameByPrjId?prjid='+this.Prjid).subscribe((data)=>{
    this.vehAssignmtStaffRole=data.json();  
 });
 }  
 //Get the All vehicles Area label details.
 getAllStaffNameByRoleId(staffRole)
 {  
  this.http.get(environment.apiUrl+'admin/getAllStaffNameByRoleId?roleid='+this.staffRole).subscribe((data)=>{
    this.staffNameData=data.json();  
});
}  

//To Get the Area Assignment Details and bind Table for Area Assignment 
getAllAreaAssignmentDetails(Id){   
  this.http.get(environment.apiUrl+'admin/getAreaAssignmentDetails?VEHID='+Id).subscribe((data)=> {
         this.areaAssignDetails = data.json();  
         if(this.areaAssignDetails.length==0){
            this.vehAreaRecordNotFound=true;
          }else{
          this.vehAreaRecordNotFound=false;
         }  
  }); 
}   

//To Get the Area Assignment Details and bind Table for Staff Assignment 
getAllStaffAssignmentDetails(Id){  
  this.http.get(environment.apiUrl+'admin/getStaffAssignmentDetails?VEHID='+Id).subscribe((data)=> {
    this.staffAssignDetails = data.json(); 
    if(this.staffAssignDetails.length==0){
      this.staffAssignReNotFound=true;
    }else{
      this.staffAssignReNotFound=false;
    } 
  }); 
}  

//To save the Area Asign Entity Data into the VEHENTITYMAP Table 
onClickToSaveVehEntityDeta(){  
  this.currentDate=new Date();
  var activeStatus; 
  this.isVehAssignSave=true;
  if(this.activeStatus=="Active"){activeStatus=1} 
  if(this.vehAreaModel==null||this.vehAreaModel==undefined){
    this.vehEntityArea=true;
    return;
  }
  if(this.vehAreaEntityModel==null||this.vehAreaEntityModel==undefined){ 
    this.vehStaffStatus=true;
    return;
  } 
  var jsonAreaEntityData={  
    "VEHID":this.Id, 
    "ENTITYID":this.vehEntityData,  
    "ASSIGNDT":this.currentDate,  
    "ISACTIVE":activeStatus?activeStatus:0, 
    "ENTRYDT":this.currentDate,  
    "USERID":this.userId
  } 
  console.log("array",jsonAreaEntityData) 
  this.http.post(environment.apiUrl+'admin/saveVehAreaAssignDetails',jsonAreaEntityData).subscribe((data)=>{ 
          this.updateData=data.json(); 
          if(this.updateData.status=="ok"){
            this.saveAreaEntityStatus=true; 
            this.getAllAreaAssignmentDetails(this.Id)   
            setTimeout(()=>{
                this.saveAreaEntityStatus=false; 
                this.showHideVehAssignLoadDiv=false;  
                this.vehAreaModel=null;
                this.vehAreaEntityModel=null;  
              }, 2000);  
          }else{
             this.saveAreaEntityError=true
          }            
    }); 
} 
  
/*
 * Delete Assign Modal popup windows
 */
deleteAssignAreaPopup(item){
  console.log("data",item) 
    this.vehID=item.ID;  
} 
 
/*
 * Delete Assign Area
*/
deleteAssignArea(){  
  this.http.get(environment.apiUrl+'admin/deleteVehicleAreaEntityDetails?VEHID='+this.vehID).subscribe((data)=>{  
    var updatedData = data.json(); 
    if(updatedData.status=="ok"){
      this.deleteAreaEntity=true  
      setTimeout(()=>{  
         this.getAllAreaAssignmentDetails(this.Id); 
          this.deleteAreaEntity =false; 
          $("#myAreaEntityModel").modal("hide");
      }, 1000);
    }else{
    this.delwarning=true;
    } 
  }); 
} 

//on click to select The Row Vehid according to the Row click 
// setClkSelectStaffDetailsRow(){ 
//   this.selectStaffEntityDetailsRow = function(staffEntityData){  
//     this.staffSelectionsId=staffEntityData.id; 
//   } 
// } 

removeStaffAssignment(item){
  console.log("sfatt assign",item)
  this.vehID=item.id;  
} 

removeStaffAssign(){ 
 this.http.get(environment.apiUrl+'admin/deleteVehicleStaffEntityDetails?id='+this.vehID).subscribe((data)=>{ 
   var assignStaff = data.json();
   if(assignStaff.status=="ok"){
    this.delwarning=false
    this.deleteAreaEntity=true 
      setTimeout(()=>{  
          this.deleteAreaEntity =false; 
          this.getAllStaffAssignmentDetails(this.Id); 
          $("#myStaffEntityEntityModel").modal("hide");          
      }, 1000);
   } else{
    this.delwarning=true
   }  
 }); 
}

//==============To delete the VEhicles Details START===============================// 
  //on select to change the staff role bind the staff Name on select index changes event.
 OnChangeToSelectStaffRole(){  
  this.staffRole=this.vehStaffRoleModel;  
  this.getAllStaffNameByRoleId(this.staffRole); 
   if(this.vehStaffRoleModel==null||this.vehStaffRoleModel==undefined||this.vehStaffRoleModel==""||this.vehStaffRoleModel=="null"){
    this.isStaffAssignSave=true;
    this.showHideStaffAssignLoadDiv=false;
    this.vehStaffRoleStatus=false;
    return;
   } 
   else
   {
    //this.vehEntityArea=false;
    this.isStaffAssignSave=true;
    this.showHideStaffAssignLoadDiv=false;  
   } 
 } 

 //To check the Staff Assignment Status By Staff Drop Down List Selections
 OnChangeToSelectStaffName(){
   if(this.vehStaffRoleModel==null||this.vehStaffRoleModel==undefined||this.vehStaffNameModel==null||this.vehStaffNameModel==undefined){
    this.isStaffAssignSave=true;
    this.showHideStaffAssignLoadDiv=false;
    return;
   }
   this.showHideStaffAssignLoadDiv=true;
   this.vehStaffRoleId=this.vehStaffNameModel; 
   this.imageStaffAssignLoader="../../assets/img/loading.gif";
   this.http.get(environment.apiUrl+'admin/getVehicalStaffAssignAvailability?VEHID='+this.Id+'&EMPROLEMAPID='+this.vehStaffRoleId).subscribe((data)=>{ 
      this.vehStaffAsignStatus=data.json(); 
      if(this.vehStaffAsignStatus[0].result=="Available")
      {  
        this.isStaffAssignSave=false;
        this.showHideStaffAssignLoadDiv=true;
        this.imageStaffAssignLoader="../../assets/img/ok.png";
      }
      if(this.vehStaffAsignStatus[0].result=="Already exists")
      {
        this.isStaffAssignSave=true; 
        this.showHideStaffAssignLoadDiv=true;
        this.imageStaffAssignLoader="../../assets/img/wrong.jpg";
      } 
  }); 
 } 
//To save the Area Asign Entity Data into the VEHENTITYMAP Table
onClickToSaveVehStaffNameDeta(){
  this.currentDate=new Date();
  var activeStatus; 
  this.isStaffAssignSave=true; 
  this.loaderService.display(true); 
  if(this.activeStatus=="Active"){activeStatus=1;}   
  if(this.vehStaffRoleModel==null||this.vehStaffRoleModel==undefined)
  { 
    this.vehStaffRoleStatus=true;
    return;
  }
  if(this.vehStaffNameModel==null||this.vehStaffNameModel==undefined)
  {
    this.vehStaffRoleNameStatus=true;
    return;
  } 
  var jsonAreaEntityData=
  {  
    "VEHID":this.Id, 
    "EMPROLEMAPID":this.vehStaffNameModel,  
    "ASSIGNDT":this.currentDate,  
    "ISACTIVE":activeStatus?activeStatus:0, 
    "ENTRYDT":this.currentDate,  
    "UPDATEDBY":this.userId
  }  
  console.log("staff array",jsonAreaEntityData)
    this.http.post(environment.apiUrl+'admin/saveVehStaffNameDetails',jsonAreaEntityData).subscribe((data)=>{ 
      var staffAssignData=data.json(); 
      if(staffAssignData.status=="ok"){
        this.saveStaffNameStatus=true; 
        this.saveStaffNameError=false;
        this.getAllStaffAssignmentDetails(this.Id); 
        setTimeout(()=>{
          this.saveStaffNameStatus=false; 
          this.showHideStaffAssignLoadDiv=false;
          this.vehStaffRoleModel=null;
          this.vehStaffNameModel=null;
          this.loaderService.display(false);  
        }, 1000); 
      } else{
      this.saveStaffNameError=true;
      this.loaderService.display(false);  
      }     
  }); 
 
} 
 
importVehiclesExcelReport(data)
{
  const ws_name = 'VehicleReport';
  const wb: WorkBook = { SheetNames: [], Sheets: {} };
  const ws: any = utils.json_to_sheet(data);
  wb.SheetNames.push(ws_name);
  wb.Sheets[ws_name] = ws;
  const wbout = write(wb, { bookType: 'xlsx', bookSST: true, type: 
'binary' });
saveAs(new Blob([this.s2ab(wbout)], { type: 'application/octet-stream' }), 'exported.xlsx');
}
s2ab(s) 
  {
    const buf = new ArrayBuffer(s.length);
    const view = new Uint8Array(buf);
    for (let i = 0; i !== s.length; ++i) {
      view[i] = s.charCodeAt(i) & 0xFF;
    };
    return buf;
  }
 
 
activeStatus:any;
delete(data){
  this.VehiclesNo=data.vehno
  $("#myModal").modal("show");
}
assigmant(data){ 
  console.log("data",data)
  this.VehiclesNo=data.vehno
  this.vehCatArea=data.vehcatname
  this.isVehAssignSave=true; 
  this.isStaffAssignSave=true;
  this.Id=data.ID
  this.activeStatus=data.isactive
  $("#myVehiclesAssignmtModal").modal("show");
  this.getAllAreaAssignmentDetails(this.Id)
  this.getAllStaffAssignmentDetails(this.Id); 
  this.saveStaffNameError=false;
  this.delwarning=false;
}  

//=================To validations for only Vehicles Catogery and Type============//
OnChangeVehiclesCatogeryName()
{
 this.getAllVehiclesType(this.vehCotId); 
 if(this.vehCotId==undefined||this.vehCotId==null) 
 { 
   this.vehTypeId=null;
   this.isVehicleUpdtbtn=true;
   return; 
 } 
 if(this.vehCotId!=undefined||this.vehCotId!=null) 
 {   
   this.isVehicleUpdtbtn=false;
   return true;
 } 
} 
//Vehicles Type check
OnChangeVehiclesTypeName()
{
  if(this.vehTypeId==undefined||this.vehTypeId==null) 
 {
   this.udptVehTypename=true;
   this.isVehicleUpdtbtn=true; 
   return;
 } 
 if(this.vehTypeId!=undefined||this.vehTypeId!=null) 
 {  
   this.udptVehTypename=false;
   this.isVehicleUpdtbtn=false;
   return true;
 } 
} 
 //restrict input only number  
public restrictNumericForVtsMobileNo(e) 
{
  let input;
  var inputlen;
  if (e.metaKey || e.ctrlKey) {
    return true;
  }
  if (e.which === 32) {
   return false;
  }
  if (e.which === 0) {
   return true;
  }
  if (e.which < 33) {
    return true;
  }
  input = String.fromCharCode(e.which); 
  return !!/[\d\s]/.test(input);
 }

 OnChangeVehiclesParkLocId()
 {
  if(this.parkLocations==undefined||this.parkLocations==null) 
  {
    this.udptParkLocation=true;
    this.isVehicleUpdtbtn=true; 
    return;
  } 
  if(this.parkLocations!=undefined||this.parkLocations!=null) 
  {  
    this.udptParkLocation=false;
    this.isVehicleUpdtbtn=false; 
    return true;
  } 
 } 
 OnChangeDataStatus()
 {
  if(this.vehDataStatus==undefined||this.vehDataStatus==null) 
  {
    this.udptDataStatus=true; 
    this.isVehicleUpdtbtn=true; 
    return;
  } 
  if(this.vehDataStatus!=undefined||this.vehDataStatus!=null) 
  {  
    this.udptDataStatus=false;
    this.isVehicleUpdtbtn=false; 
    return true;
  } 
 } 

//Created by RAM on 21-08-2018
getVtsModalData(){
  this.http.get(environment.apiUrl+'admin/getVtsModalDetails?prjid='+this.Prjid).subscribe((data)=>{
  this.vtsModalaData=data.json();
 });
}


/*
 * On select change event VTS Modal 
 */
onChangeVtsModal(data){ 
  if(data!=null){
    this.vtsData=data.VTSMODALNO 
    this.vtsModelRequired=false; 
  } 
  else{ 
    this.vtsModelRequired=true;
  }
}

/*
 * To select the vehicle owner Type
*/ 
onChangeVehTypOwner(data){
  if(data!=null){
    this.ownerType=data.VALUE 
    this.vehOwnerRequired=false; 
  } 
  else{
    this.vehOwnerRequired=true; 
  }
} 



}  
 
