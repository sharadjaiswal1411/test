import { Component } from '@angular/core';
import {HttpClient } from '@angular/common/http'; 
import { AuthService } from '../../_services'; 

@Component({
  selector: 'ent-Mapping',
  templateUrl: './ent.component.html',  
})

export class EntComponent {
 public prjId:any
 public userId:any
  constructor(private http: HttpClient,private auth : AuthService) { 
  }  
  ngOnInit() 
  { 
    this.prjId = this.auth.getAuthentication().projectId  
    this.userId = this.auth.getAuthentication().id 
  }

}
 