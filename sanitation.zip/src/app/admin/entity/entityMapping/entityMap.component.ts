

import { Component, NgZone} from '@angular/core';
import { Http } from '@angular/http'
import { environment } from '../../../../environments/environment';
import { AuthService } from '../../../_services/index'; 
import { LoaderService } from '../../../_services/loader.service'; 
import { process, State } from '@progress/kendo-data-query';
import { GroupDescriptor, DataResult } from '@progress/kendo-data-query';
import {GridDataResult,DataStateChangeEvent} from '@progress/kendo-angular-grid';
import { Observable } from 'rxjs/Observable';  

declare var $: any;  
//For Child Column
const distinctChldEntity = data => data.filter((x, idx, xs) => xs.findIndex(y => y.CHLDENTNAME === x.CHLDENTNAME) === idx); 
const distinctChldEntTyp = data => data.filter((x, idx, xs) => xs.findIndex(y => y.CHLDOEMNAME === x.CHLDOEMNAME) === idx); 
const distinctChldCat = data => data.filter((x, idx, xs) => xs.findIndex(y => y.CHLDOEMTYPE === x.CHLDOEMTYPE) === idx); 
//For parent Column
const distinctPrntEntity = data => data.filter((x, idx, xs) => xs.findIndex(y => y.PRNTENTITYNAME === x.PRNTENTITYNAME) === idx); 
const distinctPrntEntTyp = data => data.filter((x, idx, xs) => xs.findIndex(y => y.PRNTOEMNAME === x.PRNTOEMNAME) === idx); 
const distinctPrntCat = data => data.filter((x, idx, xs) => xs.findIndex(y => y.PRNTOEMTYPE === x.PRNTOEMTYPE) === idx); 

@Component({
    selector: 'app-entityMap',
    templateUrl: './entityMap.component.html',  
     
  })

  export class EntityMapComponent{ 
    public prjId:any; 
    public userId:any; 
    public showLoader:Boolean;  
    public success=false;
    public error=false; 
    public entityMapList:any;
    public entityTypList:any;
    public entityTypChildList:any;
    public entityCatChildList:any;
    public entityCategoryList:any;
    public entityList:any;
    public entityChildList:any;
    public entityChildModal:any;
    public entityModal:any;
    public entityTypeModal:any;
    public entityTypeChildModal:any;
    public statusMessage:any;
    prntCatRequired=false;
    prntEntRequired=false;
    prntEntityRequired=false;
    childCatRequired=false;
    chldEntityTypeRequired=false;
    chldEntityRequired=false;
    entityCategoryModal:any;
    entityCategoryChildModal:any;
    currId:any; 
    errorDelete=false;
    successDelete=false; 
    public state: State = { 
        skip: 0,
        take: 12, 
        filter: {
        logic: 'and',
        filters: []
      }
    };
    public groups: GroupDescriptor[] = [];
    public view: Observable<GridDataResult>;
    public gridView: DataResult;
    public groupChange(groups: GroupDescriptor[]): void {
      this.groups = groups;
      this.loadProducts();
    }
    public distinctChldEntity: any[]
    public distinctChldEntTyp: any[]
    public distinctChldCat: any[] 
    public distinctPrntEntity: any[]
    public distinctPrntEntTyp: any[]
    public distinctPrntCat: any[] 
    private loadProducts(): void {
      this.gridDataEntityMap = process(this.entityMapList, { group: this.groups }); 
    }
    public gridDataEntityMap: GridDataResult 
      constructor(private auth : AuthService,private http: Http,private loaderService: LoaderService) {
      //this.maintenanceDate= new Date(); 
      this.loaderService.status.subscribe((val: boolean) =>{
      this.showLoader = val;
      }); 
     } 

  /*
  * get vehicles Details By Project Id
  */  
  getEntityMappingList(){   
        this.loaderService.display(true);
        this.http.get(environment.apiUrl+'admin/getEntityMapping?prjId='+this.prjId).subscribe(data =>{       
              this.entityMapList=data.json();  
              if(this.entityMapList.length>0){  
               this.distinctChldEntity = distinctChldEntity(this.entityMapList)
               this.distinctChldEntTyp = distinctChldEntTyp(this.entityMapList)
               this.distinctChldCat = distinctChldCat(this.entityMapList)
               this.distinctPrntEntity = distinctPrntEntity(this.entityMapList)
               this.distinctPrntEntTyp = distinctPrntEntTyp(this.entityMapList)
               this.distinctPrntCat = distinctPrntCat(this.entityMapList)
               this.gridDataEntityMap = process(this.entityMapList, this.state);  
               this.loaderService.display(false);
               }          
               else if(this.entityMapList==0){ 
               this.loaderService.display(false);
             }  
        });
    }

    public dataStateChange(state: DataStateChangeEvent): void { 
      this.state = state;
      this.gridDataEntityMap = process(this.entityMapList, this.state);  
      if (state && state.group) {   
        this.distinctChldEntity = distinctChldEntity(this.entityMapList)
        this.distinctChldEntTyp = distinctChldEntTyp(this.entityMapList)
        this.distinctChldCat = distinctChldCat(this.entityMapList)
        this.distinctPrntEntity = distinctPrntEntity(this.entityMapList)
        this.distinctPrntEntTyp = distinctPrntEntTyp(this.entityMapList)
        this.distinctPrntCat = distinctPrntCat(this.entityMapList)
        this.gridDataEntityMap = process(this.entityMapList, this.state);   
      } 
    }

 

    entityMappingModal(){ 
        this.success=false;
        this.error=false;
        this.prntCatRequired=false;
        this.prntEntRequired=false;
        this.prntEntityRequired=false;
        this.childCatRequired=false;
        this.chldEntityTypeRequired=false;
        this.chldEntityRequired=false;
        this.entityTypeModal=null; 
        this.clearAllinputFields();
       $('#entityMappingModal').modal('show');  
    }
   
    /*
     * get entity Category
     */ 
    getEntityCategory(){ 
    this.http.get(environment.apiUrl+'admin/getEntityTypeMasterByProject?PRJID='+this.prjId).subscribe((data)=>{ 
        this.entityCategoryList=data.json();  
        this.entityCatChildList=data.json();
    });
    } 
  
    //Parent
    onEntityCategory(data){
        if(data==null){
            this.prntCatRequired=true;
        }else{
        this.prntCatRequired=false;
        this.http.get(environment.apiUrl+'admin/getEntityTypDetailsByProject?PRJID='+this.prjId+'&OEMTYPID='+data.ID).subscribe((data)=>{
                this.entityTypList=data.json();
                this.entityTypeModal=null;
                this.entityModal=null; 
           }); 
        }
    }
    //Child
    onEntityCategoryChild(data){
        if(data==null){
            this.childCatRequired=true;
        }else{
        this.childCatRequired=false; 
        this.http.get(environment.apiUrl+'admin/getEntityTypDetailsByProject?PRJID='+this.prjId+'&OEMTYPID='+data.ID).subscribe((data)=>{
                this.entityTypChildList=data.json(); 
                this.entityTypeChildModal=null;
                this.entityChildModal=null;
                console.log("data",this.entityTypChildList)
           });  
        }
    }
    
    //Parent 
    onSelectEntityType(data){
        console.log(data)
        if(data==null){
            this.prntEntRequired=true;
        }
        else{ 
        this.prntEntRequired=false;  
        this.http.get(environment.apiUrl+'admin/getEntityDetailsbyOEMID?PRJID='+this.prjId+'&PRNTID='+data.ID).subscribe((data)=>{
           this.entityList = data.json(); 
           console.log("data",this.entityList)
        });
    }  
    }
    //Child
    onSelectEntityChildType(data){
        if(data==null){
            this.chldEntityTypeRequired=true;
        }
        else{ 
        this.chldEntityTypeRequired=false; 
        this.http.get(environment.apiUrl+'admin/getEntityDetailsbyOEMID?PRJID='+this.prjId+'&PRNTID='+data.ID).subscribe((data)=>{
           this.entityChildList = data.json();  
           console.log("data",this.entityList)
        });  
      }
    }





    //For validation 
    onSelectEntity(data){
        if(data==null){
            this.prntEntityRequired=true;
        }
        else{
            this.prntEntityRequired=false;
        }
    }
    onSelectEntityChild(data){
        if(data==null){
            this.chldEntityRequired=true;
        }
        else{
            this.chldEntityRequired=false;
        }
    }


  /*
   *Seve Entity Details 
  */
    saveEntityMapDetail(){
        if(this.entityCategoryModal==null) {
            this.prntCatRequired=true;return
        }
        if(this.entityTypeModal==null){
            this.prntEntRequired=true;return
        }
        if(this.entityModal==null){
            this.prntEntityRequired=true;return
        }
        if(this.entityCategoryChildModal==null){
           this.childCatRequired=true;return
        }
        if(this.entityTypeChildModal==null){
            this.chldEntityTypeRequired=true;return
        }
        if(this.entityChildModal==null){
            this.chldEntityRequired=true;return
        }
        var entityMapJson={ 
            "PRJID":this.prjId,
            "ENTITYID":this.entityChildModal,
            "PRNTID":this.entityModal,
            "ISACTIVE":1,
            "USERID":this.userId
            } 
            this.http.post(environment.apiUrl+'admin/saveEntityMappData',entityMapJson).subscribe((data)=>{
                var status = data.json(); 
                if(status.output[0].RESPONSECODE=="200"){
                    this.success=true; 
                    this.statusMessage=status.output[1].RESPONSEMESSAGE 
                    setTimeout(() =>{  
                     this.success=false; 
                     this.clearAllinputFields();
                     this.getEntityMappingList(); 
                    },2000);
                } 
                else{
                    this.error=true;
                    this.statusMessage=status.output[1].RESPONSEMESSAGE
                }  
             });
    }

    clearAllinputFields(){
        this.entityCategoryModal=null  
        this.entityTypeModal=null 
        this.entityModal=null
        this.entityCategoryChildModal=null  
        this.entityTypeChildModal=null  
        this.entityChildModal=null 
    }

    
    
    deleteEntity(data){
        $('#deleteModalpopup').modal('show');
        this.currId=data.id; 
        console.log(this.currId)
    }

    /*
     *Delete Entity  
    */
    inactiveEntity(){
        this.http.get(environment.apiUrl+'admin/deleteEntityMapping?Id='+this.currId).subscribe((data)=>{
            var value = data.json(); 
            if(value.status=="ok"){
                this.successDelete=true;  
                this.getEntityMappingList();
                setTimeout(() =>{  
                    this.successDelete=false;  
                    $('#deleteModalpopup').modal('hide');
                   },2000);
            }else{
                this.errorDelete=true; 
            }  
         });
    }
   
    
    ngOnInit(){ 
      this.prjId = this.auth.getAuthentication().projectId
      this.userId= this.auth.getAuthentication().id  
      this.getEntityCategory();
      this.getEntityMappingList(); 
    }
  }
