import { Component ,OnInit  } from '@angular/core'; 
import {Http} from "@angular/http"; 
import { environment } from '../../../../environments/environment';
import { Broadcaster } from '../../../../environments/broadcaster'; 
import { utils, write, WorkBook } from 'xlsx';  
import { saveAs } from 'file-saver'; 
import { AuthService } from '../../../_services/index';
import { LoaderService } from '../../../_services/loader.service';
import Swal from 'sweetalert2'
declare var $:any;  

@Component({
  selector: 'app-entity',
  templateUrl: './entity.component.html',
  styleUrls: ['./entity.component.css']
})
export class EntityComponent  implements OnInit{ 
  showLoader: boolean;
public entityData:any;
public prjId:any;
public userid:any;
selectedRow : Number;
selectedVehEntityRow:Number;
selectedEmpAssignRow:Number;
public entityAssignTypeData:any;
public ddlEntityAssignType:any;
public txtEntityName:any;
public search:any;
public searchModal:any;  
public entyAssignMsgSuccess=false;  
public entyAssignMsgWarning=false; 
public entyAssignMsgError=false; 
public entityRecordNotFound=false; 
public entityAssignError=false; 
public entityEmpAssignSuccess=false;
public entityEmpAssignWarning=false;
public entityEmpAssignError=false;
public entityId:any; 
public vehicleAssignData:any;  
public vehId:any;
public status:any;
public isAssign:any; 
public isAssignedEmpStstus:any;
public entityAssignJsonData:any; 
public isEmpAssignbtn=false;
public staffAssignmentData:any;
public empId:any;
public oemId:any;
public roleId:any;
public ddlEntityModal:any;
public entityTypData:any;
public ddlEntitysModal:any;
public entityParantData:any;
public entityCodeModal:any;
public entityNameModal:any;
public ddlParantModal:any;
public txtAreaKmlModal:any;
public EntityStatusData:any;
public currentDate:any;
public entityIsActiveModel:any;
public entitySaveSuccessMsg=false;
public entitySaveWarningMsg=false;
public isSavebtn=false;
public entityNameMsg=false;
public entityOrgnizedMsg=false;
public entityCodeMsg=false;
public entityNameAlertMsg=false;
public entityPrntNameMsg=false;
public imagePath:any;
public ddlEntityCatModal:any;
public ddlEntityTypeModal:any;
public entityEntCodeDiv=false;
public entityTypId:any;
public entyVehAssignReNotFound=false;
public entyStaffAssignReNotFound=false; 
titleData:any;
successMsg:any;
changeStatus:any; 
empassignMsg:any;
assignStatus:any;
staffAssignstatus:any;
vehicleAssignedList:any;
vehAssignNotFound=false;
currntEntityId:any;
staffAssignedList:any;
staffAssignNotFound=false;
empAssignCount:any;
vehAssinedCount:any;
empAssignListCount:any;
vehassignListCount:any;
vehSearchModal:any;
empSearchModal:any
vehAssignSearchModal:any
empAssignSearchModal:any
constructor(private http: Http,private broadcaster: Broadcaster,private auth:AuthService,private loaderService: LoaderService){
    this.loaderService.status.subscribe((val: boolean) =>{
      this.showLoader = val;
    });
}  
public BindEntityStatus(){
  this.EntityStatusData=
  [{  
  "ID":1,
  "VALUE":"ACTIVE", 
  },
  {  
    "ID":2,
    "VALUE":"INACTIVE", 
  }]
}   


//To get the Entity Type Id on ddl select 
onChangeToSelectEntityType(OEMID){  
  this.getEntityDetails(OEMID); 
} 

selectEntityMstDetailsRowData(entityData,index){ 
  this.entityId=entityData.ID; 
  this.getVehAssignmentbyEntityId(); //bind Entity assign Table
  this.getStaffAssignmentbyEntityId()//bind Staff assign Table
  this.selectedRow = index;
  this.txtEntityName= entityData.ENTITYNAME; 
}
selectEntityAssignRowData(vehicleAssignData,index){ 
 this.vehId=vehicleAssignData.vehID;
 this.selectedVehEntityRow = index;
 this.isAssign=vehicleAssignData.isAssigned;
 this.status=vehicleAssignData.isactive; 
} 


//This Method is used to get the Entity Master Data
getEntityDetails(OEMID){ 
    this.loaderService.display(true); 
    this.http.get(environment.apiUrl+'admin/getEntityMasterDetailsByProject?PRJID='+this.prjId+'&OEMID='+OEMID).subscribe((data)=>{
            this.entityData = data.json();  
            if(this.entityData.length==0){ 
            this.entityRecordNotFound=true;
            }
            if(this.entityData.length!=0){ 
            this.entityRecordNotFound=false;
            }
            this.loaderService.display(false); 
    }); 
 } 



//This method is used to assignment the entity master Details
entityAssignMaster()
{  
  $("#entityMstrAssignModel").modal("show");  
}

//This method is used to get the Entity Type as per Project ID/Name 
getEntityTypeByProject(){ 
this.http.get(environment.apiUrl+'admin/getEntityTypeMasterByProject?PRJID='+this.prjId).subscribe((data)=>{ 
    this.entityAssignTypeData=data.json(); 
    this.ddlEntityAssignType=this.entityAssignTypeData[0].ID; 
    let oemId = this.entityAssignTypeData[0].ID; 
    if(oemId!=undefined){
      this.getEntityDetails(oemId); 
    }else{
      alert('Entity Id not available.')
    }
 });
} 
//This Method is use to Download the Vehicles Report into Excel File 
importEntityExcelReport(entityData){
  const ws_name = 'EntityReport';
  const wb: WorkBook = { SheetNames: [], Sheets: {} };
  const ws: any = utils.json_to_sheet(entityData);
  wb.SheetNames.push(ws_name);
  wb.Sheets[ws_name] = ws;
  const wbout = write(wb, { bookType: 'xlsx', bookSST: true, type: 'binary' });
  saveAs(new Blob([this.s2ab(wbout)], { type: 'application/octet-stream' }), 'exportedEntityReport.xlsx');
}
s2ab(s) 
  {
    const buf = new ArrayBuffer(s.length);
    const view = new Uint8Array(buf);
    for (let i = 0; i !== s.length; ++i) {
      view[i] = s.charCodeAt(i) & 0xFF;
    };
    return buf;
  }
//Open Assign modal popup windows
  entityAssignment(data){  
    console.log("sele assignement",data) 
    this.currntEntityId=data.ID 
    this.getAssignedVehicleList(this.currntEntityId)
    this.getAssignedStaffList(this.currntEntityId)
    $("#entityMstrAssignModel").modal("show"); 
  } 

/*
 * get Vehicle Assignment List
*/ 
getVehAssignmentbyEntityId(){  
this.http.get(environment.apiUrl+'admin/getVehAssignmentbyEntityAndPrjID?PRJID='+this.prjId+'&ENTITYID='+this.entityId).subscribe((data)=>{ 
    this.vehicleAssignData=data.json(); 
    if(this.vehicleAssignData==0){
      this.vehassignListCount=0; 
      this.entityRecordNotFound=true;
    }else{
      this.vehassignListCount=this.vehicleAssignData.length
      this.entityRecordNotFound=false;
    } 
 });
} 


//Click the Yes button To Assign/Unassign Entity Details.
// assignEntityDetails(){  
//   var assignStatus; 
//   this.isYesAssignbtn=true;
//   if(this.isAssign==1){assignStatus=0} if(this.isAssign==0){assignStatus=1}  
//    var entityAssignJsonData={    
//      "VEHID":this.vehId,
//      "ENTITYID":this.entityId,
//      "ISACTIVE":assignStatus,
//      "userId":this.userid  
//    }  
//     this.http.post(environment.apiUrl+'admin/editAssignDetailByProject',entityAssignJsonData).subscribe((data)=>{  
//       var statusCode=data.json().status;  
//       if(statusCode=="200"){ 
//        this.getVehAssignmentbyEntityId(); 
//        this.entityAssignSuccess=true;
//        if(this.isAssign == 1){
//         this.entityAssignSuccessMsg = "This Vehicle Assigned Successfully"
//        }else if(this.isAssign == 0){
//         this.entityAssignSuccessMsg = "This Vehicle Unassigned Successfully"
//        }       
//        this.isYesAssignbtn=true;
//       }else{ 
//        this.isYesAssignbtn=false; 
//        this.entityAssignWarning=true; 
//       }  
//       setTimeout(() =>{  
//         this.entityAssignSuccess=false;  
//         this.isYesAssignbtn=false; 
//         $("#entityAssignConformModal").modal("hide"); 
//       },1000);
//   }); 
// } 
//This Method is used to Add New Entity Modal Papup
addNewEntityDetails(){
  this.isSavebtn=true;
  $("#addNewEntityModal").modal("show"); 
}


/*
 * get Staff assigne Data
 */ 
getStaffAssignmentbyEntityId(){   
this.http.get(environment.apiUrl+'admin/getStaffAssignmentbyEntityAndPrjID?PRJID='+this.prjId+'&ENTITYID='+this.entityId).subscribe((data)=>{ 
    this.staffAssignmentData=data.json();  
    if(this.staffAssignmentData==0){
      this.entityRecordNotFound=true;
      this.empAssignListCount=0;
    }else{
      this.empAssignListCount=this.staffAssignmentData.length
      this.entityRecordNotFound=false;
    } 
 });
}


//This method is used to get the selected row Value on staff selection
// selectStaffAssignRowData(staffAssignmentData,index){ 
//  this.roleId=staffAssignmentData.roleID;
//  this.selectedEmpAssignRow = index;
//  this.empId=staffAssignmentData.empID;
//  this.isAssignedEmpStstus=staffAssignmentData.Isassigned;  
// }
//To Click the Taggel button Event and Open The Staff Assignmnet confirmations Box
// btnToggleStaffAssign(){  
//   $("#entityStaffConformModal").modal("show"); 
// }

//Click the Yes button To Assign/Staff Assignment Details.
//  assignEmployeeEntityDetails(){ 
//    var empAssignStatus; 
//    this.isEmpAssignbtn=true;  
//    if(this.isAssignedEmpStstus==1){empAssignStatus=0} if(this.isAssignedEmpStstus==0){empAssignStatus=1}   
//     var entityAssignEmployeeJsonData={   
//       "EMPID":this.empId,
//       "ENTITYID":this.entityId,
//       "ROLEID":this.roleId,
//       "ISACTIVE":empAssignStatus,
//       "userId":this.userid  
//     }  
//      this.http.post(environment.apiUrl+'admin/editAssignEmployeeDetailByProject',entityAssignEmployeeJsonData).subscribe((data)=>{  
//       var statusCode=data.json().status;  
//         if(statusCode=="200"){ 
//            this.getStaffAssignmentbyEntityId(); 
//            this.entityEmpAssignSuccess=true;
//            this.isEmpAssignbtn=true;
//         }else{ 
//          this.isEmpAssignbtn=false; 
//          this.entityEmpAssignWarning=true; 
//         }  
//         setTimeout(() =>{  
//           this.entityEmpAssignSuccess=false;  
//           this.isEmpAssignbtn=false; 
//           $("#entityStaffConformModal").modal("hide"); 
//         },2000);
//     }); 
//  }

 viewPolygon(){
  $("#viewPolygonModal").modal("show"); 
 }

 //####################### Add New Entity Details##################//

onChangeToSelectEntityCatType(){ 
 if(this.ddlEntityCatModal==null||this.ddlEntityCatModal==undefined||this.ddlEntityCatModal==''){
    this.isSavebtn=true;
    this.entityNameMsg=true 
    return
  } 
  this.entityNameMsg=false 
  this.http.get(environment.apiUrl+'admin/getEntityTypDetailsByProject?PRJID='+this.prjId+'&OEMTYPID='+this.ddlEntityCatModal).subscribe((data)=>{
          this.entityTypData=data.json(); 
     }); 
} 

//To select Entity Type Name  
onChangeToSelectParntId(data)
{   
   this.entityTypId=data.ID; 
   if((this.ddlEntityTypeModal==null||this.ddlEntityTypeModal==undefined||this.ddlEntityTypeModal=='')&&(this.entityTypId==null)){ 
     this.isSavebtn=true;
     this.entityOrgnizedMsg=true; 
     this.ddlEntityCatModal=null;
     return;
   }else{  
     this.isSavebtn=false;
     this.entityOrgnizedMsg=false; 
     this.http.get(environment.apiUrl+'admin/getEntityDetailsbyOEMID?PRJID='+this.prjId+'&PRNTID='+this.ddlEntityTypeModal).subscribe((data)=>{
        this.entityParantData = data.json(); 
        if(this.entityParantData.length>0){
          this.oemId=this.entityParantData[0].OEMID 
        } 
     }); 
   }  
} 

 /*
 * this method is used to save the Entity Details into the entitymst table
 */ 
 saveEntityDetails(){
  var entityStatus; 
  this.isSavebtn=true;
  this.currentDate=new Date();  
  if(this.ddlEntityCatModal==null||this.ddlEntityCatModal==undefined||this.ddlEntityCatModal==''){
    this.isSavebtn=true; 
    this.entityNameMsg=true;
    return; 
  }  
  if((this.entityTypId==null||this.entityTypId==undefined||this.entityTypId=='')&&(this.entityTypData[0].ID==null)){ 
    this.isSavebtn=true;
    this.entityOrgnizedMsg=true;  
    return;
  } 
  if(this.entityCodeModal==null||this.entityCodeModal==undefined||this.entityCodeModal==''){ 
    this.isSavebtn=true;
    this.entityCodeMsg=true;  
    return;
  } 
  if(this.entityNameModal==null||this.entityNameModal==undefined||this.entityNameModal==''){ 
    this.isSavebtn=true;
    this.entityNameAlertMsg=true;  
    return;
  } 
  if(this.entityIsActiveModel==1){entityStatus=1}else{entityStatus=0}
   var entityMstrJsonData={    
     "PRJID":this.prjId, 
     "OEMID":this.entityTypId?this.entityTypId:null,
     "ENTITYCD":this.entityCodeModal?this.entityCodeModal:null,
     "ENTITYNAME":this.entityNameModal?this.entityNameModal:null,
     "PRNTID":this.ddlParantModal?this.ddlParantModal:null, 
     "KML":this.txtAreaKmlModal?this.entityNameModal:null, 
     "ISOPERTNL":1,
     "ISACTIVE":entityStatus?entityStatus:0,
     "ENTRYDT":this.currentDate, 
     "UserId":this.userid  
   }  
    this.http.post(environment.apiUrl+'admin/saveEntityMasterDetails',entityMstrJsonData).subscribe((data)=>{  
      var entitydata=data.json();  
      this.entitySaveSuccessMsg=true;
      setTimeout(() =>{  
        this.entitySaveSuccessMsg=false; 
        this.clearEntityData();
      },3000);
     },  
      error=>{ 
        this.clearEntityData();
        this.entitySaveWarningMsg=true;  
      });
      
 }
 clearEntityData() {
  this.ddlEntityCatModal=null;
  this.ddlEntityTypeModal=null;
  this.entityCodeModal=null;
  this.entityNameModal=null;
  this.ddlParantModal=null;
  this.txtAreaKmlModal=null;
  this.entityEntCodeDiv=false;
 }
 //#######################Validations Sections START##########################//
// To check the Entity Code is Empty or Not
 isEntityCodeEmpty(){ 
   if(this.entityCodeModal==null||this.entityCodeModal==undefined||this.entityCodeModal==''){
    this.isSavebtn=true;
    this.entityCodeMsg=true;
    this.entityEntCodeDiv=false;
    return;
   }  else  {
    this.isSavebtn=false;
    this.entityCodeMsg=false;
   }
   this.isSavebtn=true;
   this.entityEntCodeDiv=true;
   this.imagePath="../../assets/img/loading.gif";
   this.http.get(environment.apiUrl+'admin/getEntityCodeAvailability?ENTITYCD='+this.entityCodeModal).subscribe((data)=>{  
     var isCodeAvaible=data.json();
     if(isCodeAvaible[0].result=="Available"){
      this.isSavebtn=false;
      this.entityCodeMsg=true;
      this.entityCodeMsg=false;
      this.imagePath="../../assets/img/ok.png";
     } 
     if(isCodeAvaible[0].result=="All ready exist"){
      this.isSavebtn=true;
      this.entityCodeMsg=true; 
      this.imagePath="../../assets/img/wrong.jpg";
      this.entityCodeMsg=false;
     }  
    }); 
 }
 //To check The Entity Name is Empty or Not
 isEntityNameEmpty(){ 
  if(this.entityNameModal==null||this.entityNameModal==undefined||this.entityNameModal==''){
   this.isSavebtn=true;
   this.entityNameAlertMsg=true;
   return;
  } else  {
   this.isSavebtn=false;
   this.entityNameAlertMsg=false;
  }
 }
 onChangeSelectParantName() {
  if(this.ddlParantModal==null||this.ddlParantModal==undefined||this.ddlParantModal=='')  {
   this.isSavebtn=true;
   this.entityPrntNameMsg=true;
   return;
  } else  {
   this.isSavebtn=false;
   this.entityPrntNameMsg=false;
  }
 }

 
 
// updateEntityAssign(item){  
//       if(item.isAssigned == 1){
//         this.assignmentMessage = "Are you sure to Assign this Vehicle ?"
//       }else if(item.isAssigned == 0){
//         this.assignmentMessage = "Are you sure to Unassign this Vehicle ?"
//       }
//       $("#entityAssignConformModal").modal("show"); 
//   } 

  /*
   * get Vehicle Status
  */
  setStatus(data){ 
    if(data.ActiveStatus=="Unassigned"){
      this.assignStatus="Assign"
    }else{
      this.assignStatus="Unassigned"
    }
  }
 
  /*
   * set/Assign Vehicle to the Entity
   */
  setAssignStatus(data){ 
    var status=data.ActiveStatus 
    if(status=="Unassigned")
    {
      this.changeStatus=1
      this.titleData="Are you sure to Assign this Vehicle ?"
      this.successMsg="User Assign successfully."
    } 
    else{
      this.changeStatus=0
      this.titleData="Are you sure to Unassign this Vehicle ?"
      this.successMsg="Vehicle Unassign successfully."
    } 
    var assignData={    
      "VEHID":data.vehID,
      "ENTITYID":this.entityId,
      "ISACTIVE":this.changeStatus,
      "userId":this.userid  
    } 
    Swal({
      title: this.titleData, 
      type: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Yes, Convert it!'
    }).then((result) => {
      if (result.value) { 
        this.http.post(environment.apiUrl + "admin/editAssignDetailByProject", assignData).subscribe(data =>{ 
            var response = data.json()  
            var resCode = response[0].RESPONSECODE 
            //var respMsg=response[1].RESPONSEMESSAGE
            if (resCode == "200") { 
                this.getVehAssignmentbyEntityId();
                this.getAssignedVehicleList(this.entityId);
              Swal( 
                this.successMsg,
                'success'
                ) 
                } else 
                { 
                Swal(
                this.successMsg,
                'error'
                ) 
            }
          });
      }
    })
  } 


  
  /*
   * Get staff details for assign and unassign  
   */ 
  getStaffStatus(data){
    console.log("Emp List11",data.AssignStatus) 
    if(data.AssignStatus=="Assigned"){
      this.staffAssignstatus="Unassigned"
    }else{
      this.staffAssignstatus="Assigned"
    } 
  }


   /*
   * Assign Vehicle to the Entity
   */  
  setStaffAssignStatus(data){ 
    console.log("emp selected data",data)
    var status=data.AssignStatus 
    if(status=="Unassigned")
    {
      this.changeStatus=1
      this.titleData="Are you sure to Assign this Employee to selected Location?"
      this.empassignMsg="Employee Assign successfully."
    } 
    else{
      this.changeStatus=0
      this.titleData="Are you sure to Unassign this Employee from this Location?"
      this.empassignMsg="Employee Unassign successfully."
    } 
    var empAssign={   
            "EMPID":data.empID,
            "ENTITYID":this.entityId,
            "ROLEID":data.roleID,
            "ISACTIVE":this.changeStatus,
            "userId":this.userid  
          } 
    Swal({
      title: this.titleData, 
      type: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Yes, Convert it!'
    }).then((result) => {
      if (result.value) { 
        this.http.post(environment.apiUrl + "admin/editAssignEmployeeDetailByProject", empAssign).subscribe(data =>{ 
            var response = data.json()  
            var resCode = response[0].RESPONSECODE  
            if (resCode == "200") { 
                this.getStaffAssignmentbyEntityId();
                this.getAssignedStaffList(this.entityId)
              Swal( 
                this.empassignMsg,
                'success'
                ) 
                } else 
                { 
                Swal(
                this.empassignMsg,
                'error'
                ) 
            }
          });
      }
    })
  } 

   /*
   * Get vehicle assined Details
   */ 
  getAssignedVehicleList(entityId){  
  this.http.get(environment.apiUrl+"admin/getAssinedVehList?PRJID="+this.prjId+'&ENTITYID='+entityId).subscribe((data)=>{ 
      this.vehicleAssignedList=data.json(); 
      if(this.vehicleAssignedList==0){
        this.vehAssignNotFound=true;
        this.vehAssinedCount=0; 
      }else{
        this.vehAssinedCount=this.vehicleAssignedList.length
        this.vehAssignNotFound=false;
      } 
   });
  } 

  /*
   * Get Staff assined Details
   */ 
  getAssignedStaffList(entityId){  
    this.http.get(environment.apiUrl+"admin/getAssinedStaffList?PRJID="+this.prjId+'&ENTITYID='+entityId).subscribe((data)=>{ 
        this.staffAssignedList=data.json(); 
        if(this.staffAssignedList==0){
          this.staffAssignNotFound=true;
          this.empAssignCount=0;
        }else{
          this.empAssignCount=this.staffAssignedList.length
          this.staffAssignNotFound=false;
        } 
     });
    } 
   








  ngOnInit(): void 
  {   
        this.prjId = this.auth.getAuthentication().projectId
        this.userid = this.auth.getAuthentication().id; 
        this.getEntityTypeByProject(); 
        this.BindEntityStatus();  
        this.entityIsActiveModel=this.EntityStatusData[0].ID;  
  } 
}



 


   
