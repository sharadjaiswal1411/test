import { Component, OnInit } from '@angular/core';  
@Component({
  selector: 'admin-cmp',
  templateUrl: './admin.component.html', 
})
export class AdminComponent implements OnInit {
   
  constructor() { }

  ngOnInit(){  
  }
}
