import { Component} from '@angular/core'; 
import { ActivatedRoute, Router } from '@angular/router';
import { Http} from '@angular/http' 
import { environment } from '../../../environments/environment';  
import { AuthService } from '../../_services';
import { LoaderService } from '../../_services/loader.service'; 
import { process, State} from '@progress/kendo-data-query'; 
import { GroupDescriptor, DataResult } from '@progress/kendo-data-query';
import { Observable } from 'rxjs/Observable';
import { SelectableSettings,DataStateChangeEvent,GridDataResult} from '@progress/kendo-angular-grid';
import { ExcelExportData } from '@progress/kendo-angular-excel-export'; 
import * as _moment from 'moment';  
import * as _rollupMoment from 'moment'; 
const moment = _rollupMoment || _moment;   

declare var $: any; 
const distinctFuelType = data => data.filter((x, idx, xs) => xs.findIndex(y => y.FUELTYPE === x.FUELTYPE) === idx); 
const distinctLocation = data => data.filter((x, idx, xs) => xs.findIndex(y => y.LOCATION === x.LOCATION) === idx); 
  
@Component({ 
  selector: 'fuelDistribution',
  templateUrl: './fuelDistribution.component.html',  
})
export class FuelDistributionReportComponent { 
    prjId:any;  
    showLoader:boolean; 
    startDate:any;
    endDate:any;
    defStartDt:any;
    defEndDt:any;
    dateRange:any; 
    fuelDistList:any
    fuelDistb:any;
    public state: State = { 
      skip: 0,
      take: 12,  
    filter: {
      logic: 'and',
      filters: []
    }
  };
  public pageSize :any
  public checkboxOnly = false;
  public mode = 'multiple';
  public selectableSettings: SelectableSettings; 
  public groups: GroupDescriptor[] = [];
  public view: Observable<GridDataResult>;  
  public gridDataFuelDist: DataResult;
  public groupChange(groups: GroupDescriptor[]): void {
    this.groups = groups;
    this.loadProducts();
  } 
  public allData(): ExcelExportData {
    const result: ExcelExportData =  {
        data: this.fuelDistList
    };
    return result;
   } 
  public distinctFuelType: any[]
  public distinctLocation: any[]
  private loadProducts(): void {
    this.gridDataFuelDist = process(this.fuelDistList, { group: this.groups });  
  }
  constructor(private http: Http,private auth : AuthService,public routes: ActivatedRoute, public router: Router,private loaderService: LoaderService) {
    this.loaderService.status.subscribe((val: boolean) =>{
        this.showLoader = val;
      });
    var date = new Date(); 
    this.allData = this.allData.bind(this);  
    this.defStartDt = (date.getFullYear()) + '-' + (date.getMonth() + 1) + '-' + date.getDate(); 
    this.defEndDt = (date.getFullYear()) + '-' + (date.getMonth()+1) + '-' + date.getDate(); 
    this.dateRange= {beginDate: {year: date.getFullYear(), month: date.getMonth()+1, day: date.getDate()},endDate: {year: date.getFullYear(), month: date.getMonth()+1, day: date.getDate()}}; 
  }  
  

    /*
    * get Fuel Report List
    */ 
   getFuelDistributionList(){   
         this.loaderService.display(true);  
                this.http.get(environment.apiUrl + 'reports/getFuelDistributionReport?prjid='+this.prjId+'&startDate='+this.startDate+'&endDate='+this.endDate).subscribe(data =>{ 
                this.fuelDistList=data.json();
                if(this.fuelDistList.length>0){  
                    this.distinctLocation = distinctLocation(this.fuelDistList) 
                    this.distinctFuelType = distinctFuelType(this.fuelDistList) 
                    this.gridDataFuelDist = process(this.fuelDistList, this.state);
                    this.loaderService.display(false); 
                }else{
                    this.loaderService.display(false); 
                    this.gridDataFuelDist=null;
                } 
            });  
   } 


/*
 * filter The Grid Data
*/
  public dataStateChange(state: DataStateChangeEvent): void {
  this.state = state;
  this.gridDataFuelDist = process(this.fuelDistList, this.state);  
  if (state && state.group) { 
      this.distinctLocation = distinctLocation(this.fuelDistList) 
      this.distinctFuelType = distinctFuelType(this.fuelDistList)   
      this.gridDataFuelDist = process(this.fuelDistList, this.state); 
    } 
} 

/*
*select start Date Nad To date
*/
 onDateRangeChanged(dataRange)
 {  
   if(dataRange.beginDate.day>0){ 
     this.startDate= dataRange.beginDate.year + "-"  + dataRange.beginDate.month+ "-" + dataRange.beginDate.day 
     this.endDate = dataRange.endDate.year + "-"  + dataRange.endDate.month  + "-" + dataRange.endDate.day 
     this.getFuelDistributionList(); 
   }
   else if(dataRange.beginDate.day==0){
     this.startDate= this.defStartDt
     this.endDate = this.defEndDt
     this.getFuelDistributionList(); 
   }  
 }  
 
 /*
 * Zoom Image
 */ 
  fuelDitributionImg(data){
    console.log("data",data)
    this.fuelDistb=data.IMGURL
    $("#fuelDistbutionImg").modal("show");  
  } 

 
    ngOnInit() {  
        this.startDate = moment(this.defStartDt).format('YYYY-MM-DD');
        this.endDate= moment(this.defEndDt).format('YYYY-MM-DD');
        this.prjId = this.auth.getAuthentication().projectId  
        this.getFuelDistributionList(); 
    } 
}
  
  
  


   


 
 

 



 
