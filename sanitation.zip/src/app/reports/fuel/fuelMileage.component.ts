import { Component} from '@angular/core'; 
import { ActivatedRoute, Router } from '@angular/router';
import { Http} from '@angular/http' 
import { environment } from '../../../environments/environment';  
import { AuthService } from '../../_services';
import { LoaderService } from '../../_services/loader.service'; 
import { process, State} from '@progress/kendo-data-query'; 
import { GroupDescriptor, DataResult } from '@progress/kendo-data-query';
import { Observable } from 'rxjs/Observable';
import { SelectableSettings,DataStateChangeEvent,GridDataResult} from '@progress/kendo-angular-grid'; 
import { ExcelExportData } from '@progress/kendo-angular-excel-export';
import * as _moment from 'moment';  
import * as _rollupMoment from 'moment'; 
const moment = _rollupMoment || _moment;  
declare var $: any; 
const distinctCategory = data => data.filter((x, idx, xs) => xs.findIndex(y => y.VehicleCategory === x.VehicleCategory) === idx);
const distinctVehicleType = data => data.filter((x, idx, xs) => xs.findIndex(y => y.VehicleType === x.VehicleType) === idx); 



@Component({ 
  selector: 'FuelMileage',
  templateUrl: './fuelMileage.component.html',  
})
export class MileageReportComponent { 
    prjId:any;  
    showLoader:boolean; 
    startDate:any;
    endDate:any;
    defStartDt:any;
    defEndDt:any;
    dateRange:any; 
    fuelMieleageList:any
    public state: State = {  
      skip: 0,
      take: 15, 
      filter: {
      logic: 'and',
      filters: []
    }
  };
  public pageSize :any
  public checkboxOnly = false;
  public mode = 'multiple';
  public selectableSettings: SelectableSettings;

  public allData(): ExcelExportData {
    const result: ExcelExportData =  {
        data: this.fuelMieleageList
    };
    return result;
   } 
 
  public groups: GroupDescriptor[] = [];
  public view: Observable<GridDataResult>; 
  
  
  public gridDataMileageReport: DataResult;
  public groupChange(groups: GroupDescriptor[]): void {
    this.groups = groups;
    this.loadProducts();
  } 
  public distinctCategory: any[]
  public distinctVehicleType: any[]
  private loadProducts(): void {
    this.gridDataMileageReport = process(this.fuelMieleageList, { group: this.groups });  
  }
  constructor(private http: Http,private auth : AuthService,public routes: ActivatedRoute, public router: Router,private loaderService: LoaderService) {
    this.loaderService.status.subscribe((val: boolean) =>{
        this.showLoader = val;
      });
    this.allData = this.allData.bind(this);
    var date = new Date();  
    this.defStartDt = (date.getFullYear()) + '-' + (date.getMonth() + 1) + '-' + date.getDate(); 
    this.defEndDt = (date.getFullYear()) + '-' + (date.getMonth()+1) + '-' + date.getDate(); 
    this.dateRange= {beginDate: {year: date.getFullYear(), month: date.getMonth()+1, day: date.getDate()},endDate: {year: date.getFullYear(), month: date.getMonth()+1, day: date.getDate()}}; 
   }  
  

    /*
    * get Fuel Report List
    */ 
   getFuelMieleageRepoerList(){   
         this.loaderService.display(true);  
                this.http.get(environment.apiUrl + 'reports/getFuelMielageReport?prjid='+this.prjId+'&startDate='+this.startDate+'&endDate='+this.endDate).subscribe(data =>{ 
                this.fuelMieleageList=data.json(); 
                if(this.fuelMieleageList.length>0){  
                    this.distinctCategory = distinctCategory(this.fuelMieleageList) 
                    this.distinctVehicleType = distinctVehicleType(this.fuelMieleageList) 
                    this.gridDataMileageReport = process(this.fuelMieleageList, this.state);
                    this.loaderService.display(false); 
                }else{
                    this.loaderService.display(false); 
                    this.gridDataMileageReport=null;
                } 
            });  
   } 


/*
 * filter The Grid Data
*/
  public dataStateChange(state: DataStateChangeEvent): void {
  this.state = state;
  this.gridDataMileageReport = process(this.fuelMieleageList, this.state);  
  if (state && state.group) { 
      this.distinctCategory = distinctCategory(this.fuelMieleageList) 
      this.distinctVehicleType = distinctVehicleType(this.fuelMieleageList) 
      this.gridDataMileageReport = process(this.fuelMieleageList, this.state); 
    } 
} 

/*
*select start Date Nad To date
*/
 onDateRangeChanged(dataRange)
 {  
   if(dataRange.beginDate.day>0){ 
     this.startDate= dataRange.beginDate.year + "-"  + dataRange.beginDate.month+ "-" + dataRange.beginDate.day 
     this.endDate = dataRange.endDate.year + "-"  + dataRange.endDate.month  + "-" + dataRange.endDate.day 
     this.getFuelMieleageRepoerList(); 
   }
   else if(dataRange.beginDate.day==0){
     this.startDate= this.defStartDt
     this.endDate = this.defEndDt
     this.getFuelMieleageRepoerList(); 
   }  
 } 
  
 
 
    ngOnInit() {  
        this.startDate = moment(this.defStartDt).format('YYYY-MM-DD');
        this.endDate= moment(this.defEndDt).format('YYYY-MM-DD');
        this.prjId = this.auth.getAuthentication().projectId  
        this.getFuelMieleageRepoerList();
    } 
}
  
  
  


   


 
 

 



 
