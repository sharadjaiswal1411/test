import { Component, ViewEncapsulation} from '@angular/core'; 
import { ActivatedRoute, Router } from '@angular/router';
import { Http} from '@angular/http' 
import { environment } from '../../../environments/environment';  
import { AuthService } from '../../_services';
import { LoaderService } from '../../_services/loader.service'; 
import { process, State,aggregateBy} from '@progress/kendo-data-query'; 
import { GroupDescriptor, DataResult } from '@progress/kendo-data-query';
import { Observable } from 'rxjs/Observable';
import { SelectableSettings,DataStateChangeEvent,GridDataResult} from '@progress/kendo-angular-grid'; 
import { ExcelExportData } from '@progress/kendo-angular-excel-export';
import * as _moment from 'moment';  
import * as _rollupMoment from 'moment'; 
const moment = _rollupMoment || _moment;  
declare var $: any; 
const distinctFuelType = data => data.filter((x, idx, xs) => xs.findIndex(y => y.FULETYPE === x.FULETYPE) === idx); 
const distinctVehCategory = data => data.filter((x, idx, xs) => xs.findIndex(y => y.vehcatName === x.vehcatName) === idx); 
export const MY_FORMATS = {
  parse: {
    dateInput: 'LL',
  },
  display: {
    dateInput: 'LL',
    monthYearLabel: 'MMM YYYY',
    dateA11yLabel: 'LL',
    monthYearA11yLabel: 'MMMM YYYY',
  },
}; 



@Component({

  selector: 'fuelPurchase',
  templateUrl: './fuelPurchase.component.html',  
})
export class FuelPurchaseReportComponent { 
    prjId:any;  
    showLoader:boolean; 
    startDate:any;
    endDate:any;
    defStartDt:any;
    defEndDt:any;
    dateRange:any; 
    fuelReportList:any
    purchaseImg:any;
    public state: State = {  
      skip: 0,
      take: 12, 
      filter: {
      logic: 'and',
      filters: []
    }
  };
  public pageSize :any
  public checkboxOnly = false;
  public mode = 'multiple';
  public selectableSettings: SelectableSettings;

  public allData(): ExcelExportData {
    const result: ExcelExportData =  {
        data: this.fuelReportList
    };
    return result;
   } 
 
  public groups: GroupDescriptor[] = [];
  public view: Observable<GridDataResult>; 
  
  
  public gridDataFuelReport: DataResult;
  public groupChange(groups: GroupDescriptor[]): void {
    this.groups = groups;
    this.loadProducts();
  } 
  public distinctFuelType: any[]
  public distinctVehCategory: any[]
  private loadProducts(): void {
    this.gridDataFuelReport = process(this.fuelReportList, { group: this.groups });  
  }
  constructor(private http: Http,private auth : AuthService,public routes: ActivatedRoute, public router: Router,private loaderService: LoaderService) {
    this.loaderService.status.subscribe((val: boolean) =>{
        this.showLoader = val;
      });
    this.allData = this.allData.bind(this);
    var date = new Date();  
    this.defStartDt = (date.getFullYear()) + '-' + (date.getMonth() + 1) + '-' + date.getDate(); 
    this.defEndDt = (date.getFullYear()) + '-' + (date.getMonth()+1) + '-' + date.getDate(); 
    this.dateRange= {beginDate: {year: date.getFullYear(), month: date.getMonth()+1, day: date.getDate()},endDate: {year: date.getFullYear(), month: date.getMonth()+1, day: date.getDate()}}; 
   }  
  

    /*
    * get Fuel Report List
    */ 
   getFuelRepoerList(){   
         this.loaderService.display(true); 
         var fuelType='Purchse_Vehicle' 
                this.http.get(environment.apiUrl + 'reports/getFuelReport?prjid='+this.prjId+'&fuelType='+fuelType+'&startDate='+this.startDate+'&endDate='+this.endDate).subscribe(data =>{ 
                this.fuelReportList=data.json();
                if(this.fuelReportList.length>0){ 
                    this.distinctFuelType = distinctFuelType(this.fuelReportList) 
                    this.distinctVehCategory = distinctVehCategory(this.fuelReportList) 
                    this.gridDataFuelReport = process(this.fuelReportList, this.state);
                    this.loaderService.display(false); 
                }else{
                    this.loaderService.display(false); 
                    this.gridDataFuelReport=null;
                } 
            });  
   } 


/*
 * filter The Grid Data
*/
  public dataStateChange(state: DataStateChangeEvent): void {
  this.state = state;
  this.gridDataFuelReport = process(this.fuelReportList, this.state);  
  if (state && state.group) { 
      this.distinctFuelType = distinctFuelType(this.fuelReportList)  
      this.distinctVehCategory = distinctVehCategory(this.fuelReportList)  
      this.gridDataFuelReport = process(this.fuelReportList, this.state); 
    } 
} 

/*
*select start Date Nad To date
*/
 onDateRangeChanged(dataRange)
 {  
   if(dataRange.beginDate.day>0){ 
     this.startDate= dataRange.beginDate.year + "-"  + dataRange.beginDate.month+ "-" + dataRange.beginDate.day 
     this.endDate = dataRange.endDate.year + "-"  + dataRange.endDate.month  + "-" + dataRange.endDate.day 
     this.getFuelRepoerList(); 
   }
   else if(dataRange.beginDate.day==0){
     this.startDate= this.defStartDt
     this.endDate = this.defEndDt
     this.getFuelRepoerList(); 
   }  
 } 
  

 /*
 * Zoom Image
 */
 zomeFuelImg(data){
   console.log("data",data)
   this.purchaseImg=data.IMGURL
   $("#fuelPurchaseImg").modal("show");     
 }
 
 
    ngOnInit() {  
        this.startDate = moment(this.defStartDt).format('YYYY-MM-DD');
        this.endDate= moment(this.defEndDt).format('YYYY-MM-DD');
        this.prjId = this.auth.getAuthentication().projectId  
        this.getFuelRepoerList();
    } 
}
  
  
  


   


 
 

 



 
