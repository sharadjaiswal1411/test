import { Component } from '@angular/core'; 

@Component({
  selector: 'fuel-report',
  templateUrl: './fuel.component.html',  
}) 
  export class FuelReportComponent { 
  ngOnInit(){ 
  
  } 
}
 