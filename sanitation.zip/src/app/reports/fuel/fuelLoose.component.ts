import { Component, ViewEncapsulation} from '@angular/core'; 
import { ActivatedRoute, Router } from '@angular/router';
import { Http} from '@angular/http' 
import { environment } from '../../../environments/environment';  
import { AuthService } from '../../_services';
import { LoaderService } from '../../_services/loader.service'; 
import { process, State,aggregateBy} from '@progress/kendo-data-query'; 
import { GroupDescriptor, DataResult } from '@progress/kendo-data-query';
import { Observable } from 'rxjs/Observable';
import { SelectableSettings,DataStateChangeEvent,GridDataResult} from '@progress/kendo-angular-grid'; 
import { ExcelExportData } from '@progress/kendo-angular-excel-export';
import * as _moment from 'moment';  
import * as _rollupMoment from 'moment'; 
const moment = _rollupMoment || _moment;  
declare var $: any; 
const distinctFuelType = data => data.filter((x, idx, xs) => xs.findIndex(y => y.FULETYPE === x.FULETYPE) === idx); 
const distinctLocation = data => data.filter((x, idx, xs) => xs.findIndex(y => y.PURCHASELOCATION === x.PURCHASELOCATION) === idx); 
export const MY_FORMATS = {
  parse: {
    dateInput: 'LL',
  },
  display: {
    dateInput: 'LL',
    monthYearLabel: 'MMM YYYY',
    dateA11yLabel: 'LL',
    monthYearA11yLabel: 'MMMM YYYY',
  },
}; 



@Component({ 
  selector: 'fuelLoose',
  templateUrl: './fuelLoose.component.html',  
})
export class FuelLooseReportComponent { 
    prjId:any;  
    showLoader:boolean; 
    startDate:any;
    endDate:any;
    defStartDt:any;
    defEndDt:any;
    dateRange:any; 
    looseFuelList:any
    looseFuelImg:any;
    public state: State = { 
      skip: 0,
      take: 12,  
      filter: {
      logic: 'and',
      filters: []
    }
  };
  public pageSize :any
  public checkboxOnly = false;
  public mode = 'multiple';
  public selectableSettings: SelectableSettings;

  public allData(): ExcelExportData {
    const result: ExcelExportData =  {
        data: this.looseFuelList
    };
    return result;
   } 
 
  public groups: GroupDescriptor[] = [];
  public view: Observable<GridDataResult>; 
  
  
  public gridDataFuelLoose: DataResult;
  public groupChange(groups: GroupDescriptor[]): void {
    this.groups = groups;
    this.loadProducts();
  } 
  public distinctFuelType: any[]
  public distinctLocation: any[]
  private loadProducts(): void {
    this.gridDataFuelLoose = process(this.looseFuelList, { group: this.groups });  
  }
  constructor(private http: Http,private auth : AuthService,public routes: ActivatedRoute, public router: Router,private loaderService: LoaderService) {
    this.loaderService.status.subscribe((val: boolean) =>{
        this.showLoader = val;
      });
    var date = new Date(); 
    this.allData = this.allData.bind(this); 
    this.defStartDt = (date.getFullYear()) + '-' + (date.getMonth() + 1) + '-' + date.getDate(); 
    this.defEndDt = (date.getFullYear()) + '-' + (date.getMonth()+1) + '-' + date.getDate(); 
    this.dateRange= {beginDate: {year: date.getFullYear(), month: date.getMonth()+1, day: date.getDate()},endDate: {year: date.getFullYear(), month: date.getMonth()+1, day: date.getDate()}}; 
    }  
  

    /*
    * get Fuel Report List
    */  
   getFuelLooseList(){   
    this.loaderService.display(true); 
    var fuelType='Purchse_Loose' 
    this.http.get(environment.apiUrl + 'reports/getFuelReport?prjid='+this.prjId+'&fuelType='+fuelType+'&startDate='+this.startDate+'&endDate='+this.endDate).subscribe(data =>{ 
           this.looseFuelList=data.json();
           if(this.looseFuelList.length>0){ 
               this.distinctLocation= distinctLocation(this.looseFuelList) 
               this.distinctFuelType = distinctFuelType(this.looseFuelList) 
               this.gridDataFuelLoose = process(this.looseFuelList, this.state);
               this.loaderService.display(false); 
           }else{
               this.loaderService.display(false); 
           } 
       });  
} 


/*
 * filter The Grid Data
*/
  public dataStateChange(state: DataStateChangeEvent): void {
  this.state = state;
  this.gridDataFuelLoose = process(this.looseFuelList, this.state);  
  if (state && state.group) { 
      this.distinctLocation= distinctLocation(this.looseFuelList) 
      this.distinctFuelType = distinctFuelType(this.looseFuelList)   
      this.gridDataFuelLoose = process(this.looseFuelList, this.state); 
    } 
} 

/*
*select start Date Nad To date
*/
 onDateRangeChanged(dataRange)
 {  
   if(dataRange.beginDate.day>0){ 
     this.startDate= dataRange.beginDate.year + "-"  + dataRange.beginDate.month+ "-" + dataRange.beginDate.day 
     this.endDate = dataRange.endDate.year + "-"  + dataRange.endDate.month  + "-" + dataRange.endDate.day 
     this.getFuelLooseList(); 
   }
   else if(dataRange.beginDate.day==0){
     this.startDate= this.defStartDt
     this.endDate = this.defEndDt
     this.getFuelLooseList(); 
   }  
 } 
  
/*
 * Zoom Image
 */
 zomeLooseFuelImg(data){ 
  this.looseFuelImg=data.IMGURL
  $("#fuelLooseImg").modal("show");    
 }
 
    ngOnInit() {  
        this.startDate = moment(this.defStartDt).format('YYYY-MM-DD');
        this.endDate= moment(this.defEndDt).format('YYYY-MM-DD');
        this.prjId = this.auth.getAuthentication().projectId  
        this.getFuelLooseList();
    } 
}
  
  
  


   


 
 

 



 
