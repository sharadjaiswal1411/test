import { Component, ViewEncapsulation} from '@angular/core'; 
import { ActivatedRoute, Router } from '@angular/router';
import { Http} from '@angular/http' 
import { environment } from '../../../environments/environment'; 
import { DateAdapter, MAT_DATE_FORMATS, MAT_DATE_LOCALE } from '@angular/material/core';//added by kuldeep on 10-03-2018
import { MomentDateAdapter } from '@angular/material-moment-adapter';//added by kuldeep on 10-03-2018 
import { AuthService } from '../../_services';
import { LoaderService } from '../../_services/loader.service'; 
import { process, State,aggregateBy} from '@progress/kendo-data-query'; 
import { GroupDescriptor, DataResult } from '@progress/kendo-data-query';
import { Observable } from 'rxjs/Observable';
import { SelectableSettings,DataStateChangeEvent,GridDataResult} from '@progress/kendo-angular-grid'; 
import { ExcelExportData } from '@progress/kendo-angular-excel-export';
import * as _moment from 'moment';  
import * as _rollupMoment from 'moment'; 
const moment = _rollupMoment || _moment;  
 
export const MY_FORMATS = {
  parse: {
    dateInput: 'LL',
  },
  display: {
    dateInput: 'LL',
    monthYearLabel: 'MMM YYYY',
    dateA11yLabel: 'LL',
    monthYearA11yLabel: 'MMMM YYYY',
  },
}; 

declare var $: any; 
const distinctEntity = data => data.filter((x, idx, xs) => xs.findIndex(y => y.ENTITYNAME === x.ENTITYNAME) === idx); 
const distinctEntType = data => data.filter((x, idx, xs) => xs.findIndex(y => y.TYPE === x.TYPE) === idx); 
@Component({

  selector: 'serviceReport',
  templateUrl: './serviceReport.component.html',
  encapsulation: ViewEncapsulation.None ,
  providers: [
    { provide: DateAdapter, useClass: MomentDateAdapter, deps: [MAT_DATE_LOCALE] },
    { provide: MAT_DATE_FORMATS, useValue: MY_FORMATS },
  ],

})
export class ServiceReportComponent { 
    prjId:any; 
    showLoader:boolean; 
    startDate:any;
    endDate:any;
    defStartDt:any;
    defEndDt:any;
    dateRange:any;
    serviceReportList:any;
    totalCount:any;
    imageUrl:any;
    entityName:any;
    entityType:any;
    qrCd:any;
    serviceDate:any;
    user:any;
    dateLink:any;
  //public aggregates: any[] = [{field: 'DISTANCE', aggregate: 'sum'}];
    public state: State = { 
    skip: 0,
    take: 12,  
    filter: {
      logic: 'and',
      filters: []
    }
  };

   public allData(): ExcelExportData {
    const result: ExcelExportData =  {
        data: this.serviceReportList
    };
    return result;
   }  
  public pageSize :any
  public checkboxOnly = false;
  public mode = 'multiple';
  public selectableSettings: SelectableSettings;

  public distinctEntity: any[]
  public distinctEntType: any[]
 
  public groups: GroupDescriptor[] = [];
  public view: Observable<GridDataResult>; 
  public hiddenColumns: string[] = [];
  public isHidden(columnName: string): boolean {
    return this.hiddenColumns.indexOf(columnName) > -1;
  } 
  
  public gridDataMobServiceReport: DataResult;
  public groupChange(groups: GroupDescriptor[]): void {
    this.groups = groups;
    this.loadProducts();
  }

  private loadProducts(): void {
    this.gridDataMobServiceReport = process(this.serviceReportList, { group: this.groups }); 
 
  }
  constructor(private http: Http,private auth : AuthService,public routes: ActivatedRoute, public router: Router,private loaderService: LoaderService) {
    this.loaderService.status.subscribe((val: boolean) =>{
        this.showLoader = val;
      });
    this.allData = this.allData.bind(this);
    var date = new Date(); 
    //var firstDay = new Date(date.getFullYear(), date.getMonth(), 1); 
    this.defStartDt = (date.getFullYear()) + '-' + (date.getMonth() + 1) + '-' + date.getDate(); 
    this.defEndDt = (date.getFullYear()) + '-' + (date.getMonth()+1) + '-' + date.getDate(); 
    this.dateRange= {beginDate: {year: date.getFullYear(), month: date.getMonth()+1, day: date.getDate()}, endDate: {year: date.getFullYear(), month: date.getMonth()+1, day: date.getDate()}};
   }  
  

    /*
    *get Mobility Service Report
    */
   getMobServiceReport(){ 
    this.loaderService.display(true);  
    this.http.get(environment.apiUrl + 'reports/getMobilityServiceReport?prjId='+this.prjId+'&startDate='+this.startDate+'&endDate='+this.endDate).subscribe(data =>{ 
        this.serviceReportList=data.json(); 
        if(this.serviceReportList.length>0) {
            this.gridDataMobServiceReport = process(this.serviceReportList, this.state); 
            this.distinctEntity = distinctEntity(this.serviceReportList)
            this.distinctEntType = distinctEntType(this.serviceReportList)
            this.loaderService.display(false);   
        } 
        else{
            this.gridDataMobServiceReport=null
            this.loaderService.display(false);  
        } 
      }); 
   } 


/*
 * filter The Date
*/
  public dataStateChange(state: DataStateChangeEvent): void {
  this.state = state;
  this.gridDataMobServiceReport = process(this.serviceReportList, this.state);   
  if (state && state.group) {  
      //state.group.map(group => group.aggregates = this.aggregates);  
      this.gridDataMobServiceReport = process(this.serviceReportList, this.state);
      this.distinctEntity = distinctEntity(this.serviceReportList)
      this.distinctEntType = distinctEntType(this.serviceReportList)  
    } 
} 

 /*
   *select start Date Nad To date
  */
 onDateRangeChanged(dataRange)
 {  
   if(dataRange.beginDate.day>0){ 
     this.startDate= dataRange.beginDate.year + "-"  + dataRange.beginDate.month+ "-" + dataRange.beginDate.day 
     this.endDate = dataRange.endDate.year + "-"  + dataRange.endDate.month  + "-" + dataRange.endDate.day 
     this.getMobServiceReport(); 
   }
   else if(dataRange.beginDate.day==0){
     this.startDate= this.defStartDt
     this.endDate = this.defEndDt
     this.getMobServiceReport(); 
   }  
 } 

 /*
  *Relaod The Grid Data 
 */
 refreshServiceData(){
  this.getMobServiceReport();
 }

 /*
  *Get Service Image Details 
 */ 
 serviceImagePopup(data){  
     this.user=data.USERNAME
     this.imageUrl=data.IMGURL
     this.entityName=data.ENTITYNAME
     this.entityType=data.TYPE
     this.qrCd=data.QRCD
     this.serviceDate=data.SERVICEDATE 
     $("#ImagePopup").modal("show");          
 }

 getLocation(data){  
  var lat1=data.LAT1
  var lng1=data.LNG1
  var lat2=data.LAT2
  var lng2=data.LNG2  
  this.dateLink="https://maps.google.com?saddr="+lat1+","+lng1+"&daddr="+lat2+","+lng2+"" 
 }

    ngOnInit() { 
        this.startDate = moment(this.defStartDt).format('YYYY-MM-DD');
        this.endDate= moment(this.defEndDt).format('YYYY-MM-DD');
        this.prjId = this.auth.getAuthentication().projectId
        this.getMobServiceReport();
    }










   }
  
  
  


   


 
 

 



 
