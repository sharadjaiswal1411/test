import { Component } from '@angular/core';
import {HttpClient } from '@angular/common/http'; 
import { AuthService } from '../../_services'; 

@Component({
  selector: 'mobility-report',
  templateUrl: './mobility.component.html',  
})

export class MobilityReportComponent {
 public prjId:any
 public userId:any
  constructor(private http: HttpClient,private auth : AuthService) { 
  }  
  ngOnInit() 
  { 
    this.prjId = this.auth.getAuthentication().projectId  
    this.userId = this.auth.getAuthentication().id 
  }

}
 