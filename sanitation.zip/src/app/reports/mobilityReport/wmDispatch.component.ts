import { Component} from '@angular/core'; 
import { ActivatedRoute, Router } from '@angular/router';
import { Http} from '@angular/http' 
import { environment } from '../../../environments/environment';  
import { AuthService } from '../../_services';
import { LoaderService } from '../../_services/loader.service'; 
import { process, State,aggregateBy} from '@progress/kendo-data-query'; 
import { GroupDescriptor, DataResult } from '@progress/kendo-data-query';
import { Observable } from 'rxjs/Observable';
import { SelectableSettings,DataStateChangeEvent,GridDataResult} from '@progress/kendo-angular-grid'; 
import { ExcelExportData } from '@progress/kendo-angular-excel-export';
import * as _moment from 'moment';  
import * as _rollupMoment from 'moment'; 
const moment = _rollupMoment || _moment;  
 
  

declare var $: any; 
const distinctZone = data => data.filter((x, idx, xs) => xs.findIndex(y => y.Zone === x.Zone) === idx); 
const distinctWard = data => data.filter((x, idx, xs) => xs.findIndex(y => y.Ward === x.Ward) === idx); 
@Component({

  selector: 'Vehicle-Running',
  templateUrl: './wmDispatch.component.html',
 
})
export class WmDispatchComponent { 
    prjId:any; 
    showLoader:boolean; 
    startDate:any;
    endDate:any;
    defStartDt:any;
    defEndDt:any;
    dateRange:any;  
    vehicleCount:any;
    runningCount:any;
    standByCount:any;
    breakDownCount:any;
    wmDispatchList:any;
    currentDateModal:any;
    public aggregates: any[] = [{field: 'assignedVhicles', aggregate: 'sum'},{field: 'Running', aggregate: 'sum'},{field: 'Standby', aggregate: 'sum'},{field: 'Breakdown', aggregate: 'sum'}];
    public state: State = {  
    filter: {
      logic: 'and',
      filters: []
    }
  };

   public allData(): ExcelExportData {
    const result: ExcelExportData =  {
        data: this.wmDispatchList
    };
    return result;
   }  
  public pageSize :any
  public checkboxOnly = false;
  public mode = 'multiple';
  public selectableSettings: SelectableSettings;

  public distinctZone: any[]
  public distinctWard: any[]
 
  public groups: GroupDescriptor[] = [];
  public view: Observable<GridDataResult>; 
  public hiddenColumns: string[] = [];
  public isHidden(columnName: string): boolean {
    return this.hiddenColumns.indexOf(columnName) > -1;
  } 
  
  public gridDataWMDispatch: DataResult;
  public groupChange(groups: GroupDescriptor[]): void {
    this.groups = groups;
    this.loadProducts();
  }

  private loadProducts(): void {
    this.gridDataWMDispatch = process(this.wmDispatchList, { group: this.groups }); 
 
  }
  constructor(private http: Http,private auth : AuthService,public routes: ActivatedRoute, public router: Router,private loaderService: LoaderService) {
    this.loaderService.status.subscribe((val: boolean) =>{
        this.showLoader = val;
      });
    this.vehicleCount=0;
    this.runningCount=0;
    this.standByCount=0;
    this.breakDownCount=0;
    this.allData = this.allData.bind(this);
    var date = new Date();  
    this.defStartDt = (date.getFullYear()) + '-' + (date.getMonth() + 1) + '-' + date.getDate(); 
    this.currentDateModal=date;
    //this.defEndDt = (date.getFullYear()) + '-' + (date.getMonth()+1) + '-' + date.getDate(); 
    //this.dateRange= {beginDate: {year: date.getFullYear(), month: date.getMonth()+1, day: date.getDate()}, endDate: {year: date.getFullYear(), month: date.getMonth()+1, day: date.getDate()}};
   }  
  

  /*
   *  get Mobility WM Dispatch Report Report
  */
   getWMDispatchReport(date){ 
    this.loaderService.display(true);  
    this.http.get(environment.apiUrl + 'reports/getWMDispatchReport?prjId='+this.prjId+'&startDate='+date).subscribe(data =>{ 
        this.wmDispatchList=data.json(); 
        if(this.wmDispatchList.length>0) { 
            this.distinctZone = distinctZone(this.wmDispatchList)
            this.distinctWard = distinctWard(this.wmDispatchList)
            this.vehicleCount = aggregateBy(this.wmDispatchList, this.aggregates)["assignedVhicles"].sum; 
            this.runningCount = aggregateBy(this.wmDispatchList, this.aggregates)["Running"].sum;  
            this.standByCount = aggregateBy(this.wmDispatchList, this.aggregates)["Standby"].sum;  
            this.breakDownCount = aggregateBy(this.wmDispatchList, this.aggregates)["Breakdown"].sum;  
            this.gridDataWMDispatch = process(this.wmDispatchList, this.state);  
            this.loaderService.display(false); 
        } 
        else{
            this.wmDispatchList=[];
            this.gridDataWMDispatch = process(this.wmDispatchList, this.state);
            this.loaderService.display(false);  
        } 
      }); 
   } 


  /*
  * Select Date Change Event
  */
   orgValueChange(date){ 
    this.getWMDispatchReport(date)
  }


/*
* filter The Date
*/ 
public dataStateChange(state: DataStateChangeEvent): void {
  this.state = state;
  this.gridDataWMDispatch = process(this.wmDispatchList, this.state);   
  if (state && state.group) {  
      this.vehicleCount = aggregateBy(this.gridDataWMDispatch.data, this.aggregates)["assignedVhicles"].sum; 
      this.runningCount = aggregateBy(this.gridDataWMDispatch.data, this.aggregates)["Running"].sum;  
      this.standByCount = aggregateBy(this.gridDataWMDispatch.data, this.aggregates)["Standby"].sum;  
      this.breakDownCount = aggregateBy(this.gridDataWMDispatch.data, this.aggregates)["Breakdown"].sum;  
      state.group.map(group => group.aggregates = this.aggregates); 
      this.gridDataWMDispatch = process(this.wmDispatchList, this.state); 
      console.log("vehicleCount",this.vehicleCount)
      console.log("runningCount",this.runningCount)
    } 
} 





 /*
 * select start Date Nad To date
 */
//  onDateRangeChanged(dataRange){  
//    if(dataRange.beginDate.day>0){ 
//      this.startDate= dataRange.beginDate.year + "-"  + dataRange.beginDate.month+ "-" + dataRange.beginDate.day 
//      this.endDate = dataRange.endDate.year + "-"  + dataRange.endDate.month  + "-" + dataRange.endDate.day 
//      this.getWMDispatchReport(); 
//    }
//    else if(dataRange.beginDate.day==0){
//      this.startDate= this.defStartDt
//      this.endDate = this.defEndDt
//      this.getWMDispatchReport(); 
//    }  
//  }  
  
    ngOnInit() { 
        this.startDate = moment(this.defStartDt).format('YYYY-MM-DD');
        //this.endDate= moment(this.defEndDt).format('YYYY-MM-DD');
        this.prjId = this.auth.getAuthentication().projectId
        this.getWMDispatchReport(this.startDate);
    } 
   }
  
  
  


   


 
 

 



 
