import { Component, ViewEncapsulation} from '@angular/core'; 
import { ActivatedRoute, Router } from '@angular/router';
import { Http} from '@angular/http' 
import { environment } from '../../../environments/environment';  
import { AuthService } from '../../_services';
import { LoaderService } from '../../_services/loader.service'; 
import { process, State} from '@progress/kendo-data-query'; 
import { GroupDescriptor, DataResult } from '@progress/kendo-data-query';
import { Observable } from 'rxjs/Observable';
import { SelectableSettings,DataStateChangeEvent} from '@progress/kendo-angular-grid'; 
import { RowClassArgs } from '@progress/kendo-angular-grid';
import { ExcelExportData } from '@progress/kendo-angular-excel-export';
 

import { 
  GridDataResult, 
} from '@progress/kendo-angular-grid';

  

declare var $: any; 
const distinctWard= data => data.filter((x, idx, xs) => xs.findIndex(y => y.WARD === x.WARD) === idx); 
const distinctSurvType= data => data.filter((x, idx, xs) => xs.findIndex(y => y.SURVEYTYPE === x.SURVEYTYPE) === idx); 
const distinctMapStatus= data => data.filter((x, idx, xs) => xs.findIndex(y => y.MAPPINGSTATUS === x.MAPPINGSTATUS) === idx); 
  
@Component({ 
  selector: 'mapping',
  templateUrl: './mappingReport.component.html',  
  encapsulation: ViewEncapsulation.None,
  styles: ['.green .codeColumn { color: green; font-weight: bold} .red .codeColumn { color: red; font-weight: bold}'],
})
export class MappingReportComponent { 
    prjId:any;
    zoneList:any;
    showLoader:Boolean;
    surveyDataList:any;
    defStartDt:any;
    defEndDate:any;
    surveyList:any;
    dataRangeModal:any;
    startDate:any;
    endDate:any; 
    secondaryList:any;
    entityModal:any;
    entityTypeModel:any;
    entityList:any;
    entityTypeModal:any;
    success=false;
    error=false;
    surveyRefId:any;
    entityId:any;
    isMappedDisable=false; 
    entityTypRequired=false;
    entityRequired=false;
  //public aggregates: any[] = [{field: 'TotalAmt', aggregate: 'sum'}];
  public state: State = {
    skip: 0,
    take: 12,  
    filter: {
      logic: 'and',
      filters: []
    }
  }; 
  public allData(): ExcelExportData {
    const result: ExcelExportData =  {
        data: this.surveyDataList
    };
    return result;
   } 

  public distinctWard: any[]
  public distinctSurvType: any[]
  public distinctMapStatus: any[]  
  public pageSize :any
  public checkboxOnly = false;
  public mode = 'multiple';
  public selectableSettings: SelectableSettings; 
  public groups: GroupDescriptor[] = [];
  public view: Observable<GridDataResult>; 
  public hiddenColumns: string[] = [];
  public isHidden(columnName: string): boolean {
    return this.hiddenColumns.indexOf(columnName) > -1;
  } 
  
  public gridDataMappingReport: DataResult;
  public groupChange(groups: GroupDescriptor[]): void {
    this.groups = groups;
    this.loadProducts();
  }

  private loadProducts(): void {
    this.gridDataMappingReport = process(this.surveyDataList, { group: this.groups }); 
 
  }
  constructor(private http: Http,private auth : AuthService,public routes: ActivatedRoute, public router: Router,private loaderService: LoaderService) {
    this.loaderService.status.subscribe((val: boolean) =>{
        this.showLoader = val;
      }); 
      this.allData = this.allData.bind(this);
  }  
  
   /*
    * get Survey Details Report
   */
   getMappligReportList(){
    this.loaderService.display(true);  
    this.http.get(environment.apiUrl + 'mobility/getMappingReport?prjId='+this.prjId).subscribe(data =>{ 
    this.surveyDataList=data.json();  
        if(this.surveyDataList.length>0){
          this.distinctWard = distinctWard(this.surveyDataList) 
          this.distinctSurvType = distinctSurvType(this.surveyDataList) 
          this.distinctMapStatus = distinctMapStatus(this.surveyDataList)   
          this.gridDataMappingReport = process(this.surveyDataList, this.state); 
          this.loaderService.display(false);  
        }
        else{
          this.gridDataMappingReport = null;
          this.loaderService.display(false);  
        }
    });
   }


 /*
  * Column BG color Change
  */
   public rowCallback = (context: RowClassArgs) => { 
    switch (context.dataItem.MAPPINGSTATUS) {
      case 'UnMapped': 
        return {red : true}; 
      case 'Mapped': 
        return {green : true};
      default:
        return {}; 
     } 
   }  

/*
 * filter The Date
*/
public dataStateChange(state: DataStateChangeEvent): void {
  this.state = state;
  this.gridDataMappingReport = process(this.surveyDataList, this.state); 
  if (state && state.group) {  
    this.distinctWard = distinctWard(this.surveyDataList) 
    this.distinctSurvType = distinctSurvType(this.surveyDataList) 
    this.distinctMapStatus = distinctMapStatus(this.surveyDataList)   
    this.gridDataMappingReport = process(this.surveyDataList, this.state); 
    } 
} 

    /**
     * get secondary POINT
    */
    getSecondaryPoint(){
            this.http.get(environment.apiUrl + 'mobility/getSecondaryPoint?prjId='+this.prjId).subscribe(data =>{ 
            this.secondaryList=data.json();  
        });
    } 

  /*
   * Survey Mapping Report
  */
   surveyMapping(data){  
       this.success=false;
       this.error=false;
       this.entityTypeModel=null;
       this.entityModal=null;
       this.entityTypRequired=false;
       this.entityRequired=false; 
       this.surveyRefId=data.SURVEYREFID  
       $('#surveyMapModal').modal('show');  
   }

   /**
    * get Entity Id on select Entity Type 
   */
   onSelectEntityType(data){ 
     if(data!=null){
      this.entityTypRequired=false;
         var oemId=data.ID 
         this.http.get(environment.apiUrl + 'mobility/getEntityType?prjId='+this.prjId+'&oemId='+oemId).subscribe(data =>{ 
         if(data.json().length>0)
         {
          this.entityList=data.json();  
         }
         else{
          this.entityModal=null; 
         }  
         });  
        }
        else{
          this.entityTypRequired=true;
        } 
   }

   /**
    * get Entity ID on select index change entity ddl
   */
   onSelectEntity(data){
     if(data!=null){
      this.entityRequired=false;
      this.entityId=data.ID  
     }else{
      this.entityRequired=true;
     } 
   }
   
   /*
    * Seve Survey Mapping Data
   */
   saveSurveyMapping(){ 
     if(this.entityTypeModel==null){this.entityTypRequired=true; return}
     if(this.entityModal==null){this.entityRequired=true; return}
     var surveyData={
       "entityId":this.entityId,
       "refId":this.surveyRefId
     } 
     this.isMappedDisable=true;  
     this.http.post(environment.apiUrl + 'mobility/saveSurveyData',surveyData).subscribe(data =>{  
     var saveStatus=data.json(); 
     if(saveStatus.status=="ok"){
        this.success=true;
        this.getMappligReportList();
        this.isMappedDisable=false;  
        setTimeout(()=>{this.success=false; this.error=false; $('#surveyMapModal').modal('hide')},3000);  
       }
       else{
        this.error=true;
       }
     });  
   }
    



    ngOnInit(){ 
        this.prjId = this.auth.getAuthentication().projectId  
        this.getMappligReportList();
        this.getSecondaryPoint();
        //this.getEntityList();
    }










   }
  
  
  


   


 
 

 



 
