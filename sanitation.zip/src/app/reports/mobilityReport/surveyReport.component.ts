import { Component, ViewEncapsulation} from '@angular/core'; 
import { ActivatedRoute, Router } from '@angular/router';
import { Http} from '@angular/http' 
import { environment } from '../../../environments/environment'; 
import { DateAdapter, MAT_DATE_FORMATS, MAT_DATE_LOCALE } from '@angular/material/core';//added by kuldeep on 10-03-2018
import { MomentDateAdapter } from '@angular/material-moment-adapter';//added by kuldeep on 10-03-2018 
import { AuthService } from '../../_services';
import { LoaderService } from '../../_services/loader.service'; 
import { process, State,aggregateBy} from '@progress/kendo-data-query'; 
import { GroupDescriptor, DataResult } from '@progress/kendo-data-query';
import { Observable } from 'rxjs/Observable';
import { SelectableSettings,DataStateChangeEvent} from '@progress/kendo-angular-grid'; 
import { ExcelExportData } from '@progress/kendo-angular-excel-export';
import * as _moment from 'moment';  
import * as _rollupMoment from 'moment'; 
const moment = _rollupMoment || _moment; 

import { 
  GridDataResult, 
} from '@progress/kendo-angular-grid';

 
export const MY_FORMATS = {
  parse: {
    dateInput: 'LL',
  },
  display: {
    dateInput: 'LL',
    monthYearLabel: 'MMM YYYY',
    dateA11yLabel: 'LL',
    monthYearA11yLabel: 'MMMM YYYY',
  },
}; 

declare var $: any; 
const distinctWard= data => data.filter((x, idx, xs) => xs.findIndex(y => y.WARD === x.WARD) === idx); 
const distinctSurveyTyp= data => data.filter((x, idx, xs) => xs.findIndex(y => y.SURVEYTYPE === x.SURVEYTYPE) === idx);  
const distinctStatus= data => data.filter((x, idx, xs) => xs.findIndex(y => y.STATUS === x.STATUS) === idx);  
const distinctSurvCat= data => data.filter((x, idx, xs) => xs.findIndex(y => y.CATEGORY === x.CATEGORY) === idx);  



@Component({

  selector: 'surveyReport',
  templateUrl: './surveyReport.component.html', 
  encapsulation: ViewEncapsulation.None,
  providers: [
    { provide: DateAdapter, useClass: MomentDateAdapter, deps: [MAT_DATE_LOCALE] },
    { provide: MAT_DATE_FORMATS, useValue: MY_FORMATS },
  ],

})
export class SurveyReportComponent {
 
    prjId:any;
    zoneList:any;
    showLoader:Boolean;
    surveyDataList:any;
    defStartDt:any;
    defEndDate:any;
    surveyList:any;
    dataRangeModal:any;
    startDate:any;
    endDate:any;
  //public aggregates: any[] = [{field: 'TotalAmt', aggregate: 'sum'}];
  public state: State = {
    skip: 0,
    take: 12, 
    // Initial filter descriptor
    filter: {
      logic: 'and',
      filters: []
    }
  }; 
  public distinctWard: any[]
  public distinctSurveyTyp: any[]
  public distinctStatus: any[]
  public distinctSurvCat: any[]


  public pageSize :any
  public checkboxOnly = false;
  public mode = 'multiple';
  public selectableSettings: SelectableSettings; 
  public groups: GroupDescriptor[] = [];
  public view: Observable<GridDataResult>; 
  public hiddenColumns: string[] = [];
  public isHidden(columnName: string): boolean {
    return this.hiddenColumns.indexOf(columnName) > -1;
  } 
  
  public gridDataSurveyDetail: DataResult;
  public groupChange(groups: GroupDescriptor[]): void {
    this.groups = groups;
    this.loadProducts();
  }
  public allData(): ExcelExportData {
    const result: ExcelExportData =  {
        data: this.surveyList
    };
    return result;
   } 
  private loadProducts(): void {
    this.gridDataSurveyDetail = process(this.surveyDataList, { group: this.groups }); 
 
  }
  constructor(private http: Http,private auth : AuthService,public routes: ActivatedRoute, public router: Router,private loaderService: LoaderService) {
    this.loaderService.status.subscribe((val: boolean) =>{
        this.showLoader = val;
      });
      this.allData = this.allData.bind(this);
    var date = new Date(); 
    //var firstDay = new Date(date.getFullYear(), date.getMonth(), 1); 
    this.defStartDt = (date.getFullYear()) + '-' + (date.getMonth() + 1) + '-' + date.getDate(); 
    this.defEndDate = (date.getFullYear()) + '-' + (date.getMonth()+1) + '-' + date.getDate(); 
    this.dataRangeModal= {beginDate: {year: date.getFullYear(), month: date.getMonth()+1, day: date.getDate()}, endDate: {year: date.getFullYear(), month: date.getMonth()+1, day: date.getDate()}};
   }  
  
   /*
    * get Survey Details Report
   */
   getSurveyList(){
    this.loaderService.display(true);  
    this.http.get(environment.apiUrl + 'mobility/getMobilitySurveyReport?prjId='+this.prjId+'&startDate='+this.startDate+'&endDate='+this.endDate).subscribe(data =>{ 
    this.surveyList=data.json();  
        if(this.surveyList.length>0){
          this.distinctWard = distinctWard(this.surveyList)
          this.distinctSurveyTyp = distinctSurveyTyp(this.surveyList)
          this.distinctStatus = distinctStatus(this.surveyList) 
          this.distinctSurvCat = distinctSurvCat(this.surveyList)  
          this.gridDataSurveyDetail = process(this.surveyList, this.state); 
          this.loaderService.display(false);  
        }
        else{
          this.gridDataSurveyDetail = null;
          this.loaderService.display(false);  
        }
    });
   }




/*
 * filter The Date
*/
public dataStateChange(state: DataStateChangeEvent): void {
  this.state = state;
  this.gridDataSurveyDetail = process(this.surveyList, this.state); 
  if (state && state.group) {  
    this.distinctWard = distinctWard(this.surveyList)
    this.distinctSurveyTyp = distinctSurveyTyp(this.surveyList)
    this.distinctStatus = distinctStatus(this.surveyList)   
    this.distinctSurvCat = distinctSurvCat(this.surveyList)    
    this.gridDataSurveyDetail = process(this.surveyList, this.state); 
    } 
} 

refreshSurveyData(){
  this.getSurveyList();
}

 /*
   *select start Date Nad To date
  */
 onDateRangeChanged(dataRange)
 {  
   if(dataRange.beginDate.day>0){ 
     this.startDate= dataRange.beginDate.year + "-"  + dataRange.beginDate.month+ "-" + dataRange.beginDate.day 
     this.endDate = dataRange.endDate.year + "-"  + dataRange.endDate.month  + "-" + dataRange.endDate.day 
     this.getSurveyList(); 
   }
   else if(dataRange.beginDate.day==0){
     this.startDate= this.defStartDt
     this.endDate = this.defEndDate
     this.getSurveyList(); 
   }  
 }





    ngOnInit() { 
        this.prjId = this.auth.getAuthentication().projectId 
        this.startDate = moment(this.defStartDt).format('YYYY-MM-DD');
        this.endDate= moment(this.defEndDate).format('YYYY-MM-DD');
        this.getSurveyList();
    }










   }
  
  
  


   


 
 

 



 
