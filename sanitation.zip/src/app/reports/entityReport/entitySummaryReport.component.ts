import { Component, ViewEncapsulation} from '@angular/core'; 
import { ActivatedRoute, Router } from '@angular/router';
import { Http} from '@angular/http' 
import { environment } from '../../../environments/environment'; 
import { DateAdapter, MAT_DATE_FORMATS, MAT_DATE_LOCALE } from '@angular/material/core';//added by kuldeep on 10-03-2018
import { MomentDateAdapter } from '@angular/material-moment-adapter';//added by kuldeep on 10-03-2018 
import { AuthService } from '../../_services';
import { LoaderService } from '../../_services/loader.service'; 
import { process, State,aggregateBy} from '@progress/kendo-data-query'; 
import { GroupDescriptor, DataResult } from '@progress/kendo-data-query';
import { Observable } from 'rxjs/Observable';
import { SelectableSettings,DataStateChangeEvent} from '@progress/kendo-angular-grid'; 
 
import { 
  GridDataResult, 
} from '@progress/kendo-angular-grid';

 
export const MY_FORMATS = {
  parse: {
    dateInput: 'LL',
  },
  display: {
    dateInput: 'LL',
    monthYearLabel: 'MMM YYYY',
    dateA11yLabel: 'LL',
    monthYearA11yLabel: 'MMMM YYYY',
  },
}; 

declare var $: any; 
  
@Component({

  selector: 'entityReport',
  templateUrl: './entitySummaryReport.component.html',
  encapsulation: ViewEncapsulation.None ,
  providers: [
    { provide: DateAdapter, useClass: MomentDateAdapter, deps: [MAT_DATE_LOCALE] },
    { provide: MAT_DATE_FORMATS, useValue: MY_FORMATS },
  ],

})
export class EntitySummaryReportComponent {
 
    prjId:any;
    zoneList:any;
    totalAchievedCount:any;
    totalTargetCount:any
    totalTodayCount:any
    totalAchievedAmount:any;
    totalTargetAmount:any;
    totalTodayAmount:any;
    totalCount:any
    totalAmount:any;
    dataTarget:any;
    totalAchievedCountPrct:any;
    totalAchievedAmountPrct:any;
    reportLevel:any;
    zoneId:any;
    selectedEntity:any;
    category:any
    showLoader:boolean;
    defaultStartDate:any;
    defaultEndDate:any;
    dataRangeModal:any;
    targetDataList:any; 
    totalHouseHold:any;
    totalTarget:any;
    totalAmt:any;
    totalTargetAmt:any;
    reportLabelList:any;
    wardList:any;
    beatList:any;
    zoneModal:any;
    wardModal:any;
    beatModal:any;
    hideWard=false;
    hideZone=false;
    hideBeat=false;
    public disabled: boolean = true;

  public aggregates: any[] = [{field: 'Total', aggregate: 'sum'},{field: 'Target', aggregate: 'sum'},{field: 'TotalAmt', aggregate: 'sum'},{field: 'TargetAmt', aggregate: 'sum'}];
  public state: State = {
    skip: 0,
    take: 500, 
    // Initial filter descriptor
    filter: {
      logic: 'and',
      filters: []
    }
  };
  public pageSize :any
  public checkboxOnly = false;
  public mode = 'multiple';
  public selectableSettings: SelectableSettings;
  public distinctZone: any[]
  public distinctWard: any[]
  public distinctStatus:any[]
  public groups: GroupDescriptor[] = [];
  public view: Observable<GridDataResult>; 
  public hiddenColumns: string[] = [];
  public isHidden(columnName: string): boolean {
    return this.hiddenColumns.indexOf(columnName) > -1;
  } 
  
  public gridDataEntityReportList: DataResult;
  public groupChange(groups: GroupDescriptor[]): void {
    this.groups = groups;
    this.loadProducts();
  }

  private loadProducts(): void {
    this.gridDataEntityReportList = process(this.targetDataList, { group: this.groups }); 
 
  }
  constructor(private http: Http,private auth : AuthService,public routes: ActivatedRoute, public router: Router,private loaderService: LoaderService) {
    this.loaderService.status.subscribe((val: boolean) =>{
        this.showLoader = val;
      });
    var date = new Date(); 
    var firstDay = new Date(date.getFullYear(), date.getMonth(), 1);
    // /var lastDay = new Date(date.getFullYear(), date.getMonth(), 0); 
    this.defaultStartDate = (firstDay.getFullYear()) + '-' + (firstDay.getMonth() + 1) + '-' + firstDay.getDate(); 
    this.defaultEndDate = (date.getFullYear()) + '-' + (date.getMonth()+1) + '-' + date.getDate(); 
    this.dataRangeModal= {beginDate: {year: firstDay.getFullYear(), month: firstDay.getMonth()+1, day: firstDay.getDate()}, endDate: {year: date.getFullYear(), month: date.getMonth()+1, day: date.getDate()}};
    this.reportLabelList = ["WARD","BEAT"]
  
  }  
  
/**
 * to get the Target Details
*/
  getTargetDataList(reportLable,entity){ 
     this.loaderService.display(true);  
    this.http.get(environment.apiUrl + 'reports/getTargetData?prjId='+this.prjId+'&reportType='+reportLable+'&entityId='+entity).subscribe(data =>{ 
        this.targetDataList=data.json();       
        this.gridDataEntityReportList = process(this.targetDataList, this.state); 
        if(this.targetDataList.length>0){
          this.totalHouseHold = aggregateBy(this.targetDataList, this.aggregates)["Total"].sum; 
          this.totalTarget = aggregateBy(this.targetDataList, this.aggregates)["Target"].sum;
          this.totalAmt= aggregateBy(this.targetDataList, this.aggregates)["TotalAmt"].sum; 
          this.totalTargetAmt= aggregateBy(this.targetDataList, this.aggregates)["TargetAmt"].sum; 
          this.loaderService.display(false);  
        } 
        else if(this.targetDataList.length==0){
          this.loaderService.display(false);  
        } 
      }); 
    } 


/*
 * filter The Date
*/
public dataStateChange(state: DataStateChangeEvent): void {
  this.state = state;
  this.gridDataEntityReportList = process(this.targetDataList, this.state);   
  if (state && state.group) {  
      this.gridDataEntityReportList = process(this.gridDataEntityReportList.data, this.state);
      this.totalHouseHold = aggregateBy(this.gridDataEntityReportList.data, this.aggregates)["Total"].sum; 
      this.totalTarget = aggregateBy(this.gridDataEntityReportList.data, this.aggregates)["Target"].sum;
      this.totalAmt= aggregateBy(this.gridDataEntityReportList.data, this.aggregates)["TotalAmt"].sum; 
      this.totalTargetAmt= aggregateBy(this.gridDataEntityReportList.data, this.aggregates)["TargetAmt"].sum; 
    } 
} 

/*
 * select Report Lable
*/
selectReportLabel(data){
  this.zoneModal=null
  this.wardModal=null
  this.beatModal=null   
  var lable=data 
  if(data=="ZONE"){
    this.hideZone=true;
    this.hideWard=false;  
    this.hideBeat=false      
    //this.disabled =false
  }
  if(data=="WARD"){
    this.hideWard=true;
    this.hideZone=false;
    this.hideBeat=false     
  }
  if(data=="BEAT"){
    this.hideBeat=true
    this.hideWard=false;
    this.hideZone=false; 
  }
  this.gridDataEntityReportList=null
  this.getTargetDataList(lable,null);
} 
getZone(){
  this.http.get(environment.apiUrl + 'consumer/getZoneByProject?prjid='+this.prjId+'&oemid=7').subscribe(data =>{ 
      this.zoneList= data.json();  
 }); 
} 

selectZone(data){ 
  var reportType="ZONE" 
  this.wardModal=null
  this.beatModal=null
  this.hideZone=true; 
  this.hideBeat=false;
  this.hideWard=false;  
  this.gridDataEntityReportList=null 
  this.getTargetDataList(reportType,data.id);
  this.getWard(data.id) 
  }

getWard(entityId){
  this.http.get(environment.apiUrl + 'consumer/getZoneByProject?prjid='+this.prjId+'&entityid='+entityId+'&oemid=8').subscribe(data =>{ 
     this.wardList= data.json();  
   }); 
 } 


 selectWard(data){
  var reportType="WARD" 
  this.beatModal=null 
  this.hideWard=true;
  this.hideBeat=false; 
  this.hideZone=false;  
  this.getBeat(data.id)
  this.gridDataEntityReportList=null
  this.getTargetDataList(reportType,data.id); 
 }


 getBeat(werdId){
  this.http.get(environment.apiUrl + 'consumer/getZoneByProject?prjid='+this.prjId+'&entityid='+werdId+'&oemid=9').subscribe(data =>{ 
      this.beatList= data.json(); 
   }); 
 } 

 selectBeat(data){
  var reportType="BEAT"  
  this.hideWard=false;
  this.hideBeat=true; 
  this.hideZone=false;  
  this.gridDataEntityReportList=null
  this.getTargetDataList(reportType,data.id); 
 } 


    ngOnInit() {
        this.selectedEntity = null
        this.prjId = this.auth.getAuthentication().projectId 
        this.hideZone=true;   
        this.getTargetDataList("ZONE",null)
        this.getZone();  
    }










   }
  
  
  


   


 
 

 



 
