import { Component} from '@angular/core';


import { HttpClient } from '@angular/common/http';
import { AuthService } from '../../_services';

@Component({
  selector: 'vehicle-report',
  templateUrl: './secondaryReport.component.html', 
})

export class SecondaryReport {
  constructor(private http: HttpClient,private auth : AuthService) { 
  }  
  ngOnInit() 
  { 
  
  }

}
 