import { Component} from '@angular/core'; 
import { HttpClient } from '@angular/common/http';
import { environment } from '../../environments/environment'; 
@Component({
  selector: 'app-reports',
  templateUrl: './reports.component.html',
  styleUrls: ['./reports.component.css']
})


export class ReportsComponent {

  constructor(private http: HttpClient) { }
  downloadReport()
  {
    window.open(environment.apiUrl + "reports/billcollection");
  }

  ngOnInit() {
  }
}

