import { Component } from '@angular/core';

import { HttpClient } from '@angular/common/http';
import { environment } from '../../../environments/environment';
import {DateAdapter, MAT_DATE_FORMATS, MAT_DATE_LOCALE} from '@angular/material/core';//added by kuldeep on 10-03-2018
import {MomentDateAdapter} from '@angular/material-moment-adapter';//added by kuldeep on 10-03-2018
import * as _moment from 'moment'; //added by kuldeep on 10-03-2018
import * as _rollupMoment from 'moment';//added by kuldeep on 10-03-2018
import { AuthService } from '../../_services/index';
import { ActivatedRoute, Router } from '@angular/router';
//added by kuldeep on 10-03-2018 
//##########################

const moment = _rollupMoment || _moment; 
export const MY_FORMATS = {
  parse: {
    dateInput: 'LL',
  },
  display: {
    dateInput: 'LL',
    monthYearLabel: 'MMM YYYY',
    dateA11yLabel: 'LL',
    monthYearA11yLabel: 'MMMM YYYY',
  },
};

@Component({
  selector: 'uccApp-reports',
  templateUrl: './uccReport.Component.html',
  styleUrls: ['./uccReport.Component.css'],
  providers: [
    {provide: DateAdapter, useClass: MomentDateAdapter, deps: [MAT_DATE_LOCALE]},
    {provide: MAT_DATE_FORMATS, useValue: MY_FORMATS},
  ],
})
//###################################################################

export class UccReportsComponent {
 public  startDateModel=moment()
 public  endDateModel =moment()
 public projectMaster:any
 public prjId:any
 public userId:any;
 public selectedProjectId 
  constructor(private http: HttpClient,private auth : AuthService,public routes: ActivatedRoute, public router: Router) { }
   public stdate = moment()
   public enddate = moment()


    downloadReport()
    {
      window.open(environment.apiUrl + "reports/billcollection");
    }


    dailyOperationsReport()
    {
        
      let enddt = moment(this.endDateModel).format('YYYY-MM-DD');
      window.open(environment.apiUrl + "reports/getDailyOprReport?enddate="+enddt);
    }



    collectionReport()
    {
        
      let startdate = moment(this.startDateModel).format('YYYY-MM-DD');
      let enddate = moment(this.endDateModel).format('YYYY-MM-DD');
 if(this.prjId==undefined)
 {
   alert("Please select Project")
 }
 else{
     window.open(environment.apiUrl + "reports/getDailyCollectionReport?prjId="+this.prjId +"&startdate="+startdate+"&enddate="+enddate);
 }
    }

    

//     getAllProject()
//     {
//      this.http.get(environment.apiUrl + 'project/all')
//       .subscribe((data)=>{
//        setTimeout(() => {
//          this.projectMaster=data;
//        }, 1000);     
//    });
//  }




//  GetDataByProject(data){ 
//   if(data){
//     this.prjId = data.ID;
   
//   }
// }


//*******************UCC REPORT CR BY RAM On 01_07_2018 START***********************//

/*
 *Get UCC Collection Summary report 
*/
couponCollectionSummaryReport(reportLevel){ 
  let startdate = moment(this.startDateModel).format('YYYY-MM-DD');
  let enddate = moment(this.endDateModel).format('YYYY-MM-DD');
  window.open(environment.apiUrl + "reports/getUccBulkCouponCollectionSummary?prjId="+this.prjId +"&startdate="+startdate+"&enddate="+enddate+"&reportLevel="+reportLevel); 
  }

/*
 *Get UCC ASSIGNMENT SUmmary report 
*/
assignmentSummaryReport(reportLevel){ 
 let startdate = moment(this.startDateModel).format('YYYY-MM-DD');
 let enddate = moment(this.endDateModel).format('YYYY-MM-DD');
 window.open(environment.apiUrl + "reports/getUccBulkAssignmentSummary?prjId="+this.prjId +"&startdate="+startdate+"&enddate="+enddate+"&reportLevel="+reportLevel); 
}

/*
 *Get UCC Assignment VS Collection Summary report 
*/
collectionVSassignmentReport(){  
 let startdate = moment(this.startDateModel).format('YYYY-MM-DD');
 let enddate = moment(this.endDateModel).format('YYYY-MM-DD');
 window.open(environment.apiUrl + "reports/getUccAssignmentVsCollectionReport?prjId="+this.prjId); 
 }

 /*
 *Get UCC Assignment VS Collection Summary report 
*/
bulkCollectionDetail(){ 
  this.router.navigate(['/home/reports/uccReport/bulkCollectionReport']);
 let startdate = moment(this.startDateModel).format('YYYY-MM-DD');
 let enddate = moment(this.endDateModel).format('YYYY-MM-DD');
 //window.open(environment.apiUrl + "reports/getUccBulkCollectionDetail?prjId="+this.prjId +"&startdate="+startdate+"&enddate="+enddate+""); 
 }
//*******************UCC REPORT CR BY RAM On 02_07_2018 END***********************//








    
  ngOnInit() 
  { 
    this.prjId = this.auth.getAuthentication().projectId  
    this.userId = this.auth.getAuthentication().id 
  }
}




