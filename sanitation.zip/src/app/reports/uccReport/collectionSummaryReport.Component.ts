import { Component } from '@angular/core';
import { Http } from '@angular/http'
import { environment } from '../../../environments/environment';
import { MomentDateAdapter } from '@angular/material-moment-adapter';
import { DateAdapter, MAT_DATE_FORMATS, MAT_DATE_LOCALE } from '@angular/material/core';
import { Observable } from 'rxjs/Observable';

import { AuthService } from '../../_services/index';

import 'rxjs/add/operator/map'

import { LoaderService } from '../../_services/loader.service';
import * as _moment from 'moment';
import * as _rollupMoment from 'moment';
const moment = _rollupMoment || _moment;
import { process, State, aggregateBy } from '@progress/kendo-data-query';

import { GroupDescriptor, DataResult } from '@progress/kendo-data-query';
import { SelectableSettings } from '@progress/kendo-angular-grid';
import { ExcelExportData } from '@progress/kendo-angular-excel-export'; 
import {
  GridDataResult,
  DataStateChangeEvent
} from '@progress/kendo-angular-grid';

declare var $: any;
export const MY_FORMATS = {
  parse: {
    dateInput: 'LL',
  },
  display: {
    dateInput: 'LL',
    monthYearLabel: 'MMM YYYY',
    dateA11yLabel: 'LL',
    monthYearA11yLabel: 'MMMM YYYY',
  },
};
const distinctBeat = data => data
  .filter((x, idx, xs) => xs.findIndex(y => y.beatName === x.beatName) === idx);

const distinctWard = data => data
  .filter((x, idx, xs) => xs.findIndex(y => y.wardName === x.wardName) === idx);

const distinctZone = data => data
  .filter((x, idx, xs) => xs.findIndex(y => y.zoneName === x.zoneName) === idx);

@Component({
  selector: 'collectionSummary-cmp',
  templateUrl: 'collectionSummaryReport.Component.html',
  providers: [
    { provide: DateAdapter, useClass: MomentDateAdapter, deps: [MAT_DATE_LOCALE] },
    { provide: MAT_DATE_FORMATS, useValue: MY_FORMATS },
  ],
})

export class CollectionSummaryComponent {


  public aggregates: any[] = [{ field: 'Amount', aggregate: 'sum' },{ field: 'Count', aggregate: 'sum' },{ field: 'AssignedCouponCount', aggregate: 'sum' },{ field: 'CollectedCouponCount', aggregate: 'sum' },{ field: 'CollectedAmount', aggregate: 'sum' }];
  public state: State = {
    skip: 0,
    take:12,
    // Initial filter descriptor
    // group :[{ field: 'wardName', aggregates: this.aggregates }],
    filter: {
      logic: 'and',
      filters: []
    }
  };

  prjId: any;
  userId: any;
  showLoader: any;
  collectionList: any;
  dataRangeModal: any;
  startDate: any;
  endDate: any;
  defaultStartDate: any;
  defaultEndDate: any;
  firstColumns:any;
  secondColumns:any;
  public total: any;
  count:any;
  public checkboxOnly = false;
  public mode = 'multiple';
  public selectableSettings: SelectableSettings;
  public distinctBeat: any[]
  public distinctWard: any[]
  public distinctZone: any[]
  public distinctStatus: any[]
  public groups: GroupDescriptor[] = [];
  public view: Observable<GridDataResult>;
  public gridView: DataResult;

  reortTypeList:any;
  reportLabelList:any;
  reportLabel:any;
  zoneList:any;
  wardList:any;
  beatList:any;
  zoneId:any;
  wardId:any;
  beatId:any;
  reportTypeDataList:any;
  reportTypeData:any;
  defaultUrl:any;
  hideColumn:any;
  assignedCouponCount:any;
  collectedCouponCount:any;
  collectedAmount:any;
  public groupChange(groups: GroupDescriptor[]): void {
    this.groups = groups;
    this.loadProducts();
  }

  public allData(): ExcelExportData {
    const result: ExcelExportData =  {
        data: this.collectionList
    };
    return result;
   } 
  private loadProducts(): void {
    this.gridData = process(this.collectionList, { group: this.groups });
  }
  public gridData: GridDataResult
  constructor(private http: Http, private auth: AuthService, private loaderService: LoaderService) {
    this.loaderService.status.subscribe((val: boolean) => {
      this.showLoader = val;
      this.allData = this.allData.bind(this);
    });

    var firstDay = new Date(new Date().getFullYear(), new Date().getMonth(), 1);
    var lastDay = new Date(new Date().getFullYear(), new Date().getMonth() + 1, 0);
    this.defaultStartDate = (firstDay.getFullYear()) + '-' + (firstDay.getMonth() + 1) + '-' + firstDay.getDate();
    this.defaultEndDate = (lastDay.getFullYear()) + '-' + (firstDay.getMonth()+ 1)  + '-' + new Date().getDate();
    this.dataRangeModal = { beginDate: { year: firstDay.getFullYear(), month: firstDay.getMonth() + 1, day: firstDay.getDate() }, endDate: { year: lastDay.getFullYear(), month: firstDay.getMonth() + 1, day: new Date().getDate() } };
    this.reportLabelList = ["ward","beat"]
    this.reportTypeDataList = ["Datewise"]
    this.reportLabel = 'zone'
    this.zoneId = null
    this.wardId = null
    this.beatId = null
   
    this.reortTypeList = ['Assignment Summary','AssignMent Vs Collection']
    this.defaultUrl = "reports/getUccBulkCouponCollectionSummaryData?prjId="
    
  }
  ngOnInit() {
    this.prjId = this.auth.getAuthentication().projectId
    this.userId = this.auth.getAuthentication().id
    // this.getCollectionList();
    this.hideColumn = false
    this.startDate  = moment(this.defaultStartDate).format('YYYY-MM-DD');
    this.endDate = moment(this.defaultEndDate).format('YYYY-MM-DD');
    this.getCouponListDetailsByDate(this.startDate, this.endDate,this.reportLabel,this.defaultUrl);
    this.getZone();
    this.getWard();
    this.getBeat();
  }


  getZone(){
    this.http.get(environment.apiUrl + 'consumer/getZoneByProject?prjid='+this.prjId+'&oemid=7').subscribe(data =>{ 
        this.zoneList= data.json(); 
        console.log(this.zoneList)
   }); 
} 

  getWard(){
   this.http.get(environment.apiUrl + 'consumer/getZoneByProject?prjid='+this.prjId+'&oemid=8').subscribe(data =>{ 
      this.wardList= data.json(); 
      console.log(this.wardList)
    }); 
  } 

  getBeat(){
  this.http.get(environment.apiUrl + 'consumer/getZoneByProject?prjid='+this.prjId+'&oemid=9').subscribe(data =>{ 
      this.beatList= data.json(); 
   }); 
 } 

    selectZone(data){
    
     if(this.hideColumn){
      this.getAssignmentVsCollectionData(this.startDate, this.endDate,this.reportLabel,this.defaultUrl);
     }else{
      this.getCouponListDetailsByDate(this.startDate, this.endDate,this.reportLabel,this.defaultUrl);
     }
  }
    selectWard(data){
      if(this.hideColumn){
        this.getAssignmentVsCollectionData(this.startDate, this.endDate,this.reportLabel,this.defaultUrl);
       }else{
        this.getCouponListDetailsByDate(this.startDate, this.endDate,this.reportLabel,this.defaultUrl);
       }
   }
    selectBeat(data){
      if(this.hideColumn){
        this.getAssignmentVsCollectionData(this.startDate, this.endDate,this.reportLabel,this.defaultUrl);
       }else{
        this.getCouponListDetailsByDate(this.startDate, this.endDate,this.reportLabel,this.defaultUrl);
       }
  }
 

  selectReportLabel(data){
    if(data != null){
      this.reportLabel = data
    }
    if(this.hideColumn){
      this.getAssignmentVsCollectionData(this.startDate, this.endDate,this.reportLabel,this.defaultUrl);
     }else{
      this.getCouponListDetailsByDate(this.startDate, this.endDate,this.reportLabel,this.defaultUrl);
     }
  }

  selectReportTypeData(data){
     this.reportTypeData = data
     this.getCouponListDetailsByDate(this.startDate, this.endDate,this.reportLabel,this.defaultUrl)
  }
  selectReportType(data){
    
    if(data == "Collection Summary"){
      this.hideColumn = false
      this.defaultUrl = "reports/getUccBulkCouponCollectionSummaryData?prjId="
      this.getCouponListDetailsByDate(this.startDate, this.endDate,this.reportLabel,this.defaultUrl)
    }else if(data == "Assignment Summary"){
      this.hideColumn = false
      this.defaultUrl = "reports/getUccBulkAssignmentSummaryData?prjId="
      this.getCouponListDetailsByDate(this.startDate, this.endDate,this.reportLabel,this.defaultUrl)
    }else if(data == "AssignMent Vs Collection"){
      this.hideColumn = true
      this.firstColumns= []
      this.secondColumns= []
      this.defaultUrl = "reports/getAssignmentVsCollectionData?prjId="
      this.getAssignmentVsCollectionData(this.startDate, this.endDate,this.reportLabel,this.defaultUrl)
    }

  }


  public dataStateChange(state: DataStateChangeEvent): void {
    this.loaderService.display(true);
    this.state = state;
    this.gridData = process(this.collectionList, this.state);
    if (state && state.group) {
      this.total = aggregateBy(this.collectionList, this.aggregates)["Amount"].sum;
      this.count = aggregateBy(this.collectionList, this.aggregates)["Count"].sum;
     if(this.hideColumn){
      this.collectedAmount = aggregateBy(this.collectionList, this.aggregates)["CollectedAmount"].sum;
      this.assignedCouponCount = aggregateBy(this.collectionList, this.aggregates)["AssignedCouponCount"].sum;
      this.collectedCouponCount = aggregateBy(this.collectionList, this.aggregates)["CollectedCouponCount"].sum;
     }
      state.group.map(group => group.aggregates = this.aggregates);
    }
    this.loaderService.display(false);
  }


  onDateRangeChanged(dataRange) {
    
       var startDate = dataRange.beginDate.year + "-" + dataRange.beginDate.month + "-" + dataRange.beginDate.day
       var endDate = dataRange.endDate.year + "-" + dataRange.endDate.month + "-" + dataRange.endDate.day

      this.startDate =moment(startDate).format('YYYY-MM-DD');
      this.endDate =moment(endDate).format('YYYY-MM-DD');

      this.getCouponListDetailsByDate(this.startDate,this.endDate,this.reportLabel,this.defaultUrl);
  
  }

  getAssignmentVsCollectionData(stdate, enddate,reportLevel,url) {
     this.http.get(environment.apiUrl + url + this.prjId +"&startdate="+stdate+"&enddate="+enddate+"&reportLevel="+reportLevel + "&zoneId=" + this.zoneId + "&wardId=" + this.wardId + "&beatId=" + this.beatId + "&reportType=" + "Summarize").subscribe(data => {
       this.collectionList = data.json();
       this.firstColumns= []
       this.secondColumns= []

       for(var k in this.collectionList[0]) {
        if(k == "AssignedCouponCount"|| k =="CollectedCouponCount" || k =="CollectedAmount"){
    
        }else{
          this.secondColumns.push(k);
        }
           
      }
       if (this.collectionList.length > 0) {
           this.distinctZone = distinctZone(this.collectionList)
           this.collectedAmount = aggregateBy(this.collectionList, this.aggregates)["CollectedAmount"].sum;
           this.assignedCouponCount = aggregateBy(this.collectionList, this.aggregates)["AssignedCouponCount"].sum;
           this.collectedCouponCount = aggregateBy(this.collectionList, this.aggregates)["CollectedCouponCount"].sum;
           this.gridData = process(this.collectionList, this.state);
       }else{
         this.gridData = process([], this.state);
       }
     });
   }

  getCouponListDetailsByDate(stdate, enddate,reportLevel,url) {
   // this.loaderService.display(true);
    this.http.get(environment.apiUrl + url + this.prjId +"&startdate="+stdate+"&enddate="+enddate+"&reportLevel="+reportLevel + "&zoneId=" + this.zoneId + "&wardId=" + this.wardId + "&beatId=" + this.beatId + "&reportType=" + this.reportTypeData).subscribe(data => {
      this.collectionList = data.json();
      if (this.collectionList.length > 0) {
        console.log(this.collectionList)
       // this.columns = [this.collectionList[0]]
       this.firstColumns= []
        this.secondColumns= []
        for(var k in this.collectionList[0]) {
          if(k.substr(0,1) == "D"){
              this.secondColumns.push(k)
          }else{
            if(k != "Amount" && k !="Count"){
              this.firstColumns.push(k);
            }
           
          }
          
        }
      
        this.secondColumns = this.secondColumns
        this.firstColumns = this.firstColumns
        //this.distinctBeat = distinctBeat(this.collectionList)
        //this.distinctWard = distinctWard(this.collectionList)
          this.distinctZone = distinctZone(this.collectionList)
          this.total = aggregateBy(this.collectionList, this.aggregates)["Amount"].sum;
          this.count = aggregateBy(this.collectionList, this.aggregates)["Count"].sum;
          this.gridData = process(this.collectionList, this.state);
       // this.loaderService.display(false);
      }else{
        this.gridData = process([], this.state);
      }
    });
  }
}






