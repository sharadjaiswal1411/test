import { Component } from '@angular/core';
import { Http } from '@angular/http'
import { environment } from '../../../environments/environment';
import { MomentDateAdapter } from '@angular/material-moment-adapter';
import { DateAdapter, MAT_DATE_FORMATS, MAT_DATE_LOCALE } from '@angular/material/core';
import { Observable } from 'rxjs/Observable';

import { AuthService } from '../../_services/index';
import 'rxjs/add/operator/map'
import * as _ from 'underscore';
import { LoaderService } from '../../_services/loader.service';
import * as _moment from 'moment';
import * as _rollupMoment from 'moment';
const moment = _rollupMoment || _moment;
import { process, State, aggregateBy } from '@progress/kendo-data-query';
import { GroupDescriptor, DataResult } from '@progress/kendo-data-query';
import { SelectableSettings } from '@progress/kendo-angular-grid';
import { ExcelExportData } from '@progress/kendo-angular-excel-export';
import {
  GridDataResult,
  DataStateChangeEvent
} from '@progress/kendo-angular-grid';

declare var $: any;
export const MY_FORMATS = {
  parse: {
    dateInput: 'LL',
  },
  display: {
    dateInput: 'LL',
    monthYearLabel: 'MMM YYYY',
    dateA11yLabel: 'LL',
    monthYearA11yLabel: 'MMMM YYYY',
  },
};
const distinctBeat = data => data
  .filter((x, idx, xs) => xs.findIndex(y => y.beat === x.beat) === idx);

const distinctWard = data => data
  .filter((x, idx, xs) => xs.findIndex(y => y.ward=== x.ward) === idx);

const distinctZone = data => data
  .filter((x, idx, xs) => xs.findIndex(y => y.zone === x.zone) === idx);

@Component({
  selector: 'couponReport-Ucc',
  templateUrl: 'couponCollection.component.html',
  providers: [
    { provide: DateAdapter, useClass: MomentDateAdapter, deps: [MAT_DATE_LOCALE] },
    { provide: MAT_DATE_FORMATS, useValue: MY_FORMATS },
  ],
})

export class CollectionReportComponent {


  public aggregates: any[] = [{ field: 'amount', aggregate: 'sum' }];
  public state: State = {
    skip: 0,
    take: 15,
    // Initial filter descriptor
    // group :[{ field: 'wardName', aggregates: this.aggregates }],
    filter: {
      logic: 'and',
      filters: []
    }
  };

  prjId: any;
  userId: any;
  showLoader: any;
  collectionList: any;
  dataRangeModal: any;
  startDate: any;
  endDate: any;
  defaultStartDate: any;
  defaultEndDate: any;
  couponCollectionList:any;
  public total: any;
  public checkboxOnly = false;
  public mode = 'multiple';
  public selectableSettings: SelectableSettings;
  public distinctBeat: any[]
  public distinctWard: any[]
  public distinctZone: any[]
  public distinctStatus: any[]
  public groups: GroupDescriptor[] = [];
  public view: Observable<GridDataResult>;
  public gridView: DataResult;
  public groupChange(groups: GroupDescriptor[]): void {
    this.groups = groups;
    this.loadProducts();
  }
  public allData(): ExcelExportData {
    const result: ExcelExportData =  {
        data: this.couponCollectionList
    };
    return result;
   } 
  private loadProducts(): void {
    this.gridDataCouponCollection = process(this.couponCollectionList, { group: this.groups });
  }
  public gridDataCouponCollection: GridDataResult
  constructor(private http: Http, private auth: AuthService, private loaderService: LoaderService) {
    this.loaderService.status.subscribe((val: boolean) => {
      this.showLoader = val;
    });
    this.allData = this.allData.bind(this); 
    var firstDay = new Date();
    var lastDay = new Date(); 
    this.defaultStartDate = (firstDay.getFullYear()) + '-' + (firstDay.getMonth() + 1) + '-' + firstDay.getDate(); 
    this.defaultEndDate = (firstDay.getFullYear()) + '-' + (firstDay.getMonth() + 1) + '-' + firstDay.getDate(); 
    this.dataRangeModal= {beginDate: {year: firstDay.getFullYear(), month: firstDay.getMonth()+1, day: firstDay.getDate()}, endDate: {year: lastDay.getFullYear(), month: lastDay.getMonth()+1, day: lastDay.getDate()}};

  }
  ngOnInit() { 
    this.startDate  = moment(this.defaultStartDate).format('YYYY-MM-DD');
    this.endDate = moment(this.defaultEndDate).format('YYYY-MM-DD');
    this.prjId = this.auth.getAuthentication().projectId
    this.userId = this.auth.getAuthentication().id 
    this.getCouponCollectionList();
  }

  /*
   * GetBulkCoupon collection
  */
  getCouponCollectionList() {
      this.loaderService.display(true);
      this.http.get(environment.apiUrl + 'uccnew/getUccCouponCollection?prjId='+this.prjId+"&startDate=" + this.startDate + "&endDate="  +this.endDate) .subscribe(data => { 
      this.couponCollectionList = data.json(); 
      if (this.couponCollectionList.length > 0) { 
        this.distinctZone=distinctZone(this.couponCollectionList)
        this.distinctWard=distinctWard(this.couponCollectionList)
        this.distinctBeat=distinctBeat(this.couponCollectionList)
        this.gridDataCouponCollection = process(this.couponCollectionList, this.state);
        this.loaderService.display(false);
      }
      else{
        this.gridDataCouponCollection=null;
        this.loaderService.display(false);
      }  
    });
  }




  public dataStateChange(state: DataStateChangeEvent): void { 
    this.state = state;
    this.gridDataCouponCollection = process(this.couponCollectionList, this.state); 
    if (state && state.group) {
       this.distinctZone=distinctZone(this.couponCollectionList)
       this.distinctWard=distinctWard(this.couponCollectionList)
       this.distinctBeat=distinctBeat(this.couponCollectionList) 
       this.gridDataCouponCollection = process(this.couponCollectionList, this.state); 
    } 
  }

  excelDownloadModal() {
    $('#excelDownload').modal('show');
  }


  excelDownload() {
     window.open(environment.apiUrl + "ucc/couponCollectionReportExcel?prjId=" + this.prjId + "&fromDate=" +this.startDate + "&toDate=" + this.endDate);

   }


  onDateRangeChanged(dataRange)
  {  
    if(dataRange.beginDate.day>0){ 
      this.startDate= dataRange.beginDate.year + "-"  + dataRange.beginDate.month+ "-" + dataRange.beginDate.day 
      this.endDate = dataRange.endDate.year + "-"  + dataRange.endDate.month  + "-" + dataRange.endDate.day 
      this.getCouponCollectionList(); 
    }
    else if(dataRange.beginDate.day==0){
      this.startDate= this.defaultStartDate
      this.endDate = this.defaultStartDate
      this.getCouponCollectionList(); 
    }  
  } 
   
}






