import { Component } from '@angular/core';
import { Http } from '@angular/http'
import { environment } from '../../../environments/environment';
import { MomentDateAdapter } from '@angular/material-moment-adapter';
import { DateAdapter, MAT_DATE_FORMATS, MAT_DATE_LOCALE } from '@angular/material/core';
import { Observable } from 'rxjs/Observable';

import { AuthService } from '../../_services/index';
import 'rxjs/add/operator/map'
import * as _ from 'underscore';
import { LoaderService } from '../../_services/loader.service';
import * as _moment from 'moment';
import * as _rollupMoment from 'moment';
const moment = _rollupMoment || _moment;
import { process, State, aggregateBy } from '@progress/kendo-data-query';
import { GroupDescriptor, DataResult } from '@progress/kendo-data-query';
import { SelectableSettings } from '@progress/kendo-angular-grid';
import { ExcelExportData } from '@progress/kendo-angular-excel-export'; 
import {
  GridDataResult,
  DataStateChangeEvent
} from '@progress/kendo-angular-grid';

declare var $: any;
export const MY_FORMATS = {
  parse: {
    dateInput: 'LL',
  },
  display: {
    dateInput: 'LL',
    monthYearLabel: 'MMM YYYY',
    dateA11yLabel: 'LL',
    monthYearA11yLabel: 'MMMM YYYY',
  },
};
const distinctBeat = data => data
  .filter((x, idx, xs) => xs.findIndex(y => y.beatName === x.beatName) === idx);

const distinctWard = data => data
  .filter((x, idx, xs) => xs.findIndex(y => y.wardName === x.wardName) === idx);

const distinctZone = data => data
  .filter((x, idx, xs) => xs.findIndex(y => y.zoneName === x.zoneName) === idx);

@Component({
  selector: 'bulkCollectionReport-cmp',
  templateUrl: 'bulkCollectionReport.Component.html',
  providers: [
    { provide: DateAdapter, useClass: MomentDateAdapter, deps: [MAT_DATE_LOCALE] },
    { provide: MAT_DATE_FORMATS, useValue: MY_FORMATS },
  ],
}) 

export class BulkCollectionReportComponent {


  public aggregates: any[] = [{ field: 'amount', aggregate: 'sum' }, { field: 'denomination', aggregate: 'count' }];
  public state: State = {
    skip: 0,
    take: 12,
    // Initial filter descriptor
    // group :[{ field: 'wardName', aggregates: this.aggregates }],
    filter: {
      logic: 'and',
      filters: []
    }
  };

  prjId: any;
  userId: any;
  showLoader: any;
  collectionList: any;
  dataRangeModal: any;
  startDate: any;
  endDate: any;
  defaultStartDate: any;
  defaultEndDate: any;
  public total: any;
  public checkboxOnly = false;
  public mode = 'multiple';
  public selectableSettings: SelectableSettings;
  public distinctBeat: any[]
  public distinctWard: any[]
  public distinctZone: any[]
  public distinctStatus: any[]
  public groups: GroupDescriptor[] = [];
  public view: Observable<GridDataResult>;
  public gridView: DataResult;
  public groupChange(groups: GroupDescriptor[]): void {
    this.groups = groups;
    this.loadProducts();
  }

  private loadProducts(): void {
    this.gridData = process(this.collectionList, { group: this.groups });
  }
  public gridData: GridDataResult
  public allData(): ExcelExportData {
    const result: ExcelExportData =  {
        data: this.collectionList
    };
    return result;
   } 
  constructor(private http: Http, private auth: AuthService, private loaderService: LoaderService) {
    this.loaderService.status.subscribe((val: boolean) => {
      this.showLoader = val;
      this.allData = this.allData.bind(this);
    });

    var firstDay = new Date();
    var lastDay = new Date(); 
    this.defaultStartDate = (firstDay.getFullYear()) + '-' + (firstDay.getMonth() + 1) + '-' + firstDay.getDate(); 
    this.defaultEndDate = (lastDay.getFullYear()) + '-' + (lastDay.getMonth() + 1) + '-' + lastDay.getDate(); 
    this.dataRangeModal= {beginDate: {year: firstDay.getFullYear(), month: firstDay.getMonth()+1, day: firstDay.getDate()}, endDate: {year: lastDay.getFullYear(), month: lastDay.getMonth()+1, day: lastDay.getDate()}};

  }
  ngOnInit() {

    this.startDate  = moment(this.defaultStartDate).format('YYYY-MM-DD');
    this.endDate = moment(this.defaultEndDate).format('YYYY-MM-DD');
    this.prjId = this.auth.getAuthentication().projectId
    this.userId = this.auth.getAuthentication().id
    // this.getCollectionList();
    this.getCouponListDetailsByDate(this.startDate, this.endDate);
  }

  /**
   * GetBulkCoupon collection
  */
  getCollectionList() {
    this.loaderService.display(true);
    this.http.get(environment.apiUrl + 'ucc/getCollectionList?prjId='+this.prjId+'&userId='+ this.userId + "&startDate=" + this.startDate + "&endDate="  +this.endDate) .subscribe(data => { 
      this.collectionList = data.json();
      if (this.collectionList.length > 0) {
        this.distinctBeat = distinctBeat(this.collectionList)
        this.distinctWard = distinctWard(this.collectionList)
        this.distinctZone = distinctZone(this.collectionList)
        this.total = aggregateBy(this.collectionList, this.aggregates)["amount"].sum;
        this.gridData = process(this.collectionList, this.state);
      }

      this.loaderService.display(false);
    });
  }




  public dataStateChange(state: DataStateChangeEvent): void {
    this.loaderService.display(true);
    this.state = state;
    this.gridData = process(this.collectionList, this.state);

    if (state && state.group) {
      this.total = aggregateBy(this.collectionList, this.aggregates)["amount"].sum;
      state.group.map(group => group.aggregates = this.aggregates);
    }
    this.loaderService.display(false);
  }


  onDateRangeChanged(dataRange)
    {  
      if(this.startDate!=''||this.startDate!=null||this.startDate!=undefined){ 
        var startDate= dataRange.beginDate.year + "-"  + dataRange.beginDate.month+ "-" + dataRange.beginDate.day 
        var endDate = dataRange.endDate.year + "-"  + dataRange.endDate.month  + "-" + dataRange.endDate.day
  
        this.startDate  = moment(startDate).format('YYYY-MM-DD');
        this.endDate = moment(endDate).format('YYYY-MM-DD');
        console.log(this.startDate)
        console.log(this.endDate)
        this.getCouponListDetailsByDate( this.startDate,this.endDate);
      }
      else{
    
        this.startDate  = moment(this.defaultStartDate).format('YYYY-MM-DD');
        this.endDate = moment(this.defaultEndDate).format('YYYY-MM-DD');
        this.getCouponListDetailsByDate( this.startDate,this.endDate);
      }  
    }
  
  getCouponListDetailsByDate(stdate, enddate) {
    this.loaderService.display(true);
    this.http.get(environment.apiUrl + 'reports/getCollectionListByDate?prjId=' + this.prjId + '&userId=' + null + "&startDate=" + stdate + "&endDate=" + enddate).subscribe(data => {
      this.collectionList = data.json();
      if (this.collectionList.length > 0) {
        this.distinctBeat = distinctBeat(this.collectionList)
        this.distinctWard = distinctWard(this.collectionList)
        this.distinctZone = distinctZone(this.collectionList)
        this.total = aggregateBy(this.collectionList, this.aggregates)["amount"].sum;
        this.gridData = process(this.collectionList, this.state);
        
      }
      this.loaderService.display(false);
    });
  }
}






