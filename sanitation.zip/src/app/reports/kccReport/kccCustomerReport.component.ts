import { Component, ViewEncapsulation, } from '@angular/core';


import { ActivatedRoute, Router } from '@angular/router';
import { Http } from '@angular/http'

import { environment } from '../../../environments/environment';
import { DateAdapter, MAT_DATE_FORMATS, MAT_DATE_LOCALE } from '@angular/material/core';//added by kuldeep on 10-03-2018
import { MomentDateAdapter } from '@angular/material-moment-adapter';//added by kuldeep on 10-03-2018
import * as _moment from 'moment'; //added by kuldeep on 10-03-2018
import * as _rollupMoment from 'moment';//added by kuldeep on 10-03-2018


import { AuthService } from '../../_services/index';
import { LoaderService } from '../../_services/loader.service';



import { process, State } from '@progress/kendo-data-query';

import { GroupDescriptor, DataResult } from '@progress/kendo-data-query';
import { Observable } from 'rxjs/Observable';
import { SelectableSettings } from '@progress/kendo-angular-grid';
 
import {
  GridDataResult,
  DataStateChangeEvent
} from '@progress/kendo-angular-grid';

const moment = _rollupMoment || _moment;
export const MY_FORMATS = {
  parse: {
    dateInput: 'LL',
  },
  display: {
    dateInput: 'LL',
    monthYearLabel: 'MMM YYYY',
    dateA11yLabel: 'LL',
    monthYearA11yLabel: 'MMMM YYYY',
  },
}; 

declare var $: any;
 
const distinct = data => data
  .filter((x, idx, xs) => xs.findIndex(y => y.zone === x.zone) === idx);


  const distinctWard = data => data
  .filter((x, idx, xs) => xs.findIndex(y => y.ward === x.ward) === idx);
  


  const distinctStatus = data => data
  .filter((x, idx, xs) => xs.findIndex(y => y.status === x.status) === idx);

  
@Component({

  selector: 'customerListReport-cmp',
  templateUrl: './kccCustomerReport.component.html',
  encapsulation: ViewEncapsulation.None ,
  providers: [
    { provide: DateAdapter, useClass: MomentDateAdapter, deps: [MAT_DATE_LOCALE] },
    { provide: MAT_DATE_FORMATS, useValue: MY_FORMATS },
  ],

})
export class KccCustomerReportComponent {

  public state: State = {
    skip: 0,
    take: 500, 
    // Initial filter descriptor
    filter: {
      logic: 'and',
      filters: []
    }
  };
  public pageSize :any
  public checkboxOnly = false;
  public mode = 'multiple';
  public selectableSettings: SelectableSettings;
  public distinctZone: any[]
  public distinctWard: any[]
  public distinctStatus:any[]
  public groups: GroupDescriptor[] = [];
  public view: Observable<GridDataResult>;
  public gridDataKccCustomer: DataResult;
  public hiddenColumns: string[] = [];
  public isHidden(columnName: string): boolean {
    return this.hiddenColumns.indexOf(columnName) > -1;
  }
  public groupChange(groups: GroupDescriptor[]): void {
    this.groups = groups;
    this.loadProducts();
  }

  private loadProducts(): void {
    this.gridDataKccCustomer = process(this.invoiceList, { group: this.groups });
  }
  public filteredInvoiceData:any;
  public manualSelectedData:any;
  public gridData: GridDataResult
  public invoiceList: any
  public prjId; any
  public userId:any;
  public invoiceTypeName:any;
  zoneList: any;
  showLoader: any; 
  customerList:any;
  defaultStartDate:any;
  defaultEndDate:any;
  dataRangeModal:any;
  startDate:any;
  endDate:any;

  constructor(private http: Http,private auth : AuthService,public routes: ActivatedRoute, public router: Router,private loaderService: LoaderService) {
    this.loaderService.status.subscribe((val: boolean) =>{
        this.showLoader = val;
      });
    var date = new Date(); 
    var firstDay = new Date(date.getFullYear(), date.getMonth(), 1);
    var lastDay = new Date(date.getFullYear(), date.getMonth(), 0); 
    this.defaultStartDate = (firstDay.getFullYear()) + '-' + (firstDay.getMonth() + 1) + '-' + firstDay.getDate(); 
    this.defaultEndDate = (date.getFullYear()) + '-' + (date.getMonth()+1) + '-' + date.getDate(); 
    this.dataRangeModal= {beginDate: {year: firstDay.getFullYear(), month: firstDay.getMonth()+1, day: firstDay.getDate()}, endDate: {year: date.getFullYear(), month: date.getMonth()+1, day: date.getDate()}};
  }  
  
  ngOnInit() 
  { 
    this.prjId = this.auth.getAuthentication().projectId  
    this.userId = this.auth.getAuthentication().id  
    this.getKccCustomerList(); 
  } 

  /*
   * Get All KCC customer Details
  */
  public  getKccCustomerList() {  
    this.loaderService.display(true); 
    if(this.startDate==null||this.endDate==null){
        this.startDate=this.defaultStartDate
        this.endDate=this.defaultEndDate 
    } 
    this.http.get(environment.apiUrl + 'reports/getKccCustomerReport?prjId=' + this.prjId +"&startDate=" + this.startDate + "&endDate=" + this.endDate).subscribe(data => {
    this.customerList =data.json() 
    if(this.customerList.length>0){
        this.gridDataKccCustomer = process(this.customerList, this.state);
        this.distinctZone = distinct(this.customerList); 
        this.distinctWard = distinctWard(this.customerList);
        this.distinctStatus = distinctStatus(this.customerList); 
        this.loaderService.display(false);   
    }
    else {
        this.loaderService.display(false);   
    } 
  });
}
 
  

/*
 * filter The Date
*/
  public dataStateChange(state: DataStateChangeEvent): void {
    this.state = state;
    this.gridDataKccCustomer = process(this.customerList, this.state);
    //this.selectedInvoiceCount = this.gridData.data.length
    this.manualSelectedData = []
    if (state && state.group) {  
        this.gridDataKccCustomer = process(this.customerList, this.state);
      } 
  }
 
/*
 * Select Date range
*/  
   onDateRangeChanged(dataRange)
   {  
     if(dataRange.beginDate.day>0){ 
       this.startDate= dataRange.beginDate.year + "-"  + dataRange.beginDate.month+ "-" + dataRange.beginDate.day 
       this.endDate = dataRange.endDate.year + "-"  + dataRange.endDate.month  + "-" + dataRange.endDate.day
       this.getKccCustomerList()       
     }
     else if(dataRange.beginDate.day==0){
       this.startDate=this.defaultStartDate;
       this.endDate=this.defaultEndDate; 
       this.getKccCustomerList()
     }  
   }


   


   


 
 

 



}
