import { Component } from '@angular/core';
import { Http } from '@angular/http'
import { environment } from '../../../environments/environment'; 
import { AuthService } from '../../_services/index';
import { ActivatedRoute, Router } from '@angular/router';
import { LoaderService } from '../../_services/loader.service';
import { Observable } from 'rxjs/Observable';


import { process, State ,aggregateBy } from '@progress/kendo-data-query';
import { GroupDescriptor, DataResult } from '@progress/kendo-data-query';
import {GridDataResult,DataStateChangeEvent} from '@progress/kendo-angular-grid';

import * as _moment from 'moment';
import * as _rollupMoment from 'moment';
const moment = _rollupMoment || _moment;
declare var $: any; 



const distinctZone = data => data.filter((x, idx, xs) => xs.findIndex(y => y.zone === x.zone) === idx);
const distinctWard = data => data.filter((x, idx, xs) => xs.findIndex(y => y.ward === x.ward) === idx);
 
@Component({ 
  templateUrl: './kccConsolidatedReport.component.html', 
})
//###################################################################

export class KccConsolidatedReportComponent {
 public prjId:any
 public userId:any
 public startDate:any;
 public endDate:any;

 public kccConsolidatedData
 public defaultStartDate:any;
 public defaultEndDate:any;
 public dataRangeModal:any; 
 public showLoader: boolean;  
 reportType:any;
 reportSubType:any;

 public aggregates: any[] = [{field: 'totalConsumer', aggregate: 'sum'},{field: 'paidConsumers', aggregate: 'sum'},{field: 'paidInvoice', aggregate: 'sum'},{field: 'totalAmount', aggregate: 'sum'},{field: 'outstandingAmount', aggregate: 'sum'}];
  public state: State = {
    skip: 0,
    take: 50000,
    // Initial filter descriptor
    // group :[{ field: 'wardName', aggregates: this.aggregates }],
    filter: {
      logic: 'and',
      filters: []
    }
  };

  public distinctZone: any[]
  public distinctWard: any[]
  

  public groups: GroupDescriptor[] = []; 
  public view: Observable<GridDataResult>;
  public gridView: DataResult;

  public groupChange(groups: GroupDescriptor[]): void {
    this.groups = groups;
    this.loadProducts();
  }

  private loadProducts(): void {
    this.gridData = process(this.kccConsolidatedData, { group: this.groups }); 
 
  }
  public gridData: GridDataResult 
  public listItems: Array<string> = ['PAYMENT','OUTSTANDING','RECONCILIATION']
  public selectedValue: string = "OUTSTANDING";
  
  paidConsumers:any
  paidInvoice:any;
  totalAmount:any
  outstandingAmount:any
  totalConsumer:any;

  constructor(private http: Http,private auth : AuthService,public routes: ActivatedRoute, public router: Router,private loaderService: LoaderService) {
    this.loaderService.status.subscribe((val: boolean) =>{
        this.showLoader = val;
      });

    this.reportType = 'OUTSTANDING'
    this.reportSubType = 'summary'
    var date = new Date(); 
    var firstDay = new Date(date.getFullYear(), date.getMonth(), 1);
    this.defaultStartDate = (firstDay.getFullYear()) + '-' + (firstDay.getMonth() + 1) + '-' + firstDay.getDate(); 
    this.defaultEndDate = (date.getFullYear()) + '-' + (date.getMonth()+1) + '-' + date.getDate(); 
    this.dataRangeModal= {beginDate: {year: firstDay.getFullYear(), month: firstDay.getMonth()+1, day: firstDay.getDate()}, endDate: {year: date.getFullYear(), month: date.getMonth()+1, day: date.getDate()}};
  }  

  ngOnInit() 
  { 
    this.prjId = this.auth.getAuthentication().projectId  
    this.userId = this.auth.getAuthentication().id 
    this.getCollectionSummaryList(this.reportType,this.reportSubType); 
  }
   
/**
 * get KCC summary Report List
*/

selectKccReportType(data){
   this.reportType = data 
   this.getCollectionSummaryList(this.reportType,this.reportSubType)
}

//gridDataKccSummaryList
  getCollectionSummaryList(reportType,reportSubType){ 
    this.loaderService.display(true); 
    if(this.startDate==null||this.endDate==null){
        this.startDate= moment(this.defaultStartDate).format('YYYY-MM-DD');
        this.endDate= moment(this.defaultEndDate).format('YYYY-MM-DD');
    }else{
        this.startDate= moment(this.startDate).format('YYYY-MM-DD');
        this.endDate= moment(this.endDate).format('YYYY-MM-DD');
    }
    this.http.get(environment.apiUrl + 'reports/kccConsolidatedReport?prjId=' + this.prjId +"&fromDate=" + this.startDate + "&toDate=" + this.endDate + "&reportType=" + reportType + "&reportSubType=" + reportSubType).subscribe(data => 
        { 
        this.kccConsolidatedData=data.json();  
        this.gridData = process(this.kccConsolidatedData, this.state); 
        if(this.kccConsolidatedData.length>0){ 
            this.distinctZone = distinctZone(this.kccConsolidatedData) 
            this.distinctWard = distinctWard(this.kccConsolidatedData) 
            this.totalConsumer = aggregateBy(this.kccConsolidatedData, this.aggregates)["totalConsumer"].sum; 
            this.paidConsumers = aggregateBy(this.kccConsolidatedData, this.aggregates)["paidConsumers"].sum;
            this.paidInvoice = aggregateBy(this.kccConsolidatedData, this.aggregates)["paidInvoice"].sum; 
            this.totalAmount = aggregateBy(this.kccConsolidatedData, this.aggregates)["totalAmount"].sum;
            this.outstandingAmount = aggregateBy(this.kccConsolidatedData, this.aggregates)["outstandingAmount"].sum;     
        }else{
            this.totalConsumer =0 
            this.paidConsumers = 0
            this.paidInvoice = 0 
            this.totalAmount = 0
            this.outstandingAmount = 0
        }
        this.loaderService.display(false);   
        }); 
    }

     

    /*
     * Select Date range
    */  
    onDateRangeChanged(dataRange)
    {  
      if(dataRange.beginDate.day>0){ 
        this.startDate= dataRange.beginDate.year + "-"  + dataRange.beginDate.month+ "-" + dataRange.beginDate.day 
        this.endDate = dataRange.endDate.year + "-"  + dataRange.endDate.month  + "-" + dataRange.endDate.day
        this.getCollectionSummaryList(this.reportType,this.reportSubType) 
      }
      else if(dataRange.beginDate.day==0){
        this.startDate=this.defaultStartDate;
        this.endDate=this.defaultEndDate; 
        this.getCollectionSummaryList(this.reportType,this.reportSubType) 
      }  
    }
    


    
  
     /*
     * Collection Filter
    */
   public dataStateChange(state: DataStateChangeEvent): void {
      this.state = state;  
      this.gridData = process(this.kccConsolidatedData, this.state);
     if(this.gridData.data.length>0){
      this.totalConsumer = aggregateBy(this.gridData.data, this.aggregates)["totalConsumer"].sum; 
      this.paidConsumers = aggregateBy(this.gridData.data, this.aggregates)["paidConsumers"].sum;
      this.paidInvoice = aggregateBy(this.gridData.data, this.aggregates)["paidInvoice"].sum; 
      this.totalAmount = aggregateBy(this.gridData.data, this.aggregates)["totalAmount"].sum;
      this.outstandingAmount = aggregateBy(this.gridData.data, this.aggregates)["outstandingAmount"].sum;     
     }else{
        this.totalConsumer = 0
        this.paidConsumers = 0
        this.paidInvoice = 0
        this.totalAmount = 0
        this.outstandingAmount = 0    
     }
  }

}
