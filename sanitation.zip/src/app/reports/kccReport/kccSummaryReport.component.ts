import { Component } from '@angular/core';


import { Http } from '@angular/http'
import { environment } from '../../../environments/environment'; 

import { AuthService } from '../../_services/index';
import { ActivatedRoute, Router } from '@angular/router';
import { LoaderService } from '../../_services/loader.service';
//For KENDO UI
import { process, State ,aggregateBy } from '@progress/kendo-data-query';

import { GroupDescriptor, DataResult } from '@progress/kendo-data-query';

import {GridDataResult,DataStateChangeEvent} from '@progress/kendo-angular-grid';
import { Observable } from 'rxjs/Observable';
//added by kuldeep on 10-03-2018 
//##########################
declare var $: any; 



const distinctZone = data => data.filter((x, idx, xs) => xs.findIndex(y => y.ZONENAME === x.ZONENAME) === idx);
const distinctWard = data => data.filter((x, idx, xs) => xs.findIndex(y => y.WARDNAME === x.WARDNAME) === idx);
 
@Component({ 
  templateUrl: './kccSummaryReport.component.html', 
})
//###################################################################

export class KccSummaryReportComponent {
 public prjId:any
 public userId:any
 public startDate:any;
 public endDate:any;
 public kccSummaryList:any;
 public kccReortTypeList:any;
 public defaultStartDate:any;
 public defaultEndDate:any;
 public dataRangeModal:any; 
 public showLoader: boolean;  
 public showHideCH=false;
 public showHideDM=false;
 public showHideSM=false;
 public totalTargetKcc:any;
 public totalBilledKcc:any;
 public totalPaidKcc:any;
 public totalPILeft:any;
 public totalTI:any;
 public totalPaidTI:any;
 public totalAmt:any;
 public totalPaidAmt:any;
 public totalOutStdAmt:any;

 public aggregates: any[] = [{field: 'targetKCC', aggregate: 'sum'},{field: 'billedConsumer', aggregate: 'sum'},{field: 'PaidConsumers', aggregate: 'sum'},{field: 'PILeft', aggregate: 'sum'},{field: 'TI', aggregate: 'sum'},{field: 'paidTI', aggregate: 'sum'},{field: 'TotalAmount', aggregate: 'sum'},{field: 'Paidamount', aggregate: 'sum'},{field: 'OutStanding', aggregate: 'sum'}];
  public state: State = {
    skip: 0,
    take: 50000,
    // Initial filter descriptor
    // group :[{ field: 'wardName', aggregates: this.aggregates }],
    filter: {
      logic: 'and',
      filters: []
    }
  };

  public distinctZone: any[]
  public distinctWard: any[]
  

  public groups: GroupDescriptor[] = []; 
  public view: Observable<GridDataResult>;
  public gridView: DataResult;
  public groupChange(groups: GroupDescriptor[]): void {
    this.groups = groups;
    this.loadProducts();
  }

  private loadProducts(): void {
    this.gridDataKccSummaryList = process(this.kccSummaryList, { group: this.groups }); 
 
  }
  public gridDataKccSummaryList: GridDataResult 
  public listItems: Array<string> = ['CLIENT HANDLING','SERVICE MGR','DISTRIBUTOR MGR']
  public selectedValue: string = "CLIENT HANDLING";



  constructor(private http: Http,private auth : AuthService,public routes: ActivatedRoute, public router: Router,private loaderService: LoaderService) {
    this.loaderService.status.subscribe((val: boolean) =>{
        this.showLoader = val;
      });
    var date = new Date(); 
    var firstDay = new Date(date.getFullYear(), date.getMonth(), 1);
    // var lastDay = new Date(date.getFullYear(), date.getMonth(), 0); 
    this.defaultStartDate = (firstDay.getFullYear()) + '-' + (firstDay.getMonth() + 1) + '-' + firstDay.getDate(); 
    this.defaultEndDate = (date.getFullYear()) + '-' + (date.getMonth()+1) + '-' + date.getDate(); 
    this.dataRangeModal= {beginDate: {year: firstDay.getFullYear(), month: firstDay.getMonth()+1, day: firstDay.getDate()}, endDate: {year: date.getFullYear(), month: date.getMonth()+1, day: date.getDate()}};
  }  

  ngOnInit() 
  { 
    this.prjId = this.auth.getAuthentication().projectId  
    this.userId = this.auth.getAuthentication().id 
    this.showHideCH=true;
    this.getCollectionSummaryList(); 
  }
   
/**
 * get KCC summary Report List
*/

//gridDataKccSummaryList
  getCollectionSummaryList(){ 
    this.loaderService.display(true); 
    if(this.startDate==null||this.endDate==null){
        this.startDate=this.defaultStartDate
        this.endDate=this.defaultEndDate 
    } 
    this.http.get(environment.apiUrl + 'reports/getInvoiceSummary?prjId=' + this.prjId +"&startDate=" + this.startDate + "&endDate=" + this.endDate).subscribe(data => 
        { 
        this.kccSummaryList=data.json();  
        if(this.kccSummaryList.length>0){ 
            this.distinctZone = distinctZone(this.kccSummaryList) 
            this.distinctWard = distinctWard(this.kccSummaryList) 
            this.totalTargetKcc = aggregateBy(this.kccSummaryList, this.aggregates)["targetKCC"].sum; 
            this.totalBilledKcc = aggregateBy(this.kccSummaryList, this.aggregates)["billedConsumer"].sum;
            this.totalPaidKcc= aggregateBy(this.kccSummaryList, this.aggregates)["PaidConsumers"].sum;
            this.totalPILeft= aggregateBy(this.kccSummaryList, this.aggregates)["PILeft"].sum;
            this.totalTI= aggregateBy(this.kccSummaryList, this.aggregates)["TI"].sum;
            this.totalPaidTI= aggregateBy(this.kccSummaryList, this.aggregates)["paidTI"].sum;
            this.totalAmt= aggregateBy(this.kccSummaryList, this.aggregates)["TotalAmount"].sum;
            this.totalPaidAmt= aggregateBy(this.kccSummaryList, this.aggregates)["Paidamount"].sum;
            this.totalOutStdAmt= aggregateBy(this.kccSummaryList, this.aggregates)["OutStanding"].sum; 
            this.gridDataKccSummaryList = process(this.kccSummaryList, this.state);  
            this.loaderService.display(false);           
        }
        else{
            this.loaderService.display(false); 
            this.totalTargetKcc=null 
            this.totalBilledKcc=null 
            this.totalPaidKcc=null 
            this.totalPILeft=null 
            this.totalTI=null 
            this.totalPaidTI=null 
            this.totalAmt=null 
            this.totalPaidAmt=null 
            this.totalOutStdAmt=null 
            this.gridDataKccSummaryList=null;
          } 
        }); 
    }

     

    /*
     * Select Date range
    */  
    onDateRangeChanged(dataRange)
    {  
      if(dataRange.beginDate.day>0){ 
        this.startDate= dataRange.beginDate.year + "-"  + dataRange.beginDate.month+ "-" + dataRange.beginDate.day 
        this.endDate = dataRange.endDate.year + "-"  + dataRange.endDate.month  + "-" + dataRange.endDate.day
        this.getCollectionSummaryList() 
      }
      else if(dataRange.beginDate.day==0){
        this.startDate=this.defaultStartDate;
        this.endDate=this.defaultEndDate; 
        this.getCollectionSummaryList()
      }  
    }
    


    
    /*
     * selet report type
    */
   selectKccReportType(data){ 
    if(data=="CLIENT HANDLING"){
        this.showHideCH=true;
        this.showHideSM=false;
        this.showHideDM=false;
        this.getCollectionSummaryList()
    }
    else if(data=="SERVICE MGR"){
        this.showHideSM=true;
        this.showHideDM=false;
        this.showHideCH=false;
        this.getCollectionSummaryList()
    }
    else if(data=="DISTRIBUTOR MGR"){
        this.showHideDM=true;
        this.showHideSM=false;
        this.showHideCH=false;
        this.getCollectionSummaryList()
    }
    }
 
  
     /*
     * Collection Filter
    */
   public dataStateChange(state: DataStateChangeEvent): void {
    this.state = state;  
      this.gridDataKccSummaryList = process(this.kccSummaryList, this.state);
      if(state && state.group){  
      this.totalTargetKcc = aggregateBy(this.gridDataKccSummaryList.data, this.aggregates)["targetKCC"].sum; 
      this.totalBilledKcc = aggregateBy(this.gridDataKccSummaryList.data, this.aggregates)["billedConsumer"].sum;
      this.totalPaidKcc= aggregateBy(this.gridDataKccSummaryList.data, this.aggregates)["PaidConsumers"].sum;
      this.totalPILeft= aggregateBy(this.gridDataKccSummaryList.data, this.aggregates)["PILeft"].sum;
      this.totalTI= aggregateBy(this.gridDataKccSummaryList.data, this.aggregates)["TI"].sum;
      this.totalPaidTI= aggregateBy(this.gridDataKccSummaryList.data, this.aggregates)["paidTI"].sum;
      this.totalAmt= aggregateBy(this.gridDataKccSummaryList.data, this.aggregates)["TotalAmount"].sum;
      this.totalPaidAmt= aggregateBy(this.gridDataKccSummaryList.data, this.aggregates)["Paidamount"].sum;
      this.totalOutStdAmt= aggregateBy(this.gridDataKccSummaryList.data, this.aggregates)["OutStanding"].sum;  
      state.group.map(group => group.aggregates = this.aggregates); 
      this.gridDataKccSummaryList = process(this.kccSummaryList, this.state);
    } 
  }















}
