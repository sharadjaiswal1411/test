import { Component, OnInit } from '@angular/core';


import { HttpClient } from '@angular/common/http';
import { AuthService } from '../../_services/index';
import { ActivatedRoute, Router } from '@angular/router';
//added by kuldeep on 10-03-2018 
//##########################




@Component({
  selector: 'kccApp-reports',
  templateUrl: './kccReport.component.html', 
})

export class KccReportsComponent {
 public prjId:any
 public userId:any

  constructor(private http: HttpClient,private auth : AuthService) { 
  }  
  ngOnInit() 
  { 
    this.prjId = this.auth.getAuthentication().projectId  
    this.userId = this.auth.getAuthentication().id 
  }

}
 