import { Component, ViewEncapsulation } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Http } from '@angular/http'

import { environment } from '../../../environments/environment';
import { AuthService } from '../../_services';
import { LoaderService } from '../../_services/loader.service';
import { process, State } from '@progress/kendo-data-query';
import { ExcelExportData } from '@progress/kendo-angular-excel-export';
declare var require: any;
const XlsxPopulate = require('xlsx-populate');
declare var $: any;
import * as _moment from 'moment'; //added by kuldeep on 10-03-2018
import * as _rollupMoment from 'moment';//
const moment = _rollupMoment || _moment;

@Component({
  selector: 'kccDetailReport-cmp',
  templateUrl: './kccDetailReport.component.html',
  encapsulation: ViewEncapsulation.None,

})
export class KccDetailReportComponent {

  filterData: any = {};
  wardList: any;
  employeList: any;
  searching: any;

  piStartDate: any;
  piEndDate: any;
  piDateRange: any;
  tiStartDate: any;
  tiEndDate: any;
  tiDateRange: any;
  invoiceTypeArray: any;
  invoiceType = 2;
  statusList: any;
  showLoader: any;
  invoiceList: any;
  gridData: any;
  prjId: any;
  zoneList: any;
  userId: any;
  followupStatus: any;


  public aggregates: any[] = [{ field: 'Amount', aggregate: 'sum' }, { field: 'paidAmount', aggregate: 'sum' }];
  public state: State = {
    skip: 0,
    take: 100,
    filter: {
      logic: 'and',
      filters: []
    }
  };

  public allData(): ExcelExportData {
    const result: ExcelExportData = {
      data: this.invoiceList
    };
    return result;
  }





  constructor(private http: Http, private auth: AuthService, public routes: ActivatedRoute, public router: Router, private loaderService: LoaderService) {
    this.loaderService.status.subscribe((val: boolean) => {
      this.showLoader = val;
    });

    var date = new Date();
    this.allData = this.allData.bind(this);
    var lastDay = new Date();
    var date = new Date()
    var firstDay = new Date(date.getFullYear(), date.getMonth(), 1);
    this.piStartDate = moment(new Date((firstDay.getFullYear()) + '-' + (firstDay.getMonth() + 1) + '-' + firstDay.getDate())).format('YYYY-MM-DD');
    this.piEndDate = moment(new Date((lastDay.getFullYear()) + '-' + (lastDay.getMonth() + 1) + '-' + lastDay.getDate())).format('YYYY-MM-DD');
    this.piDateRange = { beginDate: { year: firstDay.getFullYear(), month: firstDay.getMonth() + 1, day: firstDay.getDate() }, endDate: { year: lastDay.getFullYear(), month: lastDay.getMonth() + 1, day: lastDay.getDate() } };


    this.tiStartDate = moment(new Date((firstDay.getFullYear()) + '-' + (firstDay.getMonth() + 1) + '-' + firstDay.getDate())).format('YYYY-MM-DD');
    this.tiEndDate = moment(new Date((lastDay.getFullYear()) + '-' + (lastDay.getMonth() + 1) + '-' + lastDay.getDate())).format('YYYY-MM-DD');
    this.tiDateRange = { beginDate: { year: firstDay.getFullYear(), month: firstDay.getMonth() + 1, day: firstDay.getDate() }, endDate: { year: lastDay.getFullYear(), month: lastDay.getMonth() + 1, day: lastDay.getDate() } };
  }

  getEntity(oemid) {
    this.http.get(environment.apiUrl + 'consumer/getZoneByProject?prjid=' + this.prjId + '&oemid=' + oemid).subscribe(data => {
      var result = data.json();
      if (oemid == 8) {
        this.wardList = result
      } else if (oemid == 7) {
        this.zoneList = result
      }
    });
  }

  getEmploye() {
    this.http.get(environment.apiUrl + "admin/getEmploye" + "?prjId=" + this.prjId).subscribe(data => {
      this.employeList = data.json();
      console.log(this.employeList)
    });
  }
  clearFilter() {
    this.filterData = {}
    this.searchFilter();
  }
  searchFilter() {
    this.searching = true
    this.loaderService.display(true);
    var data = {
      zoneId: this.filterData.zoneId,
      wardId: this.filterData.wardId,
      piStartDate: this.piStartDate,
      piEndDate: this.piEndDate,
      tiStartDate: this.tiStartDate,
      tiEndDate: this.tiEndDate,
      clientManagerId: this.filterData.clientManagerId,
      consumerId: this.filterData.consumerId,
      pInvoiceNo: this.filterData.pInvoiceNo,
      consumerName: this.filterData.consumerName,
      address: this.filterData.address,
      invoiceType: this.invoiceType,
      statusIds: this.filterData.statusIds,
      prjId: this.prjId
    }

    this.http.post(environment.apiUrl + "invoice/getInvoiceByFilter", data).subscribe(data => {
      this.invoiceList = data.json();
      console.log(this.invoiceList)
      this.gridData = process(this.invoiceList, this.state);
      this.searching = false
      this.loaderService.display(false);
      this.allData = this.allData.bind(this);
      $("#filterModal").modal("hide")
    });

  }
  getInvoiceStatus() {
    this.http.get(environment.apiUrl + "invoice/getInvoiceStatus").subscribe(data => {
      this.statusList = data.json();
    });
  }


  piDateRangeChanged(dataRange) {
    if (dataRange.beginEpoc != 0) {
      var startDate = dataRange.beginDate.year + "-" + dataRange.beginDate.month + "-" + dataRange.beginDate.day
      var endDate = dataRange.endDate.year + "-" + dataRange.endDate.month + "-" + dataRange.endDate.day

      this.piStartDate = moment(startDate).format('YYYY-MM-DD');
      this.piEndDate = moment(endDate).format('YYYY-MM-DD');
    } else {
      this.piStartDate = null
      this.piEndDate = null
    }
  }

  tiDateRangeChanged(dataRange) {
    if (dataRange.beginEpoc != 0) {
      var startDate = dataRange.beginDate.year + "-" + dataRange.beginDate.month + "-" + dataRange.beginDate.day
      var endDate = dataRange.endDate.year + "-" + dataRange.endDate.month + "-" + dataRange.endDate.day

      this.tiStartDate = moment(startDate).format('YYYY-MM-DD');
      this.tiEndDate = moment(endDate).format('YYYY-MM-DD');

      console.log("PI date", this.tiStartDate, this.tiEndDate)
    } else {
      this.tiStartDate = null
      this.tiEndDate = null
    }
  }

  selectInvoiceType(data) {
    if (data == "Proforma Invoice") {
      this.invoiceType = 0
    } else if (data == "Invoice") {
      this.invoiceType = 1
    } else {
      this.invoiceType = 2
    }
  }

  ngOnInit() {
    this.searching = false
    this.invoiceType = 2
    this.invoiceTypeArray = ["Invoice", "Proforma Invoice"]
    this.prjId = this.auth.getAuthentication().projectId
    this.userId = this.auth.getAuthentication().id
    this.getEntity(7)
    this.getEntity(8)
    this.getEmploye()
    this.getInvoiceStatus()
    this.searchFilter()
    this.getfollowUpStatus();


  }

  getfollowUpStatus() {
    this.http.get(environment.apiUrl + "invoice/getfollowUpStatus").subscribe(data => {
      this.followupStatus = data.json();
    });
  }
  filterModal() {
    $('#filterModal').modal('show');
  }

  excelDownloadModal() {
    $('#excelDownload').modal('show');
  }


  excelDownload() {
     window.open(environment.apiUrl + "invoice/invoiceExcel?prjId=" + this.prjId + "&fromDate=" +this.piStartDate + "&toDate=" + this.piEndDate);
  //   this.http.get(environment.apiUrl + "invoice/invoiceExcel?prjId=" + this.prjId + "&fromDate=" + this.piStartDate + "&toDate=" + this.piEndDate).subscribe(data => {
  //     console.log(data.json())
  //     XlsxPopulate.fromDataAsync(data.json().data)
  //       .then(function (workbook) {
  //         workbook.outputAsync()
  //           .then(function (blob) {
  //             console.log("blob",blob)
  //             if (window.navigator && window.navigator.msSaveOrOpenBlob) {
  //               // If IE, you must uses a different method.
  //               window.navigator.msSaveOrOpenBlob(blob, "out.xlsx");
  //             } else {
  //               var url = window.URL.createObjectURL(blob);
  //               var a = document.createElement("a");
  //               document.body.appendChild(a);
  //               a.href = url;
  //               a.download = "out.xlsx";
  //               a.click();
  //               window.URL.revokeObjectURL(url);
  //               document.body.removeChild(a);
  //             }
  //           });
  //       });
  //   });
   }



}
