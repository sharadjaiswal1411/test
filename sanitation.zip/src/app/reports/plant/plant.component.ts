import { Component } from '@angular/core';
import {HttpClient } from '@angular/common/http'; 
import { AuthService } from '../../_services'; 

@Component({
  selector: 'plant-report',
  templateUrl: './plant.component.html',  
})

export class VehiclePlantComponent {
 
  constructor(private http: HttpClient,private auth : AuthService) { 
  }  
  ngOnInit() 
  { 
  
  }

}
 