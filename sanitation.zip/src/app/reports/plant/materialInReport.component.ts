import { Component, ViewEncapsulation} from '@angular/core'; 
import { ActivatedRoute, Router } from '@angular/router';
import { Http} from '@angular/http' 
import { environment } from '../../../environments/environment';  
import { AuthService } from '../../_services';
import { LoaderService } from '../../_services/loader.service'; 
import { process, State,aggregateBy} from '@progress/kendo-data-query'; 
import { GroupDescriptor, DataResult } from '@progress/kendo-data-query';
import { Observable } from 'rxjs/Observable';
import { SelectableSettings,DataStateChangeEvent,GridDataResult} from '@progress/kendo-angular-grid'; 
import { ExcelExportData } from '@progress/kendo-angular-excel-export';
import * as _moment from 'moment';  
import * as _rollupMoment from 'moment'; 
const moment = _rollupMoment || _moment;  
 
export const MY_FORMATS = {
  parse: {
    dateInput: 'LL',
  },
  display: {
    dateInput: 'LL',
    monthYearLabel: 'MMM YYYY',
    dateA11yLabel: 'LL',
    monthYearA11yLabel: 'MMMM YYYY',
  },
}; 

declare var $: any; 
const distinctZone = data => data.filter((x, idx, xs) => xs.findIndex(y => y.Zone === x.Zone) === idx);
const distinctSuplr = data => data.filter((x, idx, xs) => xs.findIndex(y => y.Supplier === x.Supplier) === idx); 
const distinctVeh = data => data.filter((x, idx, xs) => xs.findIndex(y => y.VehicleNo === x.VehicleNo) === idx); 

@Component({

  selector: 'plantReport-In',
  templateUrl: './materialInReport.component.html', 
  encapsulation: ViewEncapsulation.None,
  styleUrls: ['./plantReport.component.css']
  
})
//PlantReportComponent
export class MaterialInReportComponent { 
    prjId:any; 
    prjName:any;
    showLoader:boolean; 
    startDate:any;
    endDate:any;
    defStartDt:any;
    defEndDt:any;
    dateRange:any;
    plantReportList:any;
    totalCount:any;
    imageUrl:any;
    entityName:any;
    entityType:any;
    qrCd:any;
    serviceDate:any;
    totalInWaight:any;
    totalOutWaight:any;
    totalNetWaight:any; 
    header:any;
    swmReport:any;
    inWaitInTonne:any;
    outWaitInTonne:any;
    netInTonne:any;
    hideUlbColumn=false;
    swmHeadingHide=false;
    GFcolumnHide=false;
    GlLKcolumnHide=false;
    SuppliercolLKO=false;
    public aggregates: any[] = [{field: 'InWeight', aggregate: 'sum'},{field: 'OutWeight', aggregate: 'sum'},{field: 'NetWeight', aggregate: 'sum'}];
    public state: State = { 
      skip: 0,
      take: 13, 
      filter: {
      logic: 'and',
      filters: []
    }
  };
  public pageSize :any
  public checkboxOnly = false;
  public mode = 'multiple';
  public selectableSettings: SelectableSettings;

  public distinctZone: any[]
  public distinctSuplr: any[]
  public distinctVeh: any[]
 
  public groups: GroupDescriptor[] = [];
  public view: Observable<GridDataResult>; 
  public hiddenColumns: string[] = [];
  public isHidden(columnName: string): boolean {
    return this.hiddenColumns.indexOf(columnName) > -1;
  } 
  
  public gridDataPlantReport: DataResult;
  public groupChange(groups: GroupDescriptor[]): void {
    this.groups = groups;
    this.loadProducts();
  } 
  public allData(): ExcelExportData {
    const result: ExcelExportData =  {
        data: this.plantReportList
    };
    return result;
   } 
 
  private loadProducts(): void {
    this.gridDataPlantReport = process(this.plantReportList, { group: this.groups });  
  }
  constructor(private http: Http,private auth : AuthService,public routes: ActivatedRoute, public router: Router,private loaderService: LoaderService) {
    this.loaderService.status.subscribe((val: boolean) =>{
        this.showLoader = val;
      });
    this.allData = this.allData.bind(this);
    var date = new Date(); 
    //var firstDay = new Date(date.getFullYear(), date.getMonth(), 1); 
    this.defStartDt = (date.getFullYear()) + '-' + (date.getMonth() + 1) + '-' + date.getDate(); 
    this.defEndDt = (date.getFullYear()) + '-' + (date.getMonth()+1) + '-' + date.getDate(); 
    this.dateRange= {beginDate: {year: date.getFullYear(), month: date.getMonth()+1, day: date.getDate()}, 
                     endDate: {year: date.getFullYear(), month: date.getMonth()+1, day: date.getDate()}};
   }  
  

   /*
    * get Mobility Service Report
   */ 
   getVehiclesDetail(){   
         this.loaderService.display(true); 
         var materialType="IN" 
                this.http.get(environment.apiUrl + 'reports/getplantReport?city='+this.prjName+'&fromDt='+this.startDate+'&toDt='+this.endDate+'&mtdType='+materialType).subscribe(data =>{ 
                this.plantReportList=data.json();
                if(this.plantReportList.length>0){
                    this.totalCount= this.plantReportList.length 
                    this.distinctZone = distinctZone(this.plantReportList) 
                    this.distinctSuplr = distinctSuplr(this.plantReportList) 
                    this.distinctVeh = distinctVeh(this.plantReportList)   
                    this.totalInWaight = aggregateBy(this.plantReportList, this.aggregates)["InWeight"].sum;  
                    this.inWaitInTonne=Number(this.totalInWaight)/1000 
                    this.totalOutWaight = aggregateBy(this.plantReportList, this.aggregates)["OutWeight"].sum; 
                    this.outWaitInTonne=Number(this.totalOutWaight)/1000  
                    this.totalNetWaight = aggregateBy(this.plantReportList, this.aggregates)["NetWeight"].sum;  
                    this.netInTonne=Number(this.totalNetWaight)/1000  
                    this.gridDataPlantReport = process(this.plantReportList, this.state);   
                    this.loaderService.display(false);  
                }
                else if(this.plantReportList.length==0){ 
                    this.gridDataPlantReport = process(this.plantReportList, this.state); 
                    this.totalCount=0
                    this.totalInWaight = null
                    this.totalOutWaight = null
                    this.totalNetWaight = null
                    this.inWaitInTonne=0
                    this.outWaitInTonne=0
                    this.netInTonne=0
                    this.loaderService.display(false);  
                } 
            });  
   } 


/*
 * filter The Date
*/
  public dataStateChange(state: DataStateChangeEvent): void {
  this.state = state;
  this.gridDataPlantReport = process(this.plantReportList, this.state);  
  if (state && state.group) {  
      state.group.map(group => group.aggregates = this.aggregates);
      //this.totalCount= this.gridDataPlantReport.data.length       
      this.totalInWaight = aggregateBy(this.gridDataPlantReport.data, this.aggregates)["InWeight"].sum;  
      //this.inWaitInTonne=Number(this.totalInWaight)/1000 
      this.totalOutWaight = aggregateBy(this.gridDataPlantReport.data, this.aggregates)["OutWeight"].sum; 
      //this.outWaitInTonne=Number(this.totalOutWaight)/1000  
      this.totalNetWaight = aggregateBy(this.gridDataPlantReport.data, this.aggregates)["NetWeight"].sum; 
      //this.netInTonne=Number(this.totalNetWaight)/1000  
      this.gridDataPlantReport = process(this.plantReportList, this.state); 
    } 
} 

/*
*select start Date Nad To date
*/
 onDateRangeChanged(dataRange)
 {  
   if(dataRange.beginDate.day>0){ 
     this.startDate= dataRange.beginDate.year + "-"  + dataRange.beginDate.month+ "-" + dataRange.beginDate.day 
     this.endDate = dataRange.endDate.year + "-"  + dataRange.endDate.month  + "-" + dataRange.endDate.day 
     this.getVehiclesDetail(); 
   }
   else if(dataRange.beginDate.day==0){
     this.startDate= this.defStartDt
     this.endDate = this.defEndDt
     this.getVehiclesDetail(); 
   }  
 } 
  

 /*
  *Select Export PDF header 
 */
 selectPdfHeader(){
   if(this.prjId==1){
     this.header="Ecogreen Energy Lucknow Pvt. Ltd."
     this.swmReport="Lucknow" 
   }
  else if(this.prjId==2 ||this.prjId==3){
    this.header="Ecogreen Energy Gurgaon Faridabad Pvt. Ltd."
    this.swmReport="Faridabad"
  }
  else{
    this.header="Ecogreen Energy Gwalior Pvt. Ltd."
    this.swmReport="ISWM, WTE Project, Sivpuri Link Road,Gwalior."
  }
 } 
 
    ngOnInit() {  
        this.startDate = moment(this.defStartDt).format('YYYY-MM-DD');
        this.endDate= moment(this.defEndDt).format('YYYY-MM-DD');
        this.prjId = this.auth.getAuthentication().projectId
        if(this.prjId==1){
          this.prjName="LUCKNOW";
          this.swmHeadingHide=true;
          this.SuppliercolLKO=false;  
          this.GlLKcolumnHide=true;        
        }
        else if(this.prjId==2){
          this.prjName="GURUGRAM";
          this.swmHeadingHide=true;
          this.GFcolumnHide=true
        }
        else if(this.prjId==3){
          this.prjName="FARIDABAD"; 
          this.swmHeadingHide=true;
          this.GFcolumnHide=true
        }
        else if(this.prjId==4){
          this.prjName="GWALIOR";
          this.hideUlbColumn=true
          this.GlLKcolumnHide=true;
        } 
        this.getVehiclesDetail();
        this.selectPdfHeader();
    }










   }
  
  
  


   


 
 

 



 
