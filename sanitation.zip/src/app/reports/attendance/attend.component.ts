import { Component } from '@angular/core'; 

@Component({
  selector: 'attend-report',
  templateUrl: './attend.component.html',  
}) 
  export class AttendComponent { 
  ngOnInit(){ 
  
  } 
}
 