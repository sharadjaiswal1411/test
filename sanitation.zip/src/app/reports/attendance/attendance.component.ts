import { Component,ViewEncapsulation} from '@angular/core'; 
import { ActivatedRoute, Router } from '@angular/router';
import { Http} from '@angular/http' 
import { environment } from '../../../environments/environment';  
import { AuthService } from '../../_services';
import { LoaderService } from '../../_services/loader.service'; 
import { process, State,aggregateBy} from '@progress/kendo-data-query'; 
import { GroupDescriptor, DataResult } from '@progress/kendo-data-query';
import { Observable } from 'rxjs/Observable';
import { SelectableSettings,DataStateChangeEvent,GridDataResult} from '@progress/kendo-angular-grid';
import { RowClassArgs } from '@progress/kendo-angular-grid'; 
import * as _moment from 'moment';  
import * as _rollupMoment from 'moment'; 
const moment = _rollupMoment || _moment;   

declare var $: any; 
const distinctStatus = data => data.filter((x, idx, xs) => xs.findIndex(y => y.Status === x.Status) === idx); 
  
@Component({ 
  selector: 'Attendance',
  templateUrl: './attendance.component.html', 
  encapsulation: ViewEncapsulation.None,
  styles: ['.green .codeColumn {color: green; font-weight:bold} .red .codeColumn {color: red; font-weight: bold}'],
})
export class AttendanceReportComponent { 
    prjId:any;  
    showLoader:boolean;  
    startDate:any;
    endDate:any;
    defStartDt:any;
    defEndDt:any;
    dateRange:any; 
    attendanceReportList:any
    serialNo:any;
    currentDateModal:any;
    totalUsers:any;
    activeUsers:any;
    public aggregates: any[] = [{field: 'totalUsers', aggregate: 'sum'},{field: 'active', aggregate: 'sum'}];
    public state: State = {  
    filter: {
      logic: 'and',
      filters: []
    }
  };
  public pageSize :any
  public checkboxOnly = false;
  public mode = 'multiple';
  public attendanceDetail:any;
  public selectableSettings: SelectableSettings; 
  public groups: GroupDescriptor[] = [];
  public view: Observable<GridDataResult>;  
  public gridDataAttendanceList: DataResult;
  public gridDataAttendanceDetailList:DataResult;
  public groupChange(groups: GroupDescriptor[]): void {
    this.groups = groups;
    this.loadProducts();
  } 
  public distinctStatus: any[]
  private loadProducts(): void {
    this.gridDataAttendanceList = process(this.attendanceReportList, { group: this.groups });  
    this.gridDataAttendanceDetailList = process(this.attendanceDetail, { group: this.groups });  
  }
  constructor(private http: Http,private auth : AuthService,public routes: ActivatedRoute, public router: Router,private loaderService: LoaderService) {
    this.loaderService.status.subscribe((val: boolean) =>{
        this.showLoader = val; 
      });
    var date = new Date();   
    this.currentDateModal=date;
    this.defStartDt = (date.getFullYear()) + '-' + (date.getMonth() + 1) + '-' + date.getDate(); 
    this.defEndDt = (date.getFullYear()) + '-' + (date.getMonth()+1) + '-' + date.getDate(); 
    this.dateRange= {beginDate: {year: date.getFullYear(), month: date.getMonth()+1, day: date.getDate()},endDate: {year: date.getFullYear(), month: date.getMonth()+1, day: date.getDate()}}; 
  }  
  

    /*
    * GET ATTENDANCE REPORT
    */ 
   getAttendanceList(currDate){   
         this.loaderService.display(true);  
                this.http.get(environment.apiUrl + 'attendance/getAttendanceReport?prjid='+this.prjId+'&date='+currDate).subscribe(data =>{ 
                this.attendanceReportList=data.json(); 
                if(this.attendanceReportList.length>0){ 
                    this.distinctStatus=distinctStatus(this.attendanceReportList);
                    this.totalUsers = aggregateBy(this.attendanceReportList, this.aggregates)["totalUsers"].sum;  
                    this.activeUsers = aggregateBy(this.attendanceReportList, this.aggregates)["active"].sum; 
                    this.gridDataAttendanceList = process(this.attendanceReportList, this.state);
                    this.loaderService.display(false); 
                }else{
                    this.totalUsers=0; 
                    this.activeUsers=0;
                    this.loaderService.display(false);
                    this.attendanceReportList=[];
                    this.gridDataAttendanceList = process(this.attendanceReportList, this.state);
                } 
            });  
   } 

    /*
     * Select Date Change Event
    */
    orgValueChange(date){ 
      this.getAttendanceList(date)
    }


/*
 * filter The Grid Data
*/
public dataStateChange(state: DataStateChangeEvent): void {
  this.state = state;
  this.gridDataAttendanceList = process(this.attendanceReportList, this.state);  
  if (state && state.group) { 
      this.distinctStatus=distinctStatus(this.attendanceReportList);
      this.totalUsers = aggregateBy(this.gridDataAttendanceList.data, this.aggregates)["totalUsers"].sum;  
      this.activeUsers = aggregateBy(this.gridDataAttendanceList.data, this.aggregates)["active"].sum; 
      this.gridDataAttendanceList = process(this.attendanceReportList, this.state); 
    } 
} 

 
  
  /*
  * Column STATUS COLOR CHANGE
  */
   public rowCallback = (context: RowClassArgs) => { 
    switch (context.dataItem.Status) {
      case 'Online': 
        return {green : true}; 
      case 'Offline': 
        return {red : true}; 
      default:
        return {}; 
     } 
   }

   /*
   *  Employee Details modal popup windows
  */
   employeeDetails(data){  
    this.serialNo=data.SERIALNUMBER 
    this.attendanceDetail=[];
    this.gridDataAttendanceDetailList = process(this.attendanceDetail, this.state); 
    this.getAttendanceDetails(this.startDate,this.endDate,this.serialNo) 
    $('#allendanceDetailModal').modal('show'); 
   }

   /*
   * GET ATTENDANCE DETAILS 
   */
   getAttendanceDetails(startDate,endDate,srNo){   
    this.http.get(environment.apiUrl + 'attendance/getAttendanceDetails?serialNo='+srNo+'&startDate='+startDate+'&endDate='+endDate).subscribe(data =>{ 
      this.attendanceDetail=data.json();
      if(this.attendanceDetail.length>0){  
          this.gridDataAttendanceDetailList = process(this.attendanceDetail, this.state);  
      }else{ 
        this.attendanceDetail=[];
        this.gridDataAttendanceDetailList = process(this.attendanceDetail, this.state);  
      } 
    });  
   }


/*
 * filter The Grid Data
*/
public dataStateChangeAttendance(state: DataStateChangeEvent): void {
  this.state = state;
  this.gridDataAttendanceDetailList = process(this.attendanceDetail, this.state);  
  if (state && state.group) {  
      this.gridDataAttendanceDetailList = process(this.attendanceDetail, this.state); 
    } 
} 


/*
* select start Date Nad To date
*/
onDateRangeChanged(dataRange)
{  
  if(dataRange.beginDate.day>0){ 
    this.startDate= dataRange.beginDate.year + "-"  + dataRange.beginDate.month+ "-" + dataRange.beginDate.day 
    this.endDate = dataRange.endDate.year + "-"  + dataRange.endDate.month  + "-" + dataRange.endDate.day 
    this.getAttendanceDetails(this.startDate,this.endDate,this.serialNo) 
  }
  else if(dataRange.beginDate.day==0){
    this.startDate= this.defStartDt
    this.endDate = this.defEndDt
    this.getAttendanceDetails(this.startDate,this.endDate,this.serialNo) 
  }  
} 
    ngOnInit() {  
        this.startDate = moment(new Date()).format('YYYY-MM-DD');
        this.endDate= moment(new Date()).format('YYYY-MM-DD');
        this.prjId = this.auth.getAuthentication().projectId  
        this.getAttendanceList(this.startDate);
    } 
}
  
  
  


   


 
 

 



 
