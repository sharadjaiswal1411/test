import { Component } from '@angular/core';
import { Http } from '@angular/http'
import { environment } from '../../../environments/environment'; 
import { AuthService } from '../../_services';
import { ActivatedRoute, Router } from '@angular/router';
import { LoaderService } from '../../_services/loader.service';
import Swal from 'sweetalert2'

import {DateAdapter, MAT_DATE_FORMATS, MAT_DATE_LOCALE} from '@angular/material/core';//added by kuldeep on 10-03-2018
import {MomentDateAdapter} from '@angular/material-moment-adapter';//added by kuldeep on 10-03-2018
import * as _moment from 'moment'; //added by kuldeep on 10-03-2018
import * as _rollupMoment from 'moment';//added by kuldeep on 10-03-2018
const moment = _rollupMoment || _moment;
import { utils, write, WorkBook } from 'xlsx';
import { saveAs } from 'file-saver';

export const MY_FORMATS = {
  parse: {
    dateInput: 'LL',
  },
  display: {
    dateInput: 'LL',
    monthYearLabel: 'MMM YYYY',
    dateA11yLabel: 'LL',
    monthYearA11yLabel: 'MMMM YYYY',
  },
};

declare var $: any;  
const distinctVehCat = data => data.filter((x, idx, xs) => xs.findIndex(y => y.VehCatName === x.VehCatName) === idx);
const distinctVehType = data => data.filter((x, idx, xs) => xs.findIndex(y => y.VehTypName === x.VehTypName) === idx);
@Component({ 
  templateUrl: './primaryUnservedArea.component.html', 
}) 

export class PrimaryUnservedAreaReport {
  public pieData: any = [
    { category: 'Running', value: 0.42 },
    { category: 'Breakdown', value: 0.58 },
    { category: 'Standby', value: 0.58 }
  ]

  prjId:any;
  userId:any;
  wardList:any;
  zoneList:any;
  beatList:any
  filterData:any = {};
  fromDate:any;
  searching:any;
  isSelectedLevel:any;


  constructor(private http: Http,private auth : AuthService,public routes: ActivatedRoute, public router: Router,private loaderService: LoaderService) {
    this.fromDate  = new Date();
    this.isSelectedLevel = 'zone'
  }  
  
  s2ab(s) 
  {
    const buf = new ArrayBuffer(s.length);
    const view = new Uint8Array(buf);
    for (let i = 0; i !== s.length; ++i) {
      view[i] = s.charCodeAt(i) & 0xFF;
    };
    return buf;
  }
  importToExcel(data)
  {
    const ws_name = 'SomeSheet';
    const wb: WorkBook = { SheetNames: [], Sheets: {} };
    const ws: any = utils.json_to_sheet(data);
    wb.SheetNames.push(ws_name);
    wb.Sheets[ws_name] = ws;
    const wbout = write(wb, { bookType: 'xlsx', bookSST: true, type: 
  'binary' });
  saveAs(new Blob([this.s2ab(wbout)], { type: 'application/octet-stream' }), 'exported.xlsx');
  }

  getReport(){
    
    var date = moment(this.fromDate).format('YYYY-MM-DD')
    if(!this.filterData.zoneId){
      this.filterData.zoneId = null
    }
    if(!this.filterData.wardId){
      this.filterData.wardId = null
    }
    var data = {
      prjId:this.prjId,
      zoneId:this.filterData.zoneId,
      wardId:this.filterData.wardId,
      beatId:null,
      level :this.isSelectedLevel,
      vehicleNo:this.filterData.vehicleNo,
      date:date,
      reportType:"Unserved"
    }
    this.searching = true
    this.http.post(environment.apiUrl + 'reports/primaryVehicleMovement',data).subscribe(data => {
      var result  = data.json() 
       if(result.length>0){
         this.importToExcel(result)
         this.searching = false
          return;
        }else{
          this.searching = false
          Swal({
            type: 'error',
            title: 'Oops...',
            text: 'An Error Occurred Please Try Again',
          })
        }
     },
     error=>{ 
       this.loaderService.display(false);
       Swal({
        type: 'error',
        title: 'Oops...',
        text: 'An Error Occurred Please Try Again',
      })
      this.searching = false
    }); 
  }
  selectLevel(level){

    this.isSelectedLevel = level

  }
  
  getEntity(oemid){
    this.http.get(environment.apiUrl + 'consumer/getZoneByProject?prjid='+this.prjId+'&oemid=' + oemid).subscribe(data =>{ 
      var result = data.json(); 
      if(oemid == 8){
          this.wardList = result
      }else if(oemid == 7){
        this.zoneList = result
      }else if(oemid == 9){
        this.beatList = result
      }
     }); 
   } 

  ngOnInit(){ 
    this.prjId = this.auth.getAuthentication().projectId  
    this.userId = this.auth.getAuthentication().id 
    this.filterData.vehicleNo = null
   
    //this.getReport(this.prjId)
    this.getEntity(7)
    this.getEntity(8)
    //this.getEntity(9)
  } 
}
