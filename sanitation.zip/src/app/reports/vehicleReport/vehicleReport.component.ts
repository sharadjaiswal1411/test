import { Component} from '@angular/core';


import { HttpClient } from '@angular/common/http';
import { AuthService } from '../../_services';

@Component({
  selector: 'vehicle-report',
  templateUrl: './vehicleReport.component.html', 
})

export class VehicleReport {
  constructor(private http: HttpClient,private auth : AuthService) { 
  }  
  ngOnInit() 
  { 
  
  }

}
 