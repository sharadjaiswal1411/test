import { Component } from '@angular/core';
import { Http } from '@angular/http'
import { environment } from '../../../environments/environment';
import { AuthService } from '../../_services';
import { ActivatedRoute, Router } from '@angular/router';
import { LoaderService } from '../../_services/loader.service';
import { Observable } from 'rxjs/Observable';
import { process, State, aggregateBy } from '@progress/kendo-data-query';
import { GroupDescriptor, DataResult } from '@progress/kendo-data-query';
import { GridDataResult, DataStateChangeEvent } from '@progress/kendo-angular-grid';
import { ExcelExportData } from '@progress/kendo-angular-excel-export';
import * as _moment from 'moment';
import * as _rollupMoment from 'moment';
const moment = _rollupMoment || _moment;
import Swal from 'sweetalert2'

declare var $: any;
const distinctVehCat = data => data.filter((x, idx, xs) => xs.findIndex(y => y.VehCatName === x.VehCatName) === idx);
const distinctVehType = data => data.filter((x, idx, xs) => xs.findIndex(y => y.VehTypName === x.VehTypName) === idx);
@Component({
  templateUrl: './distanceReport.component.html',
})

export class DistanceComponent {
  public prjId: any
  public userId: any
  public startDate: any
  public endDate: any
  public defaultStartDate: any
  public defaultEndDate: any
  public dataRangeModal: any
  public showLoader: boolean
  public vehHistoryList: any
  public groups: GroupDescriptor[] = []
  public view: Observable<GridDataResult>
  public gridView: DataResult
  public gridDataDistanceReport: GridDataResult
  public primaryCount: any;
  public prmRunCount: any;
  public prmyDistCount: any;
  public prmyStopCount: any;
  public secondaryCount: any;
  public secondaryRunCount: any;
  public secondDistCount: any;
  public secondStopCount: any;
  public totalDistance: any;
  public totalStop: any;
  public primaryTotalDist: any;
  public secondTotalDist: any;
  public totalVehicle: any;
  public totalRunning: any;
  public totalStopVeh: any;
  public aggregates: any[] = [{ field: 'DISTANCE', aggregate: 'sum' }, { field: 'STOPSCOUNT', aggregate: 'sum' }];
  public state: State = {
    skip: 0,
    take: 100,
    filter: {
      logic: 'and',
      filters: []
    }
  };
  //This function for fetch all data into excel file
  public allData(): ExcelExportData {
    const result: ExcelExportData = {
      data: this.vehHistoryList
    };
    return result;
  }

  public distinctVehCat: any[]
  public distinctVehType: any[]
  constructor(private http: Http, private auth: AuthService, public routes: ActivatedRoute, public router: Router, private loaderService: LoaderService) {
    this.loaderService.status.subscribe((val: boolean) => {
      this.showLoader = val;
    });
    this.primaryCount = 0
    this.prmRunCount = 0;
    this.prmyDistCount = 0;
    this.prmyStopCount = 0;
    this.secondDistCount = 0;
    this.secondStopCount = 0;
    this.primaryTotalDist = 0;
    this.secondTotalDist = 0;
    this.allData = this.allData.bind(this);
    var date = new Date();
    this.defaultStartDate = (date.getFullYear()) + '-' + (date.getMonth() + 1) + '-' + date.getDate();
    this.defaultEndDate = (date.getFullYear()) + '-' + (date.getMonth() + 1) + '-' + date.getDate();
    this.dataRangeModal = { beginDate: { year: date.getFullYear(), month: date.getMonth() + 1, day: date.getDate() }, endDate: { year: date.getFullYear(), month: date.getMonth() + 1, day: date.getDate() } };
  }

  /*
   * Get VEHICLE HISTORY DEATILS 
  */
  getVehDistanceDataList() {
    this.loaderService.display(true);
    this.http.get(environment.apiUrl + 'reports/getVehHistoryReport?prjId=' + this.prjId + "&startDate=" + this.startDate + "&endDate=" + this.endDate).subscribe(data => {
      this.vehHistoryList = data.json()
      if (this.vehHistoryList.length > 0) {
        this.totalVehicle = this.vehHistoryList.length;
        this.assignvalue();
        for (var i = 0; i < this.vehHistoryList.length; i++) {
          if (this.vehHistoryList[i].VehCatName == "Primary") {
            this.primaryCount = this.primaryCount + 1
            if (this.vehHistoryList[i].DISTANCE > 0) {
              this.prmRunCount = this.prmRunCount + 1
              this.prmyDistCount = this.prmyDistCount + Number(this.vehHistoryList[i].DISTANCE)
              this.primaryTotalDist = this.prmyDistCount.toFixed(2)
              this.prmyStopCount = this.prmyStopCount + Number(this.vehHistoryList[i].STOPSCOUNT)
            }
          } else {
            this.secondaryCount = this.secondaryCount + 1
            if (this.vehHistoryList[i].DISTANCE > 0) {
              this.secondaryRunCount = this.secondaryRunCount + 1
              this.secondDistCount = this.secondDistCount + Number(this.vehHistoryList[i].DISTANCE)
              this.secondTotalDist = this.secondDistCount.toFixed(2)
              this.secondStopCount = this.secondStopCount + Number(this.vehHistoryList[i].STOPSCOUNT)
            }
          }
          this.totalRunning = this.prmRunCount + this.secondaryRunCount
          this.totalStopVeh = this.totalVehicle - this.totalRunning
        }
        var distance = aggregateBy(this.vehHistoryList, this.aggregates)["DISTANCE"].sum;
        this.totalDistance = distance.toFixed(2);
        this.totalStop = aggregateBy(this.vehHistoryList, this.aggregates)["STOPSCOUNT"].sum;
        this.distinctVehCat = distinctVehCat(this.vehHistoryList)
        this.distinctVehType = distinctVehType(this.vehHistoryList)
        this.gridDataDistanceReport = process(this.vehHistoryList, this.state);
        this.loaderService.display(false);
      } else {
        this.gridDataDistanceReport = null;
        this.loaderService.display(false);
      }
    },
      error => {
        this.loaderService.display(false);
        Swal({
          type: 'error',
          title: 'Oops...',
          text: 'An Error Occurred Please Try Again',
        })
      });
  }

  assignvalue() {
    this.primaryCount = 0;
    this.prmRunCount = 0;
    this.prmyDistCount = 0
    this.prmyStopCount = 0;
    this.secondaryCount = 0;
    this.secondaryRunCount = 0;
    this.secondDistCount = 0;
    this.secondStopCount = 0;
    this.primaryTotalDist = 0;
    this.secondTotalDist = 0
  }

  /*
   * Grid Filter
  */
  public dataStateChange(state: DataStateChangeEvent): void {
    this.assignvalue()
    this.state = state;
    this.gridDataDistanceReport = process(this.vehHistoryList, this.state);
    if (state && state.group) {
      for (var i = 0; i < this.gridDataDistanceReport.data.length; i++) {
        if (this.gridDataDistanceReport.data[i].VehCatName == "Primary") {
          this.primaryCount = this.primaryCount + 1
          if (this.gridDataDistanceReport.data[i].DISTANCE > 0) {
            this.prmRunCount = this.prmRunCount + 1
            this.prmyDistCount = this.prmyDistCount + Number(this.gridDataDistanceReport.data[i].DISTANCE)
            this.primaryTotalDist = this.prmyDistCount.toFixed(2)
            this.prmyStopCount = this.prmyStopCount + Number(this.gridDataDistanceReport.data[i].STOPSCOUNT)
          }
        } else {
          this.secondaryCount = this.secondaryCount + 1
          if (this.gridDataDistanceReport.data[i].DISTANCE > 0) {
            this.secondaryRunCount = this.secondaryRunCount + 1
            this.secondDistCount = this.secondDistCount + Number(this.gridDataDistanceReport.data[i].DISTANCE)
            this.secondTotalDist = this.secondDistCount.toFixed(2)
            this.secondStopCount = this.secondStopCount + Number(this.gridDataDistanceReport.data[i].STOPSCOUNT)
          }
        }
      }

      this.distinctVehCat = distinctVehCat(this.vehHistoryList)
      this.distinctVehType = distinctVehType(this.vehHistoryList)
      var dist = Number(aggregateBy(this.gridDataDistanceReport.data, this.aggregates)["DISTANCE"].sum);
      this.totalDistance = dist.toFixed(2);
      this.totalStop = aggregateBy(this.gridDataDistanceReport.data, this.aggregates)["STOPSCOUNT"].sum;
      this.gridDataDistanceReport = process(this.vehHistoryList, this.state);
    }
  }


  /*
   *select start Date Nad To date
  */
  onDateRangeChanged(dataRange) {
    if (dataRange.beginDate.day > 0) {
      this.startDate = dataRange.beginDate.year + "-" + dataRange.beginDate.month + "-" + dataRange.beginDate.day
      this.endDate = dataRange.endDate.year + "-" + dataRange.endDate.month + "-" + dataRange.endDate.day
      this.getVehDistanceDataList();
    }
    else if (dataRange.beginDate.day == 0) {
      this.startDate = this.defaultStartDate
      this.endDate = this.defaultEndDate
      this.getVehDistanceDataList();
    }
  }

  /*
   * Refresh Distance Report
  */
  refreshDistanceReport() {
    this.getVehDistanceDataList();
  }

  ngOnInit() {
    this.prjId = this.auth.getAuthentication().projectId
    this.userId = this.auth.getAuthentication().id
    this.startDate = moment(this.defaultStartDate).format('YYYY-MM-DD');
    this.endDate = moment(this.defaultEndDate).format('YYYY-MM-DD');
    this.getVehDistanceDataList();
  }
}
