import { Component} from '@angular/core';


import { HttpClient } from '@angular/common/http';
import { AuthService } from '../../_services';

@Component({
  selector: 'vts-reports',
  templateUrl: './vtsReport.component.html', 
})

export class VtsReportsComponent {
  constructor(private http: HttpClient,private auth : AuthService) { 
  }  
  ngOnInit() 
  { 
  
  }

}
 