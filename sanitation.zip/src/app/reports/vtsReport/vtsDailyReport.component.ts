import { Component } from '@angular/core';
import { Http } from '@angular/http'
import { environment } from '../../../environments/environment';
import { AuthService } from '../../_services';
import { ActivatedRoute, Router } from '@angular/router';
import { LoaderService } from '../../_services/loader.service'; 
import * as _moment from 'moment';
import * as _rollupMoment from 'moment';
const moment = _rollupMoment || _moment;
import Swal from 'sweetalert2'
import { utils, write, WorkBook } from 'xlsx';  
import { saveAs } from 'file-saver'; 

declare var $: any;
 
@Component({
  templateUrl: './vtsDailyReport.component.html',
})

export class VtsDailyReportComponent {
  public prjId: any
  public userId: any
  public startDate: any
  public endDate: any
  public defaultStartDate: any
  public defaultEndDate: any
  public dataRangeModal: any
  public showLoader: boolean
  public vehVtsDailyList: any  
  public vtsDataNotFound=false  
  public search:any;
  public selectedRow : Number;
  constructor(private http: Http, private auth: AuthService, public routes: ActivatedRoute, public router: Router, private loaderService: LoaderService) {
    this.loaderService.status.subscribe((val: boolean) => {
      this.showLoader = val;
    }); 
    var date = new Date();
    this.defaultStartDate = (date.getFullYear()) + '-' + (date.getMonth() + 1) + '-' + date.getDate();
    this.defaultEndDate = (date.getFullYear()) + '-' + (date.getMonth() + 1) + '-' + date.getDate();
    this.dataRangeModal = { beginDate: { year: date.getFullYear(), month: date.getMonth() + 1, day: date.getDate() }, endDate: { year: date.getFullYear(), month: date.getMonth() + 1, day: date.getDate() } };
   }

    /*
    * Get VEHICLE HISTORY DEATILS 
    */
    getVtsDailyReport() {
        this.loaderService.display(true);
        this.http.get(environment.apiUrl + 'reports/getVtsDailyReport?prjId=' + this.prjId + "&startDate=" + this.startDate + "&endDate=" + this.endDate).subscribe(data => {
        this.vehVtsDailyList = data.json()
        if (this.vehVtsDailyList.length > 0) {  
            this.loaderService.display(false);
            this.vtsDataNotFound=false
        } else { 
            this.loaderService.display(false);
            this.vtsDataNotFound=true
        }},
        error => {
            this.loaderService.display(false);
            Swal({
            type: 'error',
            title: 'Oops...',
            text: 'An Error Occurred Please Try Again',
            })
        });
    }


    /*
    *select start Date Nad To date
    */
    onDateRangeChanged(dataRange) {
        if (dataRange.beginDate.day > 0) {
        this.startDate = dataRange.beginDate.year + "-" + dataRange.beginDate.month + "-" + dataRange.beginDate.day
        this.endDate = dataRange.endDate.year + "-" + dataRange.endDate.month + "-" + dataRange.endDate.day
        this.getVtsDailyReport();
        }
        else if (dataRange.beginDate.day == 0) {
        this.startDate = this.defaultStartDate
        this.endDate = this.defaultEndDate
        this.getVtsDailyReport();
        }
    }


        
    /*
    * This Method Is use to Download the Vehicles Report into Excel File 
    */
    importVtsDailyReport(vehVtsDailyList){
    const ws_name = 'VtsReport';
    const wb: WorkBook = { SheetNames: [], Sheets: {} };
    const ws: any = utils.json_to_sheet(vehVtsDailyList);
    wb.SheetNames.push(ws_name);
    wb.Sheets[ws_name] = ws;
    const wbout = write(wb, { bookType: 'xlsx', bookSST: true, type: 
    'binary' });
    saveAs(new Blob([this.s2ab(wbout)], { type: 'application/octet-stream' }), 'VtsReport.xlsx');
    }s2ab(s){
        const buf = new ArrayBuffer(s.length);
        const view = new Uint8Array(buf);
        for (let i = 0; i !== s.length; ++i) {
        view[i] = s.charCodeAt(i) & 0xFF;
        };
        return buf;
    } 


    /*
     * Get Index and Select Table Row
     */
    selectRowIndex(data,index){
      this.selectedRow=index;
    }




  ngOnInit() {
    this.prjId = this.auth.getAuthentication().projectId
    this.userId = this.auth.getAuthentication().id
    this.startDate = moment(this.defaultStartDate).format('YYYY-MM-DD');
    this.endDate = moment(this.defaultEndDate).format('YYYY-MM-DD');
    this.getVtsDailyReport();
  }
}
