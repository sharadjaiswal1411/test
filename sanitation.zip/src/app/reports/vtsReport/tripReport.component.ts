import { Component } from '@angular/core';
import { Http } from '@angular/http'
import { environment } from '../../../environments/environment'; 
import { AuthService } from '../../_services';
import { ActivatedRoute, Router } from '@angular/router';
import { LoaderService } from '../../_services/loader.service';
import { Observable } from 'rxjs/Observable';


import { process, State ,aggregateBy } from '@progress/kendo-data-query';
import { GroupDescriptor, DataResult } from '@progress/kendo-data-query';
import {GridDataResult,DataStateChangeEvent} from '@progress/kendo-angular-grid';

import * as _moment from 'moment';
import * as _rollupMoment from 'moment';
const moment = _rollupMoment || _moment;
declare var $: any; 



const distinctZone = data => data.filter((x, idx, xs) => xs.findIndex(y => y.Zone === x.Zone) === idx);
const distinctWard = data => data.filter((x, idx, xs) => xs.findIndex(y => y.Ward === x.Ward) === idx);
 
@Component({ 
  templateUrl: './tripReport.component.html', 
}) 
export class TripReportComponent {
 public prjId:any
 public userId:any
 public startDate:any;
 public endDate:any;
 public defaultStartDate:any;
 public defaultEndDate:any;
 public dataRangeModal:any; 
 public showLoader: boolean;  

 tripData:any;
 

 

  public groups: GroupDescriptor[] = []; 
  public view: Observable<GridDataResult>;
  public gridView: DataResult;
  public gridData: GridDataResult 
  public state: State = {
    skip: 0,
    take: 500, 
    // Initial filter descriptor
    filter: {
      logic: 'and',
      filters: []
    }
  };

  public distinctZone: any[]
  public distinctWard: any[]
  constructor(private http: Http,private auth : AuthService,public routes: ActivatedRoute, public router: Router,private loaderService: LoaderService) {
    this.loaderService.status.subscribe((val: boolean) =>{
        this.showLoader = val;
      });

    
    var date = new Date(); 
    var firstDay = new Date(date.getFullYear(), date.getMonth(), 1);
    this.defaultStartDate = (firstDay.getFullYear()) + '-' + (firstDay.getMonth() + 1) + '-' + firstDay.getDate(); 
    this.defaultEndDate = (date.getFullYear()) + '-' + (date.getMonth()+1) + '-' + date.getDate(); 
    this.dataRangeModal= {beginDate: {year: firstDay.getFullYear(), month: firstDay.getMonth()+1, day: firstDay.getDate()}, endDate: {year: date.getFullYear(), month: date.getMonth()+1, day: date.getDate()}};
  }  




    getTripData(prjid){
      this.http.get(environment.apiUrl + 'reports/vehicles/tripReport?prjId=' + this.prjId +"&startDate=" + this.startDate + "&endDate=" + this.endDate).subscribe(data => {
        this.tripData =data.json()
        this.gridData = process(this.tripData, this.state);
        this.distinctWard = distinctWard(this.tripData)
        this.distinctZone = distinctZone(this.tripData)
      })
    }


    public dataStateChange(state: DataStateChangeEvent): void {
      this.state = state;
      
      if (state && state.group) {  
          //state.group.map(group => group.aggregates = this.aggregates);
          this.gridData = process(this.tripData, this.state);   
        } 
    }








  ngOnInit() 
  { 
    this.prjId = this.auth.getAuthentication().projectId  
    this.userId = this.auth.getAuthentication().id 

    this.getTripData(2)
   
  }

}
