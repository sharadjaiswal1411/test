

import { Component ,NgZone,ViewEncapsulation} from '@angular/core';

import { Http } from '@angular/http'

import { environment } from '../../../environments/environment';
import { AuthService } from '../../_services';

import { LoaderService } from '../../_services/loader.service';

import { saveAs } from 'file-saver';
import { utils, write, WorkBook } from 'xlsx';  

import {IMyDrpOptions} from 'mydaterangepicker'; 
declare var require: any;
declare var google:any; 
var moment = require('moment');
//For KENDO UI
import { process, State } from '@progress/kendo-data-query';

import { GroupDescriptor, DataResult } from '@progress/kendo-data-query';

import {GridDataResult,DataStateChangeEvent} from '@progress/kendo-angular-grid';
import { Observable } from 'rxjs/Observable';

import { ExcelExportData } from '@progress/kendo-angular-excel-export';
 
 

declare var $: any;
const distinctZone= data => data.filter((x, idx, xs) => xs.findIndex(y => y.zone === x.zone) === idx); 
const distinctWard= data => data.filter((x, idx, xs) => xs.findIndex(y => y.ward === x.ward) === idx); 
const distinctCompSource= data => data.filter((x, idx, xs) => xs.findIndex(y => y.SOURCE === x.SOURCE) === idx); 
const distinctCompStatus= data => data.filter((x, idx, xs) => xs.findIndex(y => y.STATUS === x.STATUS) === idx); 

@Component({
    selector: 'complainReport-cmp',
    templateUrl: './complainReport.component.html', 
    encapsulation: ViewEncapsulation.None,
    styles: ['.green .codeColumn { color: green; font-weight: bold; background-color: #00800038; } .red .codeColumn { color: red; font-weight: bold; background-color: #ff00003b; }.feedback .codeColumn { color: #059; font-weight: bold; background-color:#BEF; }.other .codeColumn { color: #9F6000; font-weight: bold; background-color:#FEEFB3; }'], 
  })

  export class ComplainReportComponent{ 
    geocoder:any;
    prjId:any;
    userId:any;
    complainData:any
    showLoader:any

    monthTillTotal:any  
    monthTillResolved:any  
    monthTillPending:any  
    monthTillPendingLate:any  
    monthTillFeedBack:any  
    todaysTotal:any    
    todaysResolved:any  
    todaysPending:any  
    todaysPendingLate:any  
    todaysFeedBack:any   
    defaultStartDate:any
    defaultEndDate:any
    startDate:any
    dataRangeModal:any
    endDate:any;
    totalComplainData:any;
    rowCallback:any;
   
    public state: State = { 
      skip: 0,
      take: 10,  
      filter: {
        logic: 'and',
        filters: []
      }
    };
    public allData(): ExcelExportData {
      const result: ExcelExportData =  {
          data: this.complainData
      };
      return result;
     } 
  public fields: string[];
  myDateRangePickerOptions: IMyDrpOptions={ 
      dateFormat: 'dd.mm.yyyy', 
  };
  
  

  public groups: GroupDescriptor[] = [];
  public view: Observable<GridDataResult>;
  public gridView: DataResult;
  public groupChange(groups: GroupDescriptor[]): void {
    this.groups = groups;
    this.loadProducts();
  }

  public distinctZone: any[]
  public distinctWard: any[]
  public distinctCompSource: any[]
  public distinctCompStatus: any[]

  private loadProducts(): void {
    this.gridDataComplainList = process(this.complainData, { group: this.groups }); 
  }
  public gridDataComplainList: GridDataResult 
  
  constructor(private auth : AuthService,private http: Http,private loaderService: LoaderService,private _ngZone: NgZone)
         {
          this.loaderService.status.subscribe((val: boolean)=>{
          this.showLoader = val;
        });
    var date = new Date();
    this.monthTillTotal=0;  
    this.monthTillResolved=0;
    this.monthTillPending=0;
    this.monthTillPendingLate=0;
    this.monthTillFeedBack=0;   
    this.todaysTotal=0;  
    this.todaysResolved=0;
    this.todaysPending=0; 
    this.todaysPendingLate=0;
    this.todaysFeedBack=0;   
    this.allData = this.allData.bind(this);
    this.defaultStartDate = (date.getFullYear()) + '-' + (date.getMonth() + 1) + '-' + date.getDate(); 
    this.defaultEndDate = (date.getFullYear()) + '-' + (date.getMonth() + 1) + '-' + date.getDate(); 
    this.dataRangeModal= {beginDate: {year: date.getFullYear(), month: date.getMonth()+1, day: date.getDate()}, endDate: {year: date.getFullYear(), month: date.getMonth()+1, day: date.getDate()}};
  } 
   
  /*
   *select start Date Nad To date
  */
  onDateRangeChanged(dataRange){   
    if(dataRange.beginDate.day>0){ 
      this.startDate= dataRange.beginDate.year + "-"  + dataRange.beginDate.month+ "-" + dataRange.beginDate.day 
      this.endDate = dataRange.endDate.year + "-"  + dataRange.endDate.month  + "-" + dataRange.endDate.day 
      this.getComplainDetails(); 
    }
    else if(dataRange.beginDate.day==0){
      this.startDate= this.defaultStartDate
      this.endDate = this.defaultEndDate
      this.getComplainDetails(); 
    }  
  }
   
   /*
    * get Complain Details By Project Id
   */  
    getComplainDetails(){   
      this.loaderService.display(true);  
      this.http.get(environment.apiUrl + 'consumer/getComplainByProject?prjid='+this.prjId+'&StartDate='+this.startDate+'&EndDate='+this.endDate).subscribe(data =>{  
               this.complainData= data.json();  
               if (this.complainData.length>0){ 
                this.distinctZone = distinctZone(this.complainData) 
                this.distinctWard = distinctWard(this.complainData) 
                this.distinctCompSource = distinctCompSource(this.complainData) 
                this.distinctCompStatus = distinctCompStatus(this.complainData)  
                this.gridDataComplainList = process(this.complainData, this.state);   
                this.loaderService.display(false);           
               }else {
                this.complainData=[]; 
                this.gridDataComplainList = process(this.complainData, this.state);   
                this.loaderService.display(false);  
               } 
          });  
    }


    /**
     * Column BG color Change
    */

    /**
     * to filter the grid data
    */
    public dataStateChange(state: DataStateChangeEvent): void {
      this.state = state;
      this.gridDataComplainList = process(this.complainData, this.state);  
      if (state && state.group) {  
        this.distinctZone = distinctZone(this.complainData) 
        this.distinctWard = distinctWard(this.complainData) 
        this.distinctCompSource = distinctCompSource(this.complainData) 
        this.distinctCompStatus = distinctCompStatus(this.complainData)  
        this.gridDataComplainList = process(this.complainData, this.state);    
        } 
    } 


    /*
     * import excel details
    */ 
   importTotalComplainList(reportType){
      this.loaderService.display(true);       
      this.http.get(environment.apiUrl + 'consumer/getComplainExcelReport?prjid='+this.prjId+'&reportType='+reportType).subscribe(data =>{  
               this.totalComplainData= data.json();  
               if(this.totalComplainData.length>0){  
                this.loaderService.display(false);  
                this.importVehiclesExcelReport(this.totalComplainData)          
               }else{  
                this.loaderService.display(false); 
               } 
          });  
    } 

/*
 *To download the Excel file with selected data GRid  
*/
importVehiclesExcelReport(totalComplainData){
  const ws_name = 'ComplainReport';
  const wb: WorkBook = { SheetNames: [], Sheets: {} };
  const ws: any = utils.json_to_sheet(totalComplainData);
  wb.SheetNames.push(ws_name);
  wb.Sheets[ws_name] = ws;
  const wbout = write(wb, { bookType: 'xlsx', bookSST: true, type:'binary' });
 saveAs(new Blob([this.s2ab(wbout)], { type: 'application/octet-stream' }), 'exported.xlsx');
}
s2ab(s){
    const buf = new ArrayBuffer(s.length);
    const view = new Uint8Array(buf);
    for (let i = 0; i !== s.length; ++i) {
      view[i] = s.charCodeAt(i) & 0xFF;
    };
    return buf;
  }


  
    /*
     * Get complain Count Details.for Dash board only
    */     
    getComplainCount(){
      this.loaderService.display(true); 
      this.http.get(environment.apiUrl + 'consumer/getComplainCountDetails?PRJID='+this.prjId).subscribe(data =>{
          var getTotalComplain=data.json(); 
          if(getTotalComplain.length>0){   
          this.todaysTotal=getTotalComplain[2]?getTotalComplain[2].Total:0 
          this.todaysPending=getTotalComplain[2]?getTotalComplain[2].Pending:0  
          this.todaysPendingLate=getTotalComplain[2]?getTotalComplain[2].Late:0 
          this.todaysFeedBack=getTotalComplain[2]?getTotalComplain[2].Feedback:0 
          this.todaysResolved=getTotalComplain[2]?getTotalComplain[2].Resolved:0          
          this.monthTillTotal=getTotalComplain[1]?getTotalComplain[1].Total:0 
          this.monthTillPending=getTotalComplain[1]?getTotalComplain[1].PendingMonthTillDate:0  
          this.monthTillPendingLate=getTotalComplain[1]?getTotalComplain[1].Late:0 
          this.monthTillFeedBack=getTotalComplain[1]?getTotalComplain[1].Feedback:0 
          this.monthTillResolved=getTotalComplain[1]?getTotalComplain[1].Resolved:0 
          }
          else{
            alert('No data found ')
          }
        });
        this.loaderService.display(false); 
    } 
 



  ngOnInit(){ 
    this.startDate = moment(this.defaultStartDate).format('YYYY-MM-DD');
    this.endDate= moment(this.defaultEndDate).format('YYYY-MM-DD');
    this.geocoder = new google.maps.Geocoder;
    this.prjId = this.auth.getAuthentication().projectId
    this.userId= this.auth.getAuthentication().id
    
    this.getComplainDetails(); 
    this.getComplainCount(); 
  
  }
  
  
}
