import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
@Injectable()
export class AuthService {
    constructor(private http: HttpClient) { }
    isLoggedIn() {
        var ret=false;
        var authData = localStorage.getItem('authData');
        if (authData)
            ret = true;
        return ret;
    };
    userHasPermission(permissions) {
        //  if (!this.isLoggedIn()) {
        //      return false;
        //   }
        if(permissions == undefined){
            return true;
        }
        if (permissions.length > 0) {
            var match = permissions.split(':');
            var path = match.length > 0 ? match[0] : permissions;
             var ret = false;
             var per = this.permissionJson();
             if (per == undefined)
                return true;
             var val = this.findProp(per, path);
             if(val == undefined){
                return true;
             }
            return val;
        } else
            return true;     
    }

    permissionJson() {
         var configJson = this.fillUserConfig();
         return configJson;
    }
    getAuthentication() {
        var authData = JSON.parse(localStorage.getItem('authData'))
        var _authentication = {projectId:"",id:"",userName:"" ,mobileNo:"",userCD:""}
        if (authData) {
            _authentication.projectId = localStorage.getItem('projectId')
            _authentication.id = authData.id
            _authentication.userCD = authData.userCD
            _authentication.userName = authData.userName
            _authentication.mobileNo = authData.mobileNo
            
        } 
        else 
        {
            
        }
        return _authentication;
    }
    fillUserConfig(){
        var projectId = localStorage.getItem('projectId')
        var permissions = JSON.parse(localStorage.getItem('authData')).permissions;
        if(permissions){
        permissions = JSON.parse(permissions)
        var activeProject = []
        var projects = Object.keys(permissions)
         for(var i= 0;i<projects.length;i++){
             if(permissions[projects[i]].active == true && permissions[projects[i]].ID == projectId ){
                 return permissions[projects[i]].permissions
                 }
             }   
        }
    }
    getActiveProjects(){
        var permissions = JSON.parse(localStorage.getItem('authData')).permissions;
        if(permissions){
        permissions = JSON.parse(permissions)
        var activeProject = []
        var projects = Object.keys(permissions)
         for(var i= 0;i<projects.length;i++){
             if(permissions[projects[i]].active == true){
                 activeProject.push({
                     ID:permissions[projects[i]].ID,PRJNAME:projects[i],permissions:permissions[projects[i]].permissions
                 })
             }
         }
           return  activeProject;
        }
    };
    findProp(obj, prop) {
        prop = prop.split('.');
        for (var i = 0; i < prop.length; i++) {
            if (typeof obj[prop[i]] == 'undefined') {
                return false;
            }
            obj = obj[prop[i]];
        }
        return obj;
    }
}