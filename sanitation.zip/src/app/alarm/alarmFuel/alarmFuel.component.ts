import { Component } from '@angular/core';
import { Http } from '@angular/http'
import { environment } from '../../../environments/environment';
import { DateAdapter, MAT_DATE_FORMATS, MAT_DATE_LOCALE } from '@angular/material/core';
import { MomentDateAdapter } from '@angular/material-moment-adapter';
import { utils, write, WorkBook } from 'xlsx';
import { saveAs } from 'file-saver';
import { AuthService } from '../../_services'; 
import { LoaderService } from '../../_services/loader.service';
import Swal from 'sweetalert2'
import * as _moment from 'moment';
import * as _rollupMoment from 'moment';
const moment = _rollupMoment || _moment; 
 
export const MY_FORMATS = {
  parse: {
    dateInput: 'LL',
  },
  display: {
    dateInput: 'LL',
    monthYearLabel: 'MMM YYYY',
    dateA11yLabel: 'LL',
    monthYearA11yLabel: 'MMMM YYYY',
  },
};
@Component({
  selector: 'alarm-Fuel',
  templateUrl: './alarmFuel.component.html',
  providers: [
    { provide: DateAdapter, useClass: MomentDateAdapter, deps: [MAT_DATE_LOCALE] },
    { provide: MAT_DATE_FORMATS, useValue: MY_FORMATS },
  ],
})

export class AlarmFuelComponent {
  prjId:any;
  public alarmDataLevel1: any
  alarmDataLevel2: any
  alarmDataLevel3: any
  alarmDataLevel4: any
  showLoader: boolean
  startDate: any;
  endDate: any;
  dataRangeModal: any;
  constructor(private http: Http, private auth: AuthService, private loaderService: LoaderService) {
    this.loaderService.status.subscribe((val: boolean) => {
      this.showLoader = val;
    });
    this.alarmDataLevel1 = []
    this.alarmDataLevel2 = []
    this.alarmDataLevel3 = []
    this.alarmDataLevel4 = []
    var date = new Date();
    this.startDate = new Date(date.getFullYear(), date.getMonth(), date.getDate()-30); 
    this.endDate=new Date();
    this.dataRangeModal = { beginDate: { year: this.startDate.getFullYear(), month: this.startDate.getMonth() + 1, day: this.startDate.getDate() }, endDate: { year: date.getFullYear(), month: date.getMonth() + 1, day: date.getDate() } };
   }

  getFuelAlarmData(level) {
    var data = { 
      prjid:this.prjId,
      level: level,
      startDate:this.startDate,
      endDate:this.endDate
    }
    this.loaderService.display(true);
    this.http.post(environment.apiUrl + 'fuelAlarm', data).subscribe(data => {
      let result = data.json()
      if (level == 'Level1') {
        this.alarmDataLevel1 = result
      } else if (level == 'Level2') {
        this.alarmDataLevel2 = result
      } else if (level == 'Level3') {
        this.alarmDataLevel3 = result
      } else if (level == 'Level4') {
        this.alarmDataLevel4 = result
      } 
      this.loaderService.display(false);
    },
    error=>{ 
      this.loaderService.display(false);
      Swal({
        type: 'error',
        title: 'Oops...',
        text: 'An Error Occurred Please Try Again',
      })
});     
  
  }

  importVehAlart1Report(alarmDataLevel1) {
    const ws_name = 'EmployeeReport';
    const wb: WorkBook = { SheetNames: [], Sheets: {} };
    const ws: any = utils.json_to_sheet(alarmDataLevel1);
    wb.SheetNames.push(ws_name);
    wb.Sheets[ws_name] = ws;
    const wbout = write(wb, {
      bookType: 'xlsx', bookSST: true, type:
        'binary'
    });
    saveAs(new Blob([this.s2ab(wbout)], { type: 'application/octet-stream' }), 'exported.xlsx');
  }
  s2ab(s) {
    const buf = new ArrayBuffer(s.length);
    const view = new Uint8Array(buf);
    for (let i = 0; i !== s.length; ++i) {
      view[i] = s.charCodeAt(i) & 0xFF;
    };
    return buf;
  }


/*
*select start Date Nad To date
*/
 onDateRangeChanged(dataRange){  
  if(dataRange.beginDate.day>0){ 
    this.startDate= dataRange.beginDate.year + "-"  + dataRange.beginDate.month+ "-" + dataRange.beginDate.day 
    this.endDate = dataRange.endDate.year + "-"  + dataRange.endDate.month  + "-" + dataRange.endDate.day 
    this.getFuelAlarmData('Level1')
    this.getFuelAlarmData('Level2')
    this.getFuelAlarmData('Level3')
    this.getFuelAlarmData('Level4') 
  }
  else if(dataRange.beginDate.day==0){
    this.startDate= this.startDate
    this.endDate = new Date();
    this.getFuelAlarmData('Level1')
    this.getFuelAlarmData('Level2')
    this.getFuelAlarmData('Level3')
    this.getFuelAlarmData('Level4') 
  }  
} 



  ngOnInit() { 
    this.startDate = moment(this.startDate).format('YYYY-MM-DD');
    this.endDate= moment(this.endDate).format('YYYY-MM-DD');
    this.prjId = this.auth.getAuthentication().projectId
    this.getFuelAlarmData('Level1')
    this.getFuelAlarmData('Level2')
    this.getFuelAlarmData('Level3')
    this.getFuelAlarmData('Level4') 
  }
}
