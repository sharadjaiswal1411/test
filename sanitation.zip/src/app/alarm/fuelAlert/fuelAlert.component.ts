

import { Component, OnInit } from '@angular/core';
import { Http } from '@angular/http'

import { environment } from '../../../environments/environment';
import { MomentDateAdapter } from '@angular/material-moment-adapter';
import { DateAdapter, MAT_DATE_FORMATS, MAT_DATE_LOCALE } from '@angular/material/core';


import { ActivatedRoute, Router } from '@angular/router';
import { AuthService } from '../../_services/index';
import { utils, write, WorkBook } from 'xlsx';
import { saveAs } from 'file-saver';
import { Broadcaster } from '../../../environments/broadcaster';
import { LoaderService } from '../../_services/loader.service';

import * as _moment from 'moment';
import * as _rollupMoment from 'moment';
const moment = _rollupMoment || _moment;
export const MY_FORMATS = {
  parse: {
    dateInput: 'LL',
  },
  display: {
    dateInput: 'LL',
    monthYearLabel: 'MMM YYYY',
    dateA11yLabel: 'LL',
    monthYearA11yLabel: 'MMMM YYYY',
  },
};
declare var $: any;
declare var google: any;
declare var firebase: any;
declare var MapLabel: any
var stopAnimation = true 
declare const MarkerClusterer;

@Component({

  selector: 'fuelAlert-cmp',
  templateUrl: './fuelAlert.component.html',
  providers: [
    { provide: DateAdapter, useClass: MomentDateAdapter, deps: [MAT_DATE_LOCALE] },
    { provide: MAT_DATE_FORMATS, useValue: MY_FORMATS },
  ],
})


export class FuelAlertComponent implements OnInit {
  prjID:any
  polygondData:any
  map:any
  showLoader: boolean
  fuelAlertList:any
  search:any;
  mapLabelArray:any
  allMarkers:any
  markerCluster:any;
  alertDetail:any
  totalAlert:any;
  totalVehicle:any;
  selectedSection:any
  tempFuelAlertList:any;
  constructor(private auth: AuthService, private http: Http, private loaderService: LoaderService, private routes: ActivatedRoute, private broadcaster: Broadcaster, private router: Router, ) {
    
    this.prjID = this.auth.getAuthentication().projectId

    this.mapLabelArray = []
    this.allMarkers = []

    this.selectedSection = 'All'

  }


  selectSection(section){
    this.selectedSection = section
    this.fuelAlertList = []
    if(section == "All"){
      this.fuelAlertList = this.tempFuelAlertList
    }
    for(var i = 0;i<this.tempFuelAlertList.length;i++){
      if(section == 'Alert'){
        if(this.tempFuelAlertList[i].alert){
          this.fuelAlertList.push(this.tempFuelAlertList[i])
        }
      }

    }
  }

   /* 
     excel Import
  */

 s2ab(s) {
  const buf = new ArrayBuffer(s.length);
  const view = new Uint8Array(buf);
  for (let i = 0; i !== s.length; ++i) {
    view[i] = s.charCodeAt(i) & 0xFF;
  };
  return buf;
}

importToExcel() {
  var data = this.fuelAlertList
  const ws_name = 'SomeSheet';
  const wb: WorkBook = { SheetNames: [], Sheets: {} };
  const ws: any = utils.json_to_sheet(data);
  wb.SheetNames.push(ws_name);
  wb.Sheets[ws_name] = ws;
  const wbout = write(wb, {
    bookType: 'xlsx', bookSST: true, type:
      'binary'
  });
  saveAs(new Blob([this.s2ab(wbout)], { type: 'application/octet-stream' }), 'FuelAlertList.xlsx');
}


  countAlert(){
    var alert = 0
    for(var i = 0;i<this.fuelAlertList.length;i++){
      if(this.fuelAlertList[i].alert){
        alert++
      }

    }
    this.totalVehicle = this.fuelAlertList.length
    this.totalAlert = alert
  }
  getfuelAlert(){
    this.http.get(environment.apiUrl + 'getfuelAlert' + '?prjId=' + this.prjID).subscribe(data => {
     this.tempFuelAlertList = data.json()
     this.fuelAlertList = data.json()
     this.countAlert()
     console.log(this.fuelAlertList)
     this.plotAllVehicles(this.fuelAlertList)
      
    });
  }
  clearFeature() {
    this.map.data.forEach((feature) => {
      this.map.data.remove(feature);
    })
  }

  
  processPoints(this, geometry, callback, thisArg) {
    if (geometry instanceof google.maps.LatLng) {
      callback.call(thisArg, geometry);
    } else if (geometry instanceof google.maps.Data.Point) {
      callback.call(thisArg, geometry.get());
    } else {
      if (geometry) {
        geometry.getArray().forEach((g) => {
          this.processPoints(g, callback, thisArg);
        });
      }
    }
  }

  zoom(this, map, isZone) {
    this.bounds = new google.maps.LatLngBounds();
    this.map.data.forEach((feature) => {
      if (isZone) {
        this.processPoints(feature.getGeometry(), this.bounds.extend, this.bounds);
      } else {
        if (feature.getProperty('type') == "route") {
          this.processPoints(feature.getGeometry(), this.bounds.extend, this.bounds);
        }
      }

    });
    map.fitBounds(this.bounds);

  }

  setStyle(thisRef) {
    this.map.data.setStyle(function (feature) {
      var color = feature.getProperty('FillColor');
      var strokeColor = feature.getProperty('Bcolor')
      var strokeOpacity = feature.getProperty('stroke-opacity')
      if (feature.getProperty('Oemid') == 8) {
        thisRef.polygonLabel(feature.getProperty('Ward'), feature.getProperty('LAT'), feature.getProperty('LON'), 16, 12, feature.getProperty('EntityID'), strokeColor)
      } else if (feature.getProperty('Oemid') == 7) {
        thisRef.polygonLabel(feature.getProperty('Zone'), feature.getProperty('LAT'), feature.getProperty('LON'), 18, 13, feature.getProperty('EntityID'), "#010100")
      }
     

      if (feature.getProperty('TYPE') == "stopMarker") {

        return ({
          fillColor: color,
          strokeColor: strokeColor,
          strokeWeight: 2,
          fillOpacity: 0.05,
          icon: 'assets/img/stopMarker.png',
          strokeopacity: 0.2,
          label: {
            text: feature.getProperty('number'),
            color: '#FFFFFF',
            fontSize: "13px",
            background: 'yellow',
            fontWeight: "bold",
            AlignmentVertical: "top",
            AlignmentHorizontal: "center"
          },
          labelClass: "my-custom-class-for-label"


        });
      } else if (feature.getProperty('TYPE') == "khatta") {
        return ({
          fillColor: color,
          strokeColor: strokeColor,
          strokeWeight: 5,
          fillOpacity: 0.0,
          strokeopacity: 0.2,
          icon: 'assets/img/khatta.png',
        });
      } else if (feature.getProperty('Oemid') == 8 || feature.getProperty('Oemid') == 9) {
        return ({
          fillColor: color,
          strokeColor: strokeColor,
          strokeWeight: 3,
          fillOpacity: 0.1,
          strokeopacity: 0.8,
        });

      } else {
        return ({
          fillColor: color,
          strokeColor: "#040C0A",
          strokeWeight: 4,
          fillOpacity: 0.1,
          strokeopacity: 0.4

        });
      }
    });
  }

  polygonLabel(text, lat, long, strokeWeight, fontSize, entityId, color) {
    var myLatlng = new google.maps.LatLng(Number(lat), Number(long));
    var mapLabel = new MapLabel({
      text: text,
      position: myLatlng,
      map: this.map,
      strokeWeight: strokeWeight,
      fontSize: fontSize,
      align: 'left',
      entityId: entityId,
      fontColor: color

    });
    this.mapLabelArray.push(mapLabel)
    mapLabel.set('position', myLatlng);
  }

  
  plotAllVehicles(data) {
    var infoWindow = new google.maps.InfoWindow;
    var markers = []
    for (var i = 0; i < data.length; i++) {
      if (data[i].lat && data[i].long) {
        var item = data[i]
       

        if (item.lat && item.long) {
          var marker = new google.maps.Marker({
            position: { lat: JSON.parse(item.lat), lng: JSON.parse(item.long) },
            icon: 'assets/img/gasStation.png',

          });
          marker.id = item.vehicleNo;
         
          markers.push(marker)
          marker.setMap(this.map);
          this.allMarkers.push(marker)
          
        }
        (function (marker, data) {
          google.maps.event.addListener(marker, "click", function (e) {
            var content = "<div class='col-sm-12 '>" + "<p class='info-deatil'><strong>IMEI:</strong>" + "  " + marker.vehicleNo + "</div>"
            infoWindow.setContent(content);
            infoWindow.open(this.map, marker);
          });
        })(marker, item);
      }
    }

    if (true) {
      this.markerCluster = new MarkerClusterer(this.map, markers,
        { imagePath: 'https://developers.google.com/maps/documentation/javascript/examples/markerclusterer/m' });
    }
  }


  getDataWhenProjectChange = async (id) => {
    $('#loderImgTab').show()
    this.loaderService.display(true);
    let polygon = await fetch(environment.apiUrl + 'entity/getPolygonByOemId' + "?prjid=" + id + "&wardOemId=null" + "&beatOemId=null")
    this.polygondData = await polygon.json()
    this.clearFeature()
    this.map.data.addGeoJson(this.polygondData.geoJson);
    this.zoom(this.map, true);
    this.setStyle(this)
  }
  closeInfo() {
    $(".individual_detail").toggle()
  }



  showDetail(data, i){
    this.alertDetail = data
    
    console.log(data.lastReceiptImage)
    $("#infotable1").show()

  }








  ngOnInit() {
    this.getfuelAlert()
    this.getDataWhenProjectChange(this.prjID)
    var thisRef = this

    $("#infotable1").hide()

    $("#play").show()
    $("#stop").hide()
    $("#veichiclesInfo-bar").hide()
    $('#progress-bar').hide()
    var myOptions = {
      center: new google.maps.LatLng(28.47769599987369, 77.06160699973178),
      zoom: 13,
      panControl: true,
      mapTypeControl: true,
      mapTypeId: google.maps.MapTypeId.ROADMAP,
      mapTypeControlOptions: {
        style: google.maps.MapTypeControlStyle.DROPDOWN_MENU,
        position: google.maps.ControlPosition.TOP_LEFT
      },
      zoomControlOptions: {
        position: google.maps.ControlPosition.LEFT_BOTTOM,
        style: google.maps.ZoomControlStyle.SMALL
      },
    
    };
    this.map = new google.maps.Map(document.getElementById('map'), myOptions);
  }
}




