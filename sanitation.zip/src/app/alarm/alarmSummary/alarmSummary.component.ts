import { Component} from '@angular/core'; 
import { Http } from '@angular/http' 

import { DateAdapter, MAT_DATE_FORMATS, MAT_DATE_LOCALE } from '@angular/material/core';
import { MomentDateAdapter } from '@angular/material-moment-adapter'; 


import { AuthService } from '../../_services';


import { LoaderService } from '../../_services/loader.service';

import * as _moment from 'moment';
import * as _rollupMoment from 'moment';


const distinctZone = data => data.filter((x, idx, xs) => xs.findIndex(y => y.zone === x.zone) === idx); 
const distinctWard = data => data.filter((x, idx, xs) => xs.findIndex(y => y.ward === x.ward) === idx); 
export const MY_FORMATS = {
  parse: {
    dateInput: 'LL',
  },
  display: {
    dateInput: 'LL',
    monthYearLabel: 'MMM YYYY',
    dateA11yLabel: 'LL',
    monthYearA11yLabel: 'MMMM YYYY',
  },
};
@Component({
  selector: 'alarm-summary',
  templateUrl: './alarmSummary.component.html', 
  providers: [
    { provide: DateAdapter, useClass: MomentDateAdapter, deps: [MAT_DATE_LOCALE] },
    { provide: MAT_DATE_FORMATS, useValue: MY_FORMATS },
  ], 
}) 


export class AlarmSummaryComponent {  
 
  constructor(private http: Http,private auth : AuthService,private loaderService: LoaderService) { 
   
    var date = new Date();
    var firstDay = new Date(date.getFullYear(), date.getMonth(), 1); 
   

  }

  showLoader:any
 

  ngOnInit(): void { 
   
  }





}








