import { Component ,OnInit} from '@angular/core';
@Component({
  selector: 'dashboard-cmp',
  templateUrl: './alarm.component.html',
  styleUrls: ['./alarm.component.css']
})
export class AlarmComponent implements OnInit {
  
  constructor() { }

  ngOnInit() {
      
}
}