import { Component} from '@angular/core';
import { Http } from '@angular/http'
import { environment } from '../../../environments/environment';
import {MomentDateAdapter} from '@angular/material-moment-adapter';
import {DateAdapter, MAT_DATE_FORMATS, MAT_DATE_LOCALE} from '@angular/material/core';
import { Broadcaster } from '../../../environments/broadcaster';
import { AuthService } from '../../_services';
import { utils, write, WorkBook } from 'xlsx';
import { saveAs } from 'file-saver';

// Depending on whether rollup is used, moment needs to be imported differently.
// Since Moment.js doesn't have a default export, we normally need to import using the `* as`
// syntax. However, rollup creates a synthetic default module and we thus need to import it using
// the `default as` syntax.
import * as _moment from 'moment';
import * as _rollupMoment from 'moment';
import { timeout } from 'q';
const moment = _rollupMoment || _moment;
export const MY_FORMATS = {
  parse: {
    dateInput: 'LL',
  },
  display: {
    dateInput: 'LL',
    monthYearLabel: 'MMM YYYY',
    dateA11yLabel: 'LL',
    monthYearA11yLabel: 'MMMM YYYY',
  },
};


declare const google: any;
declare var $: any;



interface Marker {
  lat: number;
  lng: number;
  label?: string;
  draggable?: boolean;
}
@Component({
  selector: 'area-cmp',
  templateUrl: './area.component.html',
  styleUrls: ['./area.component.css'],
  providers: [
    {provide: DateAdapter, useClass: MomentDateAdapter, deps: [MAT_DATE_LOCALE]},
    {provide: MAT_DATE_FORMATS, useValue: MY_FORMATS},
  ],
})



export class AreaComponent {
  public map:any
  public prjId:any;
  date:any;
  search:any;
  entityData:any;
  searchAreaByDate:any;
  surveyData:any;
  bounds:any;
  unverified:any;
  verified:any;
  allSurvey:any;
  slectedSurvey:Object;
  wardList:any;
  surveyTypeData:any;
  surveyType:any;
  selectedWard:any;
  isVerified:any;
  wrong:any;
  surveyDate:any;
  slectedSurveyId:any;
  unverifiedArray:any;
  verifiedArray:any;
  allSurveyData:any;
  wrongArray:any;
  verifySuccess:any;
  responseMsg:any;
  public selectedlist: number
  infoWindow:any;
  lastOpenedInfoWindow:any;



  constructor(private http: Http,private broadcaster: Broadcaster,private auth:AuthService) {
    this.isVerified = null;
    this.surveyType = null
    this.surveyDate = moment(new Date()).format('YYYY-MM-DD');
    this.selectedWard = null
    this.unverifiedArray = []
    this.verifiedArray = []
    this.wrongArray = []
    this.verifySuccess = false


  }

  filterpopup(){
    $('#filterpopupModal').modal('show');
  }
  closefilterpopup(){
    $('#filterpopupModal').modal('hide');
  }
  closeInfo(){
    this.slectedSurvey = false
  }

  processPoints(this, geometry, callback, thisArg) {
    if (geometry instanceof google.maps.LatLng) {
      callback.call(thisArg, geometry);
    } else if (geometry instanceof google.maps.Data.Point) {
      callback.call(thisArg, geometry.get());
    } else {
      if(geometry){
      geometry.getArray().forEach((g) => {
        this.processPoints(g, callback, thisArg);
      });
    }
    }
  }

  zoom(this, map) {
    this.bounds = new google.maps.LatLngBounds();
    map.data.forEach((feature) => {
       if (feature.getProperty('type') == "clickedPolygon") {
          this.processPoints(feature.getGeometry(), this.bounds.extend, this.bounds);
        }
    });
    map.fitBounds(this.bounds);
    
  }

  zoomPolygon(this, map) {
    this.bounds = new google.maps.LatLngBounds();
      map.data.forEach((feature) => {
        this.processPoints(feature.getGeometry(), this.bounds.extend, this.bounds);
      });
     map.fitBounds(this.bounds);
  }

  zoomSurveyCluster(this, map,data) {
    if(data.length>0){
    this.bounds = new google.maps.LatLngBounds();
      map.data.forEach((feature) => {
        if(feature.getProperty('type') == "surveyMarker"){
          this.processPoints(feature.getGeometry(), this.bounds.extend, this.bounds);
        }
      });
     map.fitBounds(this.bounds);
    }
  }



  zoomSurveyPoint(lat,lng){
    var myPlace = new google.maps.LatLng(lat, lng);
    this.bounds = new google.maps.LatLngBounds(myPlace);
    this.map.fitBounds(this.bounds);
    var zoomChangeBoundsListener = 
    google.maps.event.addListenerOnce(this.map, 'bounds_changed', function(event) {

      console.log("event",event)
        if (this.getZoom()){
            this.setZoom(17);
        }
    });
      setTimeout(function(){google.maps.event.removeListener(zoomChangeBoundsListener)}, 2000);
   }

  
  

  clearFeature(){
      this.map.data.forEach((feature) => {
          this.map.data.remove(feature);
      })
      
   }

  
  GetDataByProject(){ 
    this.getEntityZoneAndWard(this.prjId)   
   

  }

  s2ab(s) 
  {
    const buf = new ArrayBuffer(s.length);
    const view = new Uint8Array(buf);
    for (let i = 0; i !== s.length; ++i) {
      view[i] = s.charCodeAt(i) & 0xFF;
    };
    return buf;
  }
  
  importToExcel(data)
  {
    const ws_name = 'SomeSheet';
    const wb: WorkBook = { SheetNames: [], Sheets: {} };
    const ws: any = utils.json_to_sheet(data);
    wb.SheetNames.push(ws_name);
    wb.Sheets[ws_name] = ws;
    const wbout = write(wb, { bookType: 'xlsx', bookSST: true, type: 
  'binary' });
  saveAs(new Blob([this.s2ab(wbout)], { type: 'application/octet-stream' }), 'exported.xlsx');
  }

  plotSurvey(data,index){
   // this.closeLastOpenedInfoWindow();
    this.viewImaage(data)
    this.slectedSurvey = data
    this.slectedSurveyId = data.id
    this.selectedlist = index;
    this.zoomSurveyPoint(data.lat,data.lng)
   
  }



   reload(){
    this.getSurveyData(this.prjId,this.isVerified, this.surveyDate,this.selectedWard,this.surveyType);
   }
   getSurveyData(prjid,isVerified,surveyDate,ward,surveyType){
    this.http.get(environment.apiUrl + "survey/getSurveyData" + "?prjId=" + prjid + "&isVerified="  + isVerified +"&surveyDate=" + surveyDate + "&ward=" + ward +  "&surveyType=" + surveyType).subscribe(data => {
      this.surveyData = data.json()
      this.allSurveyData = data.json()
      this.getSurveyCount(this.surveyData)
      this.map.data.forEach((feature) => {
        if (feature.getProperty('type') == "surveyMarker") {
          this.map.data.remove(feature);
        }
      })
      this.plotAllSurveyPoint(this.surveyData)
    
      this.zoomSurveyCluster(this.map,this.allSurveyData)
      $("#loderImgTab").hide()
    });
   }



   getSurveyBystatus(status){
     if(status == 'all'){
        this.surveyData = this.allSurveyData
     }else if(status == 'verified'){
        this.surveyData = this.verifiedArray
     }else if(status == 'unverified'){
        this.surveyData = this.unverifiedArray
     }else if(status == 'wrong'){
      this.surveyData = this.wrongArray
     }

   }

   getSurveyCount(surveyData){
     this.allSurvey = surveyData.length
     var unverified =0
     var verified = 0
     var wrong = 0
     this.unverifiedArray = []
     this.verifiedArray = []
     this.wrongArray = []
     for(var i= 0;i<surveyData.length;i++){
       if(surveyData[i].isVerified == 0){
        unverified ++;
        this.unverifiedArray.push(surveyData[i])
       }else if (surveyData[i].isVerified == 1){
        verified ++;
        this.verifiedArray.push(surveyData[i])
       }else if(surveyData[i].isVerified == 2){
        wrong ++;
        this.wrongArray.push(surveyData[i])
       }
     }
     this.unverified = unverified;
     this.verified = verified;
     this.wrong = wrong

   }
   plotAllSurveyPoint(survey){
    var data = {features:[],type: ""}
    data.type = "FeatureCollection"
    var count = 1
    for (var i = 0; i < survey.length; i++) {  
      if(survey[i].lat && survey[i].lng){
        survey[i].number = count + i
        survey[i].type = "surveyMarker"
      var geometry = {coordinates:[],type:""}   
      geometry.coordinates.push(Number(survey[i].lng),Number(survey[i].lat)) 
      geometry.type = "Point"
      data.features.push({geometry:geometry,type:"Feature",properties:survey[i]})
    }
  }
  this.map.data.addGeoJson(data);

  }
 
  verifySurvey(status){
    this.http.get(environment.apiUrl + 'survey/verify' + "?status=" + status + "&id=" + this.slectedSurveyId ).subscribe(data => {
      this.responseMsg = data.json().RESPONSEMESSAGE; 
        this.verifySuccess = true
        setTimeout(()=> {
          this.verifySuccess = false
         }, 2000);
    });


  }
 
  getEntityZoneAndWard(prjID) {
    $('#loderImgTab').show()
    $('#loderImgTab').hide()
    this.http.get(environment.apiUrl + 'entity/getPolygon' + "?prjid=" + prjID).subscribe(data => {
      this.clearFeature()
      this.map.data.addGeoJson(data.json().geoJson);
      this.zoomPolygon(this.map);
      var date = moment(this.surveyDate).format('YYYY-MM-DD');
      this.getSurveyData(this.prjId,this.isVerified,date,this.selectedWard,this.surveyType);
      $('#loderImgTab').hide()
    });
  }

  getSurveyType(){
    this.http.get(environment.apiUrl + 'survey/getSurveyType').subscribe(data =>{ 
       this.surveyTypeData = data.json(); 
       console.log(this.surveyTypeData)
     }); 
   } 

  selectSurveyType(data){
    if(data){
     this.surveyType = data.SURVEYTYPE
    }else{
      this.surveyType = null
    }

  }
  getWard(){
    this.http.get(environment.apiUrl + 'consumer/getZoneByProject?prjid='+this.prjId+'&oemid=8').subscribe(data =>{ 
       this.wardList= data.json(); 
       console.log(this.wardList)
     }); 
   } 

   selectWard(data){
     if(data){
      this.selectedWard = data.entityname
     }else{
      this.selectedWard = null
     }
     
   }

   viewImaage(data){
      this.closeLastOpenedInfoWindow();
      if(this.slectedSurvey){
        var position = { lat: Number(data.lat), lng: Number(data.lng) }
      }
      if(data.imgURL){
        var content = '<div id="iw-container">' +
        '<div></div>' + '<div><div class="col-sm-12"><p><strong>Name : </strong> ' + data.name + '</p><p>' +  '<img  src=' + data.imgURL + 'height="202" width="302">' + '</p><p><small> <i class="fa fa-map-marker" style="font-size:24px;color:#7344B8" aria-hidden="true"></i>  </small> ' + '<small>' + Number(data.lat) + ','  + Number(data.lng) + '</small>' + '</p></div></div>'
      }else{
        var content = '<div id="iw-container">' +
        '<div></div>' + '<div><div class="col-sm-12"><p><strong>Name : </strong> ' + data.name + '</p><p>' +  "No Image" + '</p><p><small> <i class="fa fa-map-marker" style="font-size:24px;color:#7344B8" aria-hidden="true"></i>  </small> ' + '<small>' + Number(data.lat) + ','  + Number(data.lng) + '</small>' + '</p></div></div>'
      }
     
      this.infoWindow = new google.maps.InfoWindow({
           content: content,
           position: position,
      });
      this.infoWindow.open(this.map);
      this.lastOpenedInfoWindow = this.infoWindow;
   }

  getFilterData(){
    $("#loderImgTab").show()
    this.closefilterpopup();
    this.surveyDate = moment(this.surveyDate).format('YYYY-MM-DD');
    this.getSurveyData(this.prjId,this.isVerified, this.surveyDate,this.selectedWard,this.surveyType);
   }

   closeLastOpenedInfoWindow() {
    if (this.lastOpenedInfoWindow) {
      this.lastOpenedInfoWindow.close();
    }
  }
  ngOnInit() {
    this.prjId = this.auth.getAuthentication().projectId
    var thisRef = this
    $("#loderImgTab").show()
    this.getWard()
    this.getSurveyType()
    this.GetDataByProject()
    this.map = new google.maps.Map(document.getElementById('map'), {
      zoom: 15,
      center: { lat: 28.47769599987369, lng: 77.06160699973178 },
      styles:[
        {
          "elementType": "geometry",
          "stylers": [
            {
              "color": "#f5f5f5"
            }
          ]
        },
        {
          "elementType": "labels.icon",
          "stylers": [
            {
              "visibility": "off"
            }
          ]
        },
        {
          "elementType": "labels.text.fill",
          "stylers": [
            {
              "color": "#616161"
            }
          ]
        },
        {
          "elementType": "labels.text.stroke",
          "stylers": [
            {
              "color": "#f5f5f5"
            }
          ]
        },
        {
          "featureType": "administrative.land_parcel",
          "elementType": "labels.text.fill",
          "stylers": [
            {
              "color": "#bdbdbd"
            }
          ]
        },
        {
          "featureType": "poi",
          "elementType": "geometry",
          "stylers": [
            {
              "color": "#eeeeee"
            }
          ]
        },
        {
          "featureType": "poi",
          "elementType": "labels.text.fill",
          "stylers": [
            {
              "color": "#757575"
            }
          ]
        },
        {
          "featureType": "poi.park",
          "elementType": "geometry",
          "stylers": [
            {
              "color": "#e5e5e5"
            }
          ]
        },
        {
          "featureType": "poi.park",
          "elementType": "labels.text.fill",
          "stylers": [
            {
              "color": "#9e9e9e"
            }
          ]
        },
        {
          "featureType": "road",
          "elementType": "geometry",
          "stylers": [
            {
              "color": "#ffffff"
            }
          ]
        },
        {
          "featureType": "road.arterial",
          "elementType": "labels.text.fill",
          "stylers": [
            {
              "color": "#757575"
            }
          ]
        },
        {
          "featureType": "road.highway",
          "elementType": "geometry",
          "stylers": [
            {
              "color": "#dadada"
            }
          ]
        },
        {
          "featureType": "road.highway",
          "elementType": "labels.text.fill",
          "stylers": [
            {
              "color": "#616161"
            }
          ]
        },
        {
          "featureType": "road.local",
          "elementType": "labels.text.fill",
          "stylers": [
            {
              "color": "#9e9e9e"
            }
          ]
        },
        {
          "featureType": "transit.line",
          "elementType": "geometry",
          "stylers": [
            {
              "color": "#e5e5e5"
            }
          ]
        },
        {
          "featureType": "transit.station",
          "elementType": "geometry",
          "stylers": [
            {
              "color": "#eeeeee"
            }
          ]
        },
        {
          "featureType": "water",
          "elementType": "geometry",
          "stylers": [
            {
              "color": "#c9c9c9"
            }
          ]
        },
        {
          "featureType": "water",
          "elementType": "labels.text.fill",
          "stylers": [
            {
              "color": "#9e9e9e"
            }
          ]
        }
      ],
    zoomControlOptions: {
        position: google.maps.ControlPosition.RIGHT_CENTER
    },
    fullscreenControlOptions:{
        position: google.maps.ControlPosition.RIGHT_CENTER
    }

    });
  

    this.map.data.setStyle(function (feature) {
      var color = feature.getProperty('FillColor');
      var strokeColor = feature.getProperty('Bcolor')
      if(feature.getProperty('isVerified') == 1){
        var icon = 'assets/img/verifiedSurvey.png'
      }else if(feature.getProperty('isVerified') == 0){
        var icon = 'assets/img/surveyMarker.png'
      }else {
        var icon = 'assets/img/wrongSurvey.png'
      }
      return ({
        fillColor: color,
        strokeColor: strokeColor,
        strokeWeight: 3,
        fillOpacity: 0,
        strokeopacity: 0.7,
        content: "AREA_1",
        icon:icon,
        label: {
          text: feature.getProperty('number'),
          color: '#FFFFFF',
          fontSize: "13px",
          background:'yellow',
          fontWeight: "bold",
          AlignmentVertical:"top",
          AlignmentHorizontal:"center"
        },
        labelClass: "my-custom-class-for-label"
      
      });
    });
    thisRef.infoWindow = new google.maps.InfoWindow;

   
    this.map.data.addListener('click', showArrays);
    function showArrays(event) {
      thisRef.closeLastOpenedInfoWindow();
      var position = { lat: event.latLng.lat(), lng: event.latLng.lng() }
      if(event.feature.f.type == "surveyMarker"){
        thisRef.slectedSurvey = event.feature.f
        thisRef.slectedSurveyId = event.feature.f.id
        var content = '<div id="iw-container">' +
        '<div></div>' + '<div><div class="col-sm-12"><p><strong>Name : </strong> ' + event.feature.getProperty('name') + '</p><p>' +  '<img src=' + event.feature.getProperty('imgURL') + 'height="202" width="202">' + '</p><p><small> <i class="fa fa-map-marker" style="font-size:24px;color:#7344B8" aria-hidden="true"></i>  </small> ' + '<small>' + event.feature.getProperty('lat') + ','  + event.feature.getProperty('lng')+ '</small>' + '</p></div></div>'
      }else{
        var content = '<div id="iw-container">' +
        '<div></div>' + '<div><div class="col-sm-12"><p><strong> Ward : </strong> ' + event.feature.getProperty('Ward') + '</p><p><small> <i class="fa fa-map-marker" style="font-size:24px;color:#7344B8" aria-hidden="true"></i>  </small> ' + '<small>' + event.latLng.lat() + ','  + event.latLng.lng()+ '</small>' + '</p></div></div>'
      }
      thisRef.infoWindow = new google.maps.InfoWindow({
        content: content,
        position: position,
      });
      thisRef.infoWindow.open(thisRef.map);
      thisRef.lastOpenedInfoWindow = thisRef.infoWindow;
    }
    //search box
    let input = document.getElementById('pac-input');
    let searchBox = new google.maps.places.SearchBox(input);
    this.map.controls[google.maps.ControlPosition.TOP_LEFT].push(input);
    // Bias the SearchBox results towards current map's viewport.
  
    var markers = [];
    // Listen for the event fired when the user selects a prediction and retrieve
    // more details for that place.
    searchBox.addListener('places_changed', function (this) {
      let places = searchBox.getPlaces();
      if (places.length == 0) {
        return;
      }
      // Clear out the old markers.
      markers.forEach(function (marker) {
        marker.setMap(null);
      });
      markers = [];
      // For each place, get the icon, name and location.
      let bounds = new google.maps.LatLngBounds();
      places.forEach(function (place) {
        if (!place.geometry) {
          console.log("Returned place contains no geometry");
          return;
        }
        var icon = {
          url: place.icon,
          size: new google.maps.Size(71, 71),
          origin: new google.maps.Point(0, 0),
          anchor: new google.maps.Point(17, 34),
          scaledSize: new google.maps.Size(25, 25)
        };
        // Create a marker for each place.
        markers.push(new google.maps.Marker({
          map: thisRef.map,
          icon: icon,
          title: place.name,
          position: place.geometry.location
        }));
        
        if (place.geometry.viewport) {
          // Only geocodes have viewport.
          bounds.union(place.geometry.viewport);
        } else {
          bounds.extend(place.geometry.location);
        }
      });
      thisRef.map.fitBounds(bounds);
    });

  }

  

}




//vivek
