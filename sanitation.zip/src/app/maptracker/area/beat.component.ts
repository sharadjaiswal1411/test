import { Component} from '@angular/core';
import { Http } from '@angular/http'

import { environment } from '../../../environments/environment';
import {MomentDateAdapter} from '@angular/material-moment-adapter';
import {DateAdapter, MAT_DATE_FORMATS, MAT_DATE_LOCALE} from '@angular/material/core';
import { Broadcaster } from '../../../environments/broadcaster';
import { AuthService } from '../../_services';
import * as _moment from 'moment';
import * as _rollupMoment from 'moment';
const moment = _rollupMoment || _moment;
export const MY_FORMATS = {
  parse: {
    dateInput: 'LL',
  },
  display: {
    dateInput: 'LL',
    monthYearLabel: 'MMM YYYY',
    dateA11yLabel: 'LL',
    monthYearA11yLabel: 'MMMM YYYY',
  },
};
import {FormControl} from '@angular/forms';

declare const google: any;
declare var $: any;
declare var TreeNode: any;
@Component({
  selector: 'beat-cmp',
  templateUrl: './beat.component.html',
  providers: [
    {provide: DateAdapter, useClass: MomentDateAdapter, deps: [MAT_DATE_LOCALE]},
    {provide: MAT_DATE_FORMATS, useValue: MY_FORMATS},
  ],
})



export class BeatComponent {
  infowindowArray:any
  public entityData: any
  public map: any
  public bounds: any
  public selectedlist: any
  public saerch :any
  public projectMaster:any
  public prjId:any
  public  date = moment()
  public distanceCovered:any
  public routeDistance:any
   public entityname:any
  public zoneNAme:any
  public content1 :any
  public projectInfo:any
  public controlText:any
  public attributeSum:any
  public totalHH:any
  public coveredHH :any
  public totalComm :any
  public coveredComm :any
  public vehicleDiesel :any
  public vehicleElectric :any
  public vehicleManual :any
  public teamOP :any
  public teamUCC :any
  public teamNigam :any
  public zoneName:any
  public wardName:any
  public beatName:any
  public centerControlDiv :any
  public entityDataTemp:any
  public dayDataCollapseWard = [false, false, false, false, false, false];
  public entityGeoJson:any
  public wardStatus;
  public gIndexWard = 0
  public isChecked = true
  public currentZoneWard :any
  constructor(private http: Http,private broadcaster: Broadcaster,private auth:AuthService) {
    this.controlText = document.createElement('div');
    this.centerControlDiv = document.createElement('div');
    this.centerControlDiv.index = 1;
   }

   refreshZoneWard(){
    this.entityData = this.entityDataTemp
     this.zoneName = null
     this.wardName = null
     this.beatName = null
     this.updateControlUi(this.attributeSum)
     this.map.data.forEach((feature) => {
     // if (feature.getProperty('type') == "clickedPolygon") {
        this.map.data.remove(feature);
      //}
    })
    this.removeAllInfoWindow()
    this.map.data.addGeoJson(this.entityGeoJson);
    this.zoomPolygon(this.map);
   }

  processPoints(this, geometry, callback, thisArg) {
    if (geometry instanceof google.maps.LatLng) {
      callback.call(thisArg, geometry);
    } else if (geometry instanceof google.maps.Data.Point) {
      callback.call(thisArg, geometry.get());
    } else {
      if(geometry){
      geometry.getArray().forEach((g) => {
        this.processPoints(g, callback, thisArg);
      });
     }
    }
  }

  zoom(this, map) {
    this.bounds = new google.maps.LatLngBounds();
    map.data.forEach((feature) => {
      if (feature.getProperty('type') == "clickedPolygon" || feature.getProperty('type') == "beatPolygon" ) {
      this.processPoints(feature.getGeometry(), this.bounds.extend, this.bounds);
      }
    });
    map.fitBounds(this.bounds);
  }

  zoomPolygon(this, map) {
    this.bounds = new google.maps.LatLngBounds();
    map.data.forEach((feature) => {
      this.processPoints(feature.getGeometry(), this.bounds.extend, this.bounds);
    });
    map.fitBounds(this.bounds);
  }

  getAllVehicles(d){
    this.http.post(environment.apiUrl + 'zone/vehiclesLocation',d).subscribe(data => {
    let loc  = data.json()
    });
  }
  getCoveredDistance(id){
    var date = moment(this.date).format('YYYY-MM-DD')
    this.http.get(environment.apiUrl + 'getCoverage?id=' + id + "&DEVICEDATE=" + date + "&prjID=" + this.prjId).subscribe(data => {
      this.distanceCovered = data.json().totalDistance
      this.routeDistance = data.json().routeDistance
      $("#coveredInfo").show()
    })
  }

  plotAndGetChildEntity(polygonData){
    if(polygonData.oemid == 7){
       var oemid = 8
       this.zoneName = polygonData.entityname
    }else if(polygonData.oemid == 8){
      var oemid = 9
      this.wardName = polygonData.entityname
    }else if(polygonData.oemid == 9){
      var oemid = 9
      this.beatName = polygonData.entityname
      this.http.get(environment.apiUrl + 'beatAttributeSum?prjId=' + this.prjId + '&entityID= ' + polygonData.id + '&oemID=' + oemid).subscribe(data => {
         let result = data.json()
          this.zoom(this.map);
         this.bindAttributeCount(result.attributeSum)
         this.updateControlUi(result.attributeSum)
       });
       $('#loderImgTab').hide()
       return ;
    }
    this.http.get(environment.apiUrl + 'entityMap?prjId=' + this.prjId + '&entityID= ' + polygonData.id + '&oemID=' + oemid).subscribe(data => {
     // this.clearFeature()
      let result = data.json()
      this.map.data.addGeoJson(result.geoJson);
      this.map.data.setStyle(function (feature) {
        var color = feature.getProperty('FillColor');
        var strokeColor = feature.getProperty('Bcolor')
        var strokeOpacity = feature.getProperty('stroke-opacity')
        if (feature.getProperty('type') == "clickedPolygon") {
          return ({
            fillColor: color,
            strokeColor: color,
            strokeWeight: 7,
            fillOpacity: 0.0,
            strokeopacity: 1,
          });
        }else if (feature.getProperty('type') == "beatPolygon"){
          return ({
            fillColor: color,
            strokeColor: '#6D1E0E',
            strokeWeight: 7,
            fillOpacity: 0.3,
            strokeopacity: 1,
          });
        }
        else{
          return ({
            fillColor: color,
            strokeColor: strokeColor,
            strokeWeight: 3,
            fillOpacity: 0.08,
            strokeopacity: 1,
          });
        }
      });
      this.bindAttributeCount(result.attributeSum)
      this.updateControlUi(result.attributeSum)
   
      this.entityData = result.polygonData
     // this.zoomPolygon(this.map);
      this.zoom(this.map);
      $('#loderImgTab').hide()
    });
  }


  setStyle(){
    this.map.data.setStyle(function (feature) {
      var color = feature.getProperty('FillColor');
      var strokeColor = feature.getProperty('Bcolor')
      var strokeOpacity = feature.getProperty('stroke-opacity')
      if (feature.getProperty('type') == "route") {
        return ({
          fillColor: color,
          strokeColor: strokeColor,
          strokeWeight: 2,
          fillOpacity: 0.2,
          strokeopacity: 0.2,
        });
      }
      if (feature.getProperty('type') == "clickedPolygon") {
        return ({
          fillColor: color,
          strokeColor: '#6D1E0E',
          strokeWeight: 3,
          fillOpacity: 0.17,
          strokeopacity: 1,
        });
      } else if(feature.getProperty('type') == "beatPolygon") {
        return ({
          fillColor: color,
          strokeColor: '#6D1E0E',
          strokeWeight: 4,
          fillOpacity: 0.17,
          strokeopacity: 1,
        });
      }else{
        return ({
          fillColor: color,
          strokeWeight: 2,
          fillOpacity: 0.0,
          strokeopacity: 0.8,
        });
      }
    });
  }
  hideZoneWard(){
    if(this.isChecked  == true){
      this.isChecked  = false
    }else{
      this.isChecked  = true
    }
    if(!this.isChecked){
    this.map.data.forEach((feature) => {
      if (feature.getProperty('type') != "beatPolygon") {
        this.map.data.remove(feature);
      }
    })
    this.isChecked = false
  }else{
    this.map.data.addGeoJson(this.entityGeoJson);
    this.map.data.addGeoJson(this.currentZoneWard);
    this.zoom(this.map);
    this.setStyle()

  }
   
  }

  removeAllInfoWindow(){
    if(this.infowindowArray){
    for(var i=0;i<this.infowindowArray.length;i++){
      this.infowindowArray[i].close()
    }
  }

  }

  plotEntity(thiss, polygonData, index) {
    this.removeAllInfoWindow()
    var array = []
    $('#loderImgTab').show()
    this.entityname = polygonData.entityname
    //this.getCoveredDistance(polygonData.id)
    this.selectedlist = index;
    var data = {
      features: [{ geometry: {}, type: "Feature", properties: "" }], type: ""
    }
    
    var d = JSON.parse(polygonData.kml)
    //this.getAllVehicles(d)
    data.features[0].geometry = d
    var prop = JSON.parse(polygonData.properties)
    if(polygonData.oemid == 9){
      prop.type = "beatPolygon"
    }else{
      prop.type = "clickedPolygon"
      this.currentZoneWard = data
    }
    
    data.features[0].properties = prop
    data.type = "FeatureCollection"
    this.map.data.forEach((feature) => {
      if(feature.getProperty('LAT')){
     
        var infoWindow = new google.maps.InfoWindow();
        array.push(infoWindow)
        var windowLatLng = new google.maps.LatLng(Number(feature.getProperty('LAT')),Number(feature.getProperty('LNG')));
        infoWindow.open(this.map); 
        infoWindow.setOptions({
          content: "<div style ='color:#45B637;font-size:10px'><label> " + feature.getProperty('Beat') +  " <label style ='color:black'></label> </div>",
          position: windowLatLng,
      });
      this.setStyle();
    }
      if (feature.getProperty('type') == "clickedPolygon" || feature.getProperty('type') == "beatPolygon") {
        this.map.data.remove(feature);
       
      }
    })
    this.map.data.addGeoJson(data);
    //this.zoom(this.map);
    this.map.data.setStyle((feature)=> {
      var color = feature.getProperty('FillColor');
      var strokeColor = feature.getProperty('Bcolor')
      
     
   
      var strokeOpacity = feature.getProperty('stroke-opacity')
      if (feature.getProperty('type') == "route") {
        return ({
          fillColor: color,
          strokeColor: strokeColor,
          strokeWeight: 2,
          fillOpacity: 0.2,
          strokeopacity: 0.2,
        });
      }
      if (feature.getProperty('type') == "clickedPolygon") {
        return ({
          fillColor: color,
          strokeColor: color,
          strokeWeight: 7,
          fillOpacity: 0.17,
          strokeopacity: 1,
        });
      } else if(feature.getProperty('type') == "beatPolygon") {
        return ({
          fillColor: color,
          strokeColor: color,
          strokeWeight: 7,
          fillOpacity: 0.17,
          strokeopacity: 1,
        });
      }else{
        return ({
          fillColor: color,
          strokeWeight: 2,
          fillOpacity: 0.0,
          strokeopacity: 0.8,
        });
      }
      
    });
    
    this.plotAndGetChildEntity(polygonData)
    
    this.infowindowArray = array
  }

  clearFeature(){
    this.map.data.forEach((feature) => {
        this.map.data.remove(feature);
   })
  }

   clearFeatureRoute(){
    this.map.data.forEach((feature) => {
      if (feature.getProperty('type') == "route") {
         this.map.data.remove(feature);
      }
    })
   }
  GetDataByProject(prjId){ 
      this.getEntityZoneAndWard(prjId)
}

   searchAreaByDate(){
     let date = moment(this.date).format('YYYY-MM-DD');
     this.getAllVehiclesRouteByProject(moment(this.date).format('YYYY-MM-DD'))
     this.clearFeatureRoute()
   }
 

  getAllVehiclesRouteByProject(date){
    this.http.get(environment.apiUrl + 'vehicles/plotVehiclesByProject' + "?prjId=" + this.prjId + "&date=" + date).subscribe(data => {
       this.map.data.addGeoJson(data.json())
    });
  }
  bindAttributeCount(attributeSum){
    this.totalHH = attributeSum.TotalHH
    this.coveredHH = attributeSum.CoveredHH
    this.totalComm = attributeSum.TotalComm
    this.coveredComm = attributeSum.CoveredComm
    this.vehicleDiesel = attributeSum.VehicleDiesel
    this.vehicleElectric = attributeSum.VehicleElectric
    this.vehicleManual = attributeSum.VehManual
    this.teamOP = attributeSum.TeamOP
    this.teamUCC = attributeSum.TeamUCC
    this.teamNigam = attributeSum.TeamNigam

  }
  getEntityZoneAndWard(prjID) {
    $('#loderImgTab').show()
    this.http.get(environment.apiUrl + 'entityMap?prjId=' + prjID + '&entityID=null&oemID=7').subscribe(data => {
      this.clearFeature()
     // this.getAllVehiclesRouteByProject(moment(this.date).format('YYYY-MM-DD'))
      let result = data.json()
      this.entityGeoJson = result.geoJson
      this.attributeSum = result.attributeSum
      this.bindAttributeCount(result.attributeSum)
      this.CenterControl(this.centerControlDiv, this.map,result.attributeSum)
      this.map.controls[google.maps.ControlPosition.LEFT_CENTER].push(this.centerControlDiv);
      this.map.data.addGeoJson(result.geoJson);
      this.entityData = result.polygonData
      this.entityDataTemp = result.polygonData
      this.zoomPolygon(this.map);
      $('#loderImgTab').hide()
    });
  }

  bindProjectName(project){
    this.prjId =  project.ID
    this.projectInfo = project
  }
  test(){
    console.log("beat is clicked")
  }


  updateControlUi(attributeSum){
    this.totalHH = attributeSum.TotalHH
    this.coveredHH = attributeSum.CoveredHH
    this.totalComm = attributeSum.TotalComm
    this.coveredComm = attributeSum.CoveredComm
    this.vehicleDiesel = attributeSum.VehicleDiesel
    this.vehicleElectric = attributeSum.VehicleElectric
    this.vehicleManual = attributeSum.VehManual
    this.teamOP = attributeSum.TeamOP
    this.teamUCC = attributeSum.TeamUCC
    this.teamNigam = attributeSum.TeamNigam
    var content = []
    content.push('<span  (click) ="test()" class="google-map-info"><label> BEAT : </label> ' + this.beatName + '</span><br>');
    content.push('<span class="google-map-info"><label> WARD : </label> ' + this.wardName + '</span><br>');
    content.push('<span class="google-map-info"><label> ZONE : </label> ' + this.zoneName + '</span><br>');
    content.push('<label>HH  </label> :' + this.coveredHH +'/' + this.totalHH + ' <label>COMM  </label> :' + this.coveredComm + '/' + this.totalComm + ' <br>');
    content.push('<span class="google-map-info"><label style="text-decoration: none; ">Vehicles</label></span><br>');
    content.push('<label> Diesel</label>  - ' +  this.vehicleDiesel + '<br>');
    content.push('<label> Manual</label>  - ' +  this.vehicleElectric  + '<br>');
    content.push('<label> Electric</label> - ' + this.vehicleManual + '<br>');
      //this.controlText.innerHTML = null
      this.controlText.innerHTML = content.join('');

  }

  
  CenterControl(controlDiv, map,attributeSum) {
    this.totalHH = attributeSum.TotalHH
    this.coveredHH = attributeSum.CoveredHH
    this.totalComm = attributeSum.TotalComm
    this.coveredComm = attributeSum.CoveredComm
    this.vehicleDiesel = attributeSum.VehicleDiesel
    this.vehicleElectric = attributeSum.VehicleElectric
    this.vehicleManual = attributeSum.VehManual
    this.teamOP = attributeSum.TeamOP
    this.teamUCC = attributeSum.TeamUCC
    this.teamNigam = attributeSum.TeamNigam
    // Set CSS for the control border.
    var controlUI = document.createElement('table');
    controlUI.style.backgroundColor = '#fff';
    controlUI.style.border = '1px solid #fff';
    controlUI.style.borderRadius = '3px';
    controlUI.style.boxShadow = '0 2px 6px rgba(0,0,0,.3)';
    controlUI.style.cursor = 'pointer';
    controlUI.style.marginBottom = '22px';
    controlUI.style.textAlign = 'top_right';
    controlUI.title = 'Click to recenter the map';
    controlDiv.appendChild(controlUI);
  
    // Set CSS for the control interior.
    this.controlText = document.createElement('div');
    this.controlText.style.color = 'rgb(25,25,25)';
    this.controlText.style.fontFamily = 'Roboto,Arial,sans-serif';
    this.controlText.style.fontSize = '13px';
    this.controlText.style.lineHeight = '15px';
    this.controlText.style.paddingLeft = '3px';
    this.controlText.style.marginLeft = '14px';
    this.controlText.style.paddingRight = '5px';
  
   // controlText.innerHTML = '<span><label> Ward Name </label>:23</span><br> <label>HH  </label> :34/500 <label>COMM.  </label> :55/400';
    controlUI.appendChild(this.controlText);
   
   var  content = []
   content.push('<span (click) ="test()" class="google-map-info"><label> BEAT : </label> ' + this.beatName + '</span><br>');
    content.push('<span class="google-map-info"><label> WARD : </label> ' + this.wardName + '</span><br>');
    content.push('<span class="google-map-info"><label> ZONE : </label> ' + this.zoneName + '</span><br>');
    content.push('<label>HH  </label> :' + this.coveredHH +'/' + this.totalHH + ' <label>COMM  </label> :' + this.coveredComm + '/' + this.totalComm + ' <br>');
    content.push('<span class="google-map-info"><label style="text-decoration: none; ">Vehicles</label></span><br>');
    content.push('<label> Diesel</label>  - ' +  this.vehicleDiesel + '<br>');
    content.push('<label> Manual</label>  - ' +  this.vehicleElectric  + '<br>');
    content.push('<label> Electric</label> - ' + this.vehicleManual + '<br>');
            
      this.controlText.innerHTML = content.join('');

    // Setup the click event listeners: simply set the map to Chicago.
   
    
  
  }
  ngOnInit() {
    var infoWindow
    var lastOpenedInfoWindow
    var lastMarker
    var poly = []
    var thisRef = this
    this.prjId = this.auth.getAuthentication().projectId
    $("#coveredInfo").hide()
    $('#loderImgTab').hide()
   
     this.GetDataByProject(this.prjId)
     
 
   
    this.map = new google.maps.Map(document.getElementById('map'), {
      zoom: 15,
      center: { lat: 28.47769599987369, lng: 77.06160699973178 },
      styles:[
        {
          "elementType": "geometry",
          "stylers": [
            {
              "color": "#f5f5f5"
            }
          ]
        },
        {
          "elementType": "labels.icon",
          "stylers": [
            {
              "visibility": "off"
            }
          ]
        },
        {
          "elementType": "labels.text.fill",
          "stylers": [
            {
              "color": "#616161"
            }
          ]
        },
        {
          "elementType": "labels.text.stroke",
          "stylers": [
            {
              "color": "#f5f5f5"
            }
          ]
        },
        {
          "featureType": "administrative.land_parcel",
          "elementType": "labels.text.fill",
          "stylers": [
            {
              "color": "#bdbdbd"
            }
          ]
        },
        {
          "featureType": "poi",
          "elementType": "geometry",
          "stylers": [
            {
              "color": "#eeeeee"
            }
          ]
        },
        {
          "featureType": "poi",
          "elementType": "labels.text.fill",
          "stylers": [
            {
              "color": "#757575"
            }
          ]
        },
        {
          "featureType": "poi.park",
          "elementType": "geometry",
          "stylers": [
            {
              "color": "#e5e5e5"
            }
          ]
        },
        {
          "featureType": "poi.park",
          "elementType": "labels.text.fill",
          "stylers": [
            {
              "color": "#9e9e9e"
            }
          ]
        },
        {
          "featureType": "road",
          "elementType": "geometry",
          "stylers": [
            {
              "color": "#ffffff"
            }
          ]
        },
        {
          "featureType": "road.arterial",
          "elementType": "labels.text.fill",
          "stylers": [
            {
              "color": "#757575"
            }
          ]
        },
        {
          "featureType": "road.highway",
          "elementType": "geometry",
          "stylers": [
            {
              "color": "#dadada"
            }
          ]
        },
        {
          "featureType": "road.highway",
          "elementType": "labels.text.fill",
          "stylers": [
            {
              "color": "#616161"
            }
          ]
        },
        {
          "featureType": "road.local",
          "elementType": "labels.text.fill",
          "stylers": [
            {
              "color": "#9e9e9e"
            }
          ]
        },
        {
          "featureType": "transit.line",
          "elementType": "geometry",
          "stylers": [
            {
              "color": "#e5e5e5"
            }
          ]
        },
        {
          "featureType": "transit.station",
          "elementType": "geometry",
          "stylers": [
            {
              "color": "#eeeeee"
            }
          ]
        },
        {
          "featureType": "water",
          "elementType": "geometry",
          "stylers": [
            {
              "color": "#c9c9c9"
            }
          ]
        },
        {
          "featureType": "water",
          "elementType": "labels.text.fill",
          "stylers": [
            {
              "color": "#9e9e9e"
            }
          ]
        }
      ],
    zoomControlOptions: {
        position: google.maps.ControlPosition.RIGHT_CENTER
    },
    fullscreenControlOptions:{
        position: google.maps.ControlPosition.RIGHT_CENTER
    }

    });
   
    
    var vtsPoints = []
    infoWindow = new google.maps.InfoWindow;
    this.map.data.setStyle(function (feature) {
      var color = feature.getProperty('FillColor');
      var strokeColor = feature.getProperty('Bcolor')
      var strokeOpacity = feature.getProperty('stroke-opacity')
      return ({
        fillColor: color,
        strokeColor: strokeColor,
        strokeWeight: 1,
        fillOpacity: 0,
        strokeopacity: 0.7,
        content: "AREA_1"
      });
    });

    function removePreveiousMarker() {
      //lastMarker.setMap(null);
    }
    function closeLastOpenedInfoWindow() {
      if (lastOpenedInfoWindow) {
        lastOpenedInfoWindow.close();
      }
    }

    //search box

    let input = document.getElementById('pac-input');
    let searchBox = new google.maps.places.SearchBox(input);
    this.map.controls[google.maps.ControlPosition.TOP_LEFT].push(input);
    // Bias the SearchBox results towards current map's viewport.
  
    var markers = [];
    // Listen for the event fired when the user selects a prediction and retrieve
    // more details for that place.
    searchBox.addListener('places_changed', function (this) {
      let places = searchBox.getPlaces();
      if (places.length == 0) {
        return;
      }
      // Clear out the old markers.
      markers.forEach(function (marker) {
        marker.setMap(null);
      });
      markers = [];
      // For each place, get the icon, name and location.
      let bounds = new google.maps.LatLngBounds();
      places.forEach(function (place) {
        if (!place.geometry) {
          console.log("Returned place contains no geometry");
          return;
        }
        var icon = {
          url: place.icon,
          size: new google.maps.Size(71, 71),
          origin: new google.maps.Point(0, 0),
          anchor: new google.maps.Point(17, 34),
          scaledSize: new google.maps.Size(25, 25)
        };
        // Create a marker for each place.
        markers.push(new google.maps.Marker({
          map: thisRef.map,
          icon: icon,
          title: place.name,
          position: place.geometry.location
        }));
        
        if (place.geometry.viewport) {
          // Only geocodes have viewport.
          bounds.union(place.geometry.viewport);
        } else {
          bounds.extend(place.geometry.location);
        }
      });
      thisRef.map.fitBounds(bounds);
    });

    var controlUI = document.createElement('table');
    controlUI.addEventListener('click', function() {
     console.log("beat is clicked d")
    });

  
     //control

  }

  

}


