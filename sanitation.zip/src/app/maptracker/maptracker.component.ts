import { Component } from '@angular/core';







@Component({
  selector: 'app-maptracker',
  templateUrl: './maptracker.component.html',
  styleUrls: ['./maptracker.component.css'],
})
// export class MaptrackerComponent {
   

// }


export class MaptrackerComponent {
  constructor(
   ) { }

  ngOnInit() {

  }
  
}
