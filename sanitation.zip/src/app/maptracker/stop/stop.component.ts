

import { Component, OnInit } from '@angular/core';
import { Http } from '@angular/http'

import { environment } from '../../../environments/environment';
import { MomentDateAdapter } from '@angular/material-moment-adapter';
import { DateAdapter, MAT_DATE_FORMATS, MAT_DATE_LOCALE } from '@angular/material/core';

import { AuthService } from '../../_services/index';
import { Broadcaster } from '../../../environments/broadcaster';
import * as _moment from 'moment';
import * as _rollupMoment from 'moment';

const moment = _rollupMoment || _moment;
export const MY_FORMATS = {
  parse: {
    dateInput: 'LL',
  },
  display: {
    dateInput: 'LL',
    monthYearLabel: 'MMM YYYY',
    dateA11yLabel: 'LL',
    monthYearA11yLabel: 'MMMM YYYY',
  },
};
declare var MarkerClusterer: any;
declare var $: any;
declare var google: any;

declare var firebase: any;

interface Marker {
  lat: number;
  lng: number;
  label?: string;
  draggable?: boolean;
}

let movie1 = {
  name: 'Star Wars',
  episode: 7
};
var stopAnimation = true



@Component({

  selector: 'controlRoom-cmp',
  templateUrl: './stop.component.html',
  providers: [
    { provide: DateAdapter, useClass: MomentDateAdapter, deps: [MAT_DATE_LOCALE] },
    { provide: MAT_DATE_FORMATS, useValue: MY_FORMATS },
  ],
})


export class StopComponent implements OnInit {
  public entityData: any
  public map: any
  public bounds: any
  public selectedlist: any
  public saerch: any
  public projectMaster: any
  public prjId: any
  public date = moment()
  public allVehicles: any
  public operationSummary: any
  public totalVehicles:any
  public totalStopsCount:any;
  public totalDuration:any;
  public duration:any;

  constructor(private http: Http, private broadcaster: Broadcaster,private auth:AuthService) {
    this.allVehicles = []
    this.duration = 5 +"-" + 15
  }

/*
   get operation summary report
*/

  /*
     download report
  */
  
  downloadReport() {
    let DEVICEDATE = moment(this.date).format('YYYY-MM-DD');
    window.open(environment.apiUrl + "reports/vehicles/stopCount?DEVICEDATE=" + DEVICEDATE + "&PRJID=" + this.prjId);
  }

  /*
     get summary count
  */

  /*
     process each lat long for fit bound
  */
  processPoints(this, geometry, callback, thisArg) {
    if (geometry instanceof google.maps.LatLng) {
      callback.call(thisArg, geometry);
    } else if (geometry instanceof google.maps.Data.Point) {
      callback.call(thisArg, geometry.get());
    } else {
      if (geometry) {
        geometry.getArray().forEach((g) => {
          this.processPoints(g, callback, thisArg);
        });
      }
    }
  }

  /*
     zoom into entity polygon
  */
  zoom(this, map) {
    this.bounds = new google.maps.LatLngBounds();
    map.data.forEach((feature) => {
      if (feature.getProperty('type') == "clickedPolygon") {
        this.processPoints(feature.getGeometry(), this.bounds.extend, this.bounds);
      }
    });
    map.fitBounds(this.bounds);
  }

  /* 
      zoom into particular Zone and Ward
  */
  zoomPolygon(this, map) {
    this.bounds = new google.maps.LatLngBounds();
    map.data.forEach((feature) => {
      this.processPoints(feature.getGeometry(), this.bounds.extend, this.bounds);
    });
    map.fitBounds(this.bounds);
  }

  /*
     plot selected entity polygon (ZONE and WARD)
  */
 setStyle() {
  this.map.data.setStyle(function (feature) {
    var color = feature.getProperty('FillColor');
    var strokeColor = feature.getProperty('Bcolor')
    var strokeOpacity = feature.getProperty('stroke-opacity')
    if (feature.getProperty('type') != "route") {
    
      return ({
        fillColor: color,
        strokeColor: strokeColor,
        strokeWeight: 2,
        fillOpacity: 0.05,
        icon:'assets/img/stopPoint.png',
        strokeopacity: 0.2,
      });
    } else {
      return ({
        fillColor: color,
        strokeColor: strokeColor,
        strokeWeight: 5,
        fillOpacity: 0.0,
        strokeopacity: 0.2,
        icon:'assets/img/stopPoint.png',
      });
    }
  });
}

   getStopVehiclesCount(entityId,duration){
    $('#totalVehicles').show()
    let date = moment(this.date).format('YYYY-MM-DD');
    this.http.get(environment.apiUrl + 'getStopVehiclesCount' + "?PRJID=" + this.prjId + "&DEVICEDATE=" + date + "&entityId=" + entityId + "&duration=" + duration).subscribe(data => {
        this.totalVehicles = data.json().count
        $('#totalVehicles').hide()
    });
  }

   searchByDuration(event){
    if(event.keyCode == 13){
     this.reload()
     }
   }
   
  plotEntity(thiss, polygonData, index) {
    this.selectedlist = index;
    this.getAllStopPoint(this.prjId,polygonData.id,this.duration)
    this.getStopVehiclesCount(polygonData.id,this.duration)
    
    var data = {
      features: [{ geometry: {}, type: "Feature", properties: "" }], type: ""
    }
    var d = JSON.parse(polygonData.kml)
    data.features[0].geometry = d
    var prop = JSON.parse(polygonData.properties)
    prop.type = "clickedPolygon"
    data.features[0].properties = prop
    data.type = "FeatureCollection"
    this.map.data.forEach((feature) => {
      if (feature.getProperty('type') == "clickedPolygon") {
        this.map.data.remove(feature);
      }
    })
    this.map.data.addGeoJson(data);
    this.zoom(this.map);
    this.map.data.setStyle(function (feature) {
      var color = feature.getProperty('FillColor');
      var strokeColor = feature.getProperty('Bcolor')
      var strokeOpacity = feature.getProperty('stroke-opacity')
      if (feature.getProperty('type') == "clickedPolygon") {
        return ({
          fillColor: '#A3BB1B',
          strokeColor: strokeColor,
          strokeWeight: 3,
          fillOpacity: 0.5,
          strokeopacity: 0.8,
          icon:'assets/img/stopPoint.png',
        });
      } else {
        return ({
          fillColor: color,
          strokeWeight: 2,
          fillOpacity: 0.0,
          strokeopacity: 0.8,
          icon:'assets/img/stopPoint.png',
        });
      }
    });
  }

  /*
     clear All feature from map
  */
  clearFeature() {
    this.map.data.forEach((feature) => {
      this.map.data.remove(feature);
    })

  }
  GetDataByProject(prjId) {
    $('#progress-bar').show()
    if (prjId) {
      this.getPoints(prjId)
      this.getStopVehiclesCount(null,this.duration)
    }
  }



  /*
      plot all Entity polygon Zone and Ward boundary
  */
  getPoints(prjID) {
    $('#loderImgTab').show()
    this.http.get(environment.apiUrl + 'entity/getPolygon' + "?prjid=" + prjID).subscribe(data => {
      this.clearFeature()
      this.map.data.addGeoJson(data.json().geoJson);
      this.entityData = data.json().polygonData
      this.zoomPolygon(this.map);
      this.getAllStopPoint(this.prjId,null,this.duration)
      $('#loderImgTab').hide()
    });
  }

 /*
    Get All Stop location
 */
diff_hours(dt2, dt1){
  var difference = dt1.getTime() - dt2.getTime(); // This will give difference in milliseconds
  var resultInMinutes = Math.round(difference / 60000);
  var hours = (resultInMinutes / 60);
  var rhours = Math.floor(hours);
  var minutes = (hours - rhours) * 60;
  var rminutes = Math.round(minutes);
    return rhours + ": " + rminutes
 }

clearStopMarker() {
  this.map.data.forEach((feature) => {
    if (feature.getProperty('TYPE') == "stopMarker") {
      this.map.data.remove(feature);
    }
  })
}
  getAllStopPoint(prjID,entityId,duration) {
    $('#totalStopsCount').show()
    $('#totalDuration').show()
    this.clearStopMarker()
    let date = moment(this.date).format('YYYY-MM-DD');
      this.http.get(environment.apiUrl + 'getAllStopPoint' + "?PRJID=" + prjID + "&DEVICEDATE=" + date + "&entityId=" + entityId + "&duration=" + duration).subscribe(data => {
       this.map.data.addGeoJson(data.json().geoJson);
       this.totalStopsCount = data.json().totalCount;
       this.totalDuration = data.json().totalDuration;
       this.setStyle()
       $('#totalStopsCount').hide()
       $('#totalDuration').hide()
       $('#progress-bar').hide()
      $('#loderImgTab').hide()
  });
 }

 


  /*
      remove all ploted vehicles
  */
  renoveAllMarker() {
    if (this.allVehicles.length > 0) {
      for (var i = 0; i < this.allVehicles.length; i++) {
        this.allVehicles[i].setMap(null);
      }
    }
  }

  reload(){
    this.GetDataByProject(this.prjId)
  }

  /*
     plot all vehicles on map
  */


  ngOnInit() {
    var infoWindow
    var lastOpenedInfoWindow
    var lastMarker
    var poly = []
    var thisRef = this
    $('#loderImgTab').hide()


    this.map = new google.maps.Map(document.getElementById('map'), {
      zoom: 15,
      center: { lat: 28.47769599987369, lng: 77.06160699973178 },
    });
    $('#totalVehicles').hide()
    $('#totalStopsCount').hide()
    $('#totalDuration').hide()
    this.prjId = this.auth.getAuthentication().projectId
    this.GetDataByProject(this.prjId)
    var vtsPoints = []
    infoWindow = new google.maps.InfoWindow;
    this.map.data.setStyle(function (feature) {
      var color = feature.getProperty('FillColor');
      var strokeColor = feature.getProperty('Bcolor')
      var strokeOpacity = feature.getProperty('stroke-opacity')
      return ({
        fillColor: color,
        strokeColor: strokeColor,
        strokeWeight: 1,
        fillOpacity: 0,
        strokeopacity: 0.7,
        content: "AREA_1"
      });
    });
    this.map.data.addListener('click', showArrays);

    // show info window
    function showArrays(event) {
      closeLastOpenedInfoWindow();
      removePreveiousMarker()
      var position = { lat: event.latLng.lat(), lng: event.latLng.lng() }
      var content = '<div>' +
      '<div><div><p><strong>DEVICEID : </strong>' + event.feature.getProperty('DEVICEID') + '</p><p><strong>VEHICLE NO : </strong> ' + event.feature.getProperty('VEHICLE_NO') + '</p><p><strong>STARTTIME : </strong>' + event.feature.getProperty('STARTTIME') + '</p>'
      + '<p><strong>ENDTIME : </strong>' + event.feature.getProperty('ENDTIME') + '</p>'
      + '<p><strong>DURATION : </strong>' + event.feature.getProperty('DURATION') + '</p>'
      + '<p><strong>ZONE : </strong>' + event.feature.getProperty('ZONE') + '</p>'
      + '<p><strong>WARD : </strong>' + event.feature.getProperty('WARD') + '</p>'
      +'</div></div>'
      infoWindow = new google.maps.InfoWindow({
        content: content,
        position: position,
      });

      google.maps.InfoWindowOptions
      var marker = new google.maps.Marker({
        position: position,
        map: this.map,
        zoom: 16,
        visible: false,
      });
      infoWindow.open(this.map);
      lastOpenedInfoWindow = infoWindow;


      /* Since this div is in a position prior to .gm-div style-iw.
       * We use jQuery and create a iwBackground variable,
       * and took advantage of the existing reference .gm-style-iw for the previous div with .prev().
      */
     

    }

    function removePreveiousMarker() {
      //lastMarker.setMap(null);
    }
    function closeLastOpenedInfoWindow() {
      if (lastOpenedInfoWindow) {
        lastOpenedInfoWindow.close();
      }
    }

    //search box

    let input = document.getElementById('pac-input');
    let searchBox = new google.maps.places.SearchBox(input);
    this.map.controls[google.maps.ControlPosition.TOP_LEFT].push(input);
    // Bias the SearchBox results towards current map's viewport.

    var markers = [];
    // Listen for the event fired when the user selects a prediction and retrieve
    // more details for that place.
    searchBox.addListener('places_changed', function (this) {
      let places = searchBox.getPlaces();
      if (places.length == 0) {
        return;
      }
      // Clear out the old markers.
      markers.forEach(function (marker) {
        marker.setMap(null);
      });
      markers = [];
      // For each place, get the icon, name and location.
      let bounds = new google.maps.LatLngBounds();
      places.forEach(function (place) {
        if (!place.geometry) {
          console.log("Returned place contains no geometry");
          return;
        }
        var icon = {
          url: place.icon,
          size: new google.maps.Size(71, 71),
          origin: new google.maps.Point(0, 0),
          anchor: new google.maps.Point(17, 34),
          scaledSize: new google.maps.Size(25, 25)
        };
        // Create a marker for each place.
        markers.push(new google.maps.Marker({
          map: thisRef.map,
          icon: icon,
          title: place.name,
          position: place.geometry.location
        }));

        if (place.geometry.viewport) {
          // Only geocodes have viewport.
          bounds.union(place.geometry.viewport);
        } else {
          bounds.extend(place.geometry.location);
        }
      });
      thisRef.map.fitBounds(bounds);
    });

  }


}



