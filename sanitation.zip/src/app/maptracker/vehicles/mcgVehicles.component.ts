

import { Component, OnInit } from '@angular/core';
import { Http } from '@angular/http'

import { environment } from '../../../environments/environment';
import { MomentDateAdapter } from '@angular/material-moment-adapter';
import { DateAdapter, MAT_DATE_FORMATS, MAT_DATE_LOCALE } from '@angular/material/core';

import { Observable } from 'rxjs/Rx';
import { ActivatedRoute, Router } from '@angular/router';
import { AuthService } from '../../_services/index';
import { utils, write, WorkBook } from 'xlsx';
import { saveAs } from 'file-saver';
import { Broadcaster } from '../../../environments/broadcaster';
import { LoaderService } from '../../_services/loader.service';

import * as _moment from 'moment';
import * as _rollupMoment from 'moment';
const moment = _rollupMoment || _moment;
export const MY_FORMATS = {
  parse: {
    dateInput: 'LL',
  },
  display: {
    dateInput: 'LL',
    monthYearLabel: 'MMM YYYY',
    dateA11yLabel: 'LL',
    monthYearA11yLabel: 'MMMM YYYY',
  },
};
declare var $: any;
declare var google: any;
declare var firebase: any;
declare var MapLabel:any
var stopAnimation = true

declare const MarkerClusterer;

@Component({

  selector: 'mcgVehicles-cmp',
  templateUrl: './mcgVehicles.component.html',
  providers: [
    { provide: DateAdapter, useClass: MomentDateAdapter, deps: [MAT_DATE_LOCALE] },
    { provide: MAT_DATE_FORMATS, useValue: MY_FORMATS },
  ],
})


export class mcgVehiclesComponent implements OnInit {
  public polyline_array;
  IEMI: any;
  VEHNO: any;
  mapLabelArray:any;
  public drivingSummary: any
  public projectID: any
  public project: any
  public map: any
  public projectMaster: any
  public vehiclesData: any
  public selectedlist: number
  public vehiclesLocation: any
  public vehiclesRoute: any
  public search: any
  public selectedProjectId: any
  public PRJNAME: any
  public polygondData: any
  public prjID: any
  public date = moment()
  public latlongs = []
  all: any
  inactive: any
  notmoving: any
  active: any
  live: any
  offline: any
  old: any
  mismatch = 0
  notInDbAndLiveArray = []
  notInDbAndOfflineArray = []
  deadAndLive: any
  notInDbAndLive = 0
  notInDbAndOffline = 0
  dead: any
  routePath: any
  inactiveArray = []
  activeArray = []
  liveArray = []
  offlineArray = []
  oldArray = []
  mismatchArray = []
  notmovingArray = []
  deadArray = []
  dataWithoutDead = []
  activeAndLive = []
  vehiclesDataTemp: any
  isLive: any
  a = [];
  route: any
  markerStart: any
  markerEnd: any
  currentVehiclesData: any
  vehiclesNo: any
  IMEI: any
  vehiclesType: any
  mobileNo: any
  startTime: any
  endTime: any
  geocoder: any
  currentAddress: any
  Liveroute: any
  distance: any
  stopAnimation: any
  allMarkers = []
  autoTicks = false;
  disabled = false;
  invert = false;
  max = 1000;
  public value: any
  min = 0;
  showTicks = false;
  step = 1;
  thumbLabel = false;
  position = [43, -89];
  vertical = false;
  counter: any
  public icon: any
  totalStop: any;
  totalDuration: any;
  vechicleListIsClicked: any;
  servingWardName: any;
  servingBeat: any;
  stopSummary: any;
  totalStopBeat: any;
  wardBoundary: any;
  beatBoundary: any;
  polygon: any;
  infoWindowStart: any;
  infoWindowEnd: any;
  controlText: any;
  centerControlDiv: any;
  vehicleCluster: any;
  markerCluster: any;
  deadVehicleSummary: any;
  notRunningSince15Days: any;
  notRunningSince10Days: any;
  notRunningSince5Days: any;
  notRunningSince2Days: any;
  notRunningSince15DaysArray: any;
  notRunningSince10DaysArray: any;
  notRunningSince5DaysArray: any;
  notRunningSince2DaysArray: any;
  deadVehicleList: any;
  selectedDeadList: any;
  searchDeadList: any;
  runningVehiclesByType: any;
  isStats: any;
  totalWorking: any;
  totalAvilable: any;
  showLoader: any;
  isClickedVehicle: any;
  vehicleInfoWindow: any;
  vehicleInfoWindowClicked: any
  plotSecondary: any;

  plotKhattaPoint:any
  plotParking:any;
  plotFCTS:any
  plotMTS:any
  plotBins:any


  secondaryPointData: any;
  secPointMarker: any
  wardPolygonList: any;
  vehicleInWard:any;
  lastActiveTime:any;
  fuelTypeCount:any;
  constructor(private auth: AuthService, private http: Http, private loaderService: LoaderService, private routes: ActivatedRoute, private broadcaster: Broadcaster, private router: Router, ) {
    this.vehicleInfoWindow = new google.maps.InfoWindow();
    this.vehicleInfoWindowClicked = new google.maps.InfoWindow();
    this.value = 300
    this.polyline_array = []
    this.secPointMarker = []
    this.vehicleInWard = []
    this.mapLabelArray = []
    this.plotSecondary = false
    this.fuelTypeCount = null
    this.prjID = this.auth.getAuthentication().projectId
    var car = "M17.402,0H5.643C2.526,0,0,3.467,0,6.584v34.804c0,3.116,2.526,5.644,5.643,5.644h11.759c3.116,0,5.644-2.527,5.644-5.644 V6.584C23.044,3.467,20.518,0,17.402,0z M22.057,14.188v11.665l-2.729,0.351v-4.806L22.057,14.188z M20.625,10.773 c-1.016,3.9-2.219,8.51-2.219,8.51H4.638l-2.222-8.51C2.417,10.773,11.3,7.755,20.625,10.773z M3.748,21.713v4.492l-2.73-0.349 V14.502L3.748,21.713z M1.018,37.938V27.579l2.73,0.343v8.196L1.018,37.938z M2.575,40.882l2.218-3.336h13.771l2.219,3.336H2.575z M19.328,35.805v-7.872l2.729-0.355v10.048L19.328,35.805z";
    this.icon = {
      path: car,
      scale: .5,
      strokeColor: 'white',
      strokeWeight: .10,
      fillOpacity: 1,
      fillColor: '#404040',
      offset: '3%',
      // rotation: parseInt(heading[i]),
      anchor: new google.maps.Point(10, 25) // orig 10,50 back of car, 10,0 front of car, 10,25 center of car
    };

    this.controlText = document.createElement('div');
    this.centerControlDiv = document.createElement('div');
    this.centerControlDiv.index = 1;
    this.loaderService.status.subscribe((val: boolean) => {
      this.showLoader = val;
    });
  }

  mergeVechiclesData(mongodbData, sqlData) {
    for (var i = 0; i < this.vehiclesData.length; i++) {
      if( this.vehiclesData[i].FUELTYPE == 'Diesel'){
        this.fuelTypeCount.total.diesel++
      }else if( this.vehiclesData[i].FUELTYPE == 'Electric'){
        this.fuelTypeCount.total.electric++
      }
      else if( this.vehiclesData[i].FUELTYPE == 'Manual'){
        this.fuelTypeCount.total.manual++
      }


      for (var j = 0; j < this.vehiclesLocation.length; j++) {
        if (this.vehiclesData[i].IMEI == this.vehiclesLocation[j].DEVICEID) {
          this.vehiclesLocation[j].VEHNO = this.vehiclesData[i].vehno
          var d = this.vehiclesLocation[j].LASTACTIVE
          this.vehiclesLocation[j].LASTACTIVEDATE =   moment(new Date(d)).format('LTS');
          this.vehiclesLocation[j].FUELTYPE =  this.vehiclesData[i].FUELTYPE
        }
      }
    }
  }



  getDataWhenProjectChange = async (id) => {
    $('#loderImgTab').show()
    this.renoveAllMarker()
    let polygon = await fetch(environment.apiUrl + 'entity/getPolygonByOemId' + "?prjid=" + id + "&wardOemId=null" + "&beatOemId=null")
    this.polygondData = await polygon.json()
    this.clearFeature()
    this.map.data.addGeoJson(this.polygondData.geoJson);
    this.zoom(this.map, true);
    this.setStyle(this)

    let vehicles = await fetch(environment.apiUrl + 'vehicles/location/all' + '?prjID=' + id)
    this.vehiclesLocation = await vehicles.json()

    this.plotAllVehicles(this.vehiclesLocation)
    let vehiclesDetail = await fetch(environment.apiUrl + 'vehicles/detail' + '?prjId=' + id)
    this.vehiclesData = await vehiclesDetail.json()
    $('#loderImgTab').hide()
    console.log(this.vehiclesData)
   
    this.mergeVechiclesData(this.vehiclesLocation, this.vehiclesData)

    this.vehiclesDataTemp = this.vehiclesData
    this.clearPrevCount()


    this.getStatusCount(this.vehiclesData)
    this.getMisMatchCount(this.vehiclesData, this.vehiclesLocation)
    this.getDeadCount(this.activeArray, this.dataWithoutDead)
    this.getDeadAndLiveCount(this.deadArray, this.vehiclesLocation)
    this.findLiveInNotInDbArray(this.mismatchArray)

    this.currentStatus(this.dataWithoutDead)

    this.mergeVehicleStatus(this.vehiclesLocation, this.vehiclesData)

    this.getAllKhatta(id)

     this.getStatusData('live')

    $('#loderImgTab').hide()
    $('#progress-bar').hide()
  }

  getStatus(mongodb,id){
    var d1 = new Date();
    var d3 = new Date();
    var found = false
    for(var j = 0;j<mongodb.length;j++){
      if(id == Number(mongodb[j].IMEI)){
        found = true
        if (d3.setHours(0) < new Date(mongodb[j].HEARTBEATDATE).getTime()) {
          if (new Date(mongodb[j].HEARTBEATDATE).getTime() < d1.setHours(d1.getHours() - 2)) {
           
            d3 = new Date();
            d1 = new Date();
            if(mongodb[j].FUELTYPE == 'Diesel'){
              this.fuelTypeCount.offline.diesel++
            }else if(mongodb[j].FUELTYPE == 'Electric'){
              this.fuelTypeCount.offline.electric++
            }
            else if(mongodb[j].FUELTYPE == 'Manual'){
              this.fuelTypeCount.offline.manual++
            }
            return "OFFLINE"
          }
          else {
           
            if(mongodb[j].FUELTYPE == 'Diesel'){
              this.fuelTypeCount.live.diesel++
            }else if(mongodb[j].FUELTYPE == 'Electric'){
              this.fuelTypeCount.live.electric++
            }
            else if(mongodb[j].FUELTYPE == 'Manual'){
              this.fuelTypeCount.live.manual++
            }
            d1 = new Date();
            d3 = new Date();
            return "LIVE"
          }
        }
      }
    }
    if(!found){
     
      return "NOT RUNNING"
    }
  }
  mergeVehicleStatus(mongodb,sql){
    for(var i = 0;i<sql.length;i++){
      sql[i].STATUS = this.getStatus(mongodb,sql[i].IMEI)
    
    }
    for(var i = 0;i<this.mismatchArray.length;i++){
      sql.push({STATUS:"NOT IN DB(LIVE)",IMEI:this.mismatchArray[i].IMEI})
    }

  }
  refreshVechiclesLocation = async () => {
    if (!this.liveTrack) {
      let vehicles = await fetch(environment.apiUrl + 'vehicles/location/all' + '?prjID=' + this.prjID)
      this.vehiclesLocation = await vehicles.json()
      let vehiclesDetail = await fetch(environment.apiUrl + 'vehicles/detail' + '?prjId=' + this.prjID)
      this.vehiclesData = await vehiclesDetail.json()
      this.mergeVechiclesData(this.vehiclesLocation, this.vehiclesData)
      this.plotAllVehicles(this.vehiclesLocation)
      this.vehiclesDataTemp = this.vehiclesData
      this.clearPrevCount()
      this.getCurrentDataStatus(this.vehiclesLocation)
      this.getStatusCount(this.vehiclesData)
      this.getMisMatchCount(this.vehiclesData, this.vehiclesLocation)
      this.getDeadCount(this.vehiclesData, this.vehiclesLocation)
    }
  }


  clearPrevCount() {
    this.inactive = 0
    this.active = 0
    this.live = 0
    this.offline = 0
    this.old = 0
    this.mismatch = 0
    this.dead = 0
    this.notmoving = 0
  }
  filterbtn() {
    $('#filterModal').modal('show');
  }
  getStatusData(status) {
    $('#loderImgTab').show()
    this.vehiclesData = []
    if (status == "live") {
      this.vehiclesData = this.liveArray
    } else if (status == "offline") {
      this.vehiclesData = this.offlineArray
    } else if (status == "active") {
      this.vehiclesData = this.activeArray
    } else if (status == "inactive") {
      this.vehiclesData = this.inactiveArray
    } else if (status == "dead") {
      this.vehiclesData = this.deadArray
    } else if (status == "old") {
      this.vehiclesData = this.oldArray
    }
    else if (status == "mismatch") {
      this.vehiclesData = this.mismatchArray
    }
    else if (status == "all") {
      this.vehiclesData = this.vehiclesDataTemp
    } else if (status == "notmoving") {
      this.vehiclesData = this.notmovingArray
    }
    $('#loderImgTab').hide()
  }

//  vehicle fuel type  count

getFuelYypeCount(){
  this.fuelTypeCount = {
    total:{
      diesel:0,
      electric:0,
      manual:0
    },
    inactive:{
      diesel:0,
      electric:0,
      manual:0
    },
    active:{
      diesel:0,
      electric:0,
      manual:0
    },
    live:{
      diesel:0,
      electric:0,
      manual:0
    },
    offline:{
      diesel:0,
      electric:0,
      manual:0
    },
    notrunning:{
      diesel:0,
      electric:0,
      manual:0
    }
  }
}


  findLiveInNotInDbArray(data) {
    var d1 = new Date();
    var d3 = new Date();
    this.liveArray = []
    this.notInDbAndOfflineArray = []
    this.notInDbAndLiveArray = []
    d3.setHours(0);
    let notInDbAndOffline = 0
    let notInDbAndLive = 0
    d1.setHours(d1.getHours() - 2);
    data.forEach((element) => {
      var d2 = new Date(element.DATE).getTime();
      if (d3.setHours(0) < new Date(element.HEARTBEATDATE).getTime()) {
        if (new Date(element.HEARTBEATDATE).getTime() < d1.setHours(d1.getHours() - 2)) {
          notInDbAndOffline++
          element.STATUS = "OFFLINE"
          this.notInDbAndOfflineArray.push(element)
          d3 = new Date();
          d1 = new Date();
        }
        else {
          notInDbAndLive++
          element.STATUS = "LIVE"
          this.notInDbAndLiveArray.push(element)
          d1 = new Date();
          d3 = new Date();
        }
      }
    });
    this.notInDbAndOffline = notInDbAndOffline
    this.notInDbAndLive = notInDbAndLive

  }
  getDeadAndLiveCount(dead, allLive) {
    var deadAndLive = []
    for (var i = 0; i < dead.length; i++) {
      for (var j = 0; i < allLive.length; i++) {
        if (allLive[i].DEVICEID == dead[j].IMEI) {
          deadAndLive.push(allLive[i])
        }
      }
      this.deadAndLive = deadAndLive
    }
  }
  getMisMatchCount(sqlDb, currentData) {
    var mismatch = 0
    var dataWithoutDead = []
    this.mismatchArray = []
    for (var i = 0; i < currentData.length; i++) {
      currentData[i].IMEI = currentData[i].DEVICEID
      var found = false
      for (var j = 0; j < sqlDb.length; j++) {
        if (currentData[i].DEVICEID == sqlDb[j].IMEI) {
          found = true
          dataWithoutDead.push(currentData[i])
        } else { }
      }
      if (!found) {
        mismatch++
        currentData[i].STATUS = "NOT IN DB"
        this.mismatchArray.push(currentData[i])
      }
    }
    this.dataWithoutDead = dataWithoutDead
    this.mismatch = mismatch
  }
  getDeadCount(sqlDb, currentData) {
    var dead = 0
    var activeAndLive = []
    this.deadArray = []
    for (var i = 0; i < sqlDb.length; i++) {
      var found = false
      for (var j = 0; j < currentData.length; j++) {
        if (sqlDb[i].IMEI == currentData[j].DEVICEID) {
          found = true
          activeAndLive.push(sqlDb[i])
          break;
        }
      }
      if (!found) {
        dead++
        sqlDb[i].STATUS = "NOT RUNNING"
        if( sqlDb[i].STATUS == "NOT RUNNING"){
          if(sqlDb[i].FUELTYPE == 'Diesel'){
            this.fuelTypeCount.notrunning.diesel++
          }else if(sqlDb[i].FUELTYPE == 'Electric'){
            this.fuelTypeCount.notrunning.electric++
          }
          else if(sqlDb[i].FUELTYPE == 'Manual'){
            this.fuelTypeCount.notrunning.manual++
          }
        }
        this.deadArray.push(sqlDb[i])
      }
    }
    this.activeAndLive = activeAndLive
    this.dead = dead
  }
  currentStatus(data) {
    var d1 = new Date();
    var d3 = new Date();
    this.liveArray = []
    this.offlineArray = []
    this.oldArray = []
    d3.setHours(0);
    let live = 0
    let offline = 0
    let old = 0
    let notmoving = 0
    d1.setHours(d1.getHours() - 2);
    data.forEach((element) => {
      var d2 = new Date(element.DATE).getTime();
      if (new Date(element.HEARTBEATDATE).getTime() < d1.setHours(d1.getHours() - 2)) {
        offline++
        element.STATUS = "OFFLINE"
        this.offlineArray.push(element)
        d3 = new Date();
        d1 = new Date();
      }
      else {
        live++
        element.STATUS = "LIVE"
        this.liveArray.push(element)
        d1 = new Date();
        d3 = new Date();
      }
      if (new Date(element.SYSTEMDATE).getDate() < new Date(element.HEARTBEATDATE).getDate()) {
        notmoving++
        let data = element
        data.STATUS = "NOTMOVING"
        this.notmovingArray.push(data)
        d3 = new Date();
        d1 = new Date();
      }

    });

    var actualLive = live - ((live + offline + this.dead) - this.active)
    this.old = old
    this.live = actualLive
    this.offline = offline
    this.notmoving = notmoving
  }
  getCurrentDataStatus(data) {
    var d1 = new Date();
    var d3 = new Date();
    this.liveArray = []
    this.offlineArray = []
    this.oldArray = []
    d3.setHours(0);
    let live = 0
    let offline = 0
    let old = 0
    let notmoving = 0
    d1.setHours(d1.getHours() - 2);
    data.forEach((element) => {
      var d2 = new Date(element.DATE).getTime();
      if (d3.setHours(0) < new Date(element.HEARTBEATDATE).getTime()) {
        if (new Date(element.HEARTBEATDATE).getTime() < d1.setHours(d1.getHours() - 2)) {
          offline++
          element.STATUS = "OFFLINE"
          this.offlineArray.push(element)
          d3 = new Date();
          d1 = new Date();
        }
        else {
          live++
          element.STATUS = "LIVE"
          this.liveArray.push(element)
          d1 = new Date();
          d3 = new Date();
        }
        if (new Date(element.SYSTEMDATE).getDate() < new Date(element.HEARTBEATDATE).getDate()) {
          notmoving++
          let data = element
          data.STATUS = "NOTMOVING"
          this.notmovingArray.push(data)
          d3 = new Date();
          d1 = new Date();
        }
      } else {
        d1 = new Date();
        d3 = new Date();
        old++
        element.STATUS = "OLD"
        this.oldArray.push(element)

      }
    });
    this.old = old
    this.live = live
    this.offline = offline
    this.notmoving = notmoving
  }

  getStatusCount(data) {
    var inactive = 0
    var active = 0
    this.activeArray = []
    this.inactiveArray = []
    this.all = data.length
    data.forEach((element) => {
      if (!element.IMEI) {
        inactive++
        element.STATUS = "INACTIVE"
        if(element.FUELTYPE == 'Diesel'){
          this.fuelTypeCount.inactive.diesel++
        }else if(element.FUELTYPE == 'Electric'){
          this.fuelTypeCount.inactive.electric++
        }
        else if(element.FUELTYPE == 'Manual'){
          this.fuelTypeCount.inactive.manual++
        }
        this.inactiveArray.push(element)
      }
      if (element.IMEI) {
        active++
        element.STATUS = "ACTIVE"

        if(element.FUELTYPE == 'Diesel'){
          this.fuelTypeCount.active.diesel++
        }else if(element.FUELTYPE == 'Electric'){
          this.fuelTypeCount.active.electric++
        }
        else if(element.FUELTYPE == 'Manual'){
          this.fuelTypeCount.active.manual++
        }
        this.activeArray.push(element)
      }
    });
    this.inactive = inactive
    this.active = active
  }


  liveTrack() {
    if (this.isLive) {
      this.isLive = false
    } else {
      this.renoveAllMarker()
      this.route.setMap(null)
      this.plotRouteWhenLiveTrack()
      this.isLive = true
    }
  }

  deleteMarker(id, mylatlongs) {

    if (this.allMarkers.length > 0) {
      for (var i = 0; i < this.allMarkers.length; i++) {
        if (this.allMarkers[i].id == id) {
          if (this.isLive) {
            this.plotTransition(this.allMarkers[i], mylatlongs, id)
            this.allMarkers.splice(i, 1)
          }
          // this.allMarkers[i].setPosition(mylatlongs);


        }
      }
    }
  }

  renoveAllMarker() {
    if (this.allMarkers.length > 0) {
      for (var i = 0; i < this.allMarkers.length; i++) {
        this.allMarkers[i].setVisible(false);
      }
    }
  }
  plotTransition(startMarker, endMarker, id) {
    var last = startMarker.position.lat() + "," + startMarker.position.lng()
    var first = endMarker.lat() + "," + endMarker.lng()
    this.http.get(environment.apiUrl + 'vehicles/transition' + '?first=' + last + "&last=" + first).subscribe(data => {
      let result = data.json()
      this.autoRefreshLiveData(this.map, data.json().overview_polyline, id);
    });

  }
  plotMarker(point, DEVICEID, DEVICEDATE) {
    var car = "M17.402,0H5.643C2.526,0,0,3.467,0,6.584v34.804c0,3.116,2.526,5.644,5.643,5.644h11.759c3.116,0,5.644-2.527,5.644-5.644 V6.584C23.044,3.467,20.518,0,17.402,0z M22.057,14.188v11.665l-2.729,0.351v-4.806L22.057,14.188z M20.625,10.773 c-1.016,3.9-2.219,8.51-2.219,8.51H4.638l-2.222-8.51C2.417,10.773,11.3,7.755,20.625,10.773z M3.748,21.713v4.492l-2.73-0.349 V14.502L3.748,21.713z M1.018,37.938V27.579l2.73,0.343v8.196L1.018,37.938z M2.575,40.882l2.218-3.336h13.771l2.219,3.336H2.575z M19.328,35.805v-7.872l2.729-0.355v10.048L19.328,35.805z";
    var lineSymbol = {
      path: car,
      scale: .7,
      strokeColor: 'white',
      strokeWeight: .10,
      fillOpacity: 1,
      fillColor: '#0B0104',
      offset: '5%',
      anchor: new google.maps.Point(10, 25) // orig 10,50 back of car, 10,0 front of car, 10,25 center of car
    };
    this.markerStart = new google.maps.Marker({
      position: point,
      map: this.map,
      icon: lineSymbol,
      title: DEVICEID + "(" + DEVICEDATE + ")"
    });
    this.markerStart.id = DEVICEID;
    this.markerStart.setMap(this.map);
    this.allMarkers.push(this.markerStart);
  }


  transition(result) {
    var i = 0;
    var deltaLat = (result[0] - this.position[0]) / 100;
    var deltaLng = (result[1] - this.position[1]) / 100;
    this.moveMarker(deltaLat, deltaLng);
  }

  moveMarker(deltaLat, deltaLng) {
    this.position[0] += deltaLat;
    this.position[1] += deltaLng;
    var latlng = new google.maps.LatLng(this.position[0], this.position[1]);
    this.markerStart.setPosition(latlng);
    var i = 0
    if (i != 100) {
      i++;
      setTimeout(this.moveMarker, 10);
    }
  }


  plotAllVehicles(data) {
    var locations = []
    var thisRef = this
    var infoWindow = new google.maps.InfoWindow;
    var bounds = new google.maps.LatLngBounds();
    var icon
    var labels = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
    if (this.markerCluster) {
      this.markerCluster.clearMarkers();
    }

    this.renoveAllMarker()
    var markers = []
    for (var i = 0; i < data.length; i++) {
      if (data[i].vehtypname == "Tractor") {
        icon = 'assets/img/tractor.png'
      } else if (data[i].vehtypname == "Tipper" || data[i].vehtypname == "Bolero" || data[i].vehtypname == "TATA-Zip-XL" || data[i].vehtypname == "TATA-Zip") {
        icon = 'assets/img/triper.png'
      } else if (data[i].vehtypname == "Hyva") {
        icon = 'assets/img/hyva.png'
      }
      else if (data[i].vehtypname == "JCB 2DX" || data[i].vehtypname == "JCB 3DX") {
        icon = 'assets/img/jcb.png'
      } else if (data[i].vehtypname == "Refuse Compactor") {
        icon = 'assets/img/refuseCompactor.png'
      } else if (data[i].vehtypname == "Hook Loader") {
        icon = 'assets/img/hookLoader.png'
      }
      else {
        icon = 'assets/img/triper.png'
      }
      var item = data[i]
      if (item.LAT && item.LONG) {
        var marker = new google.maps.Marker({
          position: { lat: JSON.parse(item.LAT), lng: JSON.parse(item.LONG) },
          icon: icon,
          title: " VEHNO :" + item.vehno + " , TIME :" + item.HEARTBEATDATE + " , SPEED :" + item.SPEED

        });
        marker.id = item.DEVICEID;
        marker.vehno = item.vehno;
        marker.SPEED = item.SPEED;
        marker.dateTime = item.HEARTBEATDATE;
        marker.DISTANCE = (item.DISTANCE / 1000).toFixed(2);
        marker.BEAT = item.BEAT;
        marker.WARD = item.WARD
        marker.VTYPE = item.vehtypname




        markers.push(marker)
        this.allMarkers.push(marker)
        if (!this.vehicleCluster) {
          marker.setMap(this.map);
        }
      }
      (function (marker, data) {
        google.maps.event.addListener(marker, "click", function (e) {
          thisRef.isClickedVehicle = data.DEVICEID



          //Wrap the content inside an HTML DIV in order to set height and width of InfoWindow.
          var content = "<div class='col-sm-12 '>" + "<p class='info-deatil'><strong>IMEI :</strong>" + "  " + marker.id +
            "</p><p class='info-deatil'><strong>Vehicle No :</strong>" + "  " + marker.vehno +
            "</p><p class='info-deatil'><strong>Speed :</strong>" + "  " + marker.SPEED + " " +
            "</p><p class='info-deatil'><strong>Date Time :</strong>" + "  " + marker.dateTime + " " +

            "</p><p class='info-deatil'><strong>Distance :</strong>" + "  " + marker.DISTANCE + "</p></div>" +
            "</p><p class='info-deatil'><strong>Area :</strong>" + "  " + marker.BEAT + "</p></div>"
          infoWindow.setContent(content);
          infoWindow.open(this.map, marker);
        });
      })(marker, item);
    }

    if (this.vehicleCluster) {
      this.markerCluster = new MarkerClusterer(this.map, markers,
        { imagePath: 'https://developers.google.com/maps/documentation/javascript/examples/markerclusterer/m' });
    }
  }



  processPoints(this, geometry, callback, thisArg) {
    if (geometry instanceof google.maps.LatLng) {
      callback.call(thisArg, geometry);
    } else if (geometry instanceof google.maps.Data.Point) {
      callback.call(thisArg, geometry.get());
    } else {
      if (geometry) {
        geometry.getArray().forEach((g) => {
          this.processPoints(g, callback, thisArg);
        });
      }
    }
  }

  zoom(this, map, isZone) {
    this.bounds = new google.maps.LatLngBounds();
    this.map.data.forEach((feature) => {
      if (isZone) {
        this.processPoints(feature.getGeometry(), this.bounds.extend, this.bounds);
      } else {
        if (feature.getProperty('type') == "route") {
          this.processPoints(feature.getGeometry(), this.bounds.extend, this.bounds);
        }
      }

    });
    map.fitBounds(this.bounds);

  }




  reload() {
    $('#loderImgTab').hide()
    $("#infotable1").hide()
    $("#infotable2").hide()
    $("#statusTable").show()
    $("#play").show()
    $("#stop").hide()
    $("#veichiclesInfo-bar").hide()
    $('#progress-bar').hide()
    this.removeLine()
    this.removeMarker()
    this.clearStopMarker()
    this.getDataWhenProjectChange(this.prjID)
  }



  plotRoute = async (data, index) => {
    this.loaderService.display(true);
    this.vechicleListIsClicked = true
    this.IEMI = data.IMEI
    this.VEHNO = data.vehno
    this.mobileNo = data.vtsmobileno
    this.servingWardName = ""
    $("#infotable1").hide()
    $("#infotable2").hide()
    
    this.clearCurrentVehicalInfo()
    this.renoveAllMarker()
    let date = moment(this.date).format('YYYY-MM-DD');
    this.selectedlist = index;
    let response = await fetch(environment.apiUrl + 'vehicles/route' + '?DEVICEID=' + data.IMEI + "&prjId=" + this.prjID + "&date=" + date)
    let result = await response.json()
    this.loaderService.display(false);
    if (result.status == "No Route Found") {
      this.removeMarker()
      this.getPrevDayLocation(data)
      if (result.data.length > 0) {
        this.showCurrentVehiclesInfo(result.data[0], data)
        this.locateVehicle(result.data[0].STARTPOINT)
        this.plotStartAndEndPoint(result.data[0])
        this.totalStop = 0
        this.totalDuration = 0 + ": " + 0 + "(HH:MM)"
        $("#infotable1").show()
        $("#infotable2").show()
      } else {
        this.removeMarker()
        $("#infotable1").hide()
        $("#infotable2").hide()
      }

      $("#statusTable").show()
      $("#veichiclesInfo-bar").hide()
      this.clearStopMarker()
      this.removeLine()
      alert(result.status)
    } else {
      // $("#statusTable").hide()
      $("#infotable1").show()
      $("#infotable2").show()
      this.removeLine()
      this.createRoute(this.map, result.latLong);

      this.showCurrentVehiclesInfo(result, data)
      this.removeMarker()
      this.plotStartAndEndPoint(result)

      let stopInfo = await fetch(environment.apiUrl + 'getStopInfo?DEVICEID=' + data.IMEI + '&DEVICEDATE=' + date)
      let stop_info_data = await stopInfo.json()
      this.plotStopPosition(stop_info_data)



      let res = await fetch(environment.apiUrl + 'vehicles/getServingArea' + '?DEVICEID=' + data.IMEI + "&prjId=" + this.prjID + "&date=" + date)
      var servingWard = await res.json()
      this.servingWardName = servingWard.wardName

    }
  }

  getPrevDayLocation = async (data) => {
       let res = await fetch(environment.apiUrl + 'vehicles/getPrevDayLocation' + '?DEVICEID=' + data.IMEI + "&prjId=" + this.prjID)
       var lastActive = await res.json()
       if(lastActive.length>0){
        $("#infotable1").show()
        $("#infotable2").show()
         this.distance = 0
         this.vehiclesNo = data.vehno
         this.vehiclesType = data.vehtypname
         this.startTime = 'NA'
         this.endTime = 'NA'
         this.totalStop = 0
         this.totalDuration = 0 
          this.lastActiveTime =  moment(new Date(lastActive[0].lastActiveDate)).startOf('hour').fromNow()
         var latlng = { lat: lastActive[0].lastLocation.coordinates[1], lng: lastActive[0].lastLocation.coordinates[0] };
        this.geocoder.geocode({ 'location': latlng }, (results, status) => {
         if (status === 'OK') {
          this.currentAddress = results[0].formatted_address
       }
    })

    var start = new google.maps.LatLng(lastActive[0].lastLocation.coordinates[1], lastActive[0].lastLocation.coordinates[0]);
    this.markerStart = new google.maps.Marker({
      position: start,
      map: this.map,
      icon: 'assets/img/start.png',
      labelClass: "labels", // the CSS class for the label 
      labelStyle: { opacity: 1.00 }
    });
     var position = {LAT:lastActive[0].lastLocation.coordinates[1], LONG:lastActive[0].lastLocation.coordinates[0]}
     this.locateVehicle(position)
   }
  }

  closeInfo() {
    $("#infotable1").hide()
    $("#infotable2").hide()
  }
  getGeoLocation(lat, LONG, i, data) {
    var latlng = { lat: lat, lng: LONG };
    this.geocoder.geocode({ 'location': latlng, result_type: 'street_address' }, (results, status) => {
      if (status === 'OK') {
        var result = results[0].formatted_address
        var address = result.split(",")[0] + " " + result.split(",")[1] + +" " + result.split(",")[2]
        this.stopSummary[i].address = address
      }
    })
  }
  getStopSummary() {
    $("#stopSummary").modal("show")
    let date = moment(this.date).format('YYYY-MM-DD');
    this.http.get(environment.apiUrl + "vehicle/stopSummary?" + "prjId=" + this.prjID + "&deviceId=" + this.IEMI + "&date=" + date).subscribe(data => {
      this.stopSummary = data.json()
      console.log(this.stopSummary)
      this.getTotalStopsInBeat(this.stopSummary)
    })
  }




  printPdf(): void {

    let printContents, popupWin;
    printContents = document.getElementById('print-section').innerHTML;
    console.log(printContents)
    popupWin = window.open('', '_blank', 'top=0,left=0,height=100%,width=auto');
    popupWin.document.open();
    popupWin.document.write(`
      <html>
        <head>
        </head>
    <body onload="window.print();window.close()">${printContents}</body>
      </html>`
    );
    popupWin.document.close();
  }
  getTotalStopsInBeat(data) {
    var stop = 0
    for (var i = 0; i < data.length; i++) {
      stop = stop + data[i].totalStops
    }
    this.totalStopBeat = stop
  }


  getTrip(imei) {
    this.http.get(environment.apiUrl + 'vehicles/getTrip' + "?imei=" + imei).subscribe(data => {
      let result = data.json()
      console.log(result)
    })
  }
  async getEngineOffLocation(IMEI, date) {
    let engineOff = await fetch(environment.apiUrl + 'getEngineOffLocation?DEVICEID=' + IMEI + '&DEVICEDATE=' + date)
    let engineOffData = await engineOff.json()
    this.plotEngineOffLocation(engineOffData)
  }

  getAllKhatta(prjID) {
    this.http.get(environment.apiUrl + 'admin/getKhattaDetailsByProject' + "?PRJID=" + prjID).subscribe(data => {
      let result = data.json()
      console.log(result)
      this.secondaryPointData = result
      //this.plotAllKhatta(result)
    })
  }


  plotKhattaLoc(id) {
    if (this.plotKhattaPoint) {
      this.plotAllKhatta(this.secondaryPointData)
    } else {
      this.removeSecPoint(id)
    }
  }
    plotParkingPoint(id){
    if (this.plotParking) {
      this.plotAllKhatta(this.secondaryPointData)
    } else {
      this.removeSecPoint(id)
    }
  }
  plotFCTSpoint(id){
    if (this.plotFCTS) {
      this.plotAllKhatta(this.secondaryPointData)
    } else {
      this.removeSecPoint(id)
    }
  }

  plotMTSPoint(id){
    if (this.plotMTS) {
      this.plotAllKhatta(this.secondaryPointData)
    } else {
      this.removeSecPoint(id)
    }
  }

  plotBinsPoint(id){
    if (this.plotBins) {
      this.plotAllKhatta(this.secondaryPointData)
    } else {
      this.removeSecPoint(id)
    }
  }
  
  removeSecPoint(id) {
    if (this.secPointMarker.length > 0) {
      for (var i = 0; i < this.secPointMarker.length; i++) {
        if(this.secPointMarker[i].OEMID == id){
          this.secPointMarker[i].setVisible(false);
        }
      }
    }
  }
  plotAllKhatta(data) {
    var infoWindow = new google.maps.InfoWindow;
    var bounds = new google.maps.LatLngBounds();
    var coordinates = []
    var totalCount = 0
    var totalDuration = 0
    var icon = 'assets/img/khatta.png'
    for (var i = 0; i < data.length; i++) {
      var item = data[i]
      if (item.LAT != null && item.LNG != null) {
        var marker;
        if (item.OEMID == 40 && this.plotKhattaPoint) {
          icon = 'assets/img/khatta.png'
          marker = new google.maps.Marker({
            position: { lat: JSON.parse(item.LAT), lng: JSON.parse(item.LNG) },
            map: this.map,
            icon: icon,
            title: data[i].ENTITYNAME + " ( " + data[i].OEMNAME + " ) ",
            OEMID : data[i].OEMID
          });
          this.secPointMarker.push(marker)
          marker.setMap(this.map);
        } else if (item.OEMID == 14 && this.plotBins) {
          icon = 'assets/img/dustbin.png'
          marker = new google.maps.Marker({
            position: { lat: JSON.parse(item.LAT), lng: JSON.parse(item.LNG) },
            map: this.map,
            icon: icon,
            title: data[i].ENTITYNAME + " ( " + data[i].OEMNAME + " ) ",
            OEMID : data[i].OEMID
          });
          this.secPointMarker.push(marker)
          marker.setMap(this.map);
        }
        else if (item.OEMID == 12   && this.plotFCTS) {
          icon = 'assets/img/ts.png'
          marker = new google.maps.Marker({
            position: { lat: JSON.parse(item.LAT), lng: JSON.parse(item.LNG) },
            map: this.map,
            icon: icon,
            title: data[i].ENTITYNAME + " ( " + data[i].OEMNAME + " ) ",
            OEMID : data[i].OEMID
          });
          this.secPointMarker.push(marker)
          marker.setMap(this.map);
        } else if (item.OEMID == 13 && this.plotParking) {
          icon = 'assets/img/parking.png'
          marker = new google.maps.Marker({
            position: { lat: JSON.parse(item.LAT), lng: JSON.parse(item.LNG) },
            map: this.map,
            icon: icon,
            title: data[i].ENTITYNAME + " ( " + data[i].OEMNAME + " ) ",
            OEMID : data[i].OEMID
          });
          this.secPointMarker.push(marker)
          marker.setMap(this.map);
        }
        else if (item.OEMID == 42 && this.plotMTS) {
          icon = 'assets/img/ts.png'
          marker = new google.maps.Marker({
            position: { lat: JSON.parse(item.LAT), lng: JSON.parse(item.LNG) },
            map: this.map,
            icon: icon,
            title: data[i].ENTITYNAME + " ( " + data[i].OEMNAME + " ) ",
            OEMID : data[i].OEMID
          });
          this.secPointMarker.push(marker)
          marker.setMap(this.map);
        }
      }
    }
  }

  plotEngineOffLocation(engineOffData) {
    //this.clearStopMarker()
    var data = { features: [], type: "" }
    data.type = "FeatureCollection"
    var coordinates = []
    var stop = 0
    var totalDuration = 0
    for (var i = 0; i < engineOffData.length; i++) {
      if (engineOffData[i].LONG && engineOffData[i].LAT) {
        stop++
        var geometry = { coordinates: [], type: "" }
        geometry.coordinates.push(Number(engineOffData[i].LONG), Number(engineOffData[i].LAT))
        geometry.type = "Point"
        // var duration =  this.diff_hours(new Date(engineOffData[i].STARTTIME), new Date(engineOffData[i].ENDTIME))
        totalDuration = totalDuration + engineOffData[i].duration;
        data.features.push({
          geometry: geometry, type: "Feature", properties: {
            "ZONE": engineOffData[i].zoneName,
            "WARD": engineOffData[i].WardName,
            "TYPE": "engine_Off",
            "STARTTIME": engineOffData[i].HEARTBEATDATE,
          }
        })
      }
    }
    this.map.data.addGeoJson(data);

  }
  drivingSummaryModal() {
    $("#drivingSummary").modal("show")
  }

  diff_hours(dt2, dt1) {
    var difference = dt1.getTime() - dt2.getTime(); // This will give difference in milliseconds
    var resultInMinutes = Math.round(difference / 60000);
    var hours = (resultInMinutes / 60);
    var rhours = Math.floor(hours);
    var minutes = (hours - rhours) * 60;
    var rminutes = Math.round(minutes);
    return rhours + ": " + rminutes
  }



  plotStopPosition(stopInfo) {
    this.clearStopMarker()
    var data = { features: [], type: "" }
    data.type = "FeatureCollection"
    var coordinates = []
    var stop = 0
    var totalDuration = 0
    for (var i = 0; i < stopInfo.length; i++) {
      if (stopInfo[i].LONG && stopInfo[i].LAT) {
        stop++
        var geometry = { coordinates: [], type: "" }
        geometry.coordinates.push(Number(stopInfo[i].LONG), Number(stopInfo[i].LAT))
        geometry.type = "Point"
        var duration = this.diff_hours(new Date(stopInfo[i].STARTTIME), new Date(stopInfo[i].ENDTIME))
        totalDuration = totalDuration + stopInfo[i].duration;
        data.features.push({
          geometry: geometry, type: "Feature", properties: {
            "DEVICEID": stopInfo[i].DEVICEID,
            "VEHICLE_NO": stopInfo[i].VEHICLE_NO,
            "STARTTIME": stopInfo[i].STARTTIME,
            "ENDTIME": stopInfo[i].ENDTIME,
            "DURATION": duration,
            "ZONE": stopInfo[i].zoneName,
            "WARD": stopInfo[i].WardName,
            "BEAT": stopInfo[i].beatName,
            "TYPE": "stopMarker",
            "engineStatus": (stopInfo[i].ACC == 0) ? "Off" : "On",
            "number": stop
          }
        })
      }
    }
    this.totalStop = stop
    var hours = (totalDuration / 60);
    var rhours = Math.floor(hours);
    var minutes = (hours - rhours) * 60;
    var rminutes = Math.round(minutes);
    this.totalDuration = rhours + ": " + rminutes + "(HH:MM)"
    this.map.data.addGeoJson(data);

  }

  plotRouteWhenLiveTrack() {
    this.route = new google.maps.Polyline({
      path: this.routePath,
      strokeColor: '#686C55',
      strokeOpacity: 1.0,
      strokeWeight: 4,
      map: this.map
    });
  }
  createRoute(map, pathCoords) {
    var i, route, marker;
    var polyCords = []
    for (i = 0; i < pathCoords.length; i++) {
      polyCords.push({ lat: JSON.parse(pathCoords[i][1]), lng: JSON.parse(pathCoords[i][0]) });
    }
    var car = "M17.402,0H5.643C2.526,0,0,3.467,0,6.584v34.804c0,3.116,2.526,5.644,5.643,5.644h11.759c3.116,0,5.644-2.527,5.644-5.644 V6.584C23.044,3.467,20.518,0,17.402,0z M22.057,14.188v11.665l-2.729,0.351v-4.806L22.057,14.188z M20.625,10.773 c-1.016,3.9-2.219,8.51-2.219,8.51H4.638l-2.222-8.51C2.417,10.773,11.3,7.755,20.625,10.773z M3.748,21.713v4.492l-2.73-0.349 V14.502L3.748,21.713z M1.018,37.938V27.579l2.73,0.343v8.196L1.018,37.938z M2.575,40.882l2.218-3.336h13.771l2.219,3.336H2.575z M19.328,35.805v-7.872l2.729-0.355v10.048L19.328,35.805z";
    var icon = {
      path: car,
      scale: 1,
      strokeColor: 'white',
      strokeWeight: .10,
      fillOpacity: 5,
      fillColor: '#1DA42B',
      offset: '2%',
      // rotation: parseInt(heading[i]),
      anchor: new google.maps.Point(10, 25) // orig 10,50 back of car, 10,0 front of car, 10,25 center of car
    };
    this.routePath = polyCords
    this.route = new google.maps.Polyline({
      path: polyCords,
      strokeColor: '#4753B0',
      strokeOpacity: 4.0,
      strokeWeight: 6,
      icons: [{
        icon: icon,
        offset: '100%',

      },
      ],
      map: map
    });
    this.zoomToObject(this.route)
  }

  clearCurrentVehicalInfo() {
    this.distance = null
    this.vehiclesNo = null
    this.IMEI = null
    this.vehiclesType = null
    this.startTime = null
    this.endTime = null
    this.currentAddress = null
  }

  showCurrentVehiclesInfo(data, tableRow) {
    this.distance = data.distance.toFixed(2);
    this.vehiclesNo = tableRow.vehno
    this.IMEI = tableRow.IMEI
    this.vehiclesType = tableRow.vehtypname
    this.startTime = moment(new Date(data.STARTTIME)).format('h:mm:ss a');
    this.endTime = moment(new Date(data.ENDTIME)).format('h:mm:ss a');
    this.lastActiveTime =  tableRow.LASTACTIVEDATE
    var latlng = { lat: data.ENDPOINT.LAT, lng: data.ENDPOINT.LONG };
    this.geocoder.geocode({ 'location': latlng }, (results, status) => {
      if (status === 'OK') {
        this.currentAddress = results[0].formatted_address
      }
    })

  }
  removeLine() {
    if (this.route) {
      this.route.setMap(null);
    }
  }
  removeMarker() {
    if (this.markerStart && this.markerEnd) {
      this.markerStart.setMap(null);
      this.markerEnd.setMap(null);
    }else if(this.markerStart){
      this.markerStart.setMap(null);
    }
  }
  removeStartAndEndPoint() {
    this.infoWindowStart.close();
    this.infoWindowEnd.close();
  }
  StatusUp(){
    $('.status_extra').toggle();
  }
  plotStartAndEndPoint(data) {
    console.log(data)
    var start = new google.maps.LatLng(data.STARTPOINT.LAT, data.STARTPOINT.LONG);
    var end = new google.maps.LatLng(data.ENDPOINT.LAT, data.ENDPOINT.LONG);
    this.markerStart = new google.maps.Marker({
      position: start,
      map: this.map,
      icon: 'assets/img/start.png',

      labelClass: "labels", // the CSS class for the label 
      labelStyle: { opacity: 1.00 }

    });
    this.markerEnd = new google.maps.Marker({
      position: end,
      map: this.map,
      icon: 'assets/img/end.png'
    });
  }

  autoRefreshLiveData(map, pathCoords, id) {
    var i, route, marker;
    var polyCords = []
    var polyLiveCords = []
    this.removePolyLine(id)
    for (i = 0; i < pathCoords.length; i++) {
      polyCords.push({ lat: JSON.parse(pathCoords[i][1]), lng: JSON.parse(pathCoords[i][0]) });
      //  this.routePath.push({ lat: JSON.parse(pathCoords[i][1]), lng: JSON.parse(pathCoords[i][0]) })
    }
    // if(this.live){
    //   this.plotLiveRoute(pathCoords)
    // }

    this.Liveroute = new google.maps.Polyline({
      path: polyCords,
      strokeColor: '#686C55',
      strokeOpacity: 1.0,
      strokeWeight: 4,
      icons: [{
        icon: this.icon,
        offset: '100%'

      },
      ],
      map: this.map
    });
    this.polyline_array.push({ line: this.Liveroute, id: id })
    // this.animateCircle(this.Liveroute)
    var markerPoint = pathCoords[0]
    polyCords = []
  }

  plotLiveRoute(polyCords) {
    this.route = new google.maps.Polyline({
      path: polyCords,
      strokeColor: '#686C55',
      strokeOpacity: 1.0,
      strokeWeight: 4,
      icons: [{
        icon: this.icon,
        offset: '100%'
      },
      ],
      map: this.map
    });
  }
  removePolyLine(id) {
    for (var i = 0; i < this.polyline_array.length; i++) {
      if (id == this.polyline_array[i].id) {
        this.polyline_array[i].line.setMap(null)
      }
    }
  }


  animateLiveCircle(line) {
    var count = 0;
    var value = 300
    stopAnimation = true
    var myinterval = setInterval(() => {
      count = (count + 1) % 200;
      var icons = line.get('icons');
      icons[0].offset = (count / 2) + '%';
      if (count === 199) {
        line.set('icons', null);
        clearInterval(myinterval)
        //line.unSet('icons', icons);
        line.setMap(null)
      }
      line.set('icons', icons);
    }, 250)
  }


  animateCircle(line) {
    var count = 0;
    $("#play").hide()
    $("#stop").show()
    if (!stopAnimation) {
      stopAnimation = true
      return;
    }
    stopAnimation = true
   var myVar =  window.setInterval(function() {
    if (stopAnimation) {
      count = (count + 1) % 200;
      var icons = line.get('icons');
      icons[0].offset = (count / 2) + '%';
      if (count === 199) {
        clearInterval(myVar);
        $("#play").show()
        $("#stop").hide()
      }
      line.set('icons', icons);
    }
  }, 6);
}


  async refreshLiveData() {
    let vehicles = await fetch(environment.apiUrl + 'vehicles/location/all' + '?prjID=' + this.prjID)
    this.vehiclesLocation = await vehicles.json()
    this.plotAllVehicles(this.vehiclesLocation)
  }
  stopPlay() {
    stopAnimation = false
    $("#play").show()
    $("#stop").hide()

  }
  zoomToObject(obj) {
    var bounds = new google.maps.LatLngBounds();
    var points = obj.getPath().getArray();
    for (var n = 0; n < points.length; n++) {
      bounds.extend(points[n]);
    }
    this.map.fitBounds(bounds);
  }

  clearFeature() {
    this.map.data.forEach((feature) => {
      this.map.data.remove(feature);
    })
  }
  removeMapLabel(entityId){
    for(var i = 0;i<this.mapLabelArray.length;i++){
      if(entityId == this.mapLabelArray[i].entityId){
        this.mapLabelArray[i].setMap(null);
      }
    }
  }
  async plotWardBoundary(entityId) {
    if (!this.wardBoundary) {
      this.map.data.forEach((feature) => {
        if (feature.getProperty('TYPE') != "stopMarker" && feature.getProperty('Oemid') == entityId) {
          this.map.data.remove(feature);
          this.removeMapLabel(feature.getProperty('EntityID'))
        }
      })
    } else {
      let polygon = await fetch(environment.apiUrl + 'entity/getPolygonByOemId' + "?prjid=" + this.prjID + "&wardOemId=" + entityId + "&beatOemId =" + null)
      var polygondData = await polygon.json()
      this.map.data.addGeoJson(polygondData.geoJson);
    }
  }

  async getWardPolygon() {
    let polygon = await fetch(environment.apiUrl + 'entity/getPolygonByOemId' + "?prjid=" + this.prjID + "&wardOemId=" + 8 + "&beatOemId =" + null)
    var polygondData = await polygon.json()
    this.wardPolygonList = polygondData.entityData
    console.log(this.wardPolygonList)
  }

  selectWard(polygonData){
    console.log(polygonData)
        var data = {
          features: [{ geometry: {}, type: "Feature", properties: "" }], type: ""
        }
        var d = JSON.parse(polygonData.kml)
        data.features[0].geometry = d
        var prop = JSON.parse(polygonData.properties)
        prop.type = "clickedPolygon"
        data.features[0].properties = prop
        data.type = "FeatureCollection"
        var color = '#B05C3C'
        this.map.data.forEach((feature) => {
          if (feature.getProperty('type') == "clickedPolygon") {
            this.map.data.remove(feature);
          }
        })
        this.removeOutsideMarker(polygonData.entityname)
        this.map.data.addGeoJson(data);
        this.zoomOneEntity(this.map);
  }

  
  removeOutsideMarker(wardName) {
    this.vehicleInWard = []
    console.log("wardName",wardName)
    if (this.allMarkers.length > 0) {
      for (var i = 0; i < this.allMarkers.length; i++) {
        if(wardName == this.allMarkers[i].WARD){
        this.allMarkers[i].setVisible(true);
        var obj = {
          IMEI:this.allMarkers[i].id,
          VEHICLE_NO:this.allMarkers[i].vehno,
          DATETIME:this.allMarkers[i].dateTime,
          "DISTANCE(KM)":this.allMarkers[i].DISTANCE,
          WARD:this.allMarkers[i].WARD,
          BEAT:this.allMarkers[i].BEAT,
          TYPE:this.allMarkers[i].VTYPE
        }
        this.vehicleInWard.push(obj)
       }else{
         console.log(wardName)
         this.allMarkers[i].setVisible(false);
       }
    }
  }
  }


  vehicleInWardExport(){
    const ws_name = 'SomeSheet';
    const wb: WorkBook = { SheetNames: [], Sheets: {} };
    const ws: any = utils.json_to_sheet(this.vehicleInWard);
    wb.SheetNames.push(ws_name);
    wb.Sheets[ws_name] = ws;
    const wbout = write(wb, {
      bookType: 'xlsx', bookSST: true, type:
        'binary'
    });
    saveAs(new Blob([this.s2ab(wbout)], { type: 'application/octet-stream' }), 'Vehicle.xlsx');
  }
  zoomOneEntity(this, map) {
    this.bounds = new google.maps.LatLngBounds();
    map.data.forEach((feature) => {
      if (feature.getProperty('type') == "clickedPolygon") {
        this.processPoints(feature.getGeometry(), this.bounds.extend, this.bounds);
      }
    });
    map.fitBounds(this.bounds);
  }


  async plotBeatBoundary(entityId) {
    if (!this.beatBoundary) {
      this.map.data.forEach((feature) => {
        if (feature.getProperty('TYPE') != "stopMarker" && feature.getProperty('Oemid') == entityId) {
          this.map.data.remove(feature);
        }
      })
    } else {
      let polygon = await fetch(environment.apiUrl + 'entity/getPolygonByOemId' + "?prjid=" + this.prjID + "&wardOemId=" + null + "&beatOemId=" + entityId)
      var polygondData = await polygon.json()
      this.map.data.addGeoJson(polygondData.geoJson);
    }
  }

  clearPrevRoute(data) {

    this.map.data.forEach((feature) => {
      if (feature.getProperty('type') == "route") {
        this.map.data.remove(feature);
      }
    })
  }

  clearStopMarker() {
    this.map.data.forEach((feature) => {
      if (feature.getProperty('TYPE') == "stopMarker" || feature.getProperty('TYPE') == "engine_Off") {
        this.map.data.remove(feature);
      }
    })
  }
  setStyle(thisRef) {

    this.map.data.setStyle(function (feature) {
      var color = feature.getProperty('FillColor');
      var strokeColor = feature.getProperty('Bcolor')
      var strokeOpacity = feature.getProperty('stroke-opacity')
      if(feature.getProperty('Oemid') == 8){ 
        thisRef.polygonLabel(feature.getProperty('Ward'),feature.getProperty('LAT'),feature.getProperty('LON'),16,12,feature.getProperty('EntityID'),strokeColor)
      }else if(feature.getProperty('Oemid') == 7){
        thisRef.polygonLabel(feature.getProperty('Zone'),feature.getProperty('LAT'),feature.getProperty('LON'),18,13,feature.getProperty('EntityID'),"#010100")
      }
      // else if(feature.getProperty('Oemid') == 9){
      //   thisRef.polygonLabel(feature.getProperty('Beat'),feature.getProperty('LAT'),feature.getProperty('LON'))
      // }
     
      if (feature.getProperty('TYPE') == "stopMarker") {

        return ({
          fillColor: color,
          strokeColor: strokeColor,
          strokeWeight: 2,
          fillOpacity: 0.05,
          icon: 'assets/img/stopMarker.png',
          strokeopacity: 0.2,
          label: {
            text: feature.getProperty('number'),
            color: '#FFFFFF',
            fontSize: "13px",
            background: 'yellow',
            fontWeight: "bold",
            AlignmentVertical: "top",
            AlignmentHorizontal: "center"
          },
          labelClass: "my-custom-class-for-label"


        });
      } else if (feature.getProperty('TYPE') == "khatta") {
        return ({
          fillColor: color,
          strokeColor: strokeColor,
          strokeWeight: 5,
          fillOpacity: 0.0,
          strokeopacity: 0.2,
          icon: 'assets/img/khatta.png',
        });
      } else if (feature.getProperty('Oemid') == 8 || feature.getProperty('Oemid') == 9) {
        return ({
          fillColor: color,
          strokeColor: strokeColor,
          strokeWeight: 3,
          fillOpacity: 0.1,
          strokeopacity: 0.8,
        });

      } else {
        return ({
          fillColor: color,
          strokeColor: "#040C0A",
          strokeWeight: 4,
          fillOpacity: 0.1,
          strokeopacity: 0.4

        });
      }
    });
  }

  /* 
     excel Import
  */

  s2ab(s) {
    const buf = new ArrayBuffer(s.length);
    const view = new Uint8Array(buf);
    for (let i = 0; i !== s.length; ++i) {
      view[i] = s.charCodeAt(i) & 0xFF;
    };
    return buf;
  }

  importToExcel(data) {
    const ws_name = 'SomeSheet';
    const wb: WorkBook = { SheetNames: [], Sheets: {} };
    const ws: any = utils.json_to_sheet(data);
    wb.SheetNames.push(ws_name);
    wb.Sheets[ws_name] = ws;
    const wbout = write(wb, {
      bookType: 'xlsx', bookSST: true, type:
        'binary'
    });
    saveAs(new Blob([this.s2ab(wbout)], { type: 'application/octet-stream' }), 'exported.xlsx');
  }

  async refreshCount(id) {
    let vehicles = await fetch(environment.apiUrl + 'vehicles/location/all' + '?prjID=' + id)
    this.vehiclesLocation = await vehicles.json()
    let vehiclesDetail = await fetch(environment.apiUrl + 'vehicles/detail' + '?prjId=' + id)
    this.vehiclesData = await vehiclesDetail.json()
    if(!this.IEMI){
      this.plotAllVehicles(this.vehiclesLocation)
    }
    
    this.mergeVechiclesData(this.vehiclesLocation, this.vehiclesData)

    this.vehiclesDataTemp = this.vehiclesData
    this.clearPrevCount()


    this.getStatusCount(this.vehiclesData)
    this.getMisMatchCount(this.vehiclesData, this.vehiclesLocation)
    this.getDeadCount(this.activeArray, this.dataWithoutDead)
    this.getDeadAndLiveCount(this.deadArray, this.vehiclesLocation)
    this.findLiveInNotInDbArray(this.mismatchArray)

    this.currentStatus(this.dataWithoutDead)

    this.mergeVehicleStatus(this.vehiclesLocation, this.vehiclesData)

    //this.getStatusData('live')

  }


  /*

      dead report

  */
  ViewDaedReportbtn() {
    $('#ViewDaedReportModal').modal('show');
    this.getDeadReport()
    this.selectedDeadList = "notRunningSince15Days"

  }
  getDeadArray(data, selected) {
    this.deadVehicleList = data
    this.selectedDeadList = selected

  }
  async getDeadReport() {

    let vehicles = await fetch(environment.apiUrl + "vehicles/deadVehicleReport?prjId=" + this.prjID)
    this.deadVehicleSummary = await vehicles.json()
    this.notRunningSince15Days = this.deadVehicleSummary.notRunningSince15Days.count
    this.notRunningSince10Days = this.deadVehicleSummary.notRunningSince10Days.count
    this.notRunningSince5Days = this.deadVehicleSummary.notRunningSince5Days.count
    this.notRunningSince2Days = this.deadVehicleSummary.notRunningSince2Days.count

    this.notRunningSince15DaysArray = this.deadVehicleSummary.notRunningSince15Days.data
    this.notRunningSince10DaysArray = this.deadVehicleSummary.notRunningSince10Days.data
    this.notRunningSince5DaysArray = this.deadVehicleSummary.notRunningSince5Days.data
    this.notRunningSince2DaysArray = this.deadVehicleSummary.notRunningSince2Days.data

    this.deadVehicleList = this.notRunningSince15DaysArray


    console.log(this.deadVehicleSummary)

  }


  importDeadList(data) {

    for (var i = 0; i < data.length; i++) {
      delete data[i].isactive
      delete data[i].id
      delete data[i].sim
      delete data[i].vehtypid
      delete data[i].vehTempNo

    }
    const ws_name = 'SomeSheet';
    const wb: WorkBook = { SheetNames: [], Sheets: {} };
    const ws: any = utils.json_to_sheet(data);
    wb.SheetNames.push(ws_name);
    wb.Sheets[ws_name] = ws;
    const wbout = write(wb, {
      bookType: 'xlsx', bookSST: true, type:
        'binary'
    });
    saveAs(new Blob([this.s2ab(wbout)], { type: 'application/octet-stream' }), 'notrunning.xlsx');
  }






  locateVehicle(position) {
    var myPlace = new google.maps.LatLng(position.LAT, position.LONG);
    var bounds = new google.maps.LatLngBounds(myPlace);
    this.map.fitBounds(bounds);
  }





  CenterControl(controlDiv, map) {
    // Set CSS for the control border.
    var controlUI = document.createElement('table');
    controlUI.style.backgroundColor = '#fff';
    controlUI.style.border = '2px solid #fff';
    controlUI.style.borderRadius = '1px';
    controlUI.style.boxShadow = '0 2px 6px rgba(0,0,0,.4)';
    controlUI.style.cursor = 'pointer';
    controlUI.style.marginBottom = '0px';
    controlUI.style.textAlign = 'top_right';
    controlDiv.appendChild(controlUI);

    // Set CSS for the control interior.
    this.controlText = document.createElement('div');
    // this.controlText.style.color = 'rgb(25,25,25)';
     this.controlText.style.fontFamily = 'Roboto,Arial,sans-serif';
    // this.controlText.style.fontSize = '13px';
    // this.controlText.style.lineHeight = '15px';
    // this.controlText.style.paddingLeft = '3px';
    // this.controlText.style.marginLeft = '14px';
    this.controlText.style.padding = '2px';

    controlUI.appendChild(this.controlText);
    var content = []
    content.push('<span (click) ="test()" class="google-map-info"><img src="../assets/img/khatta.png"/> Khatta </span><br>');
    content.push('<span (click) ="test()" class="google-map-info"><img src="../assets/img/boundry_line.png" width="24"/> Boundry </span><br>');
    content.push('<span (click) ="test()" class="google-map-info"><img src="../assets/img/dustbin.png"/> Dustbin </span><br>');
    content.push('<span (click) ="test()" class="google-map-info"><img src="../assets/img/ts.png"/> FCTS </span><br>');
    content.push('<span (click) ="test()" class="google-map-info"><img src="../assets/img/plant.png"/> Plant </span><br>');
    content.push('<span (click) ="test()" class="google-map-info"><img src="../assets/img/stopMarker.png"/> Stop </span><br>');
    content.push('<span (click) ="test()" class="google-map-info"><img src="../assets/img/route.png"/> Route </span><br>');
    content.push('<span (click) ="test()" class="google-map-info"><img src="../assets/img/parking.png"/> Parking </span><br>');

    content.push('<span (click) ="test()" class="google-map-info"><img src="../assets/img/hookLoader.png"/> Hook Loader </span><br>');
    content.push('<span (click) ="test()" class="google-map-info"><img src="../assets/img/refuseCompactor.png"/> Refuse Compactor </span><br>');
    content.push('<span (click) ="test()" class="google-map-info"><img src="../assets/img/tractor.png"/> Tractor </span><br>');
    content.push('<span (click) ="test()" class="google-map-info"><img src="../assets/img/hyva.png"/> Hyva </span><br>');
    content.push('<span (click) ="test()" class="google-map-info"><img src="../assets/img/jcb.png"/> JCB </span><br>');
    content.push('<span (click) ="test()" class="google-map-info"><img src="../assets/img/triper.png"/> Tipper/Bolero </span><br>');
    this.controlText.innerHTML = content.join('');
  }

  polygonLabel(text,lat,long,strokeWeight,fontSize,entityId,color){
    var myLatlng = new google.maps.LatLng(Number(lat), Number(long));
    var mapLabel = new MapLabel({
      text: text,
      position: myLatlng,
      map: this.map,
      strokeWeight:strokeWeight,
      fontSize:fontSize,
      align: 'left',
      entityId:entityId,
      fontColor:color
      
    });
    this.mapLabelArray.push(mapLabel)
    mapLabel.set('position', myLatlng);
  }
  ngOnInit() {

    $("#drivingSummary").modal("hide")
    this.getFuelYypeCount();
    this.getDataWhenProjectChange(this.prjID)
  
    this.getWardPolygon()
    var thisRef = this
    $('#loderImgTab').hide()
    $("#infotable1").hide()
    $("#infotable2").hide()
    $("#statusTable").show()
    $("#play").show()
    $("#stop").hide()
    $("#veichiclesInfo-bar").hide()
    $('#progress-bar').hide()
    this.geocoder = new google.maps.Geocoder;
    var myOptions = {
      center: new google.maps.LatLng(28.47769599987369, 77.06160699973178),
      zoom: 13,
      panControl: true,
      mapTypeControl: true,
      mapTypeId: google.maps.MapTypeId.ROADMAP,
      mapTypeControlOptions: {
    style: google.maps.MapTypeControlStyle.DROPDOWN_MENU,
    position: google.maps.ControlPosition.TOP_LEFT
      },
      zoomControlOptions: {
        position: google.maps.ControlPosition.RIGHT_BOTTOM,
        style: google.maps.ZoomControlStyle.SMALL
      },
      fullscreenControlOptions: {
        position: google.maps.ControlPosition.TOP_CENTER,
        style: google.maps.ControlPosition.SMALL
      }

    };
    this.map = new google.maps.Map(document.getElementById('map'), myOptions);
    // var trafficLayer = new google.maps.TrafficLayer();
    // trafficLayer.setMap(this.map);
    var config = {
      authDomain: "ecogreen-citizen-app.firebaseapp.com",
      apiKey: 'AIzaSyAHMkYkbjRTa9RazdKPJjtOJrdHCZVxxYg',
      databaseURL: 'https://ecogreen-citizen-app-2ad05.firebaseio.com/',
      storageBucket: 'ecogreen-citizen-app.appspot.com',
      projectId: 'ecogreen-citizen-app'
    };




    var infoWindow = new google.maps.InfoWindow;
    this.map.data.addListener('click', showArrays);
    function showArrays(event) {
      if (event.feature.getProperty('TYPE') == "stopMarker") {
        var position = { lat: event.latLng.lat(), lng: event.latLng.lng() }
        var content = "<div class='col-sm-12'>" + "<p class='info-deatil'><strong>Entry Time :</strong>" + "  " + event.feature.getProperty('STARTTIME') +
          "</p><p class='info-deatil'><strong>Exit Time :</strong>" + "  " + event.feature.getProperty('ENDTIME') +
          "</p><p class='info-deatil'><strong>Duration :</strong>" + "  " + event.feature.getProperty('DURATION') + " " +
          "</p><p class='info-deatil'><strong>Ward :</strong>" + "  " + event.feature.getProperty('WARD') + " " +

          "</p><p class='info-deatil'><strong>Engine :</strong>" + "  " + event.feature.getProperty('engineStatus') + "</p></div>"
        infoWindow = new google.maps.InfoWindow({
          content: content,
          position: position,
        });

        google.maps.InfoWindowOptions
        infoWindow.open(this.map);
      } else {
        var position = { lat: event.latLng.lat(), lng: event.latLng.lng() }
        thisRef.http.post(environment.apiUrl + "entity/getEntityByPoint", position).subscribe(data => {
          var result = data.json()[0]
          var content = "<div class='col-sm-12'><p class='info-deatil'><strong>Zone :</strong>" + "  " + result.zoneName + "<label title='Information' class='cursor badge pull-right' style='background: #3F51B5; margin-left: 138px;padding: 3px 1px;'><i class='fa fa-info'></i><label>" +
            "</p><p class='info-deatil'><strong>Ward :</strong>" + "  " + result.WardName +
            "</p><p class='info-deatil'><strong>Beat :</strong>" + result.beatName

          infoWindow = new google.maps.InfoWindow({
            content: content,
            position: position,
          });
          google.maps.InfoWindowOptions
          infoWindow.open(this.map);
        })

      }


    }
    firebase.initializeApp(config);

















    var listRef = firebase.database().ref('/');
    listRef.on('child_changed', (dataSnapshot) => {
      const msg = dataSnapshot.val();
      var newPosition = dataSnapshot.val();
      var mylatlongs = new google.maps.LatLng(newPosition.LAT, newPosition.LONG);
      if (this.vechicleListIsClicked) {
        if (this.IMEI == newPosition.DEVICEID) {
          if (newPosition.LAT && newPosition.LONG && newPosition.LAT != " " && newPosition.LONG != " " && msg.prjID == Number(this.prjID)) {
            var point = new google.maps.LatLng(newPosition.LAT, newPosition.LONG);

            this.latlongs.push(mylatlongs);
            this.deleteMarker(newPosition.DEVICEID, mylatlongs)
            var marker = new google.maps.Marker({
              position: point,
              icon: this.icon,
              title: newPosition.DEVICEID + "(" + newPosition.HEARTBEATDATE + ")"
            });
            marker.id = newPosition.DEVICEID;
            //this.allMarkers.push(marker);

            if (this.vehicleInfoWindowClicked) {
              this.vehicleInfoWindowClicked.close()
            }
            if (newPosition.SPEED > 0) {
              var status = "Moving"
            } else {
              var status = "Stoped"
            }
            //Wrap the content inside an HTML DIV in order to set height and width of InfoWindow.
            var content = "<div class='col-sm-12'>" + "<p class='info-deatil'><strong>IMEI :</strong>" + "  " + newPosition.DEVICEID +
              "</p><p class='info-deatil'><strong>Vehicle No :</strong>" + "  " + newPosition.RCNO +
              "</p><p class='info-deatil'><strong>Speed :</strong>" + "  " + newPosition.SPEED + " " +
              "</p><p class='info-deatil'><strong>Date Time :</strong>" + "  " + newPosition.HEARTBEATDATE + " " +

              // "</p><p class='info-deatil'><strong>Distance :</strong>" + "  " + (newPosition.distance/1000).toFixed(2) + "</p></div>" +
              "</p><p class='info-deatil'><strong>Area :</strong>" + "  " + newPosition.beatName + "</p></div>" +
              "</p><p class='info-deatil'><strong>Status :</strong>" + "  " + "<label style='font:bold'>" + status + " </label>" + "</p></div>"
            this.vehicleInfoWindowClicked.setContent(content);
            this.vehicleInfoWindowClicked.open(this.map, marker);






          }
        }



      } else {

        for (var i = 0; i < this.allMarkers.length; i++) {
          if (newPosition.DEVICEID == this.allMarkers[i].id) {
            var title = " VEHNO :" + newPosition.RCNO + " , TIME :" + newPosition.HEARTBEATDATE + " ,  SPEED :" + newPosition.SPEED

            this.allMarkers[i].setPosition(mylatlongs);
            this.allMarkers[i].setTitle(title)

            this.allMarkers[i].BEAT = newPosition.beatName
            this.allMarkers[i].SPEED = newPosition.SPEED
            this.allMarkers[i].dateTime = newPosition.HEARTBEATDATE


            if (thisRef.isClickedVehicle == newPosition.DEVICEID) {
              if (this.vehicleInfoWindow) {
                this.vehicleInfoWindow.close()
              }
              if (newPosition.SPEED > 0) {
                var status = "Moving"
              } else {
                var status = "Stoped"
              }
              //Wrap the content inside an HTML DIV in order to set height and width of InfoWindow.
              var content = "<div class='col-sm-12'>" + "<p class='info-deatil'><strong>IMEI :</strong>" + "  " + newPosition.DEVICEID +
                "</p><p class='info-deatil'><strong>Vehicle No :</strong>" + "  " + newPosition.RCNO +
                "</p><p class='info-deatil'><strong>Speed :</strong>" + "  " + newPosition.SPEED + " " +
                "</p><p class='info-deatil'><strong>Date Time :</strong>" + "  " + newPosition.HEARTBEATDATE + " " +

                // "</p><p class='info-deatil'><strong>Distance :</strong>" + "  " + (newPosition.distance/1000).toFixed(2) + "</p></div>" +
                "</p><p class='info-deatil'><strong>Area :</strong>" + "  " + newPosition.beatName + "</p></div>" +
                "</p><p class='info-deatil'><strong>Status :</strong>" + "  " + "<label style='font:bold'>" + status + " </label>" + "</p></div>"
              this.vehicleInfoWindow.setContent(content);
              this.vehicleInfoWindow.open(this.map, this.allMarkers[i]);
            }

          }
        }
        if (newPosition.LAT && newPosition.LONG && newPosition.LAT != " " && newPosition.LONG != " " && msg.prjID == Number(this.prjID)) {
          var point = new google.maps.LatLng(JSON.parse(newPosition.LAT), JSON.parse(newPosition.LONG));
          var mylatlongs = new google.maps.LatLng(JSON.parse(newPosition.LAT), JSON.parse(newPosition.LONG));
          this.latlongs.push(mylatlongs);
          //this.deleteMarker(newPosition.DEVICEID, mylatlongs)
          //this.plotMarker(point, newPosition.DEVICEID, newPosition.DEVICEDATE)

        }
      }

    })

    //search box

   
    $('#divvehicledate').hide()
    Observable.interval(6 * 60 * 1000).subscribe(x => {
      thisRef.refreshCount(this.prjID)

    });
    thisRef.CenterControl(thisRef.centerControlDiv, thisRef.map)
    this.map.controls[google.maps.ControlPosition.LEFT_CENTER].push(this.centerControlDiv);
    var card = document.getElementById('pac-card');
    var input = document.getElementById('pac-input');
    var types = document.getElementById('type-selector');
    var strictBounds = document.getElementById('strict-bounds-selector');

    //thisRef.map.controls[google.maps.ControlPosition.TOP_RIGHT].push(card);

    var autocomplete = new google.maps.places.Autocomplete(input);

    // Bind the map's bounds (viewport) property to the autocomplete object,
    // so that the autocomplete requests use the current map bounds for the
    // bounds option in the request.
    autocomplete.bindTo('bounds', thisRef.map);

    // Set the data fields to return when the user selects a place.
    autocomplete.setFields(
      ['address_components', 'geometry', 'icon', 'name']);

    var infowindow = new google.maps.InfoWindow();
    var infowindowContent = document.getElementById('infowindow-content');
    infowindow.setContent(infowindowContent);
    var marker = new google.maps.Marker({
      map: thisRef.map,
      anchorPoint: new google.maps.Point(0, -29)
    });

    autocomplete.addListener('place_changed', function () {
      infowindow.close();
      marker.setVisible(false);
      var place = autocomplete.getPlace();
      if (!place.geometry) {
        // User entered the name of a Place that was not suggested and
        // pressed the Enter key, or the Place Details request failed.
        window.alert("No details available for input: '" + place.name + "'");
        return;
      }

      // If the place has a geometry, then present it on a map.
      if (place.geometry.viewport) {
        thisRef.map.fitBounds(place.geometry.viewport);
      } else {
        thisRef.map.setCenter(place.geometry.location);
        thisRef.map.setZoom(17);  // Why 17? Because it looks good.
      }
      marker.setPosition(place.geometry.location);
      marker.setVisible(true);

      var address = '';
      if (place.address_components) {
        address = [
          (place.address_components[0] && place.address_components[0].short_name || ''),
          (place.address_components[1] && place.address_components[1].short_name || ''),
          (place.address_components[2] && place.address_components[2].short_name || '')
        ].join(' ');
      }

      infowindowContent.children['place-icon'].src = place.icon;
      infowindowContent.children['place-name'].textContent = place.name;
      infowindowContent.children['place-address'].textContent = address;
      infowindow.open(thisRef.map, marker);
    });


    //  drawing manager 

    var drawingManager = new google.maps.drawing.DrawingManager({
      drawingControl: true,
      drawingControlOptions: {
        position: google.maps.ControlPosition.TOP_CENTER,
        drawingModes: [google.maps.drawing.OverlayType.POLYGON]
      },
      polygonOptions: {
        strokeWeight: 2,
        strokeColor: '#ff0000',
      }
    });
    //drawingManager.setMap(this.map);
    google.maps.event.addListener(drawingManager, 'overlaycomplete', function (this, event) {
      // Get overlay paths
      var paths = event.overlay.getPaths();
      // Remove overlay from map
      event.overlay.setMap(null);
      // Disable drawingManager
      drawingManager.setDrawingMode(null);
      thisRef.polygon = new google.maps.Polygon({
        fillColor: '#D4D9C8',
        fillOpacity: 0,
        strokeWeight: 3,
        strokeColor: '#7620A7',
        editable: true,
        paths: paths,
        map: this.map
      });
      var coordinatesArray = event.overlay.getPath()

      var testArray = [];
      for (var a = 0; a < coordinatesArray.length; a++) {
        var arr = [coordinatesArray.getAt(a).lng()]
        arr.push(coordinatesArray.getAt(a).lat())
        testArray.push(arr);
      }
      var arr1 = [coordinatesArray.getAt(0).lng()]
      arr1.push(coordinatesArray.getAt(0).lat())
      testArray.push(arr1);

   
      
    })



   






  }

}



//comment


