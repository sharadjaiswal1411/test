

import { Component, OnInit } from '@angular/core';
import { Http } from '@angular/http'

import { environment } from '../../../environments/environment';
import { MomentDateAdapter } from '@angular/material-moment-adapter';
import { DateAdapter, MAT_DATE_FORMATS, MAT_DATE_LOCALE } from '@angular/material/core';

import { Observable } from 'rxjs/Rx';
import { ActivatedRoute, Router } from '@angular/router';
import { AuthService } from '../../_services/index';
import { utils, write, WorkBook } from 'xlsx';
import { saveAs } from 'file-saver';
import { Broadcaster } from '../../../environments/broadcaster';
import { LoaderService } from '../../_services/loader.service';

import * as _moment from 'moment';
import * as _rollupMoment from 'moment';
const moment = _rollupMoment || _moment;
export const MY_FORMATS = {
  parse: {
    dateInput: 'LL',
  },
  display: {
    dateInput: 'LL',
    monthYearLabel: 'MMM YYYY',
    dateA11yLabel: 'LL',
    monthYearA11yLabel: 'MMMM YYYY',
  },
};
declare var $: any;
declare var google: any;
declare var firebase: any;
declare var MapLabel: any
var stopAnimation = true

declare const MarkerClusterer;

@Component({

  selector: 'secondaryOps-cmp',
  templateUrl: './secondaryOps.component.html',
  providers: [
    { provide: DateAdapter, useClass: MomentDateAdapter, deps: [MAT_DATE_LOCALE] },
    { provide: MAT_DATE_FORMATS, useValue: MY_FORMATS },
  ],
})


export class SecondaryOpsComponent implements OnInit {
  public polyline_array;
  IEMI: any;
  VEHNO: any;
  mapLabelArray: any;
  public drivingSummary: any
  public map: any
  plotAllPoint:any
  public vehiclesList: any
  public selectedlist: number
  public vehiclesLocation: any
  public search: any

  public polygondData: any
  public prjID: any
  public date = moment()
  public latlongs = []
  all: any


  offline: any
  routePath: any
  currentAddressStart:any

  offlineArray = []
  oldArray = []
  isLive: any
  plotPcts:any
  route: any
  markerStart: any
  markerEnd: any
  currentVehiclesData: any
  vehiclesNo: any
  IMEI: any
  vehiclesType: any
  mobileNo: any
  startTime: any
  endTime: any
  geocoder: any
  currentAddress: any
  Liveroute: any
  distance: any
  stopAnimation: any
  allMarkers = []
  autoTicks = false;
  disabled = false;
  invert = false;
  max = 1000;
  public value: any
  min = 0;
  showTicks = false;
  step = 1;
  thumbLabel = false;
  position = [43, -89];
  vertical = false;
  counter: any
  public icon: any
  totalStop: any;
  totalDuration: any;
  vechicleListIsClicked: any;
  servingWardName: any;
  servingBeat: any;
  stopSummary: any;
  totalStopBeat: any;
  wardBoundary: any;
  beatBoundary: any;
  removeVehicles:any
  polygon: any;
  infoWindowStart: any;
  infoWindowEnd: any;
  controlText: any;
  centerControlDiv: any;
  vehicleCluster: any;
  markerCluster: any;
  deadVehicleSummary: any;
  notRunningSince15Days: any;
  notRunningSince10Days: any;
  notRunningSince5Days: any;
  notRunningSince2Days: any;
  notRunningSince15DaysArray: any;
  notRunningSince10DaysArray: any;
  notRunningSince5DaysArray: any;
  notRunningSince2DaysArray: any;
  deadVehicleList: any;
  selectedDeadList: any;
  searchDeadList: any;
  runningVehiclesByType: any;
  isStats: any;
  totalWorking: any;
  totalAvilable: any;
  showLoader: any;
  isClickedVehicle: any;
  vehicleInfoWindow: any;
  vehicleInfoWindowClicked: any
  plotSecondary: any;

  plotKhattaPoint: any
  plotParking: any;
  plotFCTS: any
  plotMTS: any
  plotBins: any


  secondaryPointData: any;
  secPointMarker: any
  wardPolygonList: any;
  vehicleInWard: any;
  lastActiveTime: any;

  moving: any;
  stopped: any;
  movingArray: any
  stoppedArray: any
  STOPPED: any;
  MOVING: any
  OFFLINE: any;
  ALL: any
  selectedFilter: any;
  notStarted:any
  notStartedArray:any
  NOTSTARTED:any;
 
  plotPlant:any
  searchSec:any
  constructor(private auth: AuthService, private http: Http, private loaderService: LoaderService, private routes: ActivatedRoute, private broadcaster: Broadcaster, private router: Router, ) {
    this.vehicleInfoWindow = new google.maps.InfoWindow();
    this.vehicleInfoWindowClicked = new google.maps.InfoWindow();
    this.value = 300
    this.polyline_array = []
    this.secPointMarker = []
    this.vehicleInWard = []
    this.mapLabelArray = []
    this.plotSecondary = false
    this.selectedFilter  = null
    this.runningVehiclesByType = []
    this.removeVehicles = true
    this.offline = 0
    this.moving = 0
    this.stopped = 0
    this.notStarted = 0
    this.movingArray = []
    this.stoppedArray = []
    this.notStartedArray = []
    
    this.ALL = true
    this.prjID = this.auth.getAuthentication().projectId
    var car = "M17.402,0H5.643C2.526,0,0,3.467,0,6.584v34.804c0,3.116,2.526,5.644,5.643,5.644h11.759c3.116,0,5.644-2.527,5.644-5.644 V6.584C23.044,3.467,20.518,0,17.402,0z M22.057,14.188v11.665l-2.729,0.351v-4.806L22.057,14.188z M20.625,10.773 c-1.016,3.9-2.219,8.51-2.219,8.51H4.638l-2.222-8.51C2.417,10.773,11.3,7.755,20.625,10.773z M3.748,21.713v4.492l-2.73-0.349 V14.502L3.748,21.713z M1.018,37.938V27.579l2.73,0.343v8.196L1.018,37.938z M2.575,40.882l2.218-3.336h13.771l2.219,3.336H2.575z M19.328,35.805v-7.872l2.729-0.355v10.048L19.328,35.805z";
    this.icon = {
      path: car,
      scale: .5,
      strokeColor: 'white',
      strokeWeight: .10,
      fillOpacity: 1,
      fillColor: '#404040',
      offset: '3%',
      anchor: new google.maps.Point(10, 25) 
    };

    this.controlText = document.createElement('div');
    this.centerControlDiv = document.createElement('div');
    this.centerControlDiv.index = 1;
    this.loaderService.status.subscribe((val: boolean) => {
      this.showLoader = val;
    });
  }



  viewStats() {
    this.getVehicleType()
    $("#vehicleDetail").toggle();
   
  }




  getVehicleType() {
    this.http.get(environment.apiUrl + "vehicles/runningSecVehicleByType?prjId=" + this.prjID).subscribe(data => {
      var result = data.json()
      var totalAvilable = 0
      var totalWorking = 0
      for (var i = 0; i < result.length; i++) {
        totalWorking = totalWorking + result[i].active;
        totalAvilable = totalAvilable + result[i].total

      }
      this.totalWorking = totalWorking
      this.totalAvilable = totalAvilable
      this.runningVehiclesByType = data.json()
      this.runningVehiclesByType.push({ VEHICLETYPENAME: 'All' })
      
    })
  }


  vehicleStats() {
    $('.divvehicledate').toggle();
    $('#divvehicledate').show();
  }
  vehiclelist() {
    $('.vehiclelist').toggle();
    $('#VehicleList').show();
    $('#SecondaryPoint').hide();
  }
  VehicleListbtn() {
    $('#VehicleList').show();
    $('#SecondaryPoint').hide();
  }

  SecondaryPointbtn() {
    $('#VehicleList').hide();
    $('#SecondaryPoint').show();
  }
  getDataWhenProjectChange = async (id) => {
    $('#loderImgTab').show()
    this.renoveAllMarker()
    let polygon = await fetch(environment.apiUrl + 'entity/getPolygonByOemId' + "?prjid=" + id + "&wardOemId=null" + "&beatOemId=null")
    this.polygondData = await polygon.json()
    this.clearFeature()
    this.map.data.addGeoJson(this.polygondData.geoJson);
    this.zoom(this.map, true);
    this.setStyle(this)

    let vehicles = await fetch(environment.apiUrl + 'vehicles/location/secondary' + '?prjID=' + id)
    this.vehiclesLocation = await vehicles.json()

    this.plotAllVehicles(this.vehiclesLocation)
    $('#loderImgTab').hide()
    this.status()
    this.vehicleStatus('all')
    this.getAllKhatta(id)
    $('#loderImgTab').hide()
    $('#progress-bar').hide()
  }




  status() {
    var d1 = new Date();
    var d3 = new Date();
    for (var j = 0; j < this.vehiclesLocation.length; j++) {
      delete this.vehiclesLocation[j]._id
      if (d3.setHours(0) < new Date(this.vehiclesLocation[j].HEARTBEATDATE).getTime()) {
        if (new Date(this.vehiclesLocation[j].HEARTBEATDATE).getTime() < d1.setHours(d1.getHours() - 2)) {
          d3 = new Date();
          d1 = new Date();

          this.vehiclesLocation[j].STATUS = "OFFLINE"
          this.offlineArray.push(this.vehiclesLocation[j])
          this.offline++
        }
        else {

          if (this.vehiclesLocation[j].SPEED == 0 && this.vehiclesLocation[j].DISTANCE>=100) {
            this.stopped++
            this.vehiclesLocation[j].STATUS = "STOPPED"
            this.stoppedArray.push(this.vehiclesLocation[j])
          }else if(this.vehiclesLocation[j].DISTANCE < 100 || this.vehiclesLocation[j].SPEED == null)
          {
          this.notStarted++
          this.vehiclesLocation[j].STATUS = "NOT_STARTED"
          this.notStartedArray.push(this.vehiclesLocation[j])
          
          }
          else {
            this.moving++
            this.vehiclesLocation[j].STATUS = "MOVING"
            this.movingArray.push(this.vehiclesLocation[j])
          }
        }
      }
    }
  }

  vehicleStatus(status) {


    this.vehiclesList = []
    if (status == 'all') {
      this.vehiclesList = this.vehiclesLocation
      this.totalWorking = this.vehiclesList.length
      this.MOVING = false
      this.STOPPED = false
      this.OFFLINE = false
      this.ALL = true
    } else if (status == 'MOVING') {
      this.MOVING = true
      this.STOPPED = false
      this.OFFLINE = false
      this.ALL = false
      this.NOTSTARTED = false
      this.vehiclesList = this.movingArray
    } else if (status == 'STOPPED') {
      this.MOVING = false
      this.STOPPED = true
      this.OFFLINE = false
      this.ALL = false
      this.NOTSTARTED = false
      this.vehiclesList = this.stoppedArray
    } else if (status == 'OFFLINE') {
      this.MOVING = false
      this.STOPPED = false
      this.OFFLINE = true
      this.ALL = false
      this.NOTSTARTED = false
      this.vehiclesList = this.offlineArray
    } else if (status == 'NOT_STARTED') {
      this.MOVING = false
      this.STOPPED = false
      this.OFFLINE = false
      this.ALL = false
      this.NOTSTARTED = true
      this.vehiclesList = this.notStartedArray
    }

  }

  filterVehicleList(type, i) {
    this.selectedFilter = i
    if (type == 'All') {
      this.search = null
    } else {
      this.search = type
    }

  }

  liveTrack() {
    if (this.isLive) {
      this.isLive = false
    } else {
      this.renoveAllMarker()
      this.route.setMap(null)
      this.plotRouteWhenLiveTrack()
      this.isLive = true
    }
  }

  deleteMarker(id, mylatlongs) {

    if (this.allMarkers.length > 0) {
      for (var i = 0; i < this.allMarkers.length; i++) {
        if (this.allMarkers[i].id == id) {
          if (this.isLive) {
            this.plotTransition(this.allMarkers[i], mylatlongs, id)
            this.allMarkers.splice(i, 1)
          }
          // this.allMarkers[i].setPosition(mylatlongs);


        }
      }
    }
  }

  renoveAllMarker() {
    if (this.allMarkers.length > 0) {
      for (var i = 0; i < this.allMarkers.length; i++) {
        this.allMarkers[i].setVisible(false);
      }
    }
  }
  plotTransition(startMarker, endMarker, id) {
    var last = startMarker.position.lat() + "," + startMarker.position.lng()
    var first = endMarker.lat() + "," + endMarker.lng()
    this.http.get(environment.apiUrl + 'vehicles/transition' + '?first=' + last + "&last=" + first).subscribe(data => {
      let result = data.json()
      this.autoRefreshLiveData(this.map, data.json().overview_polyline, id);
    });

  }
  plotMarker(point, DEVICEID, DEVICEDATE) {
    var car = "M17.402,0H5.643C2.526,0,0,3.467,0,6.584v34.804c0,3.116,2.526,5.644,5.643,5.644h11.759c3.116,0,5.644-2.527,5.644-5.644 V6.584C23.044,3.467,20.518,0,17.402,0z M22.057,14.188v11.665l-2.729,0.351v-4.806L22.057,14.188z M20.625,10.773 c-1.016,3.9-2.219,8.51-2.219,8.51H4.638l-2.222-8.51C2.417,10.773,11.3,7.755,20.625,10.773z M3.748,21.713v4.492l-2.73-0.349 V14.502L3.748,21.713z M1.018,37.938V27.579l2.73,0.343v8.196L1.018,37.938z M2.575,40.882l2.218-3.336h13.771l2.219,3.336H2.575z M19.328,35.805v-7.872l2.729-0.355v10.048L19.328,35.805z";
    var lineSymbol = {
      path: car,
      scale: .7,
      strokeColor: 'white',
      strokeWeight: .10,
      fillOpacity: 1,
      fillColor: '#0B0104',
      offset: '5%',
      anchor: new google.maps.Point(10, 25) // orig 10,50 back of car, 10,0 front of car, 10,25 center of car
    };
    this.markerStart = new google.maps.Marker({
      position: point,
      map: this.map,
      icon: lineSymbol,
      title: DEVICEID + "(" + DEVICEDATE + ")"
    });
    this.markerStart.id = DEVICEID;
    this.markerStart.setMap(this.map);
    this.allMarkers.push(this.markerStart);
  }


  transition(result) {
    var i = 0;
    var deltaLat = (result[0] - this.position[0]) / 100;
    var deltaLng = (result[1] - this.position[1]) / 100;
    this.moveMarker(deltaLat, deltaLng);
  }

  moveMarker(deltaLat, deltaLng) {
    this.position[0] += deltaLat;
    this.position[1] += deltaLng;
    var latlng = new google.maps.LatLng(this.position[0], this.position[1]);
    this.markerStart.setPosition(latlng);
    var i = 0
    if (i != 100) {
      i++;
      setTimeout(this.moveMarker, 10);
    }
  }


  plotAllVehicles(data) {

    var thisRef = this
    var infoWindow = new google.maps.InfoWindow;
    var icon
    if (this.markerCluster) {
      this.markerCluster.clearMarkers();
    }

    this.renoveAllMarker()
    var markers = []
    for (var i = 0; i < data.length; i++) {
      if (data[i].vehtypname == "Tractor") {
        icon = 'assets/img/tractor.png'
      } else if (data[i].vehtypname == "Tipper" || data[i].vehtypname == "Bolero" || data[i].vehtypname == "TATA-Zip-XL" || data[i].vehtypname == "TATA-Zip") {
        icon = 'assets/img/triper.png'
      } else if (data[i].vehtypname == "Hyva") {
        icon = 'assets/img/hyva.png'
      }
      else if (data[i].vehtypname == "JCB 2DX" || data[i].vehtypname == "JCB 3DX") {
        icon = 'assets/img/jcb.png'
      } else if (data[i].vehtypname == "Refuse Compactor") {
        icon = 'assets/img/refuseCompactor.png'
      } else if (data[i].vehtypname == "Hook Loader") {
        icon = 'assets/img/hookLoader.png'
      }
      else {
        icon = 'assets/img/triper.png'
      }
      var item = data[i]
      if (item.LAT && item.LONG) {
        var marker = new google.maps.Marker({
          position: { lat: JSON.parse(item.LAT), lng: JSON.parse(item.LONG) },
          icon: icon,
          title: " VEHNO :" + item.vehno + " , TIME :" + item.HEARTBEATDATE + " , SPEED :" + item.SPEED

        });
        marker.id = item.DEVICEID;
        marker.vehno = item.vehno;
        marker.SPEED = item.SPEED;
        marker.dateTime = item.HEARTBEATDATE;
        marker.DISTANCE = (item.DISTANCE / 1000).toFixed(2);
        marker.BEAT = item.BEAT;
        marker.WARD = item.WARD
        marker.VTYPE = item.vehtypname
        markers.push(marker)
        this.allMarkers.push(marker)
        if (!this.vehicleCluster) {
          marker.setMap(this.map);
        }
      }
      (function (marker, data) {
        google.maps.event.addListener(marker, "click", function (e) {
          thisRef.isClickedVehicle = data.DEVICEID
          //Wrap the content inside an HTML DIV in order to set height and width of InfoWindow.
          var content = "<div class='col-sm-12 '>" + "<p class='info-deatil'><strong>IMEI :</strong>" + "  " + marker.id +
            "</p><p class='info-deatil'><strong>Vehicle No :</strong>" + "  " + marker.vehno +
            "</p><p class='info-deatil'><strong>Speed :</strong>" + "  " + marker.SPEED + " " +
            "</p><p class='info-deatil'><strong>Date Time :</strong>" + "  " + marker.dateTime + " " +
            "</p><p class='info-deatil'><strong>Distance :</strong>" + "  " + marker.DISTANCE + "</p></div>" +
            "</p><p class='info-deatil'><strong>Area :</strong>" + "  " + marker.BEAT + "</p></div>"
          infoWindow.setContent(content);
          infoWindow.open(this.map, marker);
        });
      })(marker, item);
    }

    if (this.vehicleCluster) {
      this.markerCluster = new MarkerClusterer(this.map, markers,
        { imagePath: 'https://developers.google.com/maps/documentation/javascript/examples/markerclusterer/m' });
    }
  }



  processPoints(this, geometry, callback, thisArg) {
    if (geometry instanceof google.maps.LatLng) {
      callback.call(thisArg, geometry);
    } else if (geometry instanceof google.maps.Data.Point) {
      callback.call(thisArg, geometry.get());
    } else {
      if (geometry) {
        geometry.getArray().forEach((g) => {
          this.processPoints(g, callback, thisArg);
        });
      }
    }
  }

  zoom(this, map, isZone) {
    this.bounds = new google.maps.LatLngBounds();
    this.map.data.forEach((feature) => {
      if (isZone) {
        this.processPoints(feature.getGeometry(), this.bounds.extend, this.bounds);
      } else {
        if (feature.getProperty('type') == "route") {
          this.processPoints(feature.getGeometry(), this.bounds.extend, this.bounds);
        }
      }

    });
    map.fitBounds(this.bounds);

  }




  reload() {
    $('#loderImgTab').hide()
    $("#infotable1").hide()
    $("#infotable2").hide()
    $("#statusTable").show()
    $("#play").show()
    $("#stop").hide()
    $("#veichiclesInfo-bar").hide()
    $('#progress-bar').hide()
    this.removeLine()
    this.removeMarker()
    this.clearStopMarker()
    this.getDataWhenProjectChange(this.prjID)
  }



  plotRoute = async (data, index) => {
    this.loaderService.display(true);
    this.vechicleListIsClicked = true
    this.IEMI = data.IMEI
    this.VEHNO = data.vehno
    this.mobileNo = data.vtsmobileno
    this.servingWardName = ""
    $("#infotable1").hide()
    $("#infotable2").hide()

    this.clearCurrentVehicalInfo()
    this.renoveAllMarker()
    let date = moment(this.date).format('YYYY-MM-DD');
    this.selectedlist = index;
    let response = await fetch(environment.apiUrl + 'vehicles/route' + '?DEVICEID=' + data.IMEI + "&prjId=" + this.prjID + "&date=" + date)
    let result = await response.json()
    this.loaderService.display(false);
    if (result.status == "No Route Found") {
      this.removeMarker()
      this.getPrevDayLocation(data)
      if (result.data.length > 0) {
        this.showCurrentVehiclesInfo(result.data[0], data)
        this.locateVehicle(result.data[0].STARTPOINT)
        this.plotStartAndEndPoint(result.data[0])
        this.totalStop = 0
        this.totalDuration = 0 + ": " + 0 + "(HH:MM)"
        $("#infotable1").show()
        $("#infotable2").show()
      } else {
        this.removeMarker()
        $("#infotable1").hide()
        $("#infotable2").hide()
      }

      $("#statusTable").show()
      $("#veichiclesInfo-bar").hide()
      this.clearStopMarker()
      this.removeLine()
      alert(result.status)
    } else {
      $("#infotable1").show()
      $("#infotable2").show()
      this.removeLine()
      this.createRoute(this.map, result.latLong);

      this.showCurrentVehiclesInfo(result, data)
      this.removeMarker()
      this.plotStartAndEndPoint(result)

      let stopInfo = await fetch(environment.apiUrl + 'getStopInfo?DEVICEID=' + data.IMEI + '&DEVICEDATE=' + date)
      let stop_info_data = await stopInfo.json()
      this.plotStopPosition(stop_info_data)
      let res = await fetch(environment.apiUrl + 'vehicles/getServingArea' + '?DEVICEID=' + data.IMEI + "&prjId=" + this.prjID + "&date=" + date)
      var servingWard = await res.json()
      this.servingWardName = servingWard.wardName

    }
  }

  getPrevDayLocation = async (data) => {
    let res = await fetch(environment.apiUrl + 'vehicles/getPrevDayLocation' + '?DEVICEID=' + data.IMEI + "&prjId=" + this.prjID)
    var lastActive = await res.json()
    if (lastActive.length > 0) {
      $("#infotable1").show()
      $("#infotable2").show()
      this.distance = 0
      this.vehiclesNo = data.vehno
      this.vehiclesType = data.vehtypname
      this.startTime = 'NA'
      this.endTime = 'NA'
      this.totalStop = 0
      this.totalDuration = 0
      this.lastActiveTime = moment(new Date(lastActive[0].lastActiveDate)).startOf('hour').fromNow()
      var latlng = { lat: lastActive[0].lastLocation.coordinates[1], lng: lastActive[0].lastLocation.coordinates[0] };
      this.geocoder.geocode({ 'location': latlng }, (results, status) => {
        if (status === 'OK') {
          this.currentAddress = results[0].formatted_address
        }
      })

      var start = new google.maps.LatLng(lastActive[0].lastLocation.coordinates[1], lastActive[0].lastLocation.coordinates[0]);
      this.markerStart = new google.maps.Marker({
        position: start,
        map: this.map,
        icon: 'assets/img/start.png',
        labelClass: "labels", // the CSS class for the label 
        labelStyle: { opacity: 1.00 }
      });
      var position = { LAT: lastActive[0].lastLocation.coordinates[1], LONG: lastActive[0].lastLocation.coordinates[0] }
      this.locateVehicle(position)
    }
  }

  closeInfo() {
    $(".individual_detail").toggle()
  }
  getGeoLocation(lat, LONG, i, data) {
    var latlng = { lat: lat, lng: LONG };
    this.geocoder.geocode({ 'location': latlng, result_type: 'street_address' }, (results, status) => {
      if (status === 'OK') {
        var result = results[0].formatted_address
        var address = result.split(",")[0] + " " + result.split(",")[1] + +" " + result.split(",")[2]
        this.stopSummary[i].address = address
      }
    })
  }
  getStopSummary() {
    $("#stopSummary").modal("show")
    let date = moment(this.date).format('YYYY-MM-DD');
    this.http.get(environment.apiUrl + "vehicle/stopSummary?" + "prjId=" + this.prjID + "&deviceId=" + this.IEMI + "&date=" + date).subscribe(data => {
      this.stopSummary = data.json()
      console.log(this.stopSummary)
      this.getTotalStopsInBeat(this.stopSummary)
    })
  }

  getTotalStopsInBeat(data) {
    var stop = 0
    for (var i = 0; i < data.length; i++) {
      stop = stop + data[i].totalStops
    }
    this.totalStopBeat = stop
  }


  
 

  getAllKhatta(prjID) {
    this.http.get(environment.apiUrl + 'admin/getKhattaDetailsByProject' + "?PRJID=" + prjID).subscribe(data => {
      let result = data.json()
      console.log(result)
      this.secondaryPointData = result
      this.plotKhattaPoint = true
      this.plotParking = true
      this.plotFCTS = true
      this.plotMTS = true
      this.plotBins = true
      this.plotPcts = true
      this.plotPlant = true
      this.plotAllPoint = true
      this.plotAllKhatta(result)


    })
  }


  plotPoint(data, i) {

  }

  plotKhattaLoc(id) {
    if (this.plotKhattaPoint) {
      this.plotAllKhatta(this.secondaryPointData)
    } else {
      this.removeSecPoint(id)
    }
  }
  plotParkingPoint(id) {
    if (this.plotParking) {
      this.plotAllKhatta(this.secondaryPointData)
    } else {
      this.removeSecPoint(id)
    }
  }
  plotFCTSpoint(id) {
    if (this.plotFCTS) {
      this.plotAllKhatta(this.secondaryPointData)
    } else {
      this.removeSecPoint(id)
    }
  }

  plotMTSPoint(id) {
    if (this.plotMTS) {
      this.plotAllKhatta(this.secondaryPointData)
    } else {
      this.removeSecPoint(id)
    }
  }
  plotPlantPoint(id){
    if (this.plotPlant) {
      this.plotAllKhatta(this.secondaryPointData)
    } else {
      this.removeSecPoint(id)
    }
  }

  plotBinsPoint(id) {
    if (this.plotBins) {
      this.plotAllKhatta(this.secondaryPointData)
    } else {
      this.removeSecPoint(id)
    }
  }
  plotPctsPoint(id) {
    if (this.plotPcts) {
      this.plotAllKhatta(this.secondaryPointData)
    } else {
      this.removeSecPoint(id)
    }
  }

  removeVehicle(){
    if (this.removeVehicles) {
      if (this.allMarkers.length > 0) {
        for (var i = 0; i < this.allMarkers.length; i++) {
          this.allMarkers[i].setVisible(true);
        }
      }
    } else {
      this.renoveAllMarker()
    }
  }

  removeSecPoint(id) {
    if (this.secPointMarker.length > 0) {
      for (var i = 0; i < this.secPointMarker.length; i++) {
        if (this.secPointMarker[i].OEMID == id) {
          this.secPointMarker[i].setVisible(false);
        }
      }
    }
  }


  plotAll(){
    if(this.plotAllPoint){
      this.plotKhattaPoint = true
      this.plotParking = true
      this.plotFCTS = true
      this.plotMTS = true
      this.plotBins = true
      this.plotPcts = true
      this.plotPlant = true

      this.plotKhattaLoc(40) 
      this.plotParkingPoint(13)
      this.plotFCTSpoint(12)
    
      this.plotMTSPoint(42) 
      this.plotPlantPoint(15)
    
      this.plotBinsPoint(14) 
      this.plotPctsPoint(11) 
      }else{
        this.plotKhattaPoint = false
        this.plotParking = false
        this.plotFCTS = false
        this.plotMTS = false
        this.plotBins = false
        this.plotPcts = false
        this.plotPlant = false
        this.removeSecPoint(40)
        this.removeSecPoint(13)
        this.removeSecPoint(12)
        this.removeSecPoint(42)
        this.removeSecPoint(15)
        this.removeSecPoint(14)
        this.removeSecPoint(11)
      

      }
    

  }



  plotAllKhatta(data) {
    var infoWindow = new google.maps.InfoWindow;
    var bounds = new google.maps.LatLngBounds();
    var coordinates = []
    var totalCount = 0
    var totalDuration = 0
    var icon = 'assets/img/khatta.png'
    for (var i = 0; i < data.length; i++) {
      var item = data[i]
      if (item.LAT != null && item.LNG != null) {
        var marker;
        if (item.OEMID == 40 && this.plotKhattaPoint) {
          icon = 'assets/img/khatta.png'
          marker = new google.maps.Marker({
            position: { lat: JSON.parse(item.LAT), lng: JSON.parse(item.LNG) },
            map: this.map,
            icon: icon,
            title: data[i].ENTITYNAME + " ( " + data[i].OEMNAME + " ) ",
            OEMID: data[i].OEMID
          });
          this.secPointMarker.push(marker)
          marker.setMap(this.map);
        } else if (item.OEMID == 14 && this.plotBins) {
          icon = 'assets/img/dustbin.png'
          marker = new google.maps.Marker({
            position: { lat: JSON.parse(item.LAT), lng: JSON.parse(item.LNG) },
            map: this.map,
            icon: icon,
            title: data[i].ENTITYNAME + " ( " + data[i].OEMNAME + " ) ",
            OEMID: data[i].OEMID
          });
          this.secPointMarker.push(marker)
          marker.setMap(this.map);
        }
        else if (item.OEMID == 12 && this.plotFCTS) {
          icon = 'assets/img/ts.png'
          marker = new google.maps.Marker({
            position: { lat: JSON.parse(item.LAT), lng: JSON.parse(item.LNG) },
            map: this.map,
            icon: icon,
            title: data[i].ENTITYNAME + " ( " + data[i].OEMNAME + " ) ",
            OEMID: data[i].OEMID
          });
          this.secPointMarker.push(marker)
          marker.setMap(this.map);
        } else if (item.OEMID == 13 && this.plotParking) {
          icon = 'assets/img/parking.png'
          marker = new google.maps.Marker({
            position: { lat: JSON.parse(item.LAT), lng: JSON.parse(item.LNG) },
            map: this.map,
            icon: icon,
            title: data[i].ENTITYNAME + " ( " + data[i].OEMNAME + " ) ",
            OEMID : data[i].OEMID
          });
          this.secPointMarker.push(marker)
          marker.setMap(this.map);
        }
        else if (item.OEMID == 42 && this.plotMTS) {
          icon = 'assets/img/ts.png'
          marker = new google.maps.Marker({
            position: { lat: JSON.parse(item.LAT), lng: JSON.parse(item.LNG) },
            map: this.map,
            icon: icon,
            title: data[i].ENTITYNAME + " ( " + data[i].OEMNAME + " ) ",
            OEMID: data[i].OEMID
          });
          this.secPointMarker.push(marker)
          marker.setMap(this.map);
        }else if (item.OEMID == 11 && this.plotPcts) {
          icon = 'assets/img/ts.png'
          marker = new google.maps.Marker({
            position: { lat: JSON.parse(item.LAT), lng: JSON.parse(item.LNG) },
            map: this.map,
            icon: icon,
            title: data[i].ENTITYNAME + " ( " + data[i].OEMNAME + " ) ",
            OEMID: data[i].OEMID
          });
          this.secPointMarker.push(marker)
          marker.setMap(this.map);
        }else if (item.OEMID == 15 && this.plotPlant) {
          icon = 'assets/img/plant.png'
          marker = new google.maps.Marker({
            position: { lat: JSON.parse(item.LAT), lng: JSON.parse(item.LNG) },
            map: this.map,
            icon: icon,
            title: data[i].ENTITYNAME + " ( " + data[i].OEMNAME + " ) ",
            OEMID: data[i].OEMID
          });
          this.secPointMarker.push(marker)
          marker.setMap(this.map);
        }
      }
    }
  }

  plotEngineOffLocation(engineOffData) {
    //this.clearStopMarker()
    var data = { features: [], type: "" }
    data.type = "FeatureCollection"
    var coordinates = []
    var stop = 0
    var totalDuration = 0
    for (var i = 0; i < engineOffData.length; i++) {
      if (engineOffData[i].LONG && engineOffData[i].LAT) {
        stop++
        var geometry = { coordinates: [], type: "" }
        geometry.coordinates.push(Number(engineOffData[i].LONG), Number(engineOffData[i].LAT))
        geometry.type = "Point"
        // var duration =  this.diff_hours(new Date(engineOffData[i].STARTTIME), new Date(engineOffData[i].ENDTIME))
        totalDuration = totalDuration + engineOffData[i].duration;
        data.features.push({
          geometry: geometry, type: "Feature", properties: {
            "ZONE": engineOffData[i].zoneName,
            "WARD": engineOffData[i].WardName,
            "TYPE": "engine_Off",
            "STARTTIME": engineOffData[i].HEARTBEATDATE,
          }
        })
      }
    }
    this.map.data.addGeoJson(data);

  }
  drivingSummaryModal() {
    $("#drivingSummary").modal("show")
  }

  diff_hours(dt2, dt1) {
    var difference = dt1.getTime() - dt2.getTime(); // This will give difference in milliseconds
    var resultInMinutes = Math.round(difference / 60000);
    var hours = (resultInMinutes / 60);
    var rhours = Math.floor(hours);
    var minutes = (hours - rhours) * 60;
    var rminutes = Math.round(minutes);
    return rhours + ": " + rminutes
  }



  plotStopPosition(stopInfo) {
    this.clearStopMarker()
    var data = { features: [], type: "" }
    data.type = "FeatureCollection"
    var coordinates = []
    var stop = 0
    var totalDuration = 0
    for (var i = 0; i < stopInfo.length; i++) {
      if (stopInfo[i].LONG && stopInfo[i].LAT) {
        stop++
        var geometry = { coordinates: [], type: "" }
        geometry.coordinates.push(Number(stopInfo[i].LONG), Number(stopInfo[i].LAT))
        geometry.type = "Point"
        var duration = this.diff_hours(new Date(stopInfo[i].STARTTIME), new Date(stopInfo[i].ENDTIME))
        totalDuration = totalDuration + stopInfo[i].duration;
        data.features.push({
          geometry: geometry, type: "Feature", properties: {
            "DEVICEID": stopInfo[i].DEVICEID,
            "VEHICLE_NO": stopInfo[i].VEHICLE_NO,
            "STARTTIME": stopInfo[i].STARTTIME,
            "ENDTIME": stopInfo[i].ENDTIME,
            "DURATION": duration,
            "ZONE": stopInfo[i].zoneName,
            "WARD": stopInfo[i].WardName,
            "BEAT": stopInfo[i].beatName,
            "TYPE": "stopMarker",
            "engineStatus": (stopInfo[i].ACC == 0) ? "Off" : "On",
            "number": stop
          }
        })
      }
    }
    this.totalStop = stop
    var hours = (totalDuration / 60);
    var rhours = Math.floor(hours);
    var minutes = (hours - rhours) * 60;
    var rminutes = Math.round(minutes);
    this.totalDuration = rhours + ": " + rminutes + "(HH:MM)"
    this.map.data.addGeoJson(data);

  }

  plotRouteWhenLiveTrack() {
    this.route = new google.maps.Polyline({
      path: this.routePath,
      strokeColor: '#686C55',
      strokeOpacity: 1.0,
      strokeWeight: 4,
      map: this.map
    });
  }
  createRoute(map, pathCoords) {
    var i, route, marker;
    var polyCords = []
    for (i = 0; i < pathCoords.length; i++) {
      polyCords.push({ lat: JSON.parse(pathCoords[i][1]), lng: JSON.parse(pathCoords[i][0]) });
    }
    var car = "M17.402,0H5.643C2.526,0,0,3.467,0,6.584v34.804c0,3.116,2.526,5.644,5.643,5.644h11.759c3.116,0,5.644-2.527,5.644-5.644 V6.584C23.044,3.467,20.518,0,17.402,0z M22.057,14.188v11.665l-2.729,0.351v-4.806L22.057,14.188z M20.625,10.773 c-1.016,3.9-2.219,8.51-2.219,8.51H4.638l-2.222-8.51C2.417,10.773,11.3,7.755,20.625,10.773z M3.748,21.713v4.492l-2.73-0.349 V14.502L3.748,21.713z M1.018,37.938V27.579l2.73,0.343v8.196L1.018,37.938z M2.575,40.882l2.218-3.336h13.771l2.219,3.336H2.575z M19.328,35.805v-7.872l2.729-0.355v10.048L19.328,35.805z";
    var icon = {
      path: car,
      scale: 1,
      strokeColor: 'white',
      strokeWeight: .10,
      fillOpacity: 5,
      fillColor: '#1DA42B',
      offset: '2%',
      // rotation: parseInt(heading[i]),
      anchor: new google.maps.Point(10, 25) // orig 10,50 back of car, 10,0 front of car, 10,25 center of car
    };
    this.routePath = polyCords
    this.route = new google.maps.Polyline({
      path: polyCords,
      strokeColor: '#4753B0',
      strokeOpacity: 4.0,
      strokeWeight: 6,
      icons: [{
        icon: icon,
        offset: '100%',

      },
      ],
      map: map
    });
    this.zoomToObject(this.route)
  }

  clearCurrentVehicalInfo() {
    this.distance = null
    this.vehiclesNo = null
    this.IMEI = null
    this.vehiclesType = null
    this.startTime = null
    this.endTime = null
    this.currentAddress = null
  }

  showCurrentVehiclesInfo(data, tableRow) {
    this.distance = data.distance.toFixed(2);
    this.vehiclesNo = tableRow.vehno
    this.IMEI = tableRow.IMEI
    this.vehiclesType = tableRow.vehtypname
    this.startTime = moment(new Date(data.STARTTIME)).format('h:mm:ss a');
    this.endTime = moment(new Date(data.ENDTIME)).format('h:mm:ss a');
    this.lastActiveTime = tableRow.LASTACTIVEDATE
    var latlng = { lat: data.ENDPOINT.LAT, lng: data.ENDPOINT.LONG };
    this.geocoder.geocode({ 'location': latlng }, (results, status) => {
      if (status === 'OK') {
        this.currentAddress = results[0].formatted_address
      }
    })

    var latlngStart = { lat: data.STARTPOINT.LAT, lng: data.STARTPOINT.LONG };

    this.geocoder.geocode({ 'location': latlngStart }, (results, status) => {
      if (status === 'OK') {
        this.currentAddressStart = results[0].formatted_address
      }
    })

  }
  removeLine() {
    if (this.route) {
      this.route.setMap(null);
    }
  }
  removeMarker() {
    if (this.markerStart && this.markerEnd) {
      this.markerStart.setMap(null);
      this.markerEnd.setMap(null);
    } else if (this.markerStart) {
      this.markerStart.setMap(null);
    }
  }
  removeStartAndEndPoint() {
    this.infoWindowStart.close();
    this.infoWindowEnd.close();
  }
  StatusUp() {
    $('.status_extra').toggle();
  }
  plotStartAndEndPoint(data) {
    console.log(data)
    var start = new google.maps.LatLng(data.STARTPOINT.LAT, data.STARTPOINT.LONG);
    var end = new google.maps.LatLng(data.ENDPOINT.LAT, data.ENDPOINT.LONG);
    this.markerStart = new google.maps.Marker({
      position: start,
      map: this.map,
      icon: 'assets/img/start.png',

      labelClass: "labels", // the CSS class for the label 
      labelStyle: { opacity: 1.00 }

    });
    this.markerEnd = new google.maps.Marker({
      position: end,
      map: this.map,
      icon: 'assets/img/end.png'
    });
  }

  autoRefreshLiveData(map, pathCoords, id) {
    var i, route, marker;
    var polyCords = []
    var polyLiveCords = []
    this.removePolyLine(id)
    for (i = 0; i < pathCoords.length; i++) {
      polyCords.push({ lat: JSON.parse(pathCoords[i][1]), lng: JSON.parse(pathCoords[i][0]) });
      //  this.routePath.push({ lat: JSON.parse(pathCoords[i][1]), lng: JSON.parse(pathCoords[i][0]) })
    }
    // if(this.live){
    //   this.plotLiveRoute(pathCoords)
    // }

    this.Liveroute = new google.maps.Polyline({
      path: polyCords,
      strokeColor: '#686C55',
      strokeOpacity: 1.0,
      strokeWeight: 4,
      icons: [{
        icon: this.icon,
        offset: '100%'

      },
      ],
      map: this.map
    });
    this.polyline_array.push({ line: this.Liveroute, id: id })
    // this.animateCircle(this.Liveroute)
    var markerPoint = pathCoords[0]
    polyCords = []
  }

  plotLiveRoute(polyCords) {
    this.route = new google.maps.Polyline({
      path: polyCords,
      strokeColor: '#686C55',
      strokeOpacity: 1.0,
      strokeWeight: 4,
      icons: [{
        icon: this.icon,
        offset: '100%'
      },
      ],
      map: this.map
    });
  }
  removePolyLine(id) {
    for (var i = 0; i < this.polyline_array.length; i++) {
      if (id == this.polyline_array[i].id) {
        this.polyline_array[i].line.setMap(null)
      }
    }
  }


  animateLiveCircle(line) {
    var count = 0;
    var value = 300
    stopAnimation = true
    var myinterval = setInterval(() => {
      count = (count + 1) % 200;
      var icons = line.get('icons');
      icons[0].offset = (count / 2) + '%';
      if (count === 199) {
        line.set('icons', null);
        clearInterval(myinterval)
        //line.unSet('icons', icons);
        line.setMap(null)
      }
      line.set('icons', icons);
    }, 250)
  }


  animateCircle(line) {
    var count = 0;
    $("#play").hide()
    $("#stop").show()
    if (!stopAnimation) {
      stopAnimation = true
      return;
    }
    stopAnimation = true
    var myVar = window.setInterval(function () {
      if (stopAnimation) {
        count = (count + 1) % 200;
        var icons = line.get('icons');
        icons[0].offset = (count / 2) + '%';
        if (count === 199) {
          clearInterval(myVar);
          $("#play").show()
          $("#stop").hide()
        }
        line.set('icons', icons);
      }
    }, 6);
  }


  async refreshLiveData() {
    let vehicles = await fetch(environment.apiUrl + 'vehicles/location/all' + '?prjID=' + this.prjID)
    this.vehiclesLocation = await vehicles.json()
    this.plotAllVehicles(this.vehiclesLocation)
  }
  stopPlay() {
    stopAnimation = false
    $("#play").show()
    $("#stop").hide()

  }
  zoomToObject(obj) {
    var bounds = new google.maps.LatLngBounds();
    var points = obj.getPath().getArray();
    for (var n = 0; n < points.length; n++) {
      bounds.extend(points[n]);
    }
    this.map.fitBounds(bounds);
  }

  clearFeature() {
    this.map.data.forEach((feature) => {
      this.map.data.remove(feature);
    })
  }
  removeMapLabel(entityId) {
    for (var i = 0; i < this.mapLabelArray.length; i++) {
      if (entityId == this.mapLabelArray[i].entityId) {
        this.mapLabelArray[i].setMap(null);
      }
    }
  }
  async plotWardBoundary(entityId) {
    if (!this.wardBoundary) {
      this.map.data.forEach((feature) => {
        if (feature.getProperty('TYPE') != "stopMarker" && feature.getProperty('Oemid') == entityId) {
          this.map.data.remove(feature);
          this.removeMapLabel(feature.getProperty('EntityID'))
        }
      })
    } else {
      let polygon = await fetch(environment.apiUrl + 'entity/getPolygonByOemId' + "?prjid=" + this.prjID + "&wardOemId=" + entityId + "&beatOemId =" + null)
      var polygondData = await polygon.json()
      this.map.data.addGeoJson(polygondData.geoJson);
    }
  }

  async getWardPolygon() {
    let polygon = await fetch(environment.apiUrl + 'entity/getPolygonByOemId' + "?prjid=" + this.prjID + "&wardOemId=" + 8 + "&beatOemId =" + null)
    var polygondData = await polygon.json()
    this.wardPolygonList = polygondData.entityData
    console.log(this.wardPolygonList)
  }

  selectWard(polygonData) {
    console.log(polygonData)
    var data = {
      features: [{ geometry: {}, type: "Feature", properties: "" }], type: ""
    }
    var d = JSON.parse(polygonData.kml)
    data.features[0].geometry = d
    var prop = JSON.parse(polygonData.properties)
    prop.type = "clickedPolygon"
    data.features[0].properties = prop
    data.type = "FeatureCollection"
    var color = '#B05C3C'
    this.map.data.forEach((feature) => {
      if (feature.getProperty('type') == "clickedPolygon") {
        this.map.data.remove(feature);
      }
    })
    this.removeOutsideMarker(polygonData.entityname)
    this.map.data.addGeoJson(data);
    this.zoomOneEntity(this.map);
  }


  removeOutsideMarker(wardName) {
    this.vehicleInWard = []
    console.log("wardName", wardName)
    if (this.allMarkers.length > 0) {
      for (var i = 0; i < this.allMarkers.length; i++) {
        if (wardName == this.allMarkers[i].WARD) {
          this.allMarkers[i].setVisible(true);
          var obj = {
            IMEI: this.allMarkers[i].id,
            VEHICLE_NO: this.allMarkers[i].vehno,
            DATETIME: this.allMarkers[i].dateTime,
            "DISTANCE(KM)": this.allMarkers[i].DISTANCE,
            WARD: this.allMarkers[i].WARD,
            BEAT: this.allMarkers[i].BEAT,
            TYPE: this.allMarkers[i].VTYPE
          }
          this.vehicleInWard.push(obj)
        } else {
          console.log(wardName)
          this.allMarkers[i].setVisible(false);
        }
      }
    }
  }


  vehicleInWardExport() {
    const ws_name = 'SomeSheet';
    const wb: WorkBook = { SheetNames: [], Sheets: {} };
    const ws: any = utils.json_to_sheet(this.vehicleInWard);
    wb.SheetNames.push(ws_name);
    wb.Sheets[ws_name] = ws;
    const wbout = write(wb, {
      bookType: 'xlsx', bookSST: true, type:
        'binary'
    });
    saveAs(new Blob([this.s2ab(wbout)], { type: 'application/octet-stream' }), 'Vehicle.xlsx');
  }
  zoomOneEntity(this, map) {
    this.bounds = new google.maps.LatLngBounds();
    map.data.forEach((feature) => {
      if (feature.getProperty('type') == "clickedPolygon") {
        this.processPoints(feature.getGeometry(), this.bounds.extend, this.bounds);
      }
    });
    map.fitBounds(this.bounds);
  }


  async plotBeatBoundary(entityId) {
    if (!this.beatBoundary) {
      this.map.data.forEach((feature) => {
        if (feature.getProperty('TYPE') != "stopMarker" && feature.getProperty('Oemid') == entityId) {
          this.map.data.remove(feature);
        }
      })
    } else {
      let polygon = await fetch(environment.apiUrl + 'entity/getPolygonByOemId' + "?prjid=" + this.prjID + "&wardOemId=" + null + "&beatOemId=" + entityId)
      var polygondData = await polygon.json()
      this.map.data.addGeoJson(polygondData.geoJson);
    }
  }

  clearPrevRoute(data) {

    this.map.data.forEach((feature) => {
      if (feature.getProperty('type') == "route") {
        this.map.data.remove(feature);
      }
    })
  }

  clearStopMarker() {
    this.map.data.forEach((feature) => {
      if (feature.getProperty('TYPE') == "stopMarker" || feature.getProperty('TYPE') == "engine_Off") {
        this.map.data.remove(feature);
      }
    })
  }
  setStyle(thisRef) {
    this.map.data.setStyle(function (feature) {
      var color = feature.getProperty('FillColor');
      var strokeColor = feature.getProperty('Bcolor')
      if (feature.getProperty('Oemid') == 8) {
        thisRef.polygonLabel(feature.getProperty('Ward'), feature.getProperty('LAT'), feature.getProperty('LON'), 16, 12, feature.getProperty('EntityID'), strokeColor)
      } else if (feature.getProperty('Oemid') == 7) {
        thisRef.polygonLabel(feature.getProperty('Zone'), feature.getProperty('LAT'), feature.getProperty('LON'), 18, 13, feature.getProperty('EntityID'), "#010100")
      }

      if (feature.getProperty('TYPE') == "stopMarker") {

        return ({
          fillColor: color,
          strokeColor: strokeColor,
          strokeWeight: 2,
          fillOpacity: 0.05,
          icon: 'assets/img/stopMarker.png',
          strokeopacity: 0.2,
          label: {
            text: feature.getProperty('number'),
            color: '#FFFFFF',
            fontSize: "13px",
            background: 'yellow',
            fontWeight: "bold",
            AlignmentVertical: "top",
            AlignmentHorizontal: "center"
          },
          labelClass: "my-custom-class-for-label"


        });
      } else if (feature.getProperty('TYPE') == "khatta") {
        return ({
          fillColor: color,
          strokeColor: strokeColor,
          strokeWeight: 5,
          fillOpacity: 0.0,
          strokeopacity: 0.2,
          icon: 'assets/img/khatta.png',
        });
      } else if (feature.getProperty('Oemid') == 8 || feature.getProperty('Oemid') == 9) {
        return ({
          fillColor: color,
          strokeColor: strokeColor,
          strokeWeight: 3,
          fillOpacity: 0.1,
          strokeopacity: 0.8,
        });

      } else {
        return ({
          fillColor: color,
          strokeColor: "#040C0A",
          strokeWeight: 4,
          fillOpacity: 0.1,
          strokeopacity: 0.4

        });
      }
    });
  }

  /* 
     excel Import
  */

  s2ab(s) {
    const buf = new ArrayBuffer(s.length);
    const view = new Uint8Array(buf);
    for (let i = 0; i !== s.length; ++i) {
      view[i] = s.charCodeAt(i) & 0xFF;
    };
    return buf;
  }

  importToExcel(data) {
    const ws_name = 'SomeSheet';
    const wb: WorkBook = { SheetNames: [], Sheets: {} };
    const ws: any = utils.json_to_sheet(data);
    wb.SheetNames.push(ws_name);
    wb.Sheets[ws_name] = ws;
    const wbout = write(wb, {
      bookType: 'xlsx', bookSST: true, type:
        'binary'
    });
    saveAs(new Blob([this.s2ab(wbout)], { type: 'application/octet-stream' }), 'exported.xlsx');
  }










  locateVehicle(position) {
    var myPlace = new google.maps.LatLng(position.LAT, position.LONG);
    var bounds = new google.maps.LatLngBounds(myPlace);
    this.map.fitBounds(bounds);
  }





  CenterControl(controlDiv, map) {
    // Set CSS for the control border.
    var controlUI = document.createElement('table');
    controlUI.style.backgroundColor = '#fff';
    controlUI.style.border = '2px solid #fff';
    controlUI.style.borderRadius = '1px';
    controlUI.style.boxShadow = '0 2px 6px rgba(0,0,0,.4)';
    controlUI.style.cursor = 'pointer';
    controlUI.style.marginBottom = '0px';
    controlUI.style.textAlign = 'top_right';
    controlDiv.appendChild(controlUI);

    // Set CSS for the control interior.
    this.controlText = document.createElement('div');
    // this.controlText.style.color = 'rgb(25,25,25)';
    this.controlText.style.fontFamily = 'Roboto,Arial,sans-serif';
    // this.controlText.style.fontSize = '13px';
    // this.controlText.style.lineHeight = '15px';
    // this.controlText.style.paddingLeft = '3px';
    // this.controlText.style.marginLeft = '14px';
    this.controlText.style.padding = '2px';

    controlUI.appendChild(this.controlText);
    var content = []
    content.push('<span (click) ="test()" class="google-map-info"><img src="../assets/img/plant.png"/> Plant </span><br>');
    content.push('<span (click) ="test()" class="google-map-info"><img src="../assets/img/khatta.png"/> Khatta </span><br>');
   
    content.push('<span (click) ="test()" class="google-map-info"><img src="../assets/img/dustbin.png"/> Dustbin </span><br>');
    content.push('<span (click) ="test()" class="google-map-info"><img src="../assets/img/ts.png"/> FCTS / PCTS </span><br>');
    content.push('<span (click) ="test()" class="google-map-info"><img src="../assets/img/plant.png"/> Plant </span><br>');
    content.push('<span (click) ="test()" class="google-map-info"><img src="../assets/img/stopMarker.png"/> Stop </span><br>');
    
    content.push('<span (click) ="test()" class="google-map-info"><img src="../assets/img/parking.png"/> Parking </span><br>');

    content.push('<span (click) ="test()" class="google-map-info"><img src="../assets/img/hookLoader.png"/> Hook Loader </span><br>');
    content.push('<span (click) ="test()" class="google-map-info"><img src="../assets/img/refuseCompactor.png"/> RC </span><br>');
    content.push('<span (click) ="test()" class="google-map-info"><img src="../assets/img/tractor.png"/> Tractor </span><br>');
    content.push('<span (click) ="test()" class="google-map-info"><img src="../assets/img/hyva.png"/> Hyva </span><br>');
    content.push('<span (click) ="test()" class="google-map-info"><img src="../assets/img/jcb.png"/> JCB </span><br>');
   
    this.controlText.innerHTML = content.join('');
  }

  polygonLabel(text, lat, long, strokeWeight, fontSize, entityId, color) {
    var myLatlng = new google.maps.LatLng(Number(lat), Number(long));
    var mapLabel = new MapLabel({
      text: text,
      position: myLatlng,
      map: this.map,
      strokeWeight: strokeWeight,
      fontSize: fontSize,
      align: 'left',
      entityId: entityId,
      fontColor: color

    });
    this.mapLabelArray.push(mapLabel)
    mapLabel.set('position', myLatlng);
  }
  ngOnInit() {
    $("#vehicleDetail").hide();
    $("#drivingSummary").modal("hide")
    this.getDataWhenProjectChange(this.prjID)
    this.getVehicleType()
    this.getWardPolygon()
    var thisRef = this
    $('#loderImgTab').hide()
    $("#infotable1").hide()
    $("#infotable2").hide()
    $("#statusTable").show()
    $("#play").show()
    $("#stop").hide()
    $("#veichiclesInfo-bar").hide()
    $('#progress-bar').hide()
    this.geocoder = new google.maps.Geocoder;
    var myOptions = {
      center: new google.maps.LatLng(28.47769599987369, 77.06160699973178),
      zoom: 13,
      panControl: true,
      mapTypeControl: true,
      mapTypeId: google.maps.MapTypeId.ROADMAP,
      mapTypeControlOptions: {
        style: google.maps.MapTypeControlStyle.DROPDOWN_MENU,
        position: google.maps.ControlPosition.TOP_LEFT
      },
      zoomControlOptions: {
        position: google.maps.ControlPosition.RIGHT_BOTTOM,
        style: google.maps.ZoomControlStyle.SMALL
      },
      fullscreenControlOptions: {
        position: google.maps.ControlPosition.TOP_CENTER,
        style: google.maps.ControlPosition.SMALL
      },
      styles:[
        {
          "elementType": "geometry",
          "stylers": [
            {
              "color": "#f5f5f5"
            }
          ]
        },
        {
          "elementType": "labels.icon",
          "stylers": [
            {
              "visibility": "off"
            }
          ]
        },
        {
          "elementType": "labels.text.fill",
          "stylers": [
            {
              "color": "#616161"
            }
          ]
        },
        {
          "elementType": "labels.text.stroke",
          "stylers": [
            {
              "color": "#f5f5f5"
            }
          ]
        },
        {
          "featureType": "administrative.land_parcel",
          "elementType": "labels.text.fill",
          "stylers": [
            {
              "color": "#bdbdbd"
            }
          ]
        },
        {
          "featureType": "poi",
          "elementType": "geometry",
          "stylers": [
            {
              "color": "#eeeeee"
            }
          ]
        },
        {
          "featureType": "poi",
          "elementType": "labels.text.fill",
          "stylers": [
            {
              "color": "#757575"
            }
          ]
        },
        {
          "featureType": "poi.park",
          "elementType": "geometry",
          "stylers": [
            {
              "color": "#e5e5e5"
            }
          ]
        },
        {
          "featureType": "poi.park",
          "elementType": "labels.text.fill",
          "stylers": [
            {
              "color": "#9e9e9e"
            }
          ]
        },
        {
          "featureType": "road",
          "elementType": "geometry",
          "stylers": [
            {
              "color": "#ffffff"
            }
          ]
        },
        {
          "featureType": "road.arterial",
          "elementType": "labels.text.fill",
          "stylers": [
            {
              "color": "#757575"
            }
          ]
        },
        {
          "featureType": "road.highway",
          "elementType": "geometry",
          "stylers": [
            {
              "color": "#dadada"
            }
          ]
        },
        {
          "featureType": "road.highway",
          "elementType": "labels.text.fill",
          "stylers": [
            {
              "color": "#616161"
            }
          ]
        },
        {
          "featureType": "road.local",
          "elementType": "labels.text.fill",
          "stylers": [
            {
              "color": "#9e9e9e"
            }
          ]
        },
        {
          "featureType": "transit.line",
          "elementType": "geometry",
          "stylers": [
            {
              "color": "#e5e5e5"
            }
          ]
        },
        {
          "featureType": "transit.station",
          "elementType": "geometry",
          "stylers": [
            {
              "color": "#eeeeee"
            }
          ]
        },
        {
          "featureType": "water",
          "elementType": "geometry",
          "stylers": [
            {
              "color": "#c9c9c9"
            }
          ]
        },
        {
          "featureType": "water",
          "elementType": "labels.text.fill",
          "stylers": [
            {
              "color": "#9e9e9e"
            }
          ]
        }
      ]

    };
    this.map = new google.maps.Map(document.getElementById('map'), myOptions);
    // var trafficLayer = new google.maps.TrafficLayer();
    // trafficLayer.setMap(this.map);
    var config = {
      authDomain: "ecogreen-citizen-app.firebaseapp.com",
      apiKey: 'AIzaSyAHMkYkbjRTa9RazdKPJjtOJrdHCZVxxYg',
      databaseURL: 'https://ecogreen-citizen-app-2ad05.firebaseio.com/',
      storageBucket: 'ecogreen-citizen-app.appspot.com',
      projectId: 'ecogreen-citizen-app'
    };




    var infoWindow = new google.maps.InfoWindow;
    this.map.data.addListener('click', showArrays);
    function showArrays(event) {
      if (event.feature.getProperty('TYPE') == "stopMarker") {
        var position = { lat: event.latLng.lat(), lng: event.latLng.lng() }
        var content = "<div class='col-sm-12'>" + "<p class='info-deatil'><strong>Entry Time :</strong>" + "  " + event.feature.getProperty('STARTTIME') +
          "</p><p class='info-deatil'><strong>Exit Time :</strong>" + "  " + event.feature.getProperty('ENDTIME') +
          "</p><p class='info-deatil'><strong>Duration :</strong>" + "  " + event.feature.getProperty('DURATION') + " " +
          "</p><p class='info-deatil'><strong>Ward :</strong>" + "  " + event.feature.getProperty('WARD') + " " +

          "</p><p class='info-deatil'><strong>Engine :</strong>" + "  " + event.feature.getProperty('engineStatus') + "</p></div>"
        infoWindow = new google.maps.InfoWindow({
          content: content,
          position: position,
        });

        google.maps.InfoWindowOptions
        infoWindow.open(this.map);
      } else {
        var position = { lat: event.latLng.lat(), lng: event.latLng.lng() }
        thisRef.http.post(environment.apiUrl + "entity/getEntityByPoint", position).subscribe(data => {
          var result = data.json()[0]
          var content = "<div class='col-sm-12'><p class='info-deatil'><strong>Zone :</strong>" + "  " + result.zoneName + 
            "</p><p class='info-deatil'><strong>Ward :</strong>" + "  " + result.WardName +
            "</p><p class='info-deatil'><strong>Beat :</strong>" + result.beatName

          infoWindow = new google.maps.InfoWindow({
            content: content,
            position: position,
          });
          google.maps.InfoWindowOptions
          infoWindow.open(this.map);
        })

      }


    }
    firebase.initializeApp(config);

















    var listRef = firebase.database().ref('/');
    listRef.on('child_changed', (dataSnapshot) => {
      const msg = dataSnapshot.val();
      var newPosition = dataSnapshot.val();
      var mylatlongs = new google.maps.LatLng(newPosition.LAT, newPosition.LONG);
      if (this.vechicleListIsClicked) {
        if (this.IMEI == newPosition.DEVICEID) {
          if (newPosition.LAT && newPosition.LONG && newPosition.LAT != " " && newPosition.LONG != " " && msg.prjID == Number(this.prjID)) {
            var point = new google.maps.LatLng(newPosition.LAT, newPosition.LONG);

            this.latlongs.push(mylatlongs);
            this.deleteMarker(newPosition.DEVICEID, mylatlongs)
            var marker = new google.maps.Marker({
              position: point,
              icon: this.icon,
              title: newPosition.DEVICEID + "(" + newPosition.HEARTBEATDATE + ")"
            });
            marker.id = newPosition.DEVICEID;
            //this.allMarkers.push(marker);

            if (this.vehicleInfoWindowClicked) {
              this.vehicleInfoWindowClicked.close()
            }
            if (newPosition.SPEED > 0) {
              var status = "Moving"
            } else {
              var status = "Stoped"
            }
            //Wrap the content inside an HTML DIV in order to set height and width of InfoWindow.
            var content = "<div class='col-sm-12'>" + "<p class='info-deatil'><strong>IMEI :</strong>" + "  " + newPosition.DEVICEID +
              "</p><p class='info-deatil'><strong>Vehicle No :</strong>" + "  " + newPosition.RCNO +
              "</p><p class='info-deatil'><strong>Speed :</strong>" + "  " + newPosition.SPEED + " " +
              "</p><p class='info-deatil'><strong>Date Time :</strong>" + "  " + newPosition.HEARTBEATDATE + " " +

              // "</p><p class='info-deatil'><strong>Distance :</strong>" + "  " + (newPosition.distance/1000).toFixed(2) + "</p></div>" +
              "</p><p class='info-deatil'><strong>Area :</strong>" + "  " + newPosition.beatName + "</p></div>" +
              "</p><p class='info-deatil'><strong>Status :</strong>" + "  " + "<label style='font:bold'>" + status + " </label>" + "</p></div>"
            this.vehicleInfoWindowClicked.setContent(content);
            this.vehicleInfoWindowClicked.open(this.map, marker);






          }
        }



      } else {

        for (var i = 0; i < this.allMarkers.length; i++) {
          if (newPosition.DEVICEID == this.allMarkers[i].id) {
            var title = " VEHNO :" + newPosition.RCNO + " , TIME :" + newPosition.HEARTBEATDATE + " ,  SPEED :" + newPosition.SPEED

            this.allMarkers[i].setPosition(mylatlongs);
            this.allMarkers[i].setTitle(title)

            this.allMarkers[i].BEAT = newPosition.beatName
            this.allMarkers[i].SPEED = newPosition.SPEED
            this.allMarkers[i].dateTime = newPosition.HEARTBEATDATE


            if (thisRef.isClickedVehicle == newPosition.DEVICEID) {
              if (this.vehicleInfoWindow) {
                this.vehicleInfoWindow.close()
              }
              if (newPosition.SPEED > 0) {
                var status = "Moving"
              } else {
                var status = "Stoped"
              }
              //Wrap the content inside an HTML DIV in order to set height and width of InfoWindow.
              var content = "<div class='col-sm-12'>" + "<p class='info-deatil'><strong>IMEI :</strong>" + "  " + newPosition.DEVICEID +
                "</p><p class='info-deatil'><strong>Vehicle No :</strong>" + "  " + newPosition.RCNO +
                "</p><p class='info-deatil'><strong>Speed :</strong>" + "  " + newPosition.SPEED + " " +
                "</p><p class='info-deatil'><strong>Date Time :</strong>" + "  " + newPosition.HEARTBEATDATE + " " +

                // "</p><p class='info-deatil'><strong>Distance :</strong>" + "  " + (newPosition.distance/1000).toFixed(2) + "</p></div>" +
                "</p><p class='info-deatil'><strong>Area :</strong>" + "  " + newPosition.beatName + "</p></div>" +
                "</p><p class='info-deatil'><strong>Status :</strong>" + "  " + "<label style='font:bold'>" + status + " </label>" + "</p></div>"
              this.vehicleInfoWindow.setContent(content);
              this.vehicleInfoWindow.open(this.map, this.allMarkers[i]);
            }

          }
        }
        if (newPosition.LAT && newPosition.LONG && newPosition.LAT != " " && newPosition.LONG != " " && msg.prjID == Number(this.prjID)) {
          var point = new google.maps.LatLng(JSON.parse(newPosition.LAT), JSON.parse(newPosition.LONG));
          var mylatlongs = new google.maps.LatLng(JSON.parse(newPosition.LAT), JSON.parse(newPosition.LONG));
          this.latlongs.push(mylatlongs);

        }
      }

    })

    //search box


    $('#divvehicledate').hide()
    Observable.interval(6 * 60 * 1000).subscribe(x => {


    });
    thisRef.CenterControl(thisRef.centerControlDiv, thisRef.map)
    this.map.controls[google.maps.ControlPosition.RIGHT_CENTER].push(this.centerControlDiv);

    var input = document.getElementById('pac-input');




    var autocomplete = new google.maps.places.Autocomplete(input);

    autocomplete.bindTo('bounds', thisRef.map);
    // Set the data fields to return when the user selects a place.
    autocomplete.setFields(
      ['address_components', 'geometry', 'icon', 'name']);

    var infowindow = new google.maps.InfoWindow();
    var infowindowContent = document.getElementById('infowindow-content');
    infowindow.setContent(infowindowContent);
    var marker = new google.maps.Marker({
      map: thisRef.map,
      anchorPoint: new google.maps.Point(0, -29)
    });

    autocomplete.addListener('place_changed', function () {
      infowindow.close();
      marker.setVisible(false);
      var place = autocomplete.getPlace();
      if (!place.geometry) {
        // User entered the name of a Place that was not suggested and
        // pressed the Enter key, or the Place Details request failed.
        window.alert("No details available for input: '" + place.name + "'");
        return;
      }

      // If the place has a geometry, then present it on a map.
      if (place.geometry.viewport) {
        thisRef.map.fitBounds(place.geometry.viewport);
      } else {
        thisRef.map.setCenter(place.geometry.location);
        thisRef.map.setZoom(17);  // Why 17? Because it looks good.
      }
      marker.setPosition(place.geometry.location);
      marker.setVisible(true);

      var address = '';
      if (place.address_components) {
        address = [
          (place.address_components[0] && place.address_components[0].short_name || ''),
          (place.address_components[1] && place.address_components[1].short_name || ''),
          (place.address_components[2] && place.address_components[2].short_name || '')
        ].join(' ');
      }

      infowindowContent.children['place-icon'].src = place.icon;
      infowindowContent.children['place-name'].textContent = place.name;
      infowindowContent.children['place-address'].textContent = address;
      infowindow.open(thisRef.map, marker);
    });
  }

}






