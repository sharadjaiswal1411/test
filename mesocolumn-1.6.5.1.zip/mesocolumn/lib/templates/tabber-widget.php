<?php if ( is_active_sidebar( 'tabbed-sidebar' ) ) : ?>
<div id="tabber-widget"><div class="tabber">
<?php dynamic_sidebar( 'tabbed-sidebar' ); ?>
</div></div>
<?php endif; ?>