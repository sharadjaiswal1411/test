<div class="post-meta the-icons pm-bottom">
<?php if( has_tag() && ( is_single() || is_archive() ) ) { ?>
<span class="post-tags"><i class="fa fa-tags"></i><?php the_tags('', ', '); ?></span>
<?php } ?>
</div>