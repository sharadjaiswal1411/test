var Tool = (function(){

  var source = 'gsearc';

  var rootSel = '#sbtc';
  var addMethod = 'appendTo';

  var observer;
  var suggestionsTimer;
  var suggestionsList = {};


  var init = function(){
    initWindowMessaging();
    setTimeout( function(){
      var node = $('#sbtc')[0];
      if (!node) node = $('#tsf')[0];
      if (!node) {
        console.error("Target not found");
        return;
      }
      initMutationObserver(node);
      processPage();
    }, 500 );
    initURLChangeListener(function(){
      setTimeout( function(){
        processPage();
      }, 500 );
    });
  };


  var initWindowMessaging = function(){
    // console.log('initWindowMessaging');
    window.addEventListener("message", function(event){
      var payload = event.data;
      if (typeof payload !== 'object') return;
      var cmd = payload.cmd;
      var data = payload.data;
      if (!cmd) return;
      if (cmd === 'xt.resize') {
        var height = data.height;
        var source = data.source;
        var selector = '';
        if (source === 'pasf') selector = '#xt-google-people-search';
        else if (source === 'related') selector = '#xt-related-search';
        if (!selector) return;
        if (height <= 0) return;
        $(selector + ' iframe').height(height + 10);
      }
    }, false);
  };


  var getQuery = function(corrected){
    var query = getURLParameter('q', true);
    if (!query) query = getURLParameter('q');
    if (!query) query = '';
    if (corrected) {
      var correctedText = $.trim( $('#taw .med').text() );
      if (correctedText && correctedText.match(/(did you mean|including results for|showing results for)/i)) {
        query = $.trim($($('#taw .med a')[0]).text());
      }
    }
    return query;
  };


  var processPage = function(){
    var query = getQuery();
    if (!query) {
      UIHelper.moveButtons(50);
      return;
    }
    else UIHelper.moveButtons(10);
    query = Common.cleanKeyword(query);
    if (Common.getCredits() > 0) {
      chrome.runtime.sendMessage({
        cmd: 'api.getKeywordData',
        data: {
          keywords: [query],
          src: source
        }
      }, function( json ){
        UIHelper.checkErrors(json, $('#top_nav')[0]);
        processQueryResponse( json );
      });
    }
    setTimeout(function(){
      var settings = Starter.getSettings();
      if (settings.sourceList.gpsear) processRelatedSearch();
      if (settings.sourceList.gpsear) {
        processPeopleAlsoSearch();
      }
    }, 1000);
  };


  var processRelatedSearch = function(){
    var list = $('._e4b a');
    if (!list.length) {
      list = $('#extrares .brs_col a');
    }
    var keywords = {};
    for (var i = 0, len = list.length; i < len; i++) {
      var keyword = Common.cleanKeyword( list[i].textContent );
      keywords[ keyword ] = list[i];
    }
    processKeywords( keywords, {} );
  };


  var processPeopleAlsoSearch = function(){
    var keywords = {};
    var rows = [];
    var $nodes = $( "div.g div .rc div div[id^='eobd'] div" );
    if (!$nodes.length) {
      $nodes = $("div.g div .rc div[jsname=d3PE6e] div[data-ved]");
    }
    $nodes.each(function( index ) {
      var keyword = this.textContent;
      keywords[keyword] = true;
    });
    var listLen = Object.keys(keywords).length;
    if (listLen === 0) return;
    Common.processKeywords({
      keywords: Object.keys(keywords),
      tableNode: null,
      src: source,
      from: 'pasf',
      seed: getQuery('corrected'),
      noCheckCredits: true
    }, function(json){
      if (json.error_code === 'NOCREDITS') {
        for (var keyword in keywords) {
          rows.push({keyword: keyword})
        }
        renderWidgetTable('people-also-search', rows, null);
      }
      else {
        processPeopleAlsoSearchResponse(json, keywords, rows);
      }
    });
  };


  var processPeopleAlsoSearchResponse = function(json, keywords, rows){
    // console.log(json, keywords, rows);
    if (typeof json.data !== 'object') return;
    for (var key in json.data) {
      var item = json.data[key];
      rows.push(item);
    }
    rows.sort(function(a,b){
      var aVol = parseInt(a.vol.replace(/[,.\s]/g, ''));
      var bVol = parseInt(b.vol.replace(/[,.\s]/g, ''));
      return bVol - aVol;
    });
    renderWidgetTable('people-also-search', rows, json);
  };


  var renderWidgetTable = function(type, rows, json){
    // console.log(json);
    var country = (Starter.getSettings().country || '').toUpperCase();
    var apiKey = Starter.getSettings().apiKey || '';
    var metricsList = Starter.getSettings().metricsList;

    var title = 'People Also Search For';
    if (type === 'related-keywords') title = 'Related Keywords'
    var html = [
      '<button class="xt-export-csv">Export to CSV</button>',
      '<h2><img src="' + chrome.extension.getURL('/img/icon64.png') + '" width="32" height="32" style="vertical-align:middle"> ' + title + '</h2>',
      '<table class="' + (json ? '' : 'xt-g-table-no-credits') + '">',
      '<tr>'
    ];
    if (json) {
      html.push(
        '<th><span id="xt-google-add-all" class="xt-star" data-state="off"></span></th>',
        '<th class="xt-widget-table-th-keyword">Keyword</th>',
        metricsList.vol ? '<th>Vol' + (country ? ' (' + country + ')' : '') + '</th>' : '',
        metricsList.cpc ? '<th>CPC</th>' : '',
        metricsList.comp ? '<th>Comp</th>' : '',
      );
    }
    else {
      html.push('<th class="xt-widget-table-th-keyword" >Keyword</th>');
    }
    html.push('</tr>'),
    html = html.join('\n');
    var keywords = [];
    for (var i = 0, len = rows.length; i < len; i++) {
      var row = rows[i];
      var keyword = row.keyword;
      keywords.push(keyword);
      var keywordEnc = escapeHtml(keyword);
      var url = document.location.origin + document.location.pathname + '?q=' + keywordEnc;
      var link = '<a href="' + url + '">' + keywordEnc + '</a>';
      var tr = [
        '<td class="xt-widget-table-td-keyword" data-keyword="' + keywordEnc + '">' + Common.appendKeg(link, {}, row) + '</td>',
      ];
      if (json) {
        tr = [
          '<td>' + Common.appendStar('', row) + '</td>',
          '<td class="xt-widget-table-td-keyword" data-keyword="' + keywordEnc + '">' + Common.appendKeg(link, json, row) + '</td>',
          metricsList.vol  ? '<td>' + row.vol + '</td>' : '',
          metricsList.cpc  ? '<td>' + row.cpc + '</td>' : '',
          metricsList.comp ? '<td>' + row.competition + '</td>' : '',
        ].join('\n');
        var color = Common.highlight(row);
      }
      if (color) {
        tr = '<tr style="background:' + color + '">' + tr + '</tr>';
      }
      else tr = '<tr>' + tr + '</tr>';
      html += tr;
    }
    html += '</table>';
    html += '<div class="xt-google-iframe"><iframe src="https://keywordseverywhere.com/ke/widget.php?apiKey=' + apiKey + '&source=' + (type === 'related-keywords'? 'related' : (type === 'people-also-search'? 'pasf' : '') )+ '" scrolling="no"></div>';

    var selector = 'xt-google-people-search';
    if (type === 'related-keywords') selector = 'xt-related-search';
    var $root = $('#' + selector);
    if (!$root[0]) {
      $root = $('<div>', {id: selector, class: 'xt-widget-table'})
      if ($('#xt-google-people-search')[0]){
        $root.insertBefore($('#xt-google-people-search'));
      }
      else {
        $root.appendTo('#rhs');
      }
    }
    $root.html(html);
    $root.append($('<div/>', {
      "class": 'xt-close'
    }).text('✖').click(function(e){
      $root.remove();
    }));

    $root.find('#xt-google-add-all').click(function(e){
      var $parent = $(this).closest('.xt-widget-table');
      var $icons = $parent.find('.xt-star');
      $icons.addClass('xt-rotate');
      Common.uploadKeywordsList(keywords, function(json){
        $icons.removeClass('xt-rotate');
        if (!json.error) {
          $icons.map(function(i, node){
            node.dataset.state = 'on';
          });
        }
      });
    });

    // $root.find('td[data-keyword]').click(function(e){
    //   var keywordEnc = this.dataset.keyword;
    //   var url = document.location.origin + document.location.pathname + '?q=' + keywordEnc;
    //   chrome.runtime.sendMessage({
    //     cmd: 'new_tab',
    //     data: url
    //   });
    // });

    // $root.find('td[data-keyword]').contextmenu(function(e){
    //   e.preventDefault();
    //   var keywordEnc = this.dataset.keyword;
    //   var url = document.location.origin + document.location.pathname + '?q=' + keywordEnc;
    //   chrome.runtime.sendMessage({
    //     cmd: 'new_inactive_tab',
    //     data: url
    //   });
    // });

    $root.find('.xt-export-csv').click(function(e){
      e.preventDefault();
      var $parent = $(this).closest('.xt-widget-table');
      var table = $parent.find('table')[0];
      var filename = type;
      var query = getQuery();
      if (query) {
        query = Common.cleanKeyword(query);
        query = query.replace(/\s+/g, '-');
        filename += '-' + query;
      }
      exportTable(table, filename);
    });
  };


  var escapeHtml = function(str) {
    var div = document.createElement('div');
    div.appendChild(document.createTextNode(str));
    return div.innerHTML;
  }


  var processKeywords = function( keywords, table ){
    Common.processKeywords({
        keywords: Object.keys( keywords ),
        tableNode: table,
        src: source,
        from: 'related',
        seed: getQuery('corrected'),
        noCheckCredits: true
      },
      function(json){
        processRelatedSearchResponse( json, keywords );
        processRelatedSearchWidgetResponse( json, keywords );
      }
    );
  };


  var processQueryResponse = function( json ){
    var data;
    if (json.data) data = json.data[0];
    var $node = $('#xt-info');
    if (!$node.length) {
      $node = $('<div/>', {
          class: 'xt-google-query'
        })
        .attr('id', 'xt-info');
      var settings = Starter.getSettings();
      var $parent = $(rootSel);
      if (settings.googlePos === 'abvres') {
        rootSel = '#resultStats';
        addMethod = 'prependTo';
        $parent = $(rootSel);
        $(rootSel).addClass('xt-root-abvres');
      }
      else {
        if (!$parent[0]) $parent = $('#tsf .A8SBwf');
        if (document.location.href.indexOf('&tbm=isch') !== -1) {
          $parent = $('#tsf .A8SBwf');
        }
      }
      $node[addMethod]( $parent );
    }
    if (!data) {
      Common.processEmptyData(json, $node);
      return;
    }
    else {
      if(data.vol != '-') {
        Common.addKeywords(data.keyword);
        var html = Common.getResultStrType2(data);
        html = Common.appendStar(html, data);
        html = Common.appendKeg(html, json, data);
        $node.html(html);
        var color = Common.highlight(data);
        if (color) {
          $node.addClass('xt-highlight');
          $node.css({background: color});
        }
      }
      else {
        $node.html('');
      }
    }
  };


  var processRelatedSearchWidgetResponse = function( json, keywords ){
    var rows = [];
    if (json.error_code === 'NOCREDITS') {
      for (var keyword in keywords) {
        rows.push({keyword: keyword});
      }
      renderWidgetTable('related-keywords', rows, null);
      return;
    }

    if (typeof json.data !== 'object') return;
    for (var key in json.data) {
      var item = json.data[key];
      rows.push(item);
    }
    if (!rows.length) return;
    rows.sort(function(a,b){
      var aVol = parseInt(a.vol.replace(/[,.\s]/g, ''));
      var bVol = parseInt(b.vol.replace(/[,.\s]/g, ''));
      return bVol - aVol;
    });
    renderWidgetTable('related-keywords', rows, json);
  };


  var processRelatedSearchResponse = function( json, keywords ){
    var data = json.data;
    for (var key in data) {
      var item = data[key];
      var node = keywords[ item.keyword ];
      var $node = $(node);
      var $span = $('<span/>').addClass('xt-related-search');
      if (item.vol != '-') {
        var html = Common.getResultStr(item);
        var color = Common.highlight(item);
        if (color) {
          $span.addClass('xt-highlight');
          $span.css({background: color});
        }
        html = Common.appendStar(html, item);
        html = Common.appendKeg(html, json, item);
        $span.html(html);
      }
      $node
        .after( $span );
    }
  };

  var initURLChangeListener = function( cbProcessPage ){
    var url = document.location.href;
    var timer = setInterval(function(){
      if ( url !== document.location.href ) {
        url = document.location.href;
        cbProcessPage( url );
      }
    }, 1000);
  };


  var initMutationObserver = function( target ){
    var settings = Starter.getSettings();
    if (!settings.showMetricsForSuggestions) return;
    if (observer) observer.disconnect();
    observer = new MutationObserver(function(mutations) {
      mutations.forEach(function(mutation) {
        if (mutation.type === 'childList') {
          if (!mutation.addedNodes.length) return;
          // console.log(mutation);
          processChildList(mutation.addedNodes);
        }
      });
    });

    var config = { subtree: true, childList: true, characterData: true };
    observer.observe(target, config);
  };


  var processChildList = function(children){
    for (var i = 0, len = children.length; i < len; i++) {
      var node = children[i];
      if (typeof node.className === 'string' && node.className.match(/xt-/)) continue;
      var $node = $(node);
      if ($node.attr('role') === 'presentation') {
        processSuggestion(node);
      }
      else if ($node.parent().hasClass('sbl1')){
        processSuggestion($node.closest('[role=presentation]')[0]);
      }
      else {
        var list = $node.find('ul[role=listbox]')[0];
        if (list) {
          $(list).find('li div[role=option]').map(function(i, node){
            processSuggestion(node);
          });
        }
      }
    }
  };


  var processSuggestion = function(node){
    var $node = $(node);
    var option = $node.find('div[role=option]')[0];
    if (!option) return;
    // console.log(node.textContent);
    if (!suggestionsTimer) suggestionsList = {};
    var $option = $(option);
    var keyword = $option.find('.sbqs_c, .sbpqs_a').text();
    if (!$option.find('.sbqs_c')[0]) {
      keyword = $option.find('.sbl1 span').text();
    }
    suggestionsList[keyword] = option;
    if (suggestionsTimer) clearTimeout(suggestionsTimer);
    suggestionsTimer = setTimeout(function(){
      processSuggestionsList();
    }, 100);
  };


  var processSuggestionsList = function(){
    //console.log(suggestionsList);
    var list = $.extend({}, suggestionsList);
    suggestionsTimer = null;
    Common.processKeywords({
        keywords: Object.keys( list ),
        tableNode: {},
        src: source
      },
      function(json){
        // console.log(json, list);
        processSuggestionsListResponse( json, list );
      }
    );
  };


  var processSuggestionsListResponse = function(json, keywords){
    var data = json.data;
    for (var key in data) {
      var item = data[key];
      var node = keywords[ item.keyword ];
      var $node = $(node);
      $node.find('.xt-suggestions-search').remove();
      var $span = $('<span/>').addClass('xt-suggestions-search');
      if (item.vol != '-' && item.vol != '0') {
        var html = Common.getResultStr(item);
        var color = Common.highlight(item);
        if (color) {
          $span.addClass('xt-highlight');
          $span.css({background: color});
        }
        // html = Common.appendStar(html, item);
        // html = Common.appendKeg(html, json, item);
        $span.html(html);
      }
      $node.find('.sbqs_c, .sbpqs_a').append( $span );
      if (!$node.find('.sbqs_c')[0]) {
        $node.find('.sbl1 span').append( $span );
      }
    }
  };


  var exportTable = function( table, filename ){
    var $result = $('<table>');
    var $table = $(table);
    var hasStarColumn = true;
    if ($table.hasClass('xt-g-table-no-credits')) hasStarColumn = false;
    $table.find('tr').each(function(i, tr){
      var $tr = $('<tr>').appendTo($result);
      $(tr).find('td,th').each(function(j, td){
        if (j === 0 && hasStarColumn) return; // no star
        $('<td>').text(td.textContent).appendTo($tr);
      });
    });
    Common.exportTableToCSV( $result, filename + '.csv' );
  };


  var getURLParameter = function(sParam, useHash) {
    var qs = window.location.search.substring(1);
    if (useHash) qs = window.location.hash.substring(1);
    qs = qs.split('+').join(' ');
    var params = {},
        tokens,
        re = /[?&]?([^=]+)=([^&]*)/g;
    while (tokens = re.exec(qs)) {
      params[decodeURIComponent(tokens[1])] = decodeURIComponent(tokens[2]);
    }
    return params[sParam];
  };


  var getSource = function(){
    return source;
  };


  return {
    init: init,
    getSource: getSource
  };

})();
