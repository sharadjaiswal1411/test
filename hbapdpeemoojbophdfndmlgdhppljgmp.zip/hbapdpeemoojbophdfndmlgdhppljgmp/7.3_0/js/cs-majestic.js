var Tool = (function(){

  var source = 'majest';

  var tableSelector = '.resultstable';


  var init = function(){
    initPage();
  };


  var initPage = function(){
    var table = $(tableSelector)[0];
    processTable( $(tableSelector)[0]);
  };


  var processTable = function( table ){
    if (!table) return;
    var rows = $(table).find('.anchorText');
    if (!rows.length) return;
    var keywords = {};
    for (var i = 0, len = rows.length; i < len; i++) {
      var td = rows[i];
      var keyword = $(td).find('span').data('original-title');
      keywords[ keyword ] = td;
    }
    processKeywords( keywords, table );
    addColumns( table );
  };


  var processKeywords = function( keywords, table ){
    Common.processKeywords({
        keywords: Object.keys( keywords ),
        tableNode: table,
        src: source
      },
      function(json){
        processJSON( json, keywords );
      }
    );
  };


  var processJSON = function( json, keywords ){
    var data = json.data;
    var metricsList = Starter.getSettings().metricsList;

    for (var key in data) {
      var item = data[key];
      var td = keywords[ item.keyword ];
      var $td = $(td);
      Common.appendStar($td, item);
      Common.appendKeg($td, json, item);
      var color = Common.highlight(item);
      var $target = $td.next().next();
      if (metricsList.vol) {
        $target.text(item.vol).toggleClass('xt-highlight', color).css('background', color);
        $target = $target.next();
      }
      if (metricsList.cpc) {
        $target.text(item.cpc).toggleClass('xt-highlight', color).css('background', color);
        $target = $target.next();
      }
      if (metricsList.comp) {
        $target.text(item.competition).toggleClass('xt-highlight', color).css('background', color);
      }
    }
  };


  var addColumns = function( table ){
    if ($('.xt-col')[0]) return;
    var country = Common.getCountry();
    if (country) country = ' (' + country + ')';
    var $table = $(table);
    var metricsList = Starter.getSettings().metricsList;
    var metricsNumber = Common.getMetricsNumber();

    var $target = $table.find('tbody tr:first-child th:nth-child(3)');
    if(metricsList.comp){
      $target.after('<th class="xt-col" rowspan="2">Competition' + country + '</td>');
    }
    if(metricsList.cpc){
      $target.after('<th class="xt-col" rowspan="2">CPC' + country + '</td>');
    }
    if(metricsList.vol){
      $target.after('<th class="xt-col" rowspan="2">Monthly Volume' + country + '</td>');
    }
    for (var i = 0; i < metricsNumber; i++) {
      $table.find('tbody td:nth-child(3)')
        .after('<td class="xt-col" align="right" valign="top"></td>');
    }
  };


  var getSource = function(){
    return source;
  };


  return {
    init: init,
    getSource: getSource
  };


})();
