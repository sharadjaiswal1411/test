var Tool = (function(){

  var source = 'gtrend';

  var urlRE = new RegExp(/(trends\/explore|trends\/story)/i);
  var observerTarget = 'body';
  var observer = null;


  var init = function(){
    initPage();
  };


  var initPage = function(){
    // wait for table initialization
    checkTarget();
    var timer = setInterval(function(){
      var found = checkTarget();
      if (found) clearInterval(timer);
    }, 500);
  };


  var checkTarget = function(){
    var $target = $( observerTarget );
    if (!$target.length) return;
    initMutationObserver( $target[0] );
    return true;
  };


  var initMutationObserver = function( target ){
    if (observer) observer.disconnect();
    observer = new MutationObserver(function(mutations) {
      if ( !document.location.href.match(urlRE) ) return;
      mutations.forEach(function(mutation) {
        if (mutation.type === 'childList') {
          processChildList(mutation.addedNodes);
        }
      });
    });

    var config = { subtree: true, childList: true, characterData: true };
    observer.observe(target, config);
  };


  var processChildList = function(children){
    for (var i = 0, len = children.length; i < len; i++) {
      var node = children[i];
      var $node = $(node);
      if (node.id === 'report') {
        processReport( node );
      }
      else if ( $node.hasClass('widget-template') &&
                node.children &&
                $(node.children[0]).hasClass('fe-related-queries') ) {
        processReport( node );
      }
    }
  };


  var processReport = function( node ){
    var keywordsList = [];
    var list = $(node).find('.trends-bar-chart-name, .label-text');
    for (var i = 0, len = list.length; i < len; i++) {
      var keyword = Common.cleanKeyword( list[i].textContent );
      keywordsList.push({
        keyword: keyword,
        node: list[i]
      });
    }
    processKeywords( keywordsList, null );
  };


  var processKeywords = function( keywordsList, table ){
    var keywords = {};
    for (var i = 0, len = keywordsList.length; i < len; i++) {
      keywords[ keywordsList[i].keyword ] = '';
    }
    Common.processKeywords({
        keywords: Object.keys( keywords ),
        tableNode: table,
        src: source
      },
      function(json){
        processJSON( json, keywordsList );
      }
    );
  };


  var processJSON = function( json, keywordsList ){
    var data = json.data;
    var dataByKeyword = {};
    for (var key in data) {
      var item = data[key];
      dataByKeyword[ item.keyword ] = item;
    }
    for (var i = 0, len = keywordsList.length; i < len; i++) {
      var keyword = keywordsList[i].keyword;
      var item = dataByKeyword[ keyword];
      if (item) {
        var title = Common.getResultStr(item);
        if (title) title = '[' + title + ']';
        var $res = $('<span/>').addClass('xt-gtrends-line').text(title);
        var color = Common.highlight(item);
        if (color) {
          $res.addClass('xt-highlight');
          $res.css('background', color);
        }
        // Common.appendStar($res, item);
        Common.appendKeg($res, json, item);
        var $node = $( keywordsList[i].node );
        if (!$node.find('.xt-gtrends-line')[0]) $node.append( $res );
      }
    }
  };


  var getSource = function(){
    return source;
  };


  return {
    init: init,
    getSource: getSource
  };


})();
