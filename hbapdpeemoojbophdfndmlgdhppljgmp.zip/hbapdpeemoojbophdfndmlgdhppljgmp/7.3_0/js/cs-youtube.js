var Tool = (function(){

  var source = 'youtub';

  var rootSel = '#masthead > #container, #yt-masthead-content #masthead-search';
  var observer;
  var suggestionsTimer;
  var suggestionsList = {};


  var init = function(){
    setTimeout( function(){
      processPage();
    }, 500 );
    initSuggestions();
    initURLChangeListener(function(url){
      setTimeout( function(){
        processPage();
      }, 500 );
    });
  };


  var initSuggestions = function(){
    var timer = setInterval(function(){
      if (!observer) {
        if ($('.gssb_c, .sbdd_a')[0]) {
          clearInterval(timer);
          initMutationObserver( $('.gssb_c, .sbdd_a')[0] );
        }
      }
    }, 500);
  };

  var processPage = function(){
    var $input = $('#search-input input#search');
    if (!$input[0]) $input = $('#masthead-search-term');
    if (!$input[0]) return;
    var query = $input.val();
    query = Common.cleanKeyword(query);
    if (!query) return;
    chrome.runtime.sendMessage({
      cmd: 'api.getKeywordData',
      data: {
        keywords: [query],
        src: source
      }
    }, function( json ){
      processQueryResponse( json );
    });
  };


  var processKeywords = function( keywords, table ){
    Common.processKeywords({
        keywords: Object.keys( keywords ),
        tableNode: table,
        src: source
      },
      function(json){
      }
    );
  };


  var processQueryResponse = function( json ){
    var data;
    if (json.data) data = json.data[0];
    var $node = $('#xt-info');
    if (!$node.length) {
      $node = $('<div/>', {
          class: 'xt-youtube-query'
        })
        .attr('id', 'xt-info');
      var settings = Starter.getSettings();
      $node
        .insertAfter( $(rootSel)[0] );
      if ($('#search-form')[0]){
        $node.css({
          'margin-left': $('#search-form').position().left,
          'top': '-8px'
        });
      }

      if (!$('#xt-' + source + '-offset')[0]) {
        $('<div id="xt-' + source + '-offset"></div>').insertAfter($('#masthead-positioner-height-offset'));
      }
    }
    if (!data) {
      Common.processEmptyData(json, $node);
      return;
    }
    else {
      if(data.vol != '-') {
        Common.addKeywords(data.keyword);
        var html = Common.getResultStrType2(data);
        html = Common.appendStar(html, data);
        html = Common.appendKeg(html, json, data);
        $node.html(html);
        var color = Common.highlight(data);
        if (color) {
          $node.addClass('xt-highlight');
          $node.css({background: color});
        }
      }
      else {
        $node.html('');
      }
    }
  };


  var initURLChangeListener = function( cbProcessPage ){
    var url = document.location.href;
    var timer = setInterval(function(){
      if ( url !== document.location.href ) {
        url = document.location.href;
        cbProcessPage( url );
      }
    }, 1000);
  };


  var initMutationObserver = function( target ){
    var settings = Starter.getSettings();
    if (!settings.showMetricsForSuggestions) return;
    if (!target) return;
    if (observer) observer.disconnect();
    observer = new MutationObserver(function(mutations) {
      mutations.forEach(function(mutation) {
        if (mutation.type === 'childList') {
          if (!mutation.addedNodes.length) return;
          // console.log(mutation);
          processChildList(mutation.addedNodes);
        }
      });
    });

    var config = { subtree: true, childList: true, characterData: true };
    observer.observe(target, config);
  };


  var processChildList = function(children){
    for (var i = 0, len = children.length; i < len; i++) {
      var node = children[i];
      var $node = $(node);
      if ($node.hasClass('gsq_a')) {
        processSuggestion(node);
      }
      else if ($node.attr('role') === 'presentation') {
        processSuggestion(node);
      }
      else {
        var list = $node.find('ul[role=listbox]')[0];
        if (list) {
          $(list).find('li div[role=option]').map(function(i, node){
            processSuggestion(node);
          });
        }
      }
    }
  };


  var processSuggestion = function(node){
    var $node = $(node);
    var type = 'table';
    var option = $node.find('table tr td')[0];
    if (!option) {
      option = $node.find('div[role=option]')[0];
      type = 'ul';
    }
    if (!option) return;
    // console.log(node.textContent);
    if (!suggestionsTimer) {
      suggestionsList = {};
      $('.xt-suggestions-search').remove();
    }
    if (type === 'table') {
      var keyword = $(option).find('span').get(0).textContent;
    }
    else {
      var keyword = $(option).find('.sbqs_c, .sbpqs_a').text();
    }
    suggestionsList[keyword] = option;
    if (suggestionsTimer) clearTimeout(suggestionsTimer);
    suggestionsTimer = setTimeout(function(){
      processSuggestionsList();
    }, 100);
  };


  var processSuggestionsList = function(){
    // console.log(suggestionsList);
    var list = $.extend({}, suggestionsList);
    suggestionsTimer = null;
    Common.processKeywords({
        keywords: Object.keys( list ),
        tableNode: {},
        src: source
      },
      function(json){
        // console.log(json, list);
        processSuggestionsListResponse( json, list );
      }
    );
  };


  var processSuggestionsListResponse = function(json, keywords){
    var data = json.data;
    for (var key in data) {
      var item = data[key];
      var node = keywords[ item.keyword ];
      var $node = $(node);
      $node.find('.xt-suggestions-search').remove();
      var $span = $('<span/>').addClass('xt-suggestions-search');
      if (item.vol != '-' && item.vol != '0') {
        var html = Common.getResultStr(item);
        var color = Common.highlight(item);
        if (color) {
          $span.addClass('xt-highlight');
          $span.css({background: color});
        }
        // html = Common.appendStar(html, item);
        // html = Common.appendKeg(html, json, item);
        $span.html(html);
      }
      if ($node.find('.sbqs_c, .sbpqs_a')[0]) $node.find('.sbqs_c, .sbpqs_a').append( $span );
      else $node.append( $span );
    }
  };


  var getSource = function(){
    return source;
  };


  return {
    init: init,
    getSource: getSource
  };

})();
