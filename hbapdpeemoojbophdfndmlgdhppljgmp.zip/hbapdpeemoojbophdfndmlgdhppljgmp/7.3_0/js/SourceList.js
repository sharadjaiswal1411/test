var SourceList = {
  'gsearc': 'Google Search',
  'gpsear': 'Google Search Widgets',
  'analyt': 'Google Analytics',
  'gwmtoo': 'Google Search Console',
  'gtrend': 'Google Trends',
  'gkplan': 'Google Keyword Planner',
  'youtub': 'YouTube',
  'bingco': 'Bing Search',
  'amazon': 'Amazon',
  'ebayco': 'Ebay',
  'answtp': 'Answer The Public',
  'soovle': 'Soovle',
  'keyshi': 'Keyword Shitter',
  'majest': 'Majestic',
  'mozcom': 'Moz',
  'etsyco': 'Etsy'
};


if (typeof exports !== 'undefined') {
  exports.get = function(){
    return SourceList;
  };
}
