var Common = (function(){

  var vendor = (navigator.userAgent.match(/(Chrome|Firefox)/) || [])[1]

  var _country = '';
  var _credits = -1;

  var keywordsStorage = {};

  /**
   * [processKeywords description]
   * @param  {object} params          {keywords, src, tableNode}
   * @param  {function} cbProcessResult
   */
  var processKeywords = function( params, cbProcessResult ){
    var keywords = params.keywords;
    if (params.noCheckCredits) {}
    else if (keywords.length > _credits) {
      var resData = [];
      keywords.map(function(keyword, i){
        resData.push({keyword: keyword, vol: '-', cpc: '-', competition: '-'});
      });
      cbProcessResult({error: true, data: resData}, keywords);
      return;
    }
    var useGlobal = !!params.global;
    var queue = splitKeywords(keywords);
    for (var i = 0, len = queue.length; i < len; i++) {
      var requestKeywords = queue[i];
      (function (list) {
        var data = {
          keywords: requestKeywords,
          src: params.src,
          global: useGlobal
        };
        if (params.from) data.from = params.from;
        if (params.seed) data.seed = params.seed;
        chrome.runtime.sendMessage({
          cmd: 'api.getKeywordData',
          data: data
        }, function( json ){
          if (typeof UIHelper !== 'undefined') UIHelper.checkErrors(json, params.tableNode);
          cbProcessResult( json, list );
        });
      })(requestKeywords);
    }
  };


  var splitKeywords = function( keywords ){
    var URL_LEN_LIMIT = 1850;
    // &kw%5B%5D=
    var extraLen = 10;
    var queue = [];
    var request = [];
    var count = 0;
    for (var i = 0, len = keywords.length; i < len; i++) {
      var keyword = keywords[i];
      if (count + extraLen + encodeURIComponent(keyword).length > URL_LEN_LIMIT || request.length >= 20) {
        queue.push(request);
        request = [];
        count = 0;
      }
      request.push(keyword);
      count += encodeURIComponent(keyword).length + extraLen;
    }
    queue.push(request);
    return queue;
  };


  var cleanKeyword = function( keyword ){
    if (!keyword) return '';
    var res = keyword;
    // https://stackoverflow.com/questions/990904/remove-accents-diacritics-in-a-string-in-javascript
    // "dégustation vins paris" should be "degustation vins paris"
    res = res.normalize('NFD').replace(/[\u0300-\u036f]/g, "");
    res = res.replace(/[^-\w.& ]/g, '');
    res = res.replace(/\./g, ' ');
    res = res.replace(/[-_]/g, ' ');
    res = res.replace(/\s+/g, ' ');
    return $.trim(res);
  };


  var getResultStr = function( data, useLong ){
    if (data.vol === '-') return '';
    var settings = Starter.getSettings();
    var res = [];
    if (settings.metricsList.vol) {
      var val = '';
      if (useLong) val = 'Search Volume: ';
      res.push(val + data.vol + '/mo');
    }
    if (settings.metricsList.cpc && data.cpc !== '-') {
      if (useLong) res.push(' CPC: ' + data.cpc);
      else res.push(data.cpc);
    }
    if (settings.metricsList.comp) {
      if (useLong) res.push(' Competition: ' + data.competition);
      else res.push(data.competition);
    }
    return res.join(' - ');
  };


  var getResultStrType2 = function(data){
    if (data.vol === '-') return '';
    var settings = Starter.getSettings();
    var res = [];
    if (settings.metricsList.vol) {
      res.push('Volume: ' + data.vol + '/mo');
    }
    if (settings.metricsList.cpc) {
      res.push('CPC: ' + data.cpc);
    }
    if (settings.metricsList.comp) {
      res.push('Competition: ' + data.competition);
    }
    if (!res.length) return '';
    return res.join(' | ');
  };


  var processEmptyData = function(json, $node){
    if (json.ext_error) {
      var html = json.ext_error;
      if (html === 'Please setup a valid API key') {
        html = '<a href="https://keywordseverywhere.com/first-install-addon.html" target="_blank">Please setup a valid API key</a>';
      }
      $node.html(html);
    }
    else $node.html('No search volume');
  };


  var appendStar = function(html, data, method){
    if (!method) method = 'append';
    var state = data.fav ? 'on' : 'off';
    var $star = $('<span/>', {
      class: 'xt-star',
      "data-state": state,
      "data-keyword": data.keyword
    });
    UIHelper.addBrowserClass($star);
    if (typeof html === 'string') {
      if (html.indexOf('xt-star') !== -1) return;
      if (method === 'prepend') html = $star[0].outerHTML + html;
      else html += $star[0].outerHTML;
    }
    else {
      if (!(html instanceof jQuery)) html = $(html);
      if (html.find('.xt-star')[0]) return;
      html[method]($star);
    }
    addKeywords(data.keyword, data);
    return html;
  };


  var appendKeg = function(html, json, data, method){
    if (json.showSearchIcon !== 1) return html;
    if (!method) method = 'append';
    var $keg = $('<a/>', {
      class: 'xt-keg',
      "data-keyword": data.keyword
    });
    if (json.searchIconLink) {
      var href = json.searchIconLink.replace('#query#', encodeURIComponent(data.keyword));
      $keg.attr('href', href);
    }
    if (json.searchIconImage) {
      $keg.css('background-image', 'url(' + json.searchIconImage + ')');
    }
    UIHelper.addBrowserClass($keg);
    if (typeof html === 'string') {
      if (html.indexOf('xt-keg') !== -1) return;
      if (method === 'prepend') html = $keg[0].outerHTML + html;
      else html += $keg[0].outerHTML;
    }
    else {
      if (!(html instanceof jQuery)) html = $(html);
      if (html.find('.xt-keg')[0]) return;
      html[method]($keg);
    }
    return html;
  };


  var highlight = function(params){
    if (!params) params = {};
    var vol = params.vol;
    var cpc = params.cpc;
    var comp = params.competition;
    if (vol === '-') return false;
    if (vol) vol = parseInt(vol.replace(/[,.\s]/g, ''));
    if (cpc) cpc = parseFloat(cpc.replace(/[^\d,.]/g, '').replace(',', '.'));
    if (comp) comp = parseFloat(comp);
    var settings = Starter.getSettings();
    if (!settings.highlightCPC && !settings.highlightVolume && !settings.highlightComp) return false;
    var resVol = false;
    var resCPC = false;
    var resComp = false;
    if (settings.highlightCPC && cpc >= 0) {
      if (settings.highlightCPCCond === 'eq' && cpc == settings.highlightCPCValue) resCPC = true;
      if (settings.highlightCPCCond === 'lt' && cpc < settings.highlightCPCValue) resCPC = true;
      if (settings.highlightCPCCond === 'gt' && cpc > settings.highlightCPCValue) resCPC = true;
    }
    else resCPC = true;
    if (settings.highlightVolume && vol >= 0) {
      if (settings.highlightVolumeCond === 'eq' && vol == settings.highlightVolumeValue) resVol = true;
      if (settings.highlightVolumeCond === 'lt' && vol < settings.highlightVolumeValue) resVol = true;
      if (settings.highlightVolumeCond === 'gt' && vol > settings.highlightVolumeValue) resVol = true;
    }
    else resVol = true;
    if (settings.highlightComp && comp >= 0) {
      if (settings.highlightCompCond === 'eq' && comp == settings.highlightCompValue) resComp = true;
      if (settings.highlightCompCond === 'lt' && comp < settings.highlightCompValue) resComp = true;
      if (settings.highlightCompCond === 'gt' && comp > settings.highlightCompValue) resComp = true;
    }
    else resComp = true;
    if (resCPC && resVol && resComp) return settings.highlightColor;
    else return false;
  };


  var setCredits = function(val){
    _credits = val;
  };


  var getCredits = function(){
    return _credits;
  };


  var setCountry = function(country){
    _country = country;
  };


  var getCountry = function(){
    return _country;
  };


  var clearKeywordsStorage = function(){
    keywordsStorage = {};
  };


  var addKeywords = function(keywords, data){
    if (typeof keywords === 'object') {
      keywords.map(function(keyword){
        keywordsStorage[keyword] = keywords[keyword];
      });
    }
    else keywordsStorage[keywords] = data;
  };


  var exportKeywords = function(){
    var metricsList = Starter.getSettings().metricsList;
    var $result = $('<table>');
    var $tr = $('<tr>').appendTo($result);
    $tr.append('<th>Keyword</th>');
    if (metricsList.vol) $tr.append('<th>Vol</th>');
    if (metricsList.cpc) $tr.append('<th>CPC</th>');
    if (metricsList.comp) $tr.append('<th>Comp</th>');
    for (var keyword in keywordsStorage) {
      var $tr = $('<tr>').appendTo($result);
      var data = keywordsStorage[keyword];
      $('<td>').text(keyword).appendTo($tr);
      if (metricsList.vol) $('<td>').text(data.vol.replace(/,/g, '')).appendTo($tr);
      if (metricsList.cpc) $('<td>').text(data.cpc).appendTo($tr);
      if (metricsList.comp) $('<td>').text(data.competition).appendTo($tr);
    }
    var filename = document.location.host + '_' + Date.now() + '.csv';
    exportTableToCSV($result, filename);
  };


  var uploadKeywords = function(cbProcessResult){
    var keywords = Object.keys( keywordsStorage );
    if (!keywords.length) {
      cbProcessResult({error: false});
      return;
    }
    chrome.runtime.sendMessage({
      cmd: 'api.addKeywords',
      data: keywords
    }, cbProcessResult);
  };


  var uploadKeywordsList = function(keywords, cbProcessResult){
    chrome.runtime.sendMessage({
      cmd: 'api.addKeywords',
      data: keywords
    }, cbProcessResult);
  };


  var getMetricsNumber = function(){
    var metricsList = Starter.getSettings().metricsList;
    var metricsNumber = 0;
    for (var key in metricsList) {
      if (metricsList[key]) metricsNumber++;
    }
    return metricsNumber;
  };


  var exportTableToCSV = function($table, filename) {
    var $rows = $table.find('tr:has(td,th)');
    var tmpColDelim = String.fromCharCode(11);
    var tmpRowDelim = String.fromCharCode(0);
    var colDelim = '","';
    var rowDelim = '"\n"';
    if (getDecimalSeparator() === ',') colDelim = '";"';
    csv = '"' + $rows.map(function (i, row) {
      var $row = $(row),
      $cols = $row.find('td,th');
      return $cols.map(function (j, col) {
        var $col = $(col),
        text = $.trim( $col.text() );
        return text.replace(/"/g, '""'); // escape double quotes
      }).get().join(tmpColDelim);
    }).get().join(tmpRowDelim)
    .split(tmpRowDelim).join(rowDelim)
    .split(tmpColDelim).join(colDelim) + '"';
    if (vendor === 'Firefox') {
      chrome.runtime.sendMessage({
        cmd: 'file.download',
        data: {
          content: csv,
          name: filename
        }
      });
      return;
    }
    var csvData = 'data:application/csv;charset=utf-8,' + '\ufeff' + encodeURIComponent(csv);
    saveToFile(csvData, filename);
  };


  var getDecimalSeparator = function() {
    var decSep = ".";
    try {
      var sep = parseFloat(3/2).toLocaleString().substring(1,2);
      if (sep === '.' || sep === ',') {
        decSep = sep;
      }
    } catch(e){
      decSep = '.';
    }
    return decSep;
  };


  var saveToFile = function(fileContents, fileName) {
    var link = document.createElement('a');
    link.download = fileName;
    link.href = fileContents;
    link.click();
  };



  return {
    processKeywords: processKeywords,
    cleanKeyword: cleanKeyword,
    highlight: highlight,
    appendStar: appendStar,
    appendKeg: appendKeg,
    getResultStr: getResultStr,
    getResultStrType2: getResultStrType2,
    processEmptyData: processEmptyData,
    setCredits: setCredits,
    getCredits: getCredits,
    setCountry: setCountry,
    getCountry: getCountry,
    clearKeywordsStorage: clearKeywordsStorage,
    addKeywords: addKeywords,
    exportKeywords: exportKeywords,
    exportTableToCSV: exportTableToCSV,
    uploadKeywords: uploadKeywords,
    uploadKeywordsList: uploadKeywordsList,
    getMetricsNumber: getMetricsNumber
  };

})();
