(function(){

  var init = function(){
    chrome.storage.local.get(null, function( data ){
      if (data.settings) {
        var action = data.settings.defaultPopupAction;
        run(action);
        checkMaintenance();
        initUI(data.settings);
      }
    });
  };


  var checkMaintenance = function(){
    chrome.runtime.sendMessage({
      cmd: 'api.isOnline'
    }, function(response){
      if (!response.data) {
        $('.maintenance-msg')
          .removeClass('hidden')
          .text(response.message);
      }
    });
  };


  var initUI = function(settings){
    if (!settings.apiKey) {
      $('#apiKeyWarning').show();
    }
    populateCountries(settings);
    $('#toggle-extension')[0].dataset.state = settings.enabled ? 'on' : 'off';
    $('.toggle-button').click(function(){
      this.dataset.state = this.dataset.state === 'on' ? 'off' : 'on';
    });

    $('#toggle-extension').click(function(){
      chrome.runtime.sendMessage({
        cmd: 'app.setState',
        data: {
          state: this.dataset.state === 'on'
        }
      });
    });
    $('select').change(function(e){
      var id = this.id;
      if (id !== 'country') return;
      else settings[id] = $.trim(this.value);
      chrome.storage.local.set({settings: settings});
      chrome.runtime.sendMessage({cmd: 'settings.update'});
    });

    $('[data-page]').click(function(e){
      e.preventDefault();
      var page = this.dataset.page;
      chrome.tabs.create({
        url: '/html/page.html?page=' + page
      });
    });

    $('.analyze').click(function(e){
      e.preventDefault();
      var href = this.href;
      chrome.tabs.query({currentWindow: true, active: true}, function(tabs){
        var url = tabs[0].url;
        if (!url.match(/^http/)) {
          alert('Unsupported url');
          return;
        }
        var id = btoa(url);
        chrome.runtime.sendMessage({
          cmd: 'urlToAnalyze',
          data: {
            id: id,
            url: url
          }
        });
        chrome.tabs.create({
          url: '/html/page.html?page=analyze&id=' + encodeURIComponent(id)
        });
      });
    });
    injectIframe(settings);
  };


  var injectIframe = function(params){
    if (!params.apiKey) return;
    var src = 'https://keywordseverywhere.com/ke/popup.php?apiKey=' + params.apiKey + '&t=' + Date.now();
    $('<iframe/>').attr('src', src).appendTo($('#iframe-root'));
  };


  var run = function(action){
    if (action === 'popup') return;
    else if (action === 'settings') {
      chrome.tabs.create({url: '/html/options.html'});
    }
    else if (action === 'manual') {
      chrome.tabs.create({url: 'https://keywordseverywhere.com/ke/1/manual.php'});
    }
    else if (action === 'favorite') {
      chrome.tabs.create({url: 'https://keywordseverywhere.com/ke/1/favorites.php'});
    }
  };


  var populateCountries = function(settings){
    chrome.runtime.sendMessage({cmd: 'api.getCountries'}, function(json){
      if (!json || !Object.keys(json).length) {
        return;
      }
      for (var key in json) {
        var $option = $('<option/>')
          .attr('value', key)
          .text(json[key]);
        if (settings.country === key) $option.attr('selected', 'true');
        $option.appendTo($('#country'));
      }
    });
  };


  return {
    init: init
  };

})().init();
