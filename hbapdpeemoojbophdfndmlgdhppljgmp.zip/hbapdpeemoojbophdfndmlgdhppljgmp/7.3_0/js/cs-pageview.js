chrome.runtime.sendMessage({cmd: "trackPageView"}, null);
